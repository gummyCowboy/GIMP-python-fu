#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import (
    CaptionKey as ck,
    ForFormat as ff,
    ForGradient as fg,
    ForTriangle,
    ForWidget as fw,
    FringeKey as fr,
    ImageKey as ik,
    MaskKey as ma,
    OptionKey as ok,
    PlaceKey as pl,
    PlaqueKey as pq,
    PropertyKey as pr,
    WidgetKey as wk
)
from roller_one_preset import Preset
from roller_one_tip import Tip
from roller_widget_button import OptionButton, RollerColorButton
from roller_widget_check_button import RollerCheckButton
from roller_widget_combo import RollerComboBox
from roller_widget_entry import RollerEntry
from roller_widget_slider import RollerSlider
from roller_widget_table import RollerTable
from roller_window_brush import RWBrushChoice
from roller_window_bump_choice import RWBumpChoice
from roller_window_choice import RWChoice
from roller_window_image_choice import RWImageChoice
from roller_window_margin import RWMargin
from roller_window_resize import RWResize
from roller_window_shadow import RWShadow
from roller_window_stripe import RWStripe
import gtk
import sys

FRINGE_TYPE_TOOLTIP = {
    ff.Fringe.GRADIENT: Tip.FRINGE_ABOUT_GRADIENT,
    ff.Fringe.IMAGE: Tip.FRINGE_ABOUT_IMAGE,
    ff.Fringe.MASK: Tip.FRINGE_ABOUT_MASK,
    ff.Fringe.ONE_COLOR: Tip.FRINGE_ABOUT_ONE_COLOR,
    ff.Fringe.PATTERN: Tip.FRINGE_ABOUT_PATTERN,
    ff.Fringe.TWO_COLOR:  Tip.FRINGE_ABOUT_TWO_COLOR
}
LABEL_INDEX, WIDGET_INDEX, ARGS_INDEX, KEY_ARGS_INDEX = range(4)
MASK_TYPE_TOOLTIP = {
    ff.Mask.CHARACTER: Tip.MASK_CHARACTER,
    ff.Mask.CIRCLE: Tip.MASK_CIRCLE,
    ff.Mask.CUT_CORNERS: Tip.MASK_CUT_CORNERS,
    ff.Mask.DIAMOND: Tip.MASK_DIAMOND,
    ff.Mask.IMAGE: Tip.MASK_IMAGE,
    ff.Mask.OVAL: Tip.MASK_OVAL,
    ok.NONE: "",
    ff.Mask.RECTANGLE: Tip.MASK_RECTANGLE,
    ff.Mask.RHOMBUS: Tip.MASK_RHOMBUS,
    ff.Mask.ROUNDED_CORNERS: Tip.MASK_ROUND_CORNERS,
    ff.Mask.SQUARE: Tip.MASK_SQUARE,
    ForTriangle.TRIANGLE_DOWN: Tip.MASK_TRIANGLE_DOWN,
    ForTriangle.TRIANGLE_LEFT: Tip.MASK_TRIANGLE_LEFT,
    ForTriangle.TRIANGLE_RIGHT: Tip.MASK_TRIANGLE_RIGHT,
    ForTriangle.TRIANGLE_UP: Tip.MASK_TRIANGLE_UP
}
PAD = fw.MARGIN
SAME_SIZE_PROPERTY = pr.BLUR_BEHIND, pr.OPACITY, pr.ROTATE
VERIFY_CAPTION = (
    ck.CELL_CAPTION,
    ck.FREE_CELL_CAPTION,
    ck.LAYER_CAPTION,
    ck.OPACITY,
    ck.TEXT,
    ck.TYPE
)
VERIFY_FRINGE = (
    fr.CELL_FRINGE,
    fr.GRADIENT,
    fr.GRADIENT_TYPE,
    fr.IMAGE,
    fr.LAYER_FRINGE,
    fr.TYPE
)
VERIFY_MASK = ma.FEATHER, ma.IMAGE, ma.IMAGE_MASK, ma.TYPE
VERIFY_PLACE = pl.IMAGE_DICT, pl.RESIZE, pl.IMAGE_PLACE
VERIFY_PLAQUE = (
    pq.CELL_PLAQUE,
    pq.FEATHER,
    pq.GRADIENT,
    pq.GRADIENT_TYPE,
    pq.IMAGE,
    pq.LAYER_PLAQUE,
    pq.OPACITY,
    pq.TYPE
)


class FormatWidget:
    """Has common functions used by PortFormat and PortCell."""

    @staticmethod
    def _set_fringe_type_tooltip(g):
        """
        Set the tooltip for a fringe-type widget from the fringe group.

        g: Widget
            Has changed.
        """
        if g.key == fr.TYPE:
            if g.get_value() != ok.NONE:
                g.set_tooltip_text(FRINGE_TYPE_TOOLTIP[g.get_value()])

            else:
                g.set_tooltip_text("")

    @staticmethod
    def _set_mask_type_tooltip(d, g):
        """
        Set the tooltip for a mask-type widget from the image mask group.

        d: dict
            of mask type widget

        g: Widget
            Has changed.
        """
        # If it the mask type widget:
        if g == d[ma.TYPE]:
            n = g.get_value()
            if n in ff.Mask.TYPE:
                tooltip = MASK_TYPE_TOOLTIP[n]
                g.set_tooltip_text(tooltip)

    @staticmethod
    def _set_widget_list(d, k):
        """
        Set the widget list for the preset.

        d: dict
            of widgets

        k: string
            the preset key in d

        Return: dict
            Is 'd' without the preset.
        """
        # The preset is not in the widget dict
        # as the preset is always visible:
        e = {}
        d[k].widget_list = []

        for i in d:
            if i != k:
                e[i] = d[i]
                d[k].widget_list.append(d[i])
        return e

    @staticmethod
    def _set_widget_visibility(d, q):
        """
        Set the visibility of widgets in an option group.

        d: dict
            Has widgets as keys.

        q: list
            of widgets to show
        """
        for i in d:
            g = d[i]

            if g in q:
                g.show()

            else:
                g.hide()

    @staticmethod
    def draw_caption_group(**d):
        """
        Draw the widgets for cell caption.

        d: dict
            Has init values.

        Return: dict
            of widget
            k, v: widget key, widget
        """
        key = d['sub_type']
        is_per_cell = 0 if 'is_per_cell' not in d else 1

        if is_per_cell:
            type_list = ff.Caption.NO_SEQUENCE_LIST
            clip = "Cell"

        elif key == ck.CELL_CAPTION:
            type_list = ff.Caption.CELL_TYPE_LIST
            clip = "Cell"

        elif key == ck.FREE_CELL_CAPTION:
            type_list = ff.Caption.FREE_CELL_TYPE_LIST
            clip = "Cell"

        elif key == ck.LAYER_CAPTION:
            type_list = ff.Caption.LAYER_TYPE_LIST
            clip = "Layer"

        q = (
            [
                "Type:",
                RollerComboBox,
                dict(
                    d,
                    key=ck.TYPE,
                    combo_list=type_list
                )
            ],
            [
                "Justification:",
                RollerComboBox,
                dict(
                    d,
                    key=ck.JUSTIFICATION,
                    combo_list=ff.Caption.JUSTIFICATION_LIST
                )
            ]
        )

        if key in (ck.CELL_CAPTION, ck.FREE_CELL_CAPTION):
            q += (
                [
                    "Leading Text:",
                    RollerEntry,
                    dict(
                        d,
                        key=ck.LEADING_TEXT,
                        chars=10,
                        tooltip=Tip.CAPTION_LEADING_TEXT
                    )
                ],
                [
                    "Trailing Text:",
                    RollerEntry,
                    dict(
                        d,
                        key=ck.TRAILING_TEXT,
                        chars=10,
                        tooltip=Tip.CAPTION_TRAILING_TEXT
                    )
                ],
            )

        if key == ck.CELL_CAPTION:
            q += (
                [
                    "Start Number:",
                    RollerSlider,
                    dict(
                        d,
                        key=ck.START_NUMBER,
                        limit=(-sys.maxint, sys.maxint),
                        precision=0,
                        tooltip=Tip.CAPTION_START_NUMBER,
                    )
                ],
            )

        q += (
            [
                "Text:",
                RollerEntry,
                dict(
                    d,
                    key=ck.TEXT,
                    chars=10
                )
            ],
            [
                "Font Size:",
                RollerSlider,
                dict(d, key=ck.SIZE, limit=(4, 1000), precision=0)
            ],
            [
                "Opacity:",
                RollerSlider,
                dict(d, limit=(0, 100), key=ck.OPACITY)
            ],
            [
                "Limit Spread:",
                RollerCheckButton,
                dict(
                    d,
                    key=ck.CLIP_TO_CELL,
                    text="Clip to {}".format(clip),
                    tooltip=Tip.CAPTION_LIMIT_SPREAD.format(clip.lower())
                )
            ]
        )

        if key == ck.LAYER_CAPTION:
            q += (
                [
                    "Bounds:",
                    RollerCheckButton,
                    dict(
                        d,
                        key=ck.OBEY_MARGINS,
                        text="Obey Margins",
                        tooltip=Tip.FORMAT_BOUNDS
                    )
                ],
            )

        q += (
            [
                "Font:",
                OptionButton,
                dict(d, choice_window=RWChoice, key=ck.FONT)
            ],
            [
                "Color:",
                RollerColorButton,
                dict(d, key=ck.COLOR)
            ],
            [
                "Margins",
                OptionButton,
                dict(
                    d,
                    choice_window=RWMargin,
                    key=ck.MARGIN,
                    tip_type=ff.MARGIN_TIP_TYPE
                ),
            ],
            [
                "Shadow:",
                OptionButton,
                dict(
                    d,
                    choice_window=RWShadow,
                    key=ck.SHADOW,
                    tip_type=ff.SHADOW_TIP_TYPE
                ),
            ],
            [
                "Background Stripe:",
                OptionButton,
                dict(
                    d,
                    choice_window=RWStripe,
                    key=ck.STRIPE,
                    tip_type=ff.STRIPE_TIP_TYPE
                ),
            ]
        )
        container = d[wk.CONTAINER]

        d.pop(wk.CONTAINER)

        q += (
            [
                "{} Preset:".format(key),
                Preset,
                dict(d, key=key)
            ],
        )
        e = RollerTable.create(**dict(d, container=container, q=q))
        d1 = FormatWidget._set_widget_list(e, key)

        # for verify widgets:
        for i in e:
            e[i].preset = e[key]
            if e[i].key in VERIFY_CAPTION:
                e[i].verify = FormatWidget.verify_caption
                e[i].widget_dict = d1
                e[i].is_per_cell = is_per_cell
        return e

    @staticmethod
    def draw_fringe_group(**d):
        """
        Draw the cell fringe group.

        Cell fringe can effect a cell plaque or a cell border.

        d: dict
            Has init values.

        Return: dict
            of widget
            k, v: widget key, widget
        """
        key = d['sub_type']
        clip = "Cell" if key == fr.CELL_FRINGE else "Layer"
        q = (
            [
                "Type:",
                RollerComboBox,
                dict(
                    d,
                    key=fr.TYPE,
                    combo_list=ff.Fringe.TYPE
                )
            ],
            [
                "Gradient Type",
                RollerComboBox,
                dict(
                    d,
                    key=fr.GRADIENT_TYPE,
                    combo_list=fg.GRADIENT_TYPE_LIST
                )
            ],
            [
                "Gradient Angle",
                RollerComboBox,
                dict(
                    d,
                    key=fr.GRADIENT_ANGLE,
                    combo_list=fg.GRADIENT_ANGLE
                )
            ],
            [
                "Contract:",
                RollerSlider,
                dict(
                    d,
                    key=fr.CONTRACT,
                    limit=(0, 10000),
                    precision=0,
                    tooltip=Tip.FRINGE_CONTRACT
                )
            ],
            [
                "Limit Painting:",
                RollerCheckButton,
                dict(
                    d,
                    key=fr.CLIP_TO_CELL,
                    text="Clip to {}".format(clip),
                    tooltip=Tip.FORMAT_CLIP.format(clip.lower())
                )
            ]
        )

        if key == fr.LAYER_FRINGE:
            q += (
                [
                    "Bounds:",
                    RollerCheckButton,
                    dict(
                        d,
                        key=fr.OBEY_MARGINS,
                        text="Obey Margins",
                        tooltip=Tip.FORMAT_BOUNDS
                    )
                ],
            )

        q += (
            [
                "Brush:",
                OptionButton,
                dict(
                    d,
                    choice_window=RWBrushChoice,
                    key=fr.BRUSH,
                    tip_type=ff.BRUSH_TIP_TYPE
                )
            ],
            [
                "Bump",
                OptionButton,
                dict(
                    d,
                    choice_window=RWBumpChoice,
                    key=fr.BUMP,
                    preview=False,
                    tip_type=ff.BUMP_TIP_TYPE
                ),
            ],
            [
                "Shadow:",
                OptionButton,
                dict(
                    d,
                    choice_window=RWShadow,
                    key=fr.SHADOW,
                    tip_type=ff.SHADOW_TIP_TYPE
                )
            ],
            [
                "Color:",
                RollerColorButton,
                dict(d, key=fr.COLOR)
            ],
            [
                "Gradient",
                OptionButton,
                dict(d, choice_window=RWChoice, key=fr.GRADIENT)
            ],
            [
                "Color #1:",
                RollerColorButton,
                dict(d, key=fr.COLOR_1)
            ],
            [
                "Image:",
                OptionButton,
                dict(
                    d,
                    choice_window=RWImageChoice,
                    key=fr.IMAGE,
                    tip_type=ff.IMAGE_TIP_TYPE
                )
            ],
            [
                "Color #2:",
                RollerColorButton,
                dict(d, key=fr.COLOR_2)
            ],
            [
                "Pattern:",
                OptionButton,
                dict(d, choice_window=RWChoice, key=fr.PATTERN)
            ]
        )
        container = d[wk.CONTAINER]

        d.pop(wk.CONTAINER)

        q += (
            [
                "{} Preset:".format(key),
                Preset,
                dict(d, key=key)
            ],
        )
        e = RollerTable.create(**dict(d, container=container, q=q))
        d1 = FormatWidget._set_widget_list(e, key)

        # for verify widgets:
        for i in e:
            e[i].preset = e[key]
            if e[i].key in VERIFY_FRINGE:
                e[i].verify = FormatWidget.verify_fringe
                e[i].widget_dict = d1
        return e

    @staticmethod
    def draw_margin_group(**d):
        """
        Draw a margin button.

        d: dict
            Has init values.

        Return: list
            of widgets
        """
        q = (
            [
                "Margins:",
                OptionButton,
                dict(
                    d,
                    key=d['sub_type'].MARGIN,
                    choice_window=RWMargin,
                    tip_type=ff.MARGIN_TIP_TYPE
                )
            ],
        )
        return RollerTable.create(**dict(d, q=q))

    @staticmethod
    def draw_mask_group(**d):
        """
        Draw the image mask widget group.

        d: dict
            Has init options.

        Return: dict
            of widgets
            k, v: widget key, widget
        """
        q = (
            [
                "Type:",
                RollerComboBox,
                dict(
                    d,
                    combo_list=ff.Mask.TYPE[:],
                    key=ma.TYPE
                )
            ],
            [
                "Character:",
                RollerEntry,
                dict(d, key=ma.CHAR, chars=1)
            ],
            [
                "Horizontal Scale:",
                RollerSlider,
                dict(d, key=ma.HORZ_SCALE, limit=(.001, 1.), precision=3)
            ],
            [
                "Vertical Scale:",
                RollerSlider,
                dict(d, key=ma.VERT_SCALE, limit=(.001, 1.), precision=3)
            ],
            [
                "Feather:",
                RollerSlider,
                dict(
                    d,
                    key=ma.FEATHER,
                    limit=(0, 10000),
                    precision=0,
                    tooltip=Tip.FEATHER
                )
            ],
            [
                "Feather Steps:",
                RollerSlider,
                dict(
                    d,
                    key=ma.STEPS,
                    limit=(1, 18),
                    precision=0,
                    tooltip=Tip.STEPS
                )
            ],
            [
                "Font:",
                OptionButton,
                dict(d, choice_window=RWChoice, key=ma.FONT),
            ],
            [
                "Mask Image:",
                OptionButton,
                dict(
                    d,
                    choice_window=RWImageChoice,
                    key=ma.IMAGE,
                    tip_type=ff.IMAGE_TIP_TYPE
                ),
            ],
        )
        container = d[wk.CONTAINER]

        d.pop(wk.CONTAINER)

        q += (
            [
                "Image Mask Preset:",
                Preset,
                dict(d, key=ma.IMAGE_MASK)
            ],
        )

        e = RollerTable.create(**dict(d, container=container, q=q))
        d1 = FormatWidget._set_widget_list(e, ma.IMAGE_MASK)

        # for verify widgets:
        for i in e:
            e[i].preset = e[ma.IMAGE_MASK]
            if e[i].key in VERIFY_MASK:
                e[i].verify = FormatWidget.verify_mask
                e[i].widget_dict = d1
        return e

    @staticmethod
    def draw_place_group(**d):
        """
        Draw image place widgets.

        d: dict
            Has init values.

        Return: list
            of widget
        """
        q = (
            [
                "Horizontal:",
                RollerComboBox,
                dict(
                    d,
                    key=pl.HORIZONTAL,
                    combo_list=ff.Place.HORIZONTAL_OPTION
                )
            ],
            [
                "Vertical:",
                RollerComboBox,
                dict(
                    d,
                    key=pl.VERTICAL,
                    combo_list=ff.Place.VERTICAL_OPTION_LIST
                )
            ],
            [
                "Image:",
                OptionButton,
                dict(
                    d,
                    choice_window=RWImageChoice,
                    key=pl.IMAGE_DICT,
                    tip_type=ff.IMAGE_TIP_TYPE
                )
            ],
            [
                "Resize:",
                OptionButton,
                dict(d, choice_window=RWResize, key=pl.RESIZE)
            ]
        )
        container = d[wk.CONTAINER]

        d.pop(wk.CONTAINER)

        k = pl.IMAGE_PLACE
        q += (
            [
                "Image Place Preset:",
                Preset,
                dict(d, key=k)
            ],
        )
        e = RollerTable.create(**dict(d, container=container, q=q))
        d1 = FormatWidget._set_widget_list(e, k)

        # for verify widgets:
        for i in e:
            e[i].preset = e[k]
            if e[i].key in VERIFY_PLACE:
                e[i].verify = FormatWidget.verify_place
                e[i].widget_dict = d1
        return e

    @staticmethod
    def draw_plaque_group(**d):
        """
        Draw the plaque widgets.

        d: dict
            Has widget values.

        Return: dict
            of widget
            k, v: widget key, widget
        """
        key = d['sub_type']
        q = (
            [
                "Type:",
                RollerComboBox,
                dict(
                    d,
                    key=pq.TYPE,
                    combo_list=ff.Plaque.TYPE[:]
                )
            ],
            [
                "Gradient Type",
                RollerComboBox,
                dict(
                    d,
                    key=pq.GRADIENT_TYPE,
                    combo_list=fg.GRADIENT_TYPE_LIST
                )
            ],
            [
                "Gradient Angle",
                RollerComboBox,
                dict(
                    d,
                    key=pq.GRADIENT_ANGLE,
                    combo_list=fg.GRADIENT_ANGLE
                )
            ],
            [
                "Opacity:",
                RollerSlider,
                dict(d, key=pq.OPACITY, limit=(0., 100.))
            ],
            [
                "Blur Behind:",
                RollerSlider,
                dict(
                    d,
                    key=pq.BLUR_BEHIND,
                    limit=(0, 500),
                    precision=0
                ),
            ],
            [
                "Feather:",
                RollerSlider,
                dict(
                    d,
                    key=pq.FEATHER,
                    limit=(0, 10000),
                    precision=0,
                    tooltip=Tip.FEATHER
                )
            ],
            [
                "Feather Steps:",
                RollerSlider,
                dict(
                    d,
                    key=pq.STEPS,
                    limit=(1, 18),
                    precision=0,
                    tooltip=Tip.STEPS
                )
            ]
        )

        if key == pq.LAYER_PLAQUE:
            q += (
                [
                    "Bounds:",
                    RollerCheckButton,
                    dict(
                        d,
                        key=pq.OBEY_MARGINS,
                        text="Obey Margins",
                        tooltip=Tip.FORMAT_BOUNDS
                    )
                ],
            )

        q += (
            [
                "Color:",
                RollerColorButton,
                dict(d, key=pq.COLOR)
            ],
            [
                "Plaque Image:",
                OptionButton,
                dict(
                    d,
                    choice_window=RWImageChoice,
                    key=pq.IMAGE,
                    tip_type=ff.IMAGE_TIP_TYPE
                )
            ],
            [
                "Pattern:",
                OptionButton,
                dict(d, choice_window=RWChoice, key=pq.PATTERN)
            ],
            [
                "Gradient",
                OptionButton,
                dict(d, choice_window=RWChoice, key=pq.GRADIENT)
            ],
            [
                "Bump",
                OptionButton,
                dict(
                    d,
                    choice_window=RWBumpChoice,
                    key=pq.BUMP,
                    preview=None,
                    tip_type=ff.BUMP_TIP_TYPE
                ),
            ]
        )
        container = d[wk.CONTAINER]

        d.pop(wk.CONTAINER)

        q += (
            [
                "{} Preset:".format(key),
                Preset,
                dict(d, key=key)
            ],
        )
        e = RollerTable.create(**dict(d, container=container, q=q))
        d1 = FormatWidget._set_widget_list(e, key)

        # for verify widgets:
        for i in e:
            e[i].preset = e[key]
            if e[i].key in VERIFY_PLAQUE:
                e[i].verify = FormatWidget.verify_plaque
                e[i].widget_dict = d1
        return e

    @staticmethod
    def draw_property_group(**d):
        """
        Draw the property group.

        d: dict
            Has init values.

        Return: dict
            of widget
        """
        q = (
            [
                "Rotate:",
                RollerSlider,
                dict(d, key=pr.ROTATE, limit=(-359, 359))
            ],
            [
                "Opacity:",
                RollerSlider,
                dict(d, key=pr.OPACITY, limit=(0., 100.))
            ],
            [
                "Blur Behind:",
                RollerSlider,
                dict(d, key=pr.BLUR_BEHIND, limit=(0, 500), precision=0)
            ],
            [
                "Transform:",
                RollerCheckButton,
                dict(d, key=pr.FLIP_HORIZONTAL, text="Flip Horizontal")
            ],
            [
                "",
                RollerCheckButton,
                dict(d, key=pr.FLIP_VERTICAL, text="Flip Vertical")
            ],

        )
        container = d[wk.CONTAINER]

        d.pop(wk.CONTAINER)

        # preset key:
        k = pr.IMAGE_PROPERTY

        q += (
            [
                "Image Property Preset:",
                Preset,
                dict(d, key=k)
            ],
        )
        e = RollerTable.create(**dict(d, container=container, q=q))
        d1 = FormatWidget._set_widget_list(e, k)
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)

        # for verify widgets:
        for i in e:
            e[i].preset = e[k]
            if e[i].key in (k, pr.OPACITY):
                e[i].verify = FormatWidget.verify_property
                e[i].widget_dict = d1

        for i in SAME_SIZE_PROPERTY:
            same_size.add_widget(e[i].spin_button)
        return e

    @staticmethod
    def verify_caption(g):
        """
        Verify caption widgets.

        g: Widget
            text widget
        """
        d = g.widget_dict
        show_list = [
            d[i] for i in d if d[i].key not in (
                ck.START_NUMBER,
                ck.TEXT,
                ck.LEADING_TEXT,
                ck.TRAILING_TEXT
            )
        ]
        g, g1, g2 = d[ck.TYPE], d[ck.TEXT], d[ck.OPACITY]

        # caption type:
        n = g.get_value()

        obey = d[ck.OBEY_MARGINS] if ck.OBEY_MARGINS in d else None

        if n == ok.NONE:
            show_list = [g]

        elif not g2.get_value():
            show_list = [g, g2]

        elif n == ff.Caption.TEXT:
            if not g1.get_value():
                show_list = [g, g1]

            else:
                show_list.append(g1)
                if obey:
                    show_list.append(obey)

        elif n == ff.Caption.SEQUENCE_NUMBER:
            show_list += [d[ck.START_NUMBER]]

        if n in (ff.Caption.SEQUENCE_NUMBER, ff.Caption.IMAGE_NAME):
            show_list += [d[ck.LEADING_TEXT], d[ck.TRAILING_TEXT]]

        FormatWidget._set_widget_visibility(d, show_list)
        g.win.resize()

    @staticmethod
    def verify_fringe(g):
        """
        Verify fringe widgets.

        g: Widget
            fringe group widget
        """
        d = g.widget_dict
        n = d[fr.TYPE].get_value()

        if n == ok.NONE:
            show_list = d[fr.TYPE],

        else:
            show_list = d[fr.TYPE], d[fr.BRUSH], d[fr.CONTRACT]

            if fr.OBEY_MARGINS in d:
                show_list += d[fr.OBEY_MARGINS],

            if n != ff.Fringe.MASK:
                show_list += d[fr.CLIP_TO_CELL], d[fr.SHADOW], d[fr.BUMP]

                if n == ff.Fringe.GRADIENT:
                    show_list += d[fr.GRADIENT], d[fr.GRADIENT_TYPE]

                    # Shape-burst gradients radiate from the center:
                    if d[fr.GRADIENT_TYPE].get_value() not in fg.SHAPE_BURST:
                        show_list += d[fr.GRADIENT_ANGLE],

                elif n == ff.Fringe.IMAGE:
                    if d[fr.IMAGE].get_value() == ok.NONE:
                        show_list = d[fr.TYPE], d[fr.IMAGE]

                    else:
                        show_list += d[fr.IMAGE],

                elif n == ff.Fringe.ONE_COLOR:
                    show_list += d[fr.COLOR],

                elif n == ff.Fringe.TWO_COLOR:
                    show_list += d[fr.COLOR_1], d[fr.COLOR_2]

                elif n == ff.Fringe.PATTERN:
                    show_list += d[fr.PATTERN],

        FormatWidget._set_widget_visibility(d, show_list)
        FormatWidget._set_fringe_type_tooltip(g)
        g.win.resize()

    @staticmethod
    def verify_mask(g):
        """
        Verify mask widgets.

        g: Widget
            mask group widget
        """
        d = g.widget_dict
        n = d[ma.TYPE].get_value()
        show_list = d[ma.TYPE],

        if n != ok.NONE:
            show_list += (
                d[ma.HORZ_SCALE],
                d[ma.VERT_SCALE],
                d[ma.FEATHER]
            )

            if d[ma.FEATHER].get_value():
                show_list += d[ma.STEPS],

            if n == ff.Mask.CHARACTER:
                show_list += d[ma.FONT], d[ma.CHAR]

            elif n == ff.Mask.IMAGE:
                show_list += d[ma.IMAGE],

        FormatWidget._set_widget_visibility(d, show_list)
        FormatWidget._set_mask_type_tooltip(d, g)
        g.win.resize()

    @staticmethod
    def verify_place(g):
        """
        Verify image place widgets.

        g: ComboBox
            of image place
        """
        d = g.widget_dict
        e = d[pl.IMAGE_DICT].get_value()

        if e:
            show_list = d[pl.IMAGE_DICT],
            if d[pl.IMAGE_DICT].get_value()[ik.TYPE] != ff.Image.Type.NONE:
                show_list += d[pl.RESIZE],
                if d[pl.RESIZE].get_value() != ff.Place.FILL_CELL:
                    show_list += d[pl.HORIZONTAL], d[pl.VERTICAL]

            FormatWidget._set_widget_visibility(d, show_list)
            g.win.resize()

    @staticmethod
    def verify_plaque(g):
        """
        Verify plaque widgets.

        g: Widget
            plaque widget
        """
        d = g.widget_dict
        obey = d[pq.OBEY_MARGINS] if pq.OBEY_MARGINS in d else None
        show_list = d[pq.TYPE],
        n = d[pq.TYPE].get_value()

        if n != ok.NONE:
            if not d[pq.OPACITY].get_value():
                show_list = d[pq.OPACITY],

            else:
                show_list += (
                    d[pq.OPACITY],
                    d[pq.BLUR_BEHIND],
                    d[pq.BUMP],
                    d[pq.FEATHER]
                )

                if obey:
                    show_list += obey,

                if d[pq.FEATHER].get_value():
                    show_list += d[pq.STEPS],

                if n == ff.Plaque.COLOR:
                    show_list += d[pq.COLOR],

                elif n == ff.Plaque.IMAGE:
                    show_list += d[pq.IMAGE],

                elif n == ff.Plaque.PATTERN:
                    show_list += d[pq.PATTERN],

                elif n == ff.Plaque.GRADIENT:
                    show_list += d[pq.GRADIENT], d[pq.GRADIENT_TYPE]

                    # Shape-burst gradients radiate from the center:
                    if d[pq.GRADIENT_TYPE].get_value() not in fg.SHAPE_BURST:
                        show_list += d[pq.GRADIENT_ANGLE],

        FormatWidget._set_widget_visibility(d, show_list)
        g.win.resize()

    @staticmethod
    def verify_property(g):
        """
        Verify image property group widgets.

        g: Widget
            property widget
        """
        d = g.widget_dict
        g = d[pr.OPACITY]

        if g.get_value():
            show_list = [d[i] for i in d]

        else:
            show_list = [g]

        FormatWidget._set_widget_visibility(d, show_list)
        g.win.resize()
