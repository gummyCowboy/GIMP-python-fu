#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_format_form import Form
from roller_format_widget import FormatWidget
from roller_one_constant import (
    BranchKey,
    CaptionKey as ck,
    CellKey,
    ForFormat as ff,
    ForTriangle as ft,
    ForWidget as fw,
    FormatKey as fk,
    FreeCellKey as fck,
    FringeKey as fr,
    MaskKey,
    PlaceKey as pl,
    PlaqueKey,
    PortKey,
    PropertyKey as pr,
    SessionKey as sk,
    Signal,
    UIKey
)
from roller_one_preset import Preset
from roller_one_tip import Tip
from roller_port import Port
from roller_widget_branch import Branch
from roller_widget_combo import RollerComboBox
from roller_widget_entry import RollerEntry
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_slider import RollerSlider
from roller_widget_table import RollerTable
import gtk

COLUMN_0, COLUMN_1, COLUMN_2, COLUMN_3 = 0, 1, 2, 3
LIMIT = (-100000, 100000), (-2., 2.)
PAD = 0, 0, fw.MARGIN, fw.MARGIN
POSITION = "X", "Y", "Width", "Height"
PRECISION = 0, 6
RECT_KEY = (
    CellKey.FIXED_POSITION_X,
    CellKey.FIXED_POSITION_Y,
    CellKey.FIXED_WIDTH,
    CellKey.FIXED_HEIGHT,
    CellKey.FRACTION_POSITION_X,
    CellKey.FRACTION_POSITION_Y,
    CellKey.FRACTION_WIDTH,
    CellKey.FRACTION_HEIGHT
)
SHAPE_LIST = (
    ff.Cell.Shape.RECTANGLE,
    ff.Cell.Shape.DIAMOND,
    ff.Cell.Shape.ELLIPSE,
    ff.Cell.Shape.HEXAGON_HORIZONTAL,
    ff.Cell.Shape.HEXAGON_VERTICAL,
    ft.TRIANGLE_DOWN,
    ft.TRIANGLE_LEFT,
    ft.TRIANGLE_RIGHT,
    ft.TRIANGLE_UP
)
TOTAL_ROW = 11
TYPES = (
    "Fixed-Value",
    "Fraction-of-the-Render-Size"
)
RECT_LABEL = "X: {}, Y: {}, W: {}, H: {}"


class PortFreeCell(Port):
    """Create a free-range cell."""
    CATEGORY = "Cell", "Image"
    OPTION_DICT = {}
    SUB_CATEGORY = (
        (
            "Cell",
            "Cell Margins",
            "Cell Plaque",
            "Cell Fringe",
            "Cell Caption"
        ),
        (
            "Image Place",
            "Image Property",
            "Image Mask"
        )
    )
    TITLE = "Free-Range Cell Editor: {}"

    def __init__(self, d):
        """
        Start it up.

        d: dict
            Has init values.
        """
        cell_group = (
            self._draw_cell_group,
            self._draw_cell_margin,
            self._draw_cell_plaque_group,
            self._draw_cell_fringe_group,
            self._draw_cell_caption_group
        )
        image_group = (
            self._draw_place_group,
            self._draw_property_group,
            self._draw_mask_group
        )
        DRAW_OPTION = cell_group, image_group
        e = PortFreeCell.OPTION_DICT
        d[UIKey.PORT_KEY] = PortKey.FREE_CELL
        self._get_format_info = d[UIKey.GET_FORMAT_INFO]
        self._get_session_dict = d[UIKey.GET_SESSION_DICT]
        self._cell_index = d[UIKey.CELL_INDEX]
        self._format_x = d[UIKey.FORMAT_INDEX]

        for x, n in enumerate(PortFreeCell.CATEGORY):
            for x1, n1 in enumerate(PortFreeCell.SUB_CATEGORY[x]):
                if n not in e:
                    e[n] = {}
                e[n][n1] = DRAW_OPTION[x][x1]

        Port.__init__(self, d)
        self._show_port()

    def _draw_cell_caption_group(self, g):
        """
        Draw the cell caption group.

        g: GTK container
            to receive group
        """
        d = FormatWidget.draw_caption_group(
            bottom_pad=fw.MARGIN,
            sub_type=ck.FREE_CELL_CAPTION,
            color=self.color,
            container=g,
            fraction_of="Cell",
            get_size=self.get_size,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self.controls += [d[ck.FREE_CELL_CAPTION]]

        # Update widgets when its sub-navigation list-item is selected:
        g = d[ck.TYPE]

        g.connect_event((self, Signal.VISIBILITY_CHANGE))
        g.dependent = [g.verify]

    def _draw_cell_fringe_group(self, g):
        """
        Draw the cell fringe group.

        g: GTK container
            for group
        """
        d = FormatWidget.draw_fringe_group(
            bottom_pad=fw.MARGIN,
            sub_type=fr.CELL_FRINGE,
            container=g,
            get_image_info=self._get_format_info,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            color=self.color,
            win=self.roller_window
        )
        self.controls += [d[fr.CELL_FRINGE]]

        # Update widgets when its sub-navigation list-item is selected:
        g = d[fr.TYPE]

        g.connect_event((self, Signal.VISIBILITY_CHANGE))
        g.dependent = [g.verify]

    def _draw_cell_group(self, g):
        """
        Draw a cell group.

        g: GTK container
            for widget group
        """
        self._rect_box = g
        position_name = POSITION * 2
        widget = RollerSlider
        q = []
        d = dict(
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )

        for x in range(8):
            if x % 4:
                label = ""

            else:
                label = TYPES[x // 4]

            label1 = position_name[x]
            e = {
                'key': RECT_KEY[x],
                'limit': LIMIT[x // 4],
                'precision': PRECISION[x // 4],
            }

            e.update(d)

            if not x:
                e['tooltip'] = Tip.FREE_CELL_POSITION

            q1 = [(label, label1), widget, e]
            q.append(q1)

        e = {
            'align': (0, 0, .9, 0),
            'text': RECT_LABEL.format(0, 0, 0, 0)
        }

        e.update(d)
        q.append([("", ""), RollerLabel, e])

        e = {'chars': 20, 'key': CellKey.NAME}

        e.update(d)
        q.append([("Cell Property", "Cell Name"), RollerEntry, e])

        e = {'combo_list': SHAPE_LIST, 'key': CellKey.SHAPE}

        e.update(d)
        q.append([("", "Cell Shape"), RollerComboBox, e])

        q.append(
            [
                ("", "Cell Preset"),
                Preset,
                dict(
                    d,
                    key=fck.CELL,
                    on_widget_change=self.on_widget_change,
                    stat=self.stat,
                    win=self.roller_window
                )
            ]
        )

        q = RollerTable.do_wide(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )

        self.rect_widget = q[:8]
        self.rect_label = q[-4]
        preset = q[-1]
        preset.widget_list = q[:8] + q[9:11]
        self.controls += [preset]

    def _draw_cell_margin(self, g):
        """
        Draw the cell margins group.

        g: GTK container
            for widgets in group
        """
        d = FormatWidget.draw_margin_group(
            sub_type=fck.Cell,
            color=self.color,
            container=g,
            fraction_of="Cell",
            get_size=self.get_size,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self.controls += [d[i] for i in d]

    def _draw_cell_plaque_group(self, g):
        """
        Draw the plaque group.

        g: GTK container
            for widget group
        """
        d = FormatWidget.draw_plaque_group(
            bottom_pad=fw.MARGIN,
            sub_type=PlaqueKey.CELL_PLAQUE,
            color=self.color,
            container=g,
            get_image_info=self._get_format_info,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self.controls += [d[PlaqueKey.CELL_PLAQUE]]

        # Update widgets when its sub-navigation list-item is selected:
        g = d[PlaqueKey.TYPE]

        g.connect_event((self, Signal.VISIBILITY_CHANGE))
        g.dependent = [g.verify]

    def _draw_mask_group(self, g):
        """
        Draw the image mask group.

        g: GTK container
            container for the image mask group
        """
        d = FormatWidget.draw_mask_group(
            bottom_pad=fw.MARGIN // 2,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self.controls += [d[MaskKey.IMAGE_MASK]]

        # Update widgets when its sub-navigation list-item is selected:
        g = d[MaskKey.TYPE]

        g.connect_event((self, Signal.VISIBILITY_CHANGE))
        g.dependent = [g.verify]

    def _draw_navigation_group(self, g):
        """
        Draw the category navigation group.

        Display a multiple widget groups, one at a time,
        using a TreeView list.

        g: GTK container
            to receive group of widgets
        """
        d = {
            BranchKey.LABEL: ("Category", "Sub-Category"),
            BranchKey.MAKE_OPTION_GROUP: self.make_option_group,
            BranchKey.OFFSHOOT_ITEM: PortFreeCell.SUB_CATEGORY,
            BranchKey.TRUNK_ITEM: PortFreeCell.CATEGORY,
            UIKey.ON_KEY_PRESS: self.on_key_press,
            UIKey.WINDOW: self,
            UIKey.STAT: self.stat
        }
        self.branch = Branch(d, g)

    def _draw_place_group(self, g):
        """
        Draw the image place group.

        g: GTK container
            to receive group
        """
        d = FormatWidget.draw_place_group(
            bottom_pad=fw.MARGIN // 2,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self.controls += [d[pl.IMAGE_PLACE]]

        # Update widgets when its sub-navigation list-item is selected:
        g = d[pl.RESIZE]

        g.connect_event((self, Signal.VISIBILITY_CHANGE))
        g.dependent = [g.verify]

    def _draw_preset_group(self, g):
        """
        Draw the Preset ComboBox and Buttons.

        g: GTK container
            for widget group
        """
        self.preset = Preset(
            container=g,
            key=fck.FREE_RANGE_CELL,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_preset_change,
            stat=self.stat,
            widget_list=self.controls,
            win=self.roller_window
        )

    def _draw_property_group(self, g):
        """
        Draw the property group.

        Images have properties.

        g: GTK container
            for group widgets
        """
        d = FormatWidget.draw_property_group(
            bottom_pad=fw.MARGIN // 2,
            color=self.color,
            container=g,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )
        self.controls += [d[pr.IMAGE_PROPERTY]]

        # Update widgets when its sub-navigation list-item is selected:
        g = d[pr.OPACITY]

        g.connect_event((self, Signal.VISIBILITY_CHANGE))
        g.dependent = [g.verify]

    def _reshow_port(self):
        """Call when returning to the format port."""
        self.roller_window.switch_box.add(self.pane)
        self._show_port()

    def _show_port(self):
        """Call when opening a free-range cell port."""
        self.pane.show_all()

        x = self.branch.trunk.get_sel_x()

        if x is not None:
            self.branch.offshoot[x].treeview.emit('cursor_changed')

        else:
            self.branch.trunk.select_item(0)
            self.branch.offshoot[0].select_item(0)

        self.branch.trunk.treeview.emit('cursor_changed')
        self.roller_window.win.present()

    def _update_rect_label(self, *_):
        """Update the rectangle label in the cell group."""
        q = []
        s = self.stat.render.size

        for i in self.rect_widget:
            q.append(i.get_value())

        x = int(q[0] + q[4] * s[0])
        y = int(q[1] + q[5] * s[1])
        w = max(int(q[2] + q[6] * s[0]), 1)
        h = max(int(q[3] + q[7] * s[1]), 1)
        self.rect_label.widget.set_text(RECT_LABEL.format(x, y, w, h))
        self.rect_label.show()

    def do_accept(self, *_):
        """
        Accept the PortFreeCell port.

        Return: true
            The key-press is processed.
        """
        d = self.preset.get_value(has_preset=True)

        # Exit:
        self.switch_ports()
        return self.do_accept_callback(d)

    def do_cancel(self, *_):
        """
        Cancel the PortFreeCell port.

        Return: true
            The key-press is processed.
        """
        self.switch_ports()
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for widgets
        """
        q = (
            self._draw_navigation_group,
            self._draw_preset_group,
            self.draw_process_layout_group
        )
        group_name = "", "Free-Range Cell Preset", "Process"

        for x, p in enumerate(q):
            if x in (0, 1):
                g1 = hbox = gtk.HBox()
                g.add(hbox)

            if x in (1, 2):
                box = RollerEventBox(self.color)
                g1 = gtk.VBox()

                box.add(g1)
                hbox.add(box)

            if group_name[x]:
                g1.add(
                    RollerLabel(
                        padding=(2, 5, 4, 0),
                        text=group_name[x] + ":"
                    )
                )

            p(g1)
            self.reduce_color()

        for i in self.branch.offshoot:
            self.return_widgets.append(i.widget)
        self.return_widgets.append(self.branch.trunk.widget)
        self._rect_box.connect('expose-event', self._update_rect_label)

    def get_size(self):
        """
        Calculate the size of the free-range cell.

        Return: tuple
            width, height
            free-range cell size
            of int
        """
        d = self.preset.get_value()
        return Form.get_free_cell_rect(d[fck.CELL], self.stat.render.size)[2:]

    def make_option_group(self, g, nav_list, opt_type, opt_key):
        """
        Draw the free cell groups.
        Hide the groups that aren't selected.

        g: gtk container
            group box

        nav_list: NavigationList
            not in use

        opt_type: string
            a format name

        opt_key: string
            an image-effect key
        """
        g.add(
            RollerLabel(
                padding=(2, 0, 4, fw.MARGIN),
                text=opt_key + " Options:"
            )
        )

        p = PortFreeCell.OPTION_DICT[opt_type][opt_key]
        p(g)

    def on_preset_change(self, _):
        """
        The preset changed. Update widget visibility.
        """
        self._show_port()

    def on_widget_change(self, g):
        """
        Call when a widget changes.

        g: Widget
            the widget that changed
        """
        if not Port.loading:
            if hasattr(g, 'verify'):
                g.verify(g)

            if hasattr(g, 'preset'):
                g.preset.preset_is_undefined()

            if g.key == CellKey.NAME:
                self.roller_window.win.set_title(
                    PortFreeCell.TITLE.format(g.get_value())
                )

            if g.key in RECT_KEY:
                self._update_rect_label()
            self.preset.preset_is_undefined()

    def reopen_port(self, n, d):
        """
        Call when opening the port for the second time.

        n: string
            window title

        d: dict
            Has init values.
        """
        self._cell_index = d[UIKey.CELL_INDEX]
        self._format_x = d[UIKey.FORMAT_INDEX]
        self.roller_window.win.set_title(PortFreeCell.TITLE.format(n))
        self._reshow_port()

    def show_layout(self, *_):
        """
        Show a layout sketch-up.

        Is part of the Port template.
        """
        d = self._get_session_dict()
        d[sk.FORMAT_LIST][self._format_x][fk.Layer.CELL_LIST][
            self._cell_index] = self.preset.get_value()
        self.stat.layout.show(d)
