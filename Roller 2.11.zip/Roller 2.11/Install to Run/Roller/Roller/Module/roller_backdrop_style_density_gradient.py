#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint, seed
from roller_backdrop_style_gradient_fill import GradientFill
from roller_one_constant import (
    BackdropStyleKey as bsk,
    ForGradient as fg,
    OptionKey as ok
)
from roller_one_constant_fu import Fu
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_one_preset import Preset
import gimpfu as fu

pdb = fu.pdb
um = Fu.UnsharpMask


class DensityGradient:
    """Create a rocky texture and overlay a gradient."""

    def __init__(self, one):
        """
        Do the backdrop-style.

        one: One
            Has variables.
        """
        j = one.stat.render.image
        parent = one.z.parent
        d = one.d
        group = Lay.group(j, one.k, parent=parent)

        seed(d[ok.RANDOM_SEED])

        z = Lay.add(j, one.k, parent=group)

        pdb.plug_in_plasma(
            j,
            z,
            d[ok.RANDOM_SEED],
            Fu.Plasma.LOWEST_TURBULENCE
        )

        z = Lay.add(j, one.k, parent=group)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        pdb.plug_in_plasma(
            j,
            z,
            randint(0, 100000),
            Fu.Plasma.MEDIUM_TURBULENCE
        )

        z = z1 = Lay.add(j, one.k, parent=group)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        pdb.plug_in_plasma(
            j,
            z,
            randint(0, 100000),
            Fu.Plasma.HIGHEST_TURBULENCE
        )
        pdb.gimp_edit_copy_visible(j)

        z = Lay.paste(j, z)
        z.mode = fu.LAYER_MODE_GRAIN_EXTRACT

        for i in ((255, 0, 0), (0, 255, 0), (255, 0, 255)):
            pdb.plug_in_colortoalpha(j, z, i)

        pdb.plug_in_unsharp_mask(
            j,
            z1,
            um.RADIUS_3,
            100.,   # um.AMOUNT_100,
            um.THRESHOLD_0
        )

        Lay.clone(j, z1)
        Gegl.blur(z1, 1.5)

        z1.mode = fu.LAYER_MODE_NORMAL
        z = Lay.clone(j, z1)
        z.mode = fu.LAYER_MODE_HSV_SATURATION

        Lay.order(j, z, group)

        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_DIFFERENCE

        pdb.gimp_edit_copy_visible(j)

        z = Lay.paste(j, z)
        z.mode = fu.LAYER_MODE_EXCLUSION

        Gegl.emboss(z, d[ok.LIGHT_ANGLE], 30, 2)

        Lay.clone(j, z)
        e = Preset.get_default(bsk.GRADIENT_FILL)

        e.update(one.d)

        one.z = Lay.merge_group(j, group)
        n = d[ok.GRADIENT_ANGLE]

        if n in fg.CENTER_X:
            e[ok.START_X] = .5
            e[ok.END_X] = .5

        elif n in fg.LEFT_X:
            e[ok.START_X] = .0
            e[ok.END_X] = 1.

        else:
            e[ok.START_X] = 1.
            e[ok.END_X] = .0

        if n in fg.MIDDLE_Y:
            e[ok.START_Y] = .5
            e[ok.END_Y] = .5

        elif n in fg.TOP_Y:
            e[ok.START_Y] = .0
            e[ok.END_Y] = 1.

        else:
            e[ok.START_Y] = 1.
            e[ok.END_Y] = .0

        e[ok.MODE] = d[ok.GRADIENT_MODE]
        one.d = e
        GradientFill(one)
