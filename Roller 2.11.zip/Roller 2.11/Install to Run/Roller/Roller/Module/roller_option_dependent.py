#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import ImageEffect
from roller_one_constant import (
    BackdropStyleKey as bsk,
    ForBackdropStyle as fbs,
    ForGradient,
    OptionKey as ok
)

ek = ImageEffect.Key
BACKDROP_IMAGE_DEPENDENT = ok.BACKDROP_BLUR, ok.FIT_IMAGE, ok.INVERT
MAZES = fbs.FILLED, fbs.COMPOSITION_FRAME, fbs.SCATTERED_MAZES
NO_GAP = fbs.FILLED, fbs.COMPOSITION_FRAME
NOT_INLAY_SHADOW = ok.MAKE_OPAQUE, ok.OFFSET_X, ok.OFFSET_Y,

SUB_INTENSITY = (
    ok.INLAY_BLUR,
    ok.MAKE_OPAQUE,
    ok.OFFSET_X,
    ok.OFFSET_Y,
    ok.SHADOW_BLUR,
    ok.SHADOW_COLOR
)

VECTOR_DEPENDENT = ok.START_X, ok.START_Y, ok.DIAGONAL_ROTATION


class OptionDependent:
    """
    Manage dependent image-effect and backdrop-style option widgets.
    """

    def __init__(self, win, stat):
        """
        Initialize variables.

        win: RollerWindow
            responsible owner

        stat: Stat
            globals
        """
        self.win = win
        self.stat = stat

    @staticmethod
    def _init_backdrop_image(option_group):
        """
        Add connections for widget dependencies.

        option_group: OptionGroup
            Has widget list.
        """
        dependent = []

        d = option_group.widget_dict
        button = d[ok.BACKDROP_IMAGE]

        for i in BACKDROP_IMAGE_DEPENDENT:
            g = d[i]
            dependent.append(g)
        button.attach_dependent(dependent)

    def _init_shadow_intensity(self, option_group):
        """
        Use to set-up widget dependencies.

        option_group: OptionGroup
            Has widget group info.
        """
        d = option_group.widget_dict
        g = d[ok.INTENSITY]
        g.dependent_widget = [d[i] for i in SUB_INTENSITY if i in d]
        g.attach_dependent(
            [self.on_intensity_change],
            signal='value-changed'
        )

    def _init_frame_gradient(self, option_group):
        """
        Add connections for widget dependencies.

        option_group: OptionGroup
            Has widget list.
        """
        dependent_widget = []
        d = option_group.widget_dict
        combobox = d[ok.GRADIENT_TYPE]
        combobox.dependent_widget = dependent_widget

        for k in fbs.POINT_KEY:
            if k in d:
                dependent_widget.append(d[k])
        combobox.attach_dependent([self.on_gradient_type_change])

    def _init_gradient_pipe(self, option_group):
        """
        Use to set-up widget dependencies.

        option_group: OptionGroup
            Has widget group info.
        """
        d = option_group.widget_dict
        d[ok.NOISE_MODE].dependent_widget = (
            d[ok.NOISE_OPACITY],
            d[ok.RANDOM_SEED]
        )
        d[ok.NOISE_OPACITY].dependent_widget = (
            d[ok.RANDOM_SEED],
            d[ok.NOISE_MODE]
        )

        d[ok.NOISE_MODE].attach_dependent([self.on_gradient_pipe_change])
        d[ok.NOISE_OPACITY].attach_dependent(
            [self.on_gradient_noise_change],
            signal='value-changed'
        )

    def _init_image_gradient(self, option_group):
        """
        Use to set-up widget dependencies.

        option_group: OptionGroup
            Has widget group info.
        """
        d = option_group.widget_dict
        d[ok.SAMPLE_VECTOR].dependent_widget = []

        for i in VECTOR_DEPENDENT:
            d[ok.SAMPLE_VECTOR].dependent_widget.append(d[i])
        d[ok.SAMPLE_VECTOR].attach_dependent([self.on_image_gradient_change])

    def _init_jagged_edge(self, option_group):
        """
        Update sub-navigation list for the latest Jagged Edge shadow.

        option_group: OptionGroup
            Has widget list.
        """
        d = option_group.widget_dict
        g = d[ok.SHADOW]
        q = g.dependent_widget = [
            d[ok.MAKE_OPAQUE],
            d[ok.SHADOW_BLUR],
            d[ok.INTENSITY],
            d[ok.SHADOW_COLOR]
        ]

        g.attach_dependent([self.on_shadow_change])

        g = d[ok.INTENSITY]
        g.dependent_widget = [i for i in q if i.key != ok.INTENSITY]
        g.attach_dependent([self.on_intensity_change], signal='value-changed')

    def _init_maze_mirror(self, option_group):
        """
        Use to set-up widget dependencies.

        option_group: OptionGroup
            Has widget group info.
        """
        d = option_group.widget_dict
        gap_type = d[ok.GAP_TYPE]
        maze_type = d[ok.MAZE_TYPE]

        for i in d:
            d[i].dependent_widget = (
                d[ok.STOP_LENGTH],
                d[ok.CELL_GAP],
                d[ok.SCATTER_COUNT],
                gap_type,
                d[ok.MAZE_DIRECTION]
            )
        for i in (maze_type, gap_type):
            i.attach_dependent([self.on_maze_widget_change])

    def _init_noise_opacity(self, option_group):
        """
        Use to set-up widget dependencies.

        option_group: OptionGroup
            Has widget group info.
        """
        d = option_group.widget_dict
        g = d[ok.NOISE_OPACITY]
        g.dependent_widget = [d[ok.RANDOM_SEED]]
        g.attach_dependent(
            [self.on_noise_opacity_change],
            signal='value-changed'
        )

    def _init_rounded_edge(self, option_group):
        """
        Use to set-up widget dependencies.

        option_group: OptionGroup
            Has widget group info.
        """
        d = option_group.widget_dict

        for i in (ok.ROUNDED_EDGE_BLUR, ok.INTENSITY):
            g = d[i]

            if i == ok.ROUNDED_EDGE_BLUR:
                g.dependent_widget = [d[ok.INTENSITY]]

            else:
                g.dependent_widget = [d[ok.ROUNDED_EDGE_BLUR]]
            g.attach_dependent(
                [self.on_rounded_edge_change],
                signal='value-changed'
            )

    def init_widget_state(self, branch, opt_key, option_group):
        """
        Use to set-up widget dependencies.

        branch: Branch
            Has navigation lists.

        opt_key: string
            either effect or style
        """
        self._branch = branch
        d = {
            bsk.BACKDROP_IMAGE: self._init_backdrop_image,
            bsk.BACKDROP_STYLE: self._branch.init_option_list,
            bsk.FLOOR_SAMPLE: self._init_shadow_intensity,
            bsk.GRADIENT_FILL: self._init_frame_gradient,
            bsk.IMAGE_GRADIENT: self._init_image_gradient,
            bsk.SPECIMEN_SPECKLE: self._init_frame_gradient,
            ek.CORNER_TAPE: self._init_shadow_intensity,
            ek.CUTOUT_PLATE: self._init_noise_opacity,
            ek.DROP_SHADOW: self._init_shadow_intensity,
            ek.FILL_LIGHT_SHADOW: self._init_shadow_intensity,
            ek.FRAME_GRADIENT: self._init_frame_gradient,
            ek.GRADIENT_LEVEL: self._init_gradient_pipe,
            ek.GRADIENT_PIPE: self._init_gradient_pipe,
            ek.IMAGE_EFFECT: self._branch.init_option_list,
            ek.IMAGE_EDGE_SHADOW: self._init_shadow_intensity,
            ek.IMAGE_SHADOW: self._init_shadow_intensity,
            ek.INLAY_SHADOW: self._init_shadow_intensity,
            ek.JAGGED_EDGE: self._init_jagged_edge,
            ek.KEY_LIGHT_SHADOW: self._init_shadow_intensity,
            ek.MAZE_MIRROR: self._init_maze_mirror,
            ek.ROUNDED_EDGE: self._init_rounded_edge
        }
        if opt_key in d:
            d[opt_key](option_group)

    def on_gradient_pipe_change(self, g):
        """
        Update sub-gradient pipe noise widget visibility.

        g: RollerComboBox
            Has changed.
            Is noise mode.
        """
        if g.get_value() == ok.NONE:
            for i in g.dependent_widget:
                i.hide()

        else:
            g.dependent_widget[0].show()

            if g.dependent_widget[0]:
                g.dependent_widget[1].show()

            else:
                g.dependent_widget[1].hide()
        self.win.resize()

    def on_gradient_type_change(self, g):
        """
        Update sub-gradient widget visibility.

        g: RollerComboBox
            Has changed.
        """
        if g.get_value() in ForGradient.SHAPE_BURST:
            for i in g.dependent_widget:
                i.hide()

        else:
            for i in g.dependent_widget:
                i.show()
        self.win.resize()

    def on_image_gradient_change(self, g):
        """
        Update image-gradient widget visibility.

        g: RollerComboBox
            Has changed.
        """
        n = g.get_value()
        start_x, start_y, _dir = g.dependent_widget

        if n == fbs.HORIZONTAL:
            start_x.hide()
            start_y.show()
            _dir.hide()

        elif n == fbs.VERTICAL:
            start_x.show()
            start_y.hide()
            _dir.hide()

        else:
            start_x.hide()
            start_y.hide()
            _dir.show()
        self.win.resize()

    def on_maze_widget_change(self, g):
        """
        Update widgets based their dependency to a given widget.

        widget: Widget
            of Maze Mirror
        """
        value = g.get_value()
        k = g.key
        stop_length, cell_gap, scatter_count, gap_type, _dir = \
            g.dependent_widget

        if k == ok.MAZE_TYPE:
            if value in MAZES:
                stop_length.show()
                _dir.show()

            else:
                stop_length.hide()
                _dir.hide()

            if value in (fbs.FILLED, fbs.COMPOSITION_FRAME):
                for i in (cell_gap, scatter_count, gap_type):
                    i.hide()

            else:
                for i in (cell_gap, scatter_count, gap_type):
                    i.show()

        if gap_type.get_value() == fbs.RANDOM or k in NO_GAP:
            cell_gap.hide()

        else:
            cell_gap.show()
        self.win.resize()

    def on_noise_opacity_change(self, g):
        """
        Update widgets based their dependency to a given widget.

        widget: Widget
            of noise opacity
        """
        # random seed:
        if g.get_value():
            g.dependent_widget[0].show()

        else:
            g.dependent_widget[0].hide()
        self.win.resize()

    def on_gradient_noise_change(self, g):
        """
        Update widgets based their dependency to a given widget.

        widget: Widget
            of noise opacity
        """
        # random seed:
        if g.get_value() and g.dependent_widget[1].get_value() != ok.NONE:
            g.dependent_widget[0].show()

        else:
            g.dependent_widget[0].hide()
        self.win.resize()

    def on_intensity_change(self, g):
        """
        Update widgets based their dependency to a given widget.

        widget: Widget
            of shadow intensity
        """
        if g.get_value():
            [i.show() for i in g.dependent_widget]

        else:
            [i.hide() for i in g.dependent_widget]

    def on_rounded_edge_change(self, g):
        """
        Update blur related widgets depending widget values.

        g: Widget
            Has dependent.
        """
        g1 = g.dependent_widget[0]
        f = g.get_value()
        f1 = g1.get_value()

        if f or f1:
            if f:
                if f1:
                    g.show()
                    g1.show()

                else:
                    g.hide()
                    g1.show()

            else:
                g.show()
                g1.hide()

        else:
            if g.key == ok.ROUNDED_EDGE_BLUR:
                g.hide()
                g1.show()

            else:
                g.show()
                g1.hide()

    def on_shadow_change(self, g):
        """
        Update sub-navigation list with the latest
        selection from the Jagged Edge shadow widget.

        g: Widget
            Jagged Edge ComboBox with shadow options
        """
        n = g.get_value()
        q = g.dependent_widget

        if n == ok.NONE:
            # no shadow options:
            [i.hide() for i in q]

        else:
            q1 = [i for i in q if i.key == ok.INTENSITY]
            g = q1[0]

            g.show()
            self.on_intensity_change(g)
            if n == ek.INLAY_SHADOW:
                q1 = [i for i in q if i.key in NOT_INLAY_SHADOW]
                [i.hide() for i in q1]
        self.win.resize()
