#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Plan as fy
from roller_constant_key import (
    Material as ma, Option as ok, Node as ny, SubMaya as sm
)
from roller_fu import get_layer_position
from roller_maya_add import Add
from roller_maya import Maya
from roller_maya_layer import check_matter, check_mix_basic
from roller_maya_light import Light
from roller_view_real import make_group


def check_strip_matter(maya):
    """
    Plan uses this function to change the color
    of the Strip before drawing itself.

    Return: layer or None
        Has Strip.
    """
    def _do(_maya):
        _e = maya.value_d
        _color = _e[ok.COLOR_1]

        # Override.
        _e[ok.COLOR_1] = {
            ny.CELL: fy.CELL_STRIP_COLOR,
            ny.CANVAS: fy.CANVAS_STRIP_COLOR,
            ny.FACE: fy.FACE_STRIP_COLOR,
            ny.FACING: fy.FACE_STRIP_COLOR
        }[maya.any_group.render_key[-2]]

        _z = _do_matter(maya)
        _e[ok.COLOR_1] = _color

        if _z:
            _z.opacity = 66.
        return _z

    _do_matter = maya.do_matter
    maya.do_matter = _do
    return check_matter(maya)


def make_strip_group(maya):
    """
    Make a group layer for the Strip layer.

    maya: Maya
    Return: layer group
    """
    if not maya.group:
        z = maya.super_maya.group
        maya.group = make_group(
            "Strip", z.parent, offset=get_layer_position(z) + 1
        )
    return maya.group


class Strip(Maya):
    """Manage Strip layer output."""
    # Issues become become boolean attribute (e.g. 'is_matter').
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, super_maya, view_x, do_strip, k_path):
        """
        super_maya: Maya
            the greater Maya; a Caption Maya variant

        view_x: int
            0 or 1; Plan or Work index

        do_strip: function
            Call to make Strip material.

        k_path: tuple
            (Option key, ...)
            path to the Strip vote dict in the AnyGroup vote dict
        """
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        q = (make_strip_group, (check_strip_matter, check_matter)[view_x],)
        q1 = 'group', 'matter'
        self.do_matter = do_strip

        if view_x:
            q += (check_mix_basic,)
            q1 += (None,)

        Maya.__init__(self, any_group, view_x, zip(q, q1), k_path)

        if view_x:
            self.sub_maya[sm.ADD] = Add(any_group, self, k_path + (ok.ADD,))
            self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.STRIP)
        self.set_issue()

    def do(self, d, is_change, is_back):
        """
        Manage layer output during a view run.

        d: dict
            Caption Preset
            {Option key: value}

        is_change: bool
            Is True if Caption has changed.

        is_back: bool
            Is True if the background has changed.
        """
        d = self.value_d = d[ok.BRW][ok.STRIP]
        self.go = d[ok.SWITCH]

        if self.go:
            self.is_matter |= is_change

        self.realize()

        if self.go:
            if self.matter:
                if self.view_x:
                    self.sub_maya[sm.ADD].do(
                        d[ok.ADD], self.is_matter, self.is_matter, is_back
                    )
                    self.sub_maya[sm.LIGHT].do(self.is_matter)
            else:
                self.die()
        self.reset_issue()
