#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_key import Option as ok, SubMaya as sm
from roller_fu import move_layer
from roller_maya_below import Below
from roller_maya_build import SubBuild
from roller_maya_bump import Bump
from roller_maya_noise import Noise
from roller_maya_shadow import Shadow


def set_group(maya):
    return maya.super_maya.group


class Add(SubBuild):
    """Manage Add Preset output for Work."""
    issue_q = 'group', 'matter',
    put = (set_group, 'group'),

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            The Maya's 'matter' layer alpha is used as a mask.

        k_path: tuple
            (Option key, ...)
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, None)

        self.sub_maya[sm.BUMP] = Bump(
            any_group, super_maya, k_path + (ok.BRW, ok.BUMP)
        )
        self.sub_maya[sm.NOISE] = Noise(
            any_group, super_maya, k_path + (ok.RW1, ok.NOISE_D)
        )
        self.sub_maya[sm.BELOW] = Below(
            any_group, super_maya, k_path + (ok.RW1, ok.BELOW)
        )
        cast_maya = (self.cast, super_maya) if self.cast else (super_maya,)
        self.sub_maya[sm.SHADOW] = Shadow(
            any_group, super_maya, cast_maya, k_path + (ok.BRW, ok.SHADOW)
        )

    def do(self, d, is_change, is_mask, is_back):
        """
        Manage layer output during a view run.

        d: dict or None
            Bump Preset
            Maybe None if 'go' is False.

        is_change: bool
            Is True if the source layer for
            the Bump material has matter change.

        is_mask: bool
            Is True if the source layer's mask changed.

        is_back: bool
            Is True if the background is changed.
        """
        self.value_d = d
        self.go = d[ok.SWITCH]

        if self.go:
            self.is_matter |= is_change

            # Is True if Add changed the background, 'm'.
            m = is_shadow = self.is_matter or is_mask

        else:
            # Don't delete super Maya's stuff.
            self.group = None
            m = False

        self.realize()

        if self.go:
            j = Run.j
            e = self.sub_maya
            shadow = e[sm.SHADOW]
            d1 = shadow.sub_maya
            d2 = self.super_maya.sub_maya
            m |= e[sm.BUMP].do(d[ok.BRW][ok.BUMP], self.is_matter, is_mask)
            m |= e[sm.NOISE].do(d[ok.RW1][ok.NOISE_D], self.is_matter, is_mask)
            m1 = shadow.do(d[ok.BRW][ok.SHADOW], is_mask, is_shadow)
            m |= e[sm.BELOW].do(
                d[ok.RW1][ok.BELOW], is_back or m1, is_mask
            )
            if m or m1:
                # Arrange layer.
                # This is the layer order in the layer group:
                #    Gradient Light
                #    Inner Shadow
                #    Noise group
                #    Bump
                #    material
                #    Below
                #    Shadow #2
                #    Shadow #1

                # layer position, 'a'
                a = 0

                q = [
                    d2[sm.LIGHT].matter,
                    d1[sm.INNER].matter,
                    e[sm.NOISE].group,
                    e[sm.BUMP].matter,
                    self.super_maya.matter,
                    e[sm.BELOW].matter,
                    d1[sm.SHADOW2].matter,
                    d1[sm.SHADOW1].matter
                ]
                z = self.group
                for i in q:
                    a += move_layer(j, i, z, a)
        self.reset_issue()


class AltAdd(SubBuild):
    """Manage Add Preset output for Work."""
    issue_q = 'matter',
    put = ()

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            This Maya's 'matter' layer alpha masks output.
            Its also the target of Add function.

        k_path: tuple
            (Option key, ...)
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, None)

        self.sub_maya[sm.NOISE] = Noise(
            any_group, super_maya, k_path + (ok.NOISE_D,)
        )
        self.sub_maya[sm.BUMP] = Bump(
            any_group, super_maya, k_path + (ok.BUMP,)
        )
        self.sub_maya[sm.BELOW] = Below(
            any_group, super_maya, k_path + (ok.BELOW,)
        )

    def do(self, d, is_change, is_mask, is_back):
        """
        Manage layer output during a view run.

        d: dict or None
            Bump Preset
            Maybe None if 'go' is False.

        is_change: bool
            Is True if the source layer for
            the Bump material has matter change.

        is_mask: bool
            Is True if the source layer's mask changed.

        is_back: bool
            Is True if the background is changed.

        Return: bool
            Is True if Add changed anything.
        """
        self.value_d = d
        self.group = self.super_maya.group
        self.go = d[ok.SWITCH]
        e = self.sub_maya

        if self.go:
            m = self.is_matter = self.is_matter or is_change

        else:
            # Don't delete super Maya's stuff like 'group' which is shared.
            self.group = None
            m = bool(
                e[sm.BUMP].matter or e[sm.NOISE].group or e[sm.BELOW].matter
            )

        self.realize()

        if self.go:
            j = Run.j
            d1 = self.super_maya.sub_maya
            m |= e[sm.BUMP].do(d[ok.BUMP], self.is_matter, is_mask)
            m |= e[sm.NOISE].do(d[ok.NOISE_D], self.is_matter, is_mask)
            m |= e[sm.BELOW].do(d[ok.BELOW], is_back, is_mask)
            if m:
                # Sort layer order.
                # This is the layer order in the layer group:
                #    Gradient Light
                #    Noise group
                #    Bump
                #    material
                #    Below
                # layer position, 'a'
                a = 0

                b = d1.get(sm.LIGHT)
                q = [
                    b.matter if b else None,
                    e[sm.NOISE].group,
                    e[sm.BUMP].matter,
                    self.super_maya.matter,
                    e[sm.BELOW].matter
                ]
                z = self.group
                for i in q:
                    a += move_layer(j, i, z, a)

        self.reset_issue()
        return m


class AddAbove(SubBuild):
    """Manage Add Preset output for Work."""
    issue_q = 'matter',
    put = ()

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            This Maya's 'matter' layer alpha masks output.
            Its also the target of Add function.

        k_path: tuple
            (Option key, ...)
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, None)

        self.sub_maya[sm.NOISE] = Noise(
            any_group, super_maya, k_path + (ok.NOISE_D,)
        )
        self.sub_maya[sm.BUMP] = Bump(
            any_group, super_maya, k_path + (ok.BUMP,)
        )

    def do(self, d, is_change, is_mask):
        """
        Manage layer output during a view run.

        d: dict or None
            Bump Preset
            Maybe None if 'go' is False.

        is_change: bool
            Is True if the source layer for
            the Bump material has matter change.

        is_mask: bool
            Is True if the source layer's mask changed.

        Return: bool
            Is True if Add changed anything.
        """
        self.value_d = d
        self.group = self.super_maya.group
        self.go = d[ok.SWITCH]
        e = self.sub_maya

        if self.go:
            m = self.is_matter = self.is_matter or is_change

        else:
            # Don't delete super Maya's stuff.
            self.group = None
            m = bool(e[sm.BUMP].matter or e[sm.NOISE].group)

        self.realize()

        if self.go:
            j = Run.j
            d1 = self.super_maya.sub_maya
            m |= e[sm.BUMP].do(d[ok.BUMP], self.is_matter, is_mask)
            m |= e[sm.NOISE].do(d[ok.NOISE_D], self.is_matter, is_mask)
            if m:
                # Sort layer order.
                # This is the layer order in the layer group:
                #    Gradient Light
                #    Noise group
                #    Bump
                #    material

                # layer position, 'a'
                a = 0

                q = [
                    d1[sm.LIGHT].matter,
                    e[sm.NOISE].group,
                    e[sm.BUMP].matter,
                    self.super_maya.matter,
                ]
                z = self.group
                for i in q:
                    a += move_layer(j, i, z, a)

        self.reset_issue()
        return m
