#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from collections import OrderedDict
from roller_a_contain import PlanZ, Run
from roller_constant_for import Issue as vo, Signal as si
from roller_constant_key import Option as ok
from roller_fu import make_layer_group, remove_z, validate_item
from roller_maya import Maya
from roller_model_id import ModelId
from roller_one_ring import Ring
from roller_one_render import Render
from roller_option_group import ManyGroup
from roller_view_real import make_plan_group


def get_model_name_list(maya):
    """Return a list of active Model in their layer order."""
    return maya.model_list.get_active_model_name_q()[::-1]


class Model(ManyGroup):
    """Assign a view processor and connect responsible signal handler."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)


class Chi(Maya):
    """Factor Plan and Work."""
    issue_q = ()
    vote_type = vo.MAIN

    def __init__(self, any_group, view_x, prefix):
        """
        any_group: AnyGroup
            Has the Model options.

        view_x: int
            0 or 1; Plan or Work index

        prefix: string
            Prefix a Model layer group name.
        """
        self.is_matter = True
        self._prefix = prefix
        self.model_list = any_group.widget_d[ok.MODEL_LIST]

        Maya.__init__(self, any_group, view_x, (), ())
        self.set_issue()
        Render.gob.connect(si.CLOSE_VIEW_IMAGE, self.on_close_view_image)
        for i in (
            (si.MODEL_CREATED, self.on_model_created),
            (si.MODEL_MOVE, self.on_active_model_change),
            (si.MODEL_RENAME, self.on_model_rename)
        ):
            Ring.gob.connect(*i)

    def do(self):
        """Manage layer output during a view run."""
        if self.is_matter:
            self.position_model_group()
            self.is_matter = False

    def ensure_model_group(self, d):
        """
        Create Model layer group for the active Model.

        d: dict
            {Model name: Model}
        """
        if Run.j:
            x = self.view_x

            if x:
                group = None

            else:
                if not PlanZ.plan_group:
                    make_plan_group(self)
                group = PlanZ.plan_group
            for n, model in d.items():
                if model:
                    parent = model.group_q[x]
                    if not parent:
                        # Create the Model's layer group.
                        model.group_q[x] = make_layer_group(
                            Run.j, self._prefix + n, parent=group
                        )

    def on_close_view_image(self, *_):
        """The layer groups are gone, and new ones will be needed."""
        self.is_matter = True

    def on_model_created(self, _, model):
        """
        A new Model has change.

        _: Ring
            Sent the Signal.

        model: Model
            newly created
            not used
        """
        self.is_matter = True

    def on_model_rename(self, _, arg):
        """
        Rename Model layer.

        _: Ring
            Sent the Signal.

        arg: tuple
            (old name, new name)
        """
        def _rename(_z, _n, _x):
            """
            Recursively rename sub-Model layer.

            _z: group layer or GIMP image
            _n: string
                name prefix

            _x: int
                offset of layer name to replace
            """
            for _z1 in _z.layers:
                _z1.name = self._prefix + _n + _z1.name[_x:]
                if hasattr(_z1, 'layers'):
                    _rename(_z1, _n, _x)

        old_name, new_name = arg

        # Rename the layer output.
        # The Model's group layer is at a top of a layer tree.
        model = ModelId.get_model(new_name)
        if model:
            # (Plan, Work) index, '0 or 1'
            z = model.group_q[self.view_x]
            if z:
                # old layer name cut-off index, 'x'
                x = len(old_name) + len(self._prefix)
                z.name = self._prefix + new_name + z.name[x:]
                _rename(z, new_name, x)

    def position_model_group(self):
        """
        Ensure the Model layer group order is in
        sync with ModelList's Model order.
        """
        j = Run.j
        if j:
            x = self.view_x
            name_q = get_model_name_list(self)

            # {Model name: Model}, 'd'
            model_d = {n: ModelId.get_model(n) for n in name_q}

            self.ensure_model_group(model_d)

            order_d = self.prep_position(name_q)

            # Make a list of existing layer name
            # sorted by their ordinal position.
            # Layer offset will then be a layer
            # name's index in the sorted list.
            if x:
                group = None
                q = j.layers

            else:
                group = PlanZ.plan_group
                q = group.layers

            # Sort the list of ordinals so a
            # layer position offset can be derived.
            order_q = sorted([order_d[z.name] for z in q if z.name in order_d])

            # Process the active models.
            for offset, ordinal in enumerate(order_q):
                for k, a in order_d.items():
                    if a == ordinal:
                        z = pdb.gimp_image_get_layer_by_name(j, k)

                        pdb.gimp_image_reorder_item(j, z, group, offset)
                        break
            pdb.gimp_displays_flush()

    def prep_position(self, name_q):
        """
        Create an order dict with the structure:
        {folder name: positional ordinal}.
        Fetch a list of layers for the view context.
        Depends on the view's output image, 'Run.j'.

        x: int
            Plan or Work; 0 or 1

        Return: dict
            {layer name: position ordinal}
        """
        d = OrderedDict()
        x = self.view_x
        prefix = self._prefix

        # Make a list of layers to sort, 'q'.
        if x:
            # top layer position, '0'
            d["Plan"] = 0

            # bottom layer position, '999'
            d["Backdrop"] = 999
            q = Run.j.layers

        else:
            # bottom layer position, '999'
            d["Plan Backdrop"] = 999
            q = PlanZ.plan_group.layers

        for x1, n in enumerate(name_q, 1):
            d[prefix + n] = x1

        for x1, z in enumerate(q, 500):
            if d.get(z.name) is None:
                # Clean-up for a dead Model.
                remove_z(z)
        return d


class Plan(Chi):
    """Manage Model group layer for Plan."""

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, "Plan ")

    def on_active_model_change(self, *_):
        """
        Respond to a change of a Model's
        layer group position in the layer dock.
        """
        if PlanZ.plan_group:
            self.position_model_group()


class Work(Chi):
    """Manage Model group layer for Work."""

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Use to acquire the ModelList Widget.
        """
        Chi.__init__(self, any_group, 1, "")

    def get_model_folder_list(self):
        """
        Make a list of active Model layer group.

        Return: list
            [active Model group layer, ...]
        """
        p = ModelId.get_model
        name_q = get_model_name_list(self)
        model_q = [p(n) for n in name_q]
        q = []

        for i in model_q:
            z = i.group_q[1]
            if z and validate_item(z):
                q += [z]
        return q

    def on_active_model_change(self, *_):
        """
        Respond to a change of a Model's
        layer group position in the Layers tree.
        """
        self.position_model_group()
