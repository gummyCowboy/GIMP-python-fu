#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, pdb  # type: ignore
from roller_a_contain import Deco, Run, The
from roller_constant_for import (
    Deco as dc, Issue as vo, Plan as fy, Signal as si
)
from roller_constant_key import Group as gk, Option as ok, Plan as ak
from roller_deco_border import select_border
from roller_def_access import get_default_value
from roller_fu import load_selection, select_shape, verify_layer_group
from roller_maya import Maya
from roller_maya_layer import check_matter
from roller_one_ring import Ring
from roller_one_wip import Wip
from roller_view_hub import (
    add_text_layer, color_selection_default, make_plan_text_layer
)
from roller_view_real import add_wip_layer, make_group
from roller_view_step import get_property_group, get_planner


def draw_position(maya, group, k):
    """
    Draw the cell pocket position at the topleft corner of a cell.

    maya: Maya
    group: layer
        Is the destination for the output layer.

    k: tuple
        zero-based cell index
        (row, column)
    """
    model = maya.model
    x, y = model.get_pocket_rect(k)[:2]
    x1 = x - Wip.x
    y1 = y - Wip.y
    add_text_layer(
        group,
        make_plan_text_layer(
            Run.j,
            "{}, {}".format(*map(int, (x1, y1))),
            maya.font_size
        ),
        x + 3., y
    )


def draw_corner(maya, group, k):
    """
    Draw the cell pocket corners at the bottom-left
    and top-right corners of a cell.

    maya: Maya
    group: layer
        Is the destination for the output layer.

    k: tuple
        zero-based cell index
        (row, column)
    """
    # Modify the pocket position as it's in view image space.
    x, y, w, h = maya.model.get_pocket_rect(k)
    x1 = x - Wip.x
    y1 = y - Wip.y
    x2 = x1 + w
    y2 = y1 + h
    x1, x2, y1, y2 = map(int, (x1, x2, y1, y2))

    # top-right
    z = make_plan_text_layer(Run.j, "{}, {}".format(x2, y1), maya.font_size)

    add_text_layer(group, z, x + w - z.width - 3., y)

    # bottom-left
    z = make_plan_text_layer(Run.j, "{}, {}".format(x1, y2), maya.font_size)
    add_text_layer(group, z, x + 3., y + h - z.height)


def draw_dimension(maya, group, k):
    """
    Draw a cell dimension at the bottom-right corner of a cell.

    maya: Maya
    group: layer
        Is the parent for the output layer.

    k: tuple
        zero-based cell index
        (row, column)
    """
    x, y, w, h = maya.model.get_pocket_rect(k)
    z = make_plan_text_layer(
        Run.j, str(int(w)) + ", " + str(int(h)), maya.font_size
    )
    add_text_layer(group, z, x + w - z.width - 3., y + h - z.height)


def draw_main(maya, n, p):
    """
    Process layer output for the main option settings.

    maya: Maya
    n: string
        layer name

    p: function
        Call to make layer output.

    Return: layer or None
    """
    group = make_group(n, maya.super_maya.group)

    for k in maya.super_maya.main_q:
        p(maya, group, k)
    return verify_layer_group(group)


def draw_main_position(maya):
    """
    Draw cell position at the topleft of main cell.

    maya: Maya
    Return: layer or None
    """
    return draw_main(maya, "Position", draw_position)


def draw_main_corner(maya):
    """
    Draw cell corner coordinate for main cell.

    maya: Maya
    Return: layer or None
    """
    return draw_main(maya, "Corner", draw_corner)


def draw_main_dimension(maya):
    """
    Draw a cell dimension for main cell.

    maya: Maya
    Return: layer or None
    """
    return draw_main(maya, "Dimension", draw_dimension)


def draw_main_ratio(maya):
    """
    Draw a cell ratio at the center of a cell. A ratio
    is a cell center point divided by the render size.

    maya: Maya
    """
    return draw_main(maya, "Ratio", draw_ratio)


def draw_main_shape(maya):
    """
    Draw cell shape for main cell.

    maya: Maya
    """
    group = make_group("Cell Shape", maya.super_maya.group)

    for k in maya.super_maya.main_q:
        draw_shape(maya, k)

    fill_shape(maya, group)
    return verify_layer_group(group)


def draw_ratio(maya, group, k):
    """
    Draw a cell's position ratio in the WIP rectangle context.

    maya: Maya
    group: layer
        Is the destination for the output layer.

    k: tuple
        zero-based cell index; Goo key
        (row, column)
    """
    model = maya.model
    j = Run.j

    # view space pocket rectangle
    x, y, w, h = model.get_pocket_rect(k)

    # WIP relative position
    x1 = x - Wip.x
    y1 = y - Wip.y

    # ratio
    f_x = (w / 2. + x1) / Wip.w
    f_y = (h / 2. + y1) / Wip.h

    # format
    r_x = format(f_x, '.2f')
    r_y = format(f_y, '.2f')

    z = make_plan_text_layer(
        j,
        r_x[int(f_x < 1.):] + ", " + r_y[int(f_y < 1.):],
        maya.font_size
    )
    add_text_layer(
        group, z, x + w / 2. - z.width / 2., y + h / 2. - z.height / 2.
    )


def draw_per(maya, n, p):
    """
    Process layer output for Per settings.

    maya: Maya
    n: string
        layer name

    p: function
        Call to make layer output.

    Return: layer or None
    """
    group = make_group(n, maya.super_maya.group)

    p(maya, group, maya.super_maya.k)
    return verify_layer_group(group)


def draw_per_position(maya):
    """
    Draw the cell position at the topleft for Cell/Per.

    maya: Maya
    Return: layer or None
    """
    return draw_per(maya, "Position", draw_position)


def draw_per_corner(maya):
    """
    Draw corner coordinate for Cell/Per.

    maya: Maya
    Return: layer or None
    """
    return draw_per(maya, "Corner", draw_corner)


def draw_per_dimension(maya):
    """
    Draw cell dimension for Cell/Per.

    maya: Maya
    Return: layer or None
    """
    return draw_per(maya, "Dimension", draw_dimension)


def draw_per_ratio(maya):
    """
    Draw cell ratio for Cell/Per.

    maya: Maya
    Return: layer or None
    """
    return draw_per(maya, "Ratio", draw_ratio)


def draw_per_shape(maya):
    """
    Draw cell shape for Cell/Per.

    maya: Maya
    Return: layer or None
    """
    group = make_group("Cell Shape", maya.super_maya.group)

    draw_shape(maya, maya.super_maya.k)
    fill_shape(maya, group)
    return verify_layer_group(group)


def draw_shape(maya, k):
    """
    Draw a Cell Model's cell shape.

    maya: Maya
    """
    model = maya.model
    j = Run.j
    sel = pdb.gimp_selection_save(j) \
        if not pdb.gimp_selection_is_empty(j) else None
    d = get_default_value(gk.BORDER)
    maya.k = k
    d[ok.BORDER_W] = 2.
    d[ok.TYPE] = dc.COLOR
    Deco.shape = model.get_plaque(k)

    select_shape(j, Deco.shape)
    select_border(d)
    if sel:
        load_selection(j, sel, option=CHANNEL_OP_ADD)
        pdb.gimp_image_remove_channel(j, sel)


def fill_shape(maya, group):
    """
    Fill a selection with a color.

    maya: Maya
        not used

    group: layer
        parent for filled selection layer
    """
    if not pdb.gimp_selection_is_empty(Run.j):
        z = add_wip_layer("Cell", group)
        z.opacity = 66.
        color_selection_default(z, fy.SHAPE_COLOR)


class Detail(Maya):
    """"Manage Plan output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, super_maya, do_matter, key):
        """
        any_group: AnyGroup
            Is responsible for the 'super_maya'.

        super_maya: Maya
            Manage Detail life-cycle and activation.

        do_matter: function
            Make detail output.

        key: string
            PlanOption Widget key
        """
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self.do_matter = do_matter
        font_size_g = get_property_group(
            any_group.nav_k
        ).widget_d[ok.FONT_SIZE]
        self.font_size = font_size_g.get_a()

        Maya.__init__(
            self, any_group, 0, ((check_matter, 'matter'),), vo.NO_VOTE
        )
        self.set_issue()

        # PlanOption, 'planner'
        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(key)

        self.latch(planner, (fy.SIGNAL_D[key], self.on_plan_option_change))
        self.latch(
            font_size_g, (si.FONT_SIZE_CHANGE, self.on_font_size_change)
        )

    def do(self):
        """Manage layer output for a view run."""
        self.go = self.is_planned
        self.is_matter |= self.is_switched or self.super_maya.is_matter

        self.realize()
        self.reset_issue()

    def on_plan_option_change(self, _, arg):
        """
        Receive a Signal when a Plan option
        is activated. Update the 'go' dependency
        with 'self.is_planned'.

        _: PlanOption
            Sent the signal.

        arg: tuple
            (the value of the Margin CheckButton, its change state)
        """
        self.is_planned, self.is_switched = arg

    def on_font_size_change(self, g, q):
        """
        Respond to change in the Font Size Widget value.

        g: Widget
            Font Size

        q: tuple
            (float, bool)
            (font size, Is change.)
        """
        if The.load_count:
            # Resend the signal after loading Preset.
            Ring.add(g, si.FONT_SIZE_CHANGE, q)
        else:
            self.font_size, is_change = q
            self.is_matter |= is_change


class PlanMargin(Maya):
    """Manage Margin dependent layer output for Plan."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, super_maya, do_matter):
        self.is_switched = False
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self.do_matter = do_matter

        Maya.__init__(
            self, any_group, 0, ((check_matter, 'matter'),), vo.NO_VOTE
        )
        self.set_issue()

        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.MARGIN)
        self.latch(
            planner, (fy.SIGNAL_D[ak.MARGIN], self.on_plan_option_change)
        )

    def do(self):
        """Manage layer output for a view run."""
        self.go = self.is_planned and self.super_maya.value_d[ok.SWITCH]
        self.is_matter = self.is_switched or self.super_maya.is_matter

        self.realize()
        self.reset_issue()

    def on_plan_option_change(self, _, arg):
        """
        Receive a Signal when the Planner Margin option is modified.

        _: PlanOption
            Sent the signal.

        arg: tuple
            (the value of the Margin CheckButton, its change state)
        """
        self.is_planned, self.is_switched = arg


class PlanShape(Maya):
    """Manage Cell/Shape layer output for Plan."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, super_maya, do_matter):
        self.is_switched = False
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self.do_matter = do_matter

        Maya.__init__(
            self, any_group, 0, ((check_matter, 'matter'),), vo.NO_VOTE
        )
        self.set_issue()

        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.CELL_SHAPE)
        self.latch(
            planner, (fy.SIGNAL_D[ak.CELL_SHAPE], self.on_plan_option_change)
        )

    def do(self):
        """Manage a Plan Cell shape layer for a view run."""
        self.go = self.is_planned
        self.is_matter = self.is_switched or self.super_maya.is_matter

        self.realize()
        self.reset_issue()

    def on_plan_option_change(self, _, arg):
        """
        Receive a Signal when the Plan option is activated.
        Update the 'go' dependency with 'self.is_planned'.

        _: PlanOption
            Sent the signal.

        arg: tuple
            (the value of the Margin CheckButton, its change state)
        """
        self.is_planned, self.is_switched = arg
