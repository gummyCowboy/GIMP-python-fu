#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Backdrop as bs, Gradient as fg, Issue as vo
from roller_constant_key import Option as ok, Widget as wk
from roller_def_dialog import ARW, GMR, MAR, MOD, P3R, SHADOW
from roller_def_option import (
    ANGLE,
    BLEND,
    BLOCK_H,
    BLOCK_W,
    BLUR,
    CELL_SIZE_ETCH,
    CLIPBOARD,
    COLOR_1,
    COLOR_1A,
    COLOR_2A,
    COLOR_3,
    COLOR_3A,
    COLOR_6A,
    COLOR_COUNT,
    COLOR_GRID_TYPE,
    DIAGONAL,
    FILL_MODE,
    CRITERION,
    GRADIENT_ANGLE,
    GRADIENT_DIRECTION,
    GRADIENT_END_X,
    GRADIENT_END_Y,
    GRADIENT_START_X,
    GRADIENT_START_Y,
    GRADIENT_TYPE,
    ITERATIONS,
    KEEP,
    LAYER_COUNT,
    MATTER_MODE,
    MAZE,
    MODE,
    NAME_DROP,
    NAME_GRADIENT,
    NOISE_AMOUNT,
    OFFSET,
    OPACITY,
    PATTERN,
    PATTERN_SIZE,
    POWER,
    PREVIEW_MODE,
    R_C,
    RANDOM_ORDER,
    REVERSE,
    SEED,
    SHAPE,
    SAMPLE_COUNT,
    SAMPLE_RADIUS,
    SAMPLE_VECTOR,
    SHIFT,
    SHIFT_DIRECTION,
    SKETCH_TEXTURE,
    SLICE_COUNT,
    SPIRAL_DISTANCE,
    SPIRAL_MOD,
    SPREAD,
    START_X,
    START_Y,
    STEPS_DROP,
    SUPERPIXEL_SIZE,
    TEXTURE,
    THRESHOLD,
    TILE_SIZE,
    WAVE_PER_LAYER
)
from roller_widget_row import WidgetRow

# Define Backdrop Style Preset.
ACRYLIC_SKY = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SHIFT, deepcopy(SHIFT)),
    (ok.SUPERPIXEL_SIZE, deepcopy(SUPERPIXEL_SIZE)),
    (ok.SEED, deepcopy(SEED)),
    (ok.SHIFT_DIRECTION, deepcopy(SHIFT_DIRECTION)),
    (ok.BRW, deepcopy(MAR))
])
BACK_GAME = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.COLOR_1_MODE, deepcopy(MATTER_MODE)),
    (ok.COLOR_2_MODE, deepcopy(MATTER_MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.BELOW_COLOR_1, deepcopy(BLUR)),
    (ok.BELOW_COLOR_2, deepcopy(BLUR)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.BRW, deepcopy(MAR))
])

# Clay Chemistry_______________________________________________________________
CLAY_CHEMISTRY = OrderedDict([
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.GRADIENT_OPACITY, deepcopy(OPACITY)),
    (ok.REVERSE, deepcopy(REVERSE)),
    (ok.RW1, deepcopy(GMR)),
    (ok.BRW, deepcopy(ARW))
])
CLAY_CHEMISTRY[ok.GRADIENT_OPACITY][wk.VAL] = 50.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

COLOR_FILL = OrderedDict([
    (ok.CRITERION, deepcopy(CRITERION)),
    (ok.FILL_MODE, deepcopy(FILL_MODE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.THRESHOLD, deepcopy(THRESHOLD)),
    (ok.START_X, deepcopy(START_X)),
    (ok.START_Y, deepcopy(START_Y)),
    (ok.COLOR_1A, deepcopy(COLOR_1A)),
    (ok.BRW, deepcopy(MAR))
])
COLOR_GRID = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.COLOR_1_MODE, deepcopy(MATTER_MODE)),
    (ok.COLOR_2_MODE, deepcopy(MATTER_MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.BELOW_COLOR_1, deepcopy(BLUR)),
    (ok.BELOW_COLOR_2, deepcopy(BLUR)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.BRW, deepcopy(MAR))
])
CORE_DESIGN = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.REVERSE, deepcopy(REVERSE)),
    (ok.RW1, deepcopy(GMR)),
    (ok.BRW, deepcopy(ARW))
])
CRYSTAL_CAVE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRW, deepcopy(MAR))
])
CUBE_PATTERN = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.HEIGHT, deepcopy(CLIPBOARD)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.COLOR_3A, deepcopy(COLOR_3A)),
    (ok.BRW, deepcopy(MAR))
])
CUBISM_COVER = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.TILE_SIZE, deepcopy(TILE_SIZE)),
    (ok.BRW, deepcopy(MAR))
])

# Dark Fort____________________________________________________________________
DARK_FORT = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRW, deepcopy(MAR))
])

for i in (ok.ROW, ok.COLUMN):
    DARK_FORT[i][wk.RANDOM_Q] = 4, 16
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Density Gradient__________________________________________________________
DENSITY_GRADIENT = OrderedDict([
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.GRADIENT_MODE, deepcopy(MATTER_MODE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.RW1, deepcopy(GMR)),
    (ok.BRW, deepcopy(ARW))
])
DENSITY_GRADIENT[ok.GRADIENT_ANGLE][wk.VAL] = fg.TOP_CENTER_TO_BOTTOM_CENTER
DENSITY_GRADIENT[ok.GRADIENT_MODE][wk.VAL] = "Luma Lighten Only"
DENSITY_GRADIENT[ok.RW1][wk.SUB][ok.GRADIENT][wk.VAL] = "Desert Sunset"
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Drop Zone____________________________________________________________________
DROP_ZONE = OrderedDict([
    (ok.NAME, deepcopy(NAME_DROP)),
    (ok.SHAPE, deepcopy(SHAPE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.STEPS, deepcopy(STEPS_DROP)),
    (ok.KEEP, deepcopy(KEEP)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.BRW, deepcopy(MAR))
])
DROP_ZONE[ok.COLOR_2A][wk.VAL] = (255, 255, 255, 255), (0, 0, 0, 255)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

ETCH_SKETCH = OrderedDict([
    (ok.SKETCH_TEXTURE, deepcopy(SKETCH_TEXTURE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.CELL_SIZE, deepcopy(CELL_SIZE_ETCH)),
    (ok.BRW, deepcopy(MAR))
])

# Fading Maze__________________________________________________________________
FADING_MAZE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.WIDTH, deepcopy(CLIPBOARD)),
    (ok.SEED, deepcopy(SEED)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.BRW, deepcopy(MAR))
])

for i in (ok.ROW, ok.COLUMN):
    FADING_MAZE[i][wk.RANDOM_Q] = 4, 199
    FADING_MAZE[i][wk.LIMIT] = 4, 999
    FADING_MAZE[i][wk.VAL] = (70., 7.)[i == ok.COLUMN]

FLOOR_SAMPLE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SLICE_COUNT, deepcopy(SLICE_COUNT)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.COLOR_2A, deepcopy(COLOR_2A)),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.SHADOW, deepcopy(SHADOW)),
            (ok.MOD, deepcopy(MOD))
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.BRW, deepcopy(ARW))
])

# Galactic Field_______________________________________________________________
GALACTIC_FIELD = OrderedDict([
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
    (ok.GRADIENT_MODE, deepcopy(MATTER_MODE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.GRADIENT_OPACITY, deepcopy(OPACITY)),
    (ok.REVERSE, deepcopy(REVERSE)),
    (ok.RW1, deepcopy(GMR)),
    (ok.BRW, deepcopy(ARW))
])
GALACTIC_FIELD[ok.GRADIENT_ANGLE][wk.VAL] = fg.TOP_CENTER_TO_BOTTOM_CENTER
GALACTIC_FIELD[ok.GRADIENT_MODE][wk.VAL] = "Subtract"
GALACTIC_FIELD[ok.GRADIENT_OPACITY][wk.ISSUE] = vo.MATTER
GALACTIC_FIELD[ok.RW1][wk.SUB][ok.GRADIENT][wk.VAL] = "Galactic Field"
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

GLASS_GAW = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRW, deepcopy(MAR))
])
GRADIENT_FILL = OrderedDict([
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.START_X, deepcopy(GRADIENT_START_X)),
    (ok.START_Y, deepcopy(GRADIENT_START_Y)),
    (ok.END_X, deepcopy(GRADIENT_END_X)),
    (ok.END_Y, deepcopy(GRADIENT_END_Y)),
    (ok.REVERSE, deepcopy(REVERSE)),
    (ok.RW1, deepcopy(GMR)),
    (ok.BRW, deepcopy(ARW))
])
HISTORIC_TRIP = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ITERATIONS, deepcopy(ITERATIONS)),
    (ok.SPREAD, deepcopy(SPREAD)),
    (ok.SUPERPIXEL_SIZE, deepcopy(SUPERPIXEL_SIZE)),
    (ok.BRW, deepcopy(MAR))
])

# Image Gradient_______________________________________________________________
IMAGE_GRADIENT = OrderedDict([
    (ok.NAME, deepcopy(NAME_GRADIENT)),
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.SAMPLE_VECTOR, deepcopy(SAMPLE_VECTOR)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SAMPLE_RADIUS, deepcopy(SAMPLE_RADIUS)),
    (ok.SAMPLE_COUNT, deepcopy(SAMPLE_COUNT)),
    (ok.DIAGONAL, deepcopy(DIAGONAL)),
    (ok.START_X, deepcopy(START_X)),
    (ok.START_Y, deepcopy(START_Y)),
    (ok.REVERSE, deepcopy(REVERSE)),
    (ok.KEEP, deepcopy(KEEP)),
    (ok.PREVIEW_MODE, deepcopy(PREVIEW_MODE)),
    (ok.BRW, deepcopy(ARW))
])
IMAGE_GRADIENT[ok.START_X][wk.VAL] = IMAGE_GRADIENT[ok.START_Y][wk.VAL] = 0, .5
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

LINE_STONE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRW, deepcopy(MAR))
])
LOST_MAZE = OrderedDict([
    (ok.GRADIENT_ANGLE, GRADIENT_ANGLE),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(MAZE)),
    (ok.COLUMN, deepcopy(MAZE)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.SEED, deepcopy(SEED)),
    (ok.REVERSE, deepcopy(REVERSE)),
    (ok.RW1, deepcopy(GMR)),
    (ok.BRW, deepcopy(ARW))
])

# Maze Blend___________________________________________________________________
MAZE_BLEND = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(MAZE)),
    (ok.COLUMN, deepcopy(MAZE)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRW, deepcopy(MAR))
])
MAZE_BLEND[ok.ROW][wk.VAL] = 4.
MAZE_BLEND[ok.COLUMN][wk.VAL] = 100.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

MEAN_COLOR = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.BRW, deepcopy(MAR))
])

# Mystery Grate________________________________________________________________
MYSTERY_GRATE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.COLUMN_1, deepcopy(R_C)),
    (ok.COLUMN_2, deepcopy(R_C)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.REVERSE, deepcopy(REVERSE)),
    (ok.RW1, deepcopy(GMR)),
    (ok.BRW, deepcopy(ARW))
])
MYSTERY_GRATE[ok.COLUMN_1][wk.VAL] = 16.
MYSTERY_GRATE[ok.COLUMN_2][wk.VAL] = 160.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Noise Rift___________________________________________________________________
NOISE_RIFT = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.NOISE_AMOUNT, deepcopy(NOISE_AMOUNT)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRW, deepcopy(MAR))
])
NOISE_RIFT[ok.NOISE_AMOUNT][wk.VAL] = 1.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

PAPER_WASTE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.BLOCK_W, deepcopy(BLOCK_W)),
    (ok.BLOCK_H, deepcopy(BLOCK_H)),
    (ok.BRW, deepcopy(MAR))
])
PATTERN_FILL = OrderedDict([
    (ok.CRITERION, deepcopy(CRITERION)),
    (ok.FILL_MODE, deepcopy(FILL_MODE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.FILL_OPACITY, deepcopy(OPACITY)),
    (ok.THRESHOLD, deepcopy(THRESHOLD)),
    (ok.START_X, deepcopy(START_X)),
    (ok.START_Y, deepcopy(START_Y)),
    (ok.RW1, {
        wk.SUB: OrderedDict([
            (ok.PATTERN, deepcopy(PATTERN)),
            (ok.MOD, deepcopy(MOD))
        ]),
        wk.WIDGET: WidgetRow
    }),
    (ok.BRW, deepcopy(ARW))
])
RAINBOW_VALLEY = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.POWER, deepcopy(POWER)),
    (ok.SEED, deepcopy(SEED)),
    (ok.TEXTURE, deepcopy(TEXTURE)),
    (ok.BRW, deepcopy(MAR))
])
RECT_PATTERN = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.WIDTH, deepcopy(CLIPBOARD)),
    (ok.HEIGHT, deepcopy(CLIPBOARD)),
    (ok.COLOR_COUNT, deepcopy(COLOR_COUNT)),
    (ok.ANGLE, deepcopy(ANGLE)),
    (ok.SEED, deepcopy(SEED)),
    (ok.RANDOM_ORDER, deepcopy(RANDOM_ORDER)),
    (ok.COLOR_GRID_TYPE, deepcopy(COLOR_GRID_TYPE)),
    (ok.COLOR_6A, deepcopy(COLOR_6A)),
    (ok.BRW, deepcopy(MAR))
])
ROCKY_LANDING = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.BLEND, deepcopy(BLEND)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRW, deepcopy(MAR))
])

# Roof Top_____________________________________________________________________
ROOF_TOP = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.SEED, deepcopy(SEED)),
    (ok.COLOR_3, deepcopy(COLOR_3)),
    (ok.BRW, deepcopy(MAR))
])

for i in (ok.ROW, ok.COLUMN):
    ROOF_TOP[i][wk.RANDOM_Q] = 4, 12
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

SOFT_TOUCH = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.BRW, deepcopy(MAR))
])

# Specimen Speckle_____________________________________________________________
SPECIMEN_SPECKLE = OrderedDict([
    (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.GRADIENT_OPACITY, deepcopy(OPACITY)),
    (ok.OFFSET, deepcopy(OFFSET)),
    (ok.REVERSE, deepcopy(REVERSE)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.P3R, deepcopy(P3R)),
    (ok.RW1, deepcopy(GMR)),
    (ok.BRW, deepcopy(ARW))
])
SPECIMEN_SPECKLE[ok.COLOR_1][wk.VAL] = 176, 82, 0
SPECIMEN_SPECKLE[ok.GRADIENT_OPACITY][wk.VAL] = 50.
a = SPECIMEN_SPECKLE[ok.P3R][wk.SUB]
a[ok.PATTERN_1][wk.VAL] = "Crack"
a[ok.PATTERN_2][wk.VAL] = "Leopard"
a[ok.PATTERN_3][wk.VAL] = "Paper"
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Spiral Channel_______________________________________________________________
SPIRAL_CHANNEL = OrderedDict([
    (ok.SPIRAL_MOD, deepcopy(SPIRAL_MOD)),
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SPIRAL_DISTANCE, deepcopy(SPIRAL_DISTANCE)),
    (ok.ROW, deepcopy(R_C)),
    (ok.COLUMN, deepcopy(R_C)),
    (ok.GRADIENT_DIRECTION, deepcopy(GRADIENT_DIRECTION)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.BRW, deepcopy(MAR))
])
SPIRAL_CHANNEL[ok.COLOR_1][wk.VAL] = 75, 75, 75
SPIRAL_CHANNEL[ok.ROW][wk.VAL] = 1.
SPIRAL_CHANNEL[ok.COLUMN][wk.VAL] = 1.
SPIRAL_CHANNEL[ok.SPIRAL_MOD][wk.VAL] = bs.HORIZONTAL_FLIP

d = {wk.RANDOM_Q: (1, 10), wk.PAGE_INCR: 2, wk.LIMIT: (1, 100)}

SPIRAL_CHANNEL[ok.ROW].update(d)
SPIRAL_CHANNEL[ok.COLUMN].update(d)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

SQUARE_CLOUD = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.SEED, deepcopy(SEED)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (ok.BRW, deepcopy(MAR))
])
STONE_AGE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.PATTERN_SIZE, deepcopy(PATTERN_SIZE)),
    (ok.BRW, deepcopy(MAR))
])
TRAILING_VINE = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.OPACITY, deepcopy(OPACITY)),
    (ok.LAYER_COUNT, deepcopy(LAYER_COUNT)),
    (ok.WAVE_PER_LAYER, deepcopy(WAVE_PER_LAYER)),
    (ok.SEED, deepcopy(SEED)),
    (ok.BRW, deepcopy(MAR))
])
