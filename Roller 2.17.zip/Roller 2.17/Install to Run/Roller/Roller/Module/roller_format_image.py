#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_image_effect import LayerKey
from roller_format_form import Form
from roller_one_base import Comm
from roller_one_constant import (
    CellKey,
    ForFormat as ff,
    ForLayout,
    FormatKey as fk,
    FreeCellKey as fck,
    ImageKey as ik,
    OptionKey as ok,
    PlaceKey as pl,
    PropertyKey as pr,
    SessionKey as sk
)
from roller_one_fu import Lay, Sel
import gimp
import gimpfu as fu
import os

pdb = fu.pdb


class RollerImage:
    """Use to manage an open image."""

    # number of valid images:
    image_count = 0

    # An open image already inside GIMP
    # is assigned a RollerImage.
    # The key is an image name from image names.
    # The value is a RollerImage:
    roller_image = {}

    # valid image names:
    image_names = []

    # numeric ordered:
    relative_names = []

    # Has images opened from a file reference.
    # The key is the file path; the value is a RollerImage:
    opened_images = {}

    # Each folder that is in process has an item in "folder_pile".
    # The key is: string; a folder path.
    # The value is: tuple; (a file index, a file list).
    # The file index is: int; an index to the
    # next file to process in the file list.
    #
    # The file list is: list; of file
    # path strings found in the folder:
    folder_pile = {}

    # indices for image placement:
    next_index = previous_index = fluctuate_index = 0

    # Each image with a 'as layers' reference has a list
    # of layers and an index.
    # The key is an roller image name.
    # The value is a tuple:
    #   list of layers
    #   index to next layer
    layer_pile = {}

    # Each opened layer image has a name-key, name-value.
    # The name-key is the image reference, layer index.
    # The name-value is an image name key in 'roller_image':
    layer_image = {}

    def __init__(self, j, n, layer_name=None):
        """
        Create a RollerImage object from
        a corresponding open image.

        j: GIMP image
            Could be None for dummy-usage.

        n: string
            image name
            Could be empty for dummy-usage.

        layer_name: string
            Use instead of image name to describe image source.
        """
        self.j = j
        self.image_name = n
        self.layer_name = layer_name

        # flag; Is true when a file is to be
        # closed after its first use:
        self.free = 0

        s = (j.width, j.height) if j else (0, 0)
        self.size = self.width, self.height = s

        # 'cell' is the cell rectangle without the margins:
        self.cell = Rect((0, 0), (0, 0))

        # 'pocket' is the cell rectangle with the margins included:
        self.pocket = Rect((0, 0), (0, 0))

        # 'mold' is the image rectangle for the image place.
        # Its value is computed by layout 'mold' functions:
        self.mold = Rect((0, 0), (0, 0))

    @staticmethod
    def _add_image(j, d, n, layer_name=None):
        """
        Add a GIMP image to the RollerImage collection.

        j: GIMP image
            to be given a RollerImage

        d: dict
            of session

        n: string
            file path or layer name

        layer_name: string
            Use to describe image.

        return: RollerImage
            the corresponding RollerImage
        """
        j1 = RollerImage.opened_images[n] = RollerImage(
            j,
            j.name,
            layer_name=layer_name
        )
        j1.free = d[sk.CLOSE_FILE]
        j1.path = n
        return j1

    @staticmethod
    def _copy_layer(d, j, z):
        """
        Copy a layer from an image.

        d: dict
            of image choice

        j: GIMP image
            Has layer.

        z: layer
            to copy

        Return: GIMP buffer state
            copy of layer
        """
        q = RollerImage._hide_all_but_one(j, z, [])
        q1 = RollerImage._ensure_visible(z, [])

        if not z.visible:
            pdb.gimp_item_set_visible(z, 1)
            q1.append(z)

        if d[ik.AUTOCROP]:
            Sel.item(j, z)

            is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)

            if is_sel:
                # Copy visible material:
                Sel.rect(
                    j,
                    x,
                    y,
                    x1 - x,
                    y1 - y,
                    option=fu.CHANNEL_OP_REPLACE
                )
                pdb.gimp_edit_copy(z)

            else:
                # Copy nothing:
                pdb.gimp_edit_copy_visible(j)

        else:
            pdb.gimp_edit_copy_visible(j)

        # Restore visibility state:
        for i in q:
            Lay.show(i)
        for i in q1:
            Lay.hide(i)

    @staticmethod
    def _ensure_visible(z, q):
        """
        Ensure a layer to visible. If it part
        of a tree, then the branches need to
        be visible.

        Is recursive.

        z: layer
            to be made visible

        q: list
            Layers made visible.

        Return: list
            Layers made visible.
        """
        if hasattr(z, 'parent'):
            if z.parent and not z.parent.visible:
                Lay.show(z.parent)
                q.append(z.parent)
                q = RollerImage._ensure_visible(z.parent, q)
        return q

    @staticmethod
    def _get_file_from_path(n, d, session):
        """
        Get a RollerImage for a file path.

        Will open a file.

        n: string
            file path

        d: dict
            of image choice

        session: dict
            of session

        Return: RollerImage or None
            corresponding with an opened image
        """
        j = None

        # If the image is already opened, then don't re-open:
        if n in RollerImage.opened_images:
            j = RollerImage.opened_images[n]

        else:
            try:
                j1 = pdb.gimp_file_load(n, n)
                j = RollerImage._add_image(j1, session, n)

            except Exception as ex:
                Comm.info_msg(
                    "Roller tried to"
                    " load an image file:\n'{}'\n"
                    "and an error occurred.".format(n)
                )
                Comm.info_msg("The error was:\n" + repr(ex))
                Comm.info_msg(
                    "Roller will use a 'None' reference for the image."
                )
        return RollerImage._get_layer_image(j, session, d, n)

    @staticmethod
    def _get_fluctuate_image(n):
        """
        Get an opened image reference with the fluctuate index.

        n: string
            fluctuate descriptor

        Return: string or None
            an opened image
        """
        n1 = None
        a = RollerImage

        if a.image_count:
            if n == ff.Image.FLUCTUATE_INCREMENT:
                # Increment rollover:
                if a.fluctuate_index + 1 >= a.image_count:
                    a.fluctuate_index = -1

                a.fluctuate_index += 1
                n1 = a.image_names[a.fluctuate_index]

            else:
                # Decrement rollover:
                if a.fluctuate_index - 1 < 0:
                    a.fluctuate_index = a.image_count

                a.fluctuate_index -= 1
                n1 = a.image_names[a.fluctuate_index]
        return n1

    @staticmethod
    def _get_folder_file_reference(d):
        """
        Return a file path string from an indexed-file of a folder path.

        d: dict
            of image choice

        Return: string or None
            Return file path.
        """
        path = None
        e = RollerImage.folder_pile
        n = d[ik.IMAGE_REF]

        if n and os.path.isdir(n):
            n1 = d[ik.FILTER]
            k = d[ik.IMAGE_REF], n1

            if k in e:
                path = RollerImage._get_next_folder_file(d, k)

            else:
                try:
                    file_list = []

                    for _file in os.listdir(n):
                        ext = os.path.splitext(_file)[1]
                        if ext.lower() in ff.Image.EXTENSION:
                            if n1:
                                if n1 not in _file:
                                    continue
                            file_list.append(os.path.join(n, _file))

                    file_list = sorted(file_list)
                    e[k] = file_list, 0, len(file_list) - 1
                    path = RollerImage._get_next_folder_file(d, k)

                except Exception as ex:
                    Comm.info_msg(
                        "Roller tried to read from a folder:\n'{}'\n"
                        "and an error occurred.".format(n)
                    )
                    Comm.info_msg("The error was:\n" + repr(ex))
                    Comm.info_msg(
                        "Roller will use a 'None' image"
                        " reference for the folder."
                    )
        return path

    @staticmethod
    def _get_image_from_name(n, d, session):
        """
        Get a RollerImage corresponding
        with an opened image name.

        n: string
            image name

        d: dict
            of image choice

        session: dict
            of session

        Return: RollerImage or None
            corresponding to an opened image
        """
        e = RollerImage.roller_image
        j = RollerImage.roller_image[n] if n in e else None
        return RollerImage._get_layer_image(j, session, d, n)

    @staticmethod
    def _get_layer_image(j, session, d, n):
        """
        Get a layer image if it is still available.

        j: RollerImage
            Is it real?

        d: dict
            of image choice

        n: string
            image name
            key for layer pile

        Return: RollerImage or None
            from layer or unchanged
        """
        if (
            j and
            d[ik.AS_LAYERS] and
            d[ik.HAS_FORMAT] and
            d[ik.TYPE] in ff.Image.Type.AS_LAYERS_LIST
        ):
            e = RollerImage.layer_pile

            if n in e:
                q = e[n][0]
                x, x1 = e[n][1], e[n][2]

                if d[ik.LAYER_ORDER]:
                    # top-down:
                    x2 = x1
                    x1 += 1
                    more = len(q) > x2

                else:
                    # bottom-up:
                    x2 = x
                    x -= 1
                    more = x2 > -1

                if more:
                    # Get the next layer:
                    z = e[n][0][x2]
                    k = "{},{}".format(j.image_name, z.name)

                    if k in RollerImage.layer_image:
                        j = RollerImage.layer_image[k]

                    else:
                        RollerImage._copy_layer(d, j.j, z)

                        j = pdb.gimp_edit_paste_as_new_image()
                        j = RollerImage._add_image(
                            j,
                            session,
                            "{},{}".format(n, x2),
                            layer_name=z.name
                        )
                        RollerImage.layer_image[k] = j
                    e[n] = e[n][0], x, x1

                else:
                    j = None

            else:
                # Add an item to the layer pile:
                q = RollerImage._get_layers(j.j, [])
                x, x1 = len(q) - 1, 0

                if d[ik.LAYER_ORDER]:
                    # top-down:
                    x2 = 0
                    x1 += 1

                else:
                    # bottom-up:
                    x2 = x
                    x -= 1

                # list of layers, bottom-up index, top-down index:
                e[n] = q, x, x1
                z = e[n][0][x2]

                # Create a RollerImage from the first layer:
                RollerImage._copy_layer(d, j.j, z)

                j = pdb.gimp_edit_paste_as_new_image()
                j = RollerImage._add_image(
                    j,
                    session,
                    "{},{}".format(n, x2),
                    layer_name=z.name
                )

                if d[ik.AUTOCROP]:
                    pdb.plug_in_autocrop(j.j, j.j.layers[0])
                RollerImage.layer_image["{},{}".format(
                    j.image_name,
                    z.name
                )] = j
        return j

    @staticmethod
    def _get_layers(z, q):
        """
        Collect a list of layers belonging to an image.
        Group layers are excluded.

        Is recursive.

        z: GIMP image or layer
            Has layers.

        return: list
            of layers
        """
        for z1 in z.layers:
            if pdb.gimp_item_is_group(z1):
                # recursive:
                q = RollerImage._get_layers(z1, q)

            else:
                q.append(z1)
        return q

    @staticmethod
    def _get_next_folder_file(d, key):
        """
        Get a file reference from a folder's file list.

        d: dict
            of image choice

        key: tuple
            path, filter
            key for RollerImage.folder_pile

        Return: string or None
            file path
        """
        path = None
        file_list, x, x1 = RollerImage.folder_pile[key]

        if d[ik.FOLDER_ORDER]:
            # descending:
            x2 = x1
            x1 -= 1
            more = x2 > -1

        else:
            # ascending:
            x2 = x
            x += 1
            more = len(file_list) > x2

        if more:
            path = file_list[x2]
            RollerImage.folder_pile[key] = file_list, x, x1
        return path

    @staticmethod
    def _get_next_image(n):
        """
        Get the next image with the 'next' index.

        n: string
            Next descriptor

        Return:
            string or None
        """
        n1 = None
        a = RollerImage

        if a.image_count:
            if n == ff.Image.NEXT_LINEAR:
                if a.next_index < a.image_count:
                    n1 = a.image_names[a.next_index]
                    a.next_index += 1

            else:
                # Next-Circular:
                if a.next_index >= a.image_count:
                    a.next_index = 0

                n1 = a.image_names[a.next_index]
                a.next_index += 1
        return n1

    @staticmethod
    def _get_previous_image(n):
        """
        Get the previous opened image with the 'previous' index.

        n: string
            Previous descriptor

        Return: string
            open image title
        """
        a = RollerImage
        n1 = None

        if a.image_count:
            if n == ff.Image.PREVIOUS_LINEAR:
                if a.previous_index > -1:
                    n1 = RollerImage.image_names[a.previous_index]
                    a.previous_index -= 1

            else:
                # Previous-Circular:
                if a.previous_index < 0:
                    a.previous_index = RollerImage.image_count - 1

                n1 = RollerImage.image_names[a.previous_index]
                a.previous_index -= 1
        return n1

    @staticmethod
    def _get_relative_name_reference(n):
        """
        Get an open image reference corresponding with a numeric index.

        n: string
            numeric reference

        Return: string
            opened image name or None
        """
        n1 = None
        q = RollerImage.relative_names

        if n != ok.NONE and n in q:
            x = q.index(n)
            n1 = RollerImage.image_names[x]
        return n1

    @staticmethod
    def _get_relative_name_image(n, d, session):
        """
        Get a RollerImage corresponding with a numeric index.

        n: string
            relative position

        d: dict
            of image choice

        session: dict
            of session

        Return: RollerImage or None
            an opened image
        """
        j = None
        q = RollerImage.relative_names
        e = RollerImage.roller_image
        n1 = ""

        if n != ok.NONE and n in q:
            x = q.index(n)
            n1 = RollerImage.image_names[x]
            j = e[n1]
        return RollerImage._get_layer_image(j, session, d, n1)

    @staticmethod
    def _hide_all_but_one(z, z1, q):
        """
        Hide all the layers in the image.

        Is recursive.

        z: layer or GIMP image
            Is a branch.

        z1: layer
            layer not to hide

        q: list
            Layers that are hidden.

        return: list
            layers that are hidden.
        """
        for z2 in z.layers:
            if not hasattr(z2, 'layers'):
                if z2.visible and z2.name != z1.name:
                    pdb.gimp_item_set_visible(z2, 0)
                    q.append(z2)

            else:
                # recursive:
                q = RollerImage._hide_all_but_one(z2, z1, q)
        return q

    @staticmethod
    def _validate_file_reference(n):
        """
        Validate a file path.

        n: string
            file path

        Return: string or None
            file path
        """
        return n if n and os.path.isfile(n) else None

    @staticmethod
    def _validate_image_name(n):
        """
        Validate an image reference from opened Roller images.

        n: string
            image name

        Return: string or None
            image reference
        """
        d = RollerImage.roller_image
        return n if n in d else None

    @staticmethod
    def close_image(j):
        """
        Close an opened file.

        j: RollerImage
            opened but soon to be closed
        """
        if j and j.free:
            pdb.gimp_image_delete(j.j)
            RollerImage.opened_images.pop(j.path)

            d = RollerImage.layer_image
            q = [i for i in d]
            [d.pop(i) for i in q if d[i] == j]

    @staticmethod
    def do_blur_behind(session, stat):
        """
        Create a blur-behind layer if one doesn't exist.

        Use an opaque selection of an image
        to blur the area on the blur behind layer.

        session: dict
            of session

        stat: Stat
            globals
        """
        def create_blur_layer():
            """
            Create the Blur Behind layer.

            Return:
                z: layer
                    the blur behind layer
            """
            pdb.gimp_image_crop(j, session['w'], session['h'], 0, 0)
            pdb.gimp_edit_copy_visible(j)

            z = Lay.paste(j, image_layer)
            z.name = n
            offset = Lay.offset(j, image_layer)

            pdb.gimp_image_reorder_item(j, z, parent, offset)
            return z

        j = stat.render.image
        format_list = session[sk.FORMAT_LIST]

        for x in range(len(format_list) - 1, -1, -1):
            d = format_list[x]
            name = d[fk.Layer.NAME]
            blur_behind_layer = None
            parent = stat.render.format_group(x, name)
            image_layer = stat.render.get_image_layer(
                Lay.get_format_name_from_group(parent)
            )
            n = Lay.get_layer_name(
                LayerKey.IMAGE_BLUR_BEHIND,
                parent=parent
            )
            if image_layer:
                pdb.gimp_selection_none(j)
                Lay.hide_format_stack(stat, x)
                Lay.hide_layers_above(parent, image_layer)

                is_double = Form.is_double_space(d)
                row, col = stat.layout.get_division(x)

                for r in range(row):
                    for c in range(col):
                        blur = 1

                        if is_double:
                            blur = Form.is_double_space_cell(
                                r,
                                c,
                                is_double
                            )

                        if blur:
                            blur = Form.get_image_property(
                                d,
                                r,
                                c
                            )[pr.BLUR_BEHIND]
                        if blur:
                            if not blur_behind_layer:
                                blur_behind_layer = create_blur_layer()

                            sel = stat.get_image_sel(name, r, c)
                            if sel:
                                Sel.load(j, sel)
                                Lay.blur(j, blur_behind_layer, blur)

                r = ForLayout.FREE_CELL

                for cell in reversed(d[fk.Layer.CELL_LIST]):
                    j1 = RollerImage.get_image(
                        session,
                        cell[pl.IMAGE_PLACE][pl.IMAGE_DICT]
                    )
                    if j1:
                        blur = cell[pr.IMAGE_PROPERTY][pr.BLUR_BEHIND]
                        if blur:
                            if not blur_behind_layer:
                                blur_behind_layer = create_blur_layer()

                            sel = stat.get_image_sel(
                                cell[fck.CELL][CellKey.NAME],
                                r,
                                r
                            )
                            if sel:
                                Sel.load(j, sel)
                                Lay.blur(j, blur_behind_layer, blur)

                Lay.show_layer_on_top(parent, image_layer)
                Lay.show_format_groups(stat)

                # Clear outside of the blur-behind selection:
                pdb.gimp_selection_none(j)

                for r in range(row):
                    for c in range(col):
                        if Form.get_image_property(d, r, c)[pr.BLUR_BEHIND]:
                            sel = stat.get_image_sel(name, r, c)
                            if sel:
                                Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

                r = ForLayout.FREE_CELL

                for cell in d[fk.Layer.CELL_LIST]:
                    j1 = RollerImage.get_image(
                        session,
                        cell[pl.IMAGE_PLACE][pl.IMAGE_DICT]
                    )
                    if j1:
                        blur = cell[pr.IMAGE_PROPERTY][pr.BLUR_BEHIND]
                        if blur:
                            sel = stat.get_image_sel(
                                cell[fck.CELL][CellKey.NAME],
                                r,
                                r
                            )
                            Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)
                if Sel.is_sel(j):
                    Sel.clear_outside_of_selection(j, blur_behind_layer)

    @staticmethod
    def get_image(session, d):
        """
        Get a RollerImage object.

        session: dict
            of session

        d: dict
            of image choice

        Return: RollerImage or None
            corresponding with an opened image
        """
        return RollerImage.get_image_from_name(
            session,
            d,
            RollerImage.get_image_reference(d)
        )

    @staticmethod
    def get_image_from_name(session, d, n):
        """
        Get a RollerImage object.

        session: dict
            of session

        d: dict
            of image choice

        n: string
            image reference

        Return: RollerImage or None
            corresponding with an opened image
        """
        if n:
            if n in RollerImage.relative_names:
                x = 0

            elif n in RollerImage.image_names:
                x = 1

            else:
                x = 2
            return (
                RollerImage._get_relative_name_image,
                RollerImage._get_image_from_name,
                RollerImage._get_file_from_path,
                lambda *args: None
            )[x](n, d, session)

    @staticmethod
    def get_image_reference(d):
        """
        Get an image reference for a cell.

        d: dict
            of image choice

        Return: string or None
            image reference
        """
        a = RollerImage
        n = d[ik.TYPE]

        # Return image reference:
        if n == ff.Image.Type.FOLDER:
            return a._get_folder_file_reference(d)
        return (
            a._get_next_image,
            a._get_previous_image,
            a._get_fluctuate_image,
            a._get_relative_name_reference,
            a._validate_image_name,
            a._validate_file_reference,
            None,
            lambda *args, **kwargs: None
        )[ff.Image.Type.HAS_FORMAT.index(n)](d[ik.IMAGE_REF])

    @staticmethod
    def image_undo_start():
        """
        Roll image changes into a ball.

        Call before placing images with a render or layout.
        """
        d = RollerImage.roller_image
        for k in d:
            pdb.gimp_image_undo_group_start(d[k].j)

    @staticmethod
    def image_undo_end():
        """
        The changes are bundled.

        Call after placing images with a render or layout.
        """
        d = RollerImage.roller_image
        for k in d:
            pdb.gimp_image_undo_group_end(d[k].j)

    @staticmethod
    def init_for_layout():
        """
        Reset any file list indices back to zero.

        Reset the open image indices.

        Call before placing images, doing a
        layout, or calculating the cell table.
        """
        # dictionaries:
        d = RollerImage.folder_pile

        for k in d:
            q = d[k][0]
            d[k] = q, 0, len(q) - 1

        d = RollerImage.layer_pile

        for k in d:
            q = d[k][0]
            d[k] = q, len(q) - 1, 0

        # indices:
        RollerImage.next_index = 0
        RollerImage.fluctuate_index = -1
        RollerImage.previous_index = RollerImage.image_count - 1

    @staticmethod
    def make_image_list():
        """Collect related data for images."""
        # post-fix image number tuple:
        q = pdb.gimp_image_list()[1][::-1]

        # GIMP has an image list:
        q1 = reversed(gimp.image_list())

        d = RollerImage.roller_image
        q2 = RollerImage.image_names = []

        for x, j in enumerate(q1):
            n = j.name + "-" + str(q[x])
            d[n] = RollerImage(j, n)
            q2.append(n)

        # Use 'q2' to map the image numeric sequence to a name:
        RollerImage.image_count = len(q2)

        for i in range(len(q2)):
            go = 1
            while go:
                go = q2.count(q2[i]) - 1
                if go:
                    x = q2.index(q2[i])
                    q2[x] += " (" + str(go) + ")"

        if not q2:
            q2.append(ok.NONE)

        # numeric sequenced:
        if RollerImage.image_count:
            for i in range(len(q)):
                n = str(i + 1)
                a1 = i + 1

                if i == 0 or (a1 > 20 and a1 % 10 == 1):
                    c = n + "st"

                elif i == 1 or (a1 > 20 and a1 % 10 == 2):
                    c = n + "nd"

                elif i == 2 or (a1 > 20 and a1 % 10 == 3):
                    c = n + "rd"

                else:
                    c = n + "th"
                RollerImage.relative_names.append(c + " Image")

        else:
            RollerImage.relative_names.append(ok.NONE)
        RollerImage.image_undo_start()


class Rect(object):
    """Define a rectangle."""

    def __init__(self, position, size):
        """
        Create useful fields that define a rectangle.

        position: tuple
            x, y
            of rectangle

        size: tuple
            width, height
            of rectangle
        """
        self.x = position[0]
        self.y = position[1]
        self.width = size[0]
        self.height = size[1]

    @property
    def clone(self):
        """Make a copy of the rectangle and return the copy."""
        return Rect((self.x, self.y), (self.width, self.height))

    @property
    def position(self):
        """Return the rectangle position."""
        return self.x, self.y

    @position.setter
    def position(self, value):
        """Set the rectangle position."""
        self.x, self.y = value

    @property
    def size(self):
        """Return the rectangle size."""
        return self.width, self.height

    @size.setter
    def size(self, value):
        """Set the rectangle size."""
        self.width, self.height = value
