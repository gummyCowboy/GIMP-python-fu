#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_image_effect import ImageEffect, LayerKey
from roller_one import One
from roller_one_constant import (
    ForFormat as ff,
    OptionKey as ok,
    ShadowKey as sh
)
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

ek = ImageEffect.Key
pdb = fu.pdb
BOTTOM_LAYER = (
    LayerKey.BLURRED_BACKGROUND,
    LayerKey.CELL_FRINGE,
    LayerKey.CELL_PLAQUE,
    LayerKey.LAYER_FRINGE,
    LayerKey.LAYER_PLAQUE
)
CAPTION_LAYER = LayerKey.CELL_CAPTION, LayerKey.LAYER_CAPTION


class Shadow:
    """
    Creates a shadow layer.

    Use with shadow effects.
    """

    def __init__(self, one):
        """
        Make a shadow.

        one: One
            Has variables.

            e: keyword args
                caster_key: iterable
                    layer key(s) of layers that cast a shadow

                is_inlay: flag
                    Set to true to make the shadow an inlay-type.
        """
        # Use a selection so the shadow doesn't appear below the image:
        stat = one.stat
        d = deepcopy(one.d)
        e = one.e
        parent = one.parent
        j = stat.render.image
        caster_key = e['caster_key'] if 'caster_key' in e else []
        if caster_key and d[ok.INTENSITY]:
            is_inlay = e['is_inlay'] if 'is_inlay' in e else 0
            group, caster_layer = RenderHub.create_shadow_unit(
                stat,
                parent,
                caster_key
            )
            name = Lay.get_layer_name(one.k, parent=parent)

            if is_inlay:
                # inlay-type shadow:
                d[ok.OFFSET_X] = d[ok.OFFSET_Y] = 0
                blur = d[ok.INLAY_BLUR]

            else:
                blur = d[ok.SHADOW_BLUR]

            if ok.MAKE_OPAQUE not in d:
                d[ok.MAKE_OPAQUE] = 1

            z = RenderHub.do_shadow(
                stat,
                group,
                d[ok.OFFSET_X],
                d[ok.OFFSET_Y],
                blur,
                d[ok.SHADOW_COLOR],
                d[ok.INTENSITY],
                layer_name=name,
                d=d,
                is_inlay=is_inlay
            )

            pdb.gimp_image_remove_layer(j, group)

            if z:
                if is_inlay:
                    # Caption is to be on top:
                    a = 0
                    for i in CAPTION_LAYER:
                        a += int(
                            Lay.search(
                                parent,
                                i,
                                is_err=0
                            ) is not None
                        )
                    b = 0

                else:
                    a = len(parent.layers)
                    b = 0
                    for i in BOTTOM_LAYER:
                        reserved = Lay.search(parent, i, is_err=0)
                        b = b - 1 if reserved else b

                pdb.gimp_image_reorder_item(j, z, parent, a + b)
                if one.k == ek.KEY_LIGHT_SHADOW:
                    z.mode = fu.LAYER_MODE_NORMAL

            [Lay.show(i) for i in caster_layer]
            pdb.gimp_selection_none(j)

    @staticmethod
    def do_shadows(j, z, d, stat, name):
        """
        Draw shadows for a material
        given a shadow dict.

        j: GIMP image
            work-in-progress

        z: layer
            with material

        d: dict
            of shadow choice

        stat: Stat
            globals

        name: string
            layer key of cast member

        Return: tuple
            layer:
                the shadow layer or None

            flag:
                Is true if the shadow is an inlay.
        """
        def cast_shadow():
            """
            Create the shadow effect and merge
            it with the material layer.
            """
            one.d = e

            if n in ff.Shadow.LOWER_SHADOWS:
                one.e['is_inlay'] = 0
                is_inlay = 0

            elif n == sh.INLAY_SHADOW:
                one.e['is_inlay'] = 1
                is_inlay = 1

            Shadow(one)

            z1 = j.active_layer
            z1.name = 'shadow'

            # Did Shadow create a layer?
            if z1.name != z.name:
                offset = 0 if is_inlay else Lay.offset(j, z) + 1
                pdb.gimp_image_reorder_item(j, z1, z.parent, offset)

        n = d[sh.TYPE]
        group = Lay.group(j, name, parent=z.parent)

        pdb.gimp_image_reorder_item(j, z, group, 0)

        one = One(
            e={'caster_key': (name,)},
            k='shadow',
            stat=stat,
            parent=group
        )

        # one shadow:
        if n in (sh.DROP_SHADOW, sh.INLAY_SHADOW):
            e = d[n]
            cast_shadow()

        # multiple shadows:
        elif n in (sh.SHADOW_PAIR, sh.TRI_SHADOW):
            n1 = n
            for n in d[n1]:
                e = d[n1][n]
                cast_shadow()
        return Lay.merge_group(j, group, name)
