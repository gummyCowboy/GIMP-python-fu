#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import (
    ForFormat as ff,
    ForWidget as fw,
    OptionKey as ok,
    OptionLimitKey as olk,
    ShadowKey as sh,
    UIKey
)
from roller_one_preset import Preset
from roller_port import Port
from roller_widget_box import RollerBox
from roller_widget_button import RollerColorButton
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_radio import RadioBox, RollerRadioList
from roller_widget_slider import RollerSlider
from roller_widget_table import RollerTable
from roller_widget_tree import NavigationList
import gtk

OPTION_LABEL = (
    "Drop Shadow",
    "Inlay Shadow",
    "Shadow Pair",
    "Tri-Shadow",
    ok.NONE
)


class PortShadow(Port):
    """Offer options for defining a shadow."""

    def __init__(self, d, g):
        """
        Create a shadow-choice port.

        d: dict
            Has init values.

        g: OptionButton
            Has option values.
        """
        self.do_accept_callback = d[UIKey.ON_ACCEPT]
        self.do_cancel_callback = d[UIKey.ON_CANCEL]
        self.color = g.color
        self._d = g.get_value()
        self._list = []
        self._intensity = []
        Port.__init__(self, d)

    def _draw_drop_shadow_group(self, g):
        """
        Draw the drop shadow group.

        g: GTK container
            to receive group
        """
        self.controls.append(self._draw_widgets(g, sh.DROP_SHADOW))

    def _draw_group(self, g, preset_key):
        """
        Draw widgets in a table.

        There are multiple groups to draw so
        a three column table is required.

        g: VBox
            container for widgets

        preset_key: string
            for preset
            of shadow sub-type
        """
        sub_preset = []
        d = self._d[preset_key]
        hbox = gtk.HBox()
        _list = NavigationList(
            hbox,
            self.on_list_change,
            130,
            self.on_key_press
        )
        _list.switch_group_box = gtk.VBox()
        q = [i for i in d] + [preset_key + " Preset"]

        g.add(hbox)
        _list.set_value(q)
        hbox.add(_list.switch_group_box)
        self._list.append(_list)

        for x, i in enumerate(q):
            vbox = gtk.VBox()

            _list.group_box.append(vbox)
            vbox.add(
                RollerLabel(
                    padding=(2, 0, 4, 0),
                    text=i + " Options:"
                )
            )
            if x < len(q) - 1:
                sub_preset.append(self._draw_widgets(vbox, i))

            else:
                q = (
                    [
                        "{} Preset:".format(preset_key),
                        Preset,
                        dict(
                            key=preset_key,
                            on_key_press=self.on_key_press,
                            on_widget_change=self.on_widget_change,
                            stat=self.stat,
                            win=self.roller_window
                        )
                    ],
                )
                d = RollerTable.create(
                    **dict(d, container=vbox, q=q, color=self.color)
                )
                self.controls += [d[preset_key]]
                d[preset_key].widget_list = sub_preset

    def _draw_inlay_shadow_group(self, g):
        """
        Draw the inlay shadow group.

        g: GTK container
            to receive group
        """
        self.controls.append(self._draw_widgets(g, sh.INLAY_SHADOW))

    @staticmethod
    def _draw_no_shadow_group(g):
        """
        Draw the no shadow options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        g1 = RollerLabel(
            padding=(w, w, w, w),
            text=" No shadow is provided with this option. "
        )
        g.pack_start(g1, expand=True)

    def _draw_shadow_pair_group(self, g):
        """
        Draw the shadow pair group.

        g: GTK container
            to receive group
        """
        self._draw_group(g, sh.SHADOW_PAIR)

    def _draw_tri_shadow_group(self, g):
        """
        Draw the shadow pair group.

        g: GTK container
            to receive group
        """
        self._draw_group(g, sh.TRI_SHADOW)

    def _draw_preset_group(self, g):
        """
        Draw a preset group for the shadow options.

        g: VBox
            container for widgets
        """
        self.preset = Preset(
            container=g,
            key=sh.SHADOW_DICT,
            on_key_press=self.on_key_press,
            on_widget_change=self.on_preset_change,
            stat=self.stat,
            win=self.roller_window
        )

    def _draw_options(self, g):
        """
        Draw the shadow choices group.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        label = OPTION_LABEL
        box = RollerBox(
            gtk.VBox,
            align=(1, 1, 1, 1),
            padding=(w // 2, w, 0, 0)
        )

        g.add(box)

        g = self._radio_list = RollerRadioList(
            container=box,
            key=sh.TYPE,
            labels=label,
            on_widget_change=self._on_list_change,
            padding=(1, 0, w, w)
        )
        self.controls += [g]

    def _draw_shadow_options(self, g):
        """
        Draw the option groups for radio-list choices.

        g: VBox
            container for widgets
        """
        g1 = self._radio_list
        g1.switch_group_box = g
        process = (
            self._draw_drop_shadow_group,
            self._draw_inlay_shadow_group,
            self._draw_shadow_pair_group,
            self._draw_tri_shadow_group,
            PortShadow._draw_no_shadow_group
        )
        label = OPTION_LABEL

        for x, p in enumerate(process):
            vbox = gtk.VBox()

            g1.group_box.append(vbox)

            if label[x]:
                vbox.add(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=label[x] + " Options:"
                    )
                )
            p(vbox)

    def _draw_widgets(self, g, preset_key):
        """
        Draw widgets in a table.

        g: VBox
            container for widgets

        preset_key: string
            for preset
            of shadow sub-type

        Return: widget
            preset for group
        """
        q = []
        a = self.stat.option_limit
        d = Preset.get_default(preset_key)

        for k in d:
            e = dict(
                key=k,
                on_key_press=self.on_key_press,
                on_widget_change=self.on_widget_change,
                stat=self.stat,
                win=self.roller_window
            )
            g1 = a.pure[k][olk.WIDGET]

            if g1 == RollerSlider:
                g1 = RollerSlider
                e.update(a.collect_widget_arg(k, None, self))

            elif g1 == RollerColorButton:
                g1 = RollerColorButton

            elif g1 == RadioBox:
                g1 = RadioBox
                d1 = self.stat.option_limit.pure[ok.MAKE_OPAQUE]
                e['labels'] = d1[olk.LABELS]
                e['tooltip'] = d1[olk.TOOLTIP]
                k = "Make Shadow Source Opaque?"

            q.append([k, g1, e])

        q += (
            [
                "{} Preset:".format(preset_key),
                Preset,
                dict(e, key=preset_key)
            ],
        )
        d = RollerTable.create(
            **dict(d, container=g, q=q, color=self.color)
        )

        self._intensity.append((g, d))
        q = d[preset_key].widget_list = [d[i] for i in d if i != preset_key]
        e = d[sh.INTENSITY].widget_dict = {}

        for i in q:
            if i.key not in (sh.INTENSITY, preset_key):
                e[i.key] = i
            if i.key != preset_key:
                i.preset = d[preset_key]
        return d[preset_key]

    def _on_list_change(self, g, index):
        """
        Use to update a navigation list's visibility.

        g: RadioList
            Is responsible.
            Has radio button list.

        x: int
            index to radio button that is responsible
        """
        self.on_list_change(g, index)
        if index in (2, 3):
            g = self._list[index - 2]

            if g.get_sel_x() is None:
                g.select_item(0)
            self.on_list_change(g, g.get_sel_x())

    def on_vbox_expose(self, vbox, event):
        """
        Update the visibility of the table option group.

        vbox: gtk.VBox
            Has option group.

        event: gtk.gdk.Event
            GDK_EXPOSE type
            not used
        """
        for g, d in self._intensity:
            if vbox == g:
                self._update_widget(d[sh.INTENSITY])
                break

    def _update_widget(self, g):
        """
        Update visibility of shadow widgets dependent on intensity.

        g: RollerSlider
            of intensity

        d: dict
            of option group widgets
        """
        d = g.widget_dict

        if g.get_value():
            for i in d:
                d[i].show()

        else:
            for i in d:
                d[i].hide()
            self.roller_window.resize()

    def do_accept(self, *_):
        """
        Accept the shadow choice.

        Return: true
            The key-press is handled.
        """
        d = self.preset.get_value()
        d[sh.TYPE] = ff.Shadow.SHADOW_OPTION[
            self._radio_list.get_value()]
        return self.do_accept_callback(d)

    def do_cancel(self, *_):
        """
        Cancel the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        q = (
            self._draw_options,
            self._draw_shadow_options,
            self._draw_preset_group,
            self.draw_process_group
        )
        group_name = "Choose a Shadow", "", "", "Process"

        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if group_name[x]:
                vbox.pack_start(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=group_name[x] + ":"
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()

            if x in (0, 2):
                hbox = gtk.HBox()
                g.pack_start(hbox, expand=False)
            hbox.pack_start(box, expand=True)

        self.preset.widget_list = self.controls

        a = Port.loading
        Port.loading = 0
        x = ff.Shadow.SHADOW_OPTION.index(self._d[sh.TYPE])

        self.preset.load_preset(fw.UNDEFINED, self._d)
        self._radio_list.set_value(x)
        self.on_list_change(self._radio_list, x)

        for i in self._intensity:
            i[0].connect('expose-event', self.on_vbox_expose)
        Port.loading = a

    def on_preset_change(self, g):
        """
        Call when a preset is loaded.

        g: RollerComboBox
            Is responsible.
            not used
        """
        self.on_list_change(self._radio_list, self._radio_list.get_value())

    def on_widget_change(self, g):
        """
        Call when a widget is changed.

        g: Widget
            Is changed.
        """
        if not Port.loading:
            self.preset.preset_is_undefined()

            if hasattr(g, 'preset'):
                g.preset.preset_is_undefined()
            if g.key == sh.INTENSITY:
                self._update_widget(g)
        return
