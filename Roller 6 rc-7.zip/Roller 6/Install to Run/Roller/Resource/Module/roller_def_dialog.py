#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import Bump as fb, Frame as ff, Issue as vo
from roller_constant_key import (
    Button as bk,
    Frame as ek,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_def_act import make_bool_tip, make_text_tip, scour
from roller_def_option import (
    AMP,
    AMPLITUDE,
    ANGLE,
    ANGLE_JITTER,
    ANGLE_SHIFT,
    AUTOCROP,
    BACKING_TYPE,
    BEVEL_W,
    BLUR,
    BLUR_XY,
    BRUSH,
    BRUSH_ANGLE,
    BRUSH_SIZE,
    BRUSH_SPACING,
    BUMP_DEPTH,
    BUMP_TYPE,
    CAMO_TYPE,
    CFW,
    CIRCLE_DIAMETER,
    CLIP,
    COLOR_1,
    COLOR_2A,
    COLORIZE,
    CONTRACT,
    CONTRAST,
    CORNER_SHIFT,
    CORNER_TYPE,
    CROP_X,
    CROP_Y,
    CUT_OUT,
    DESATURATE,
    DISTRESS,
    EDGE_MODE,
    EDGE_TYPE,
    EMBOSS,
    FACTOR_SIZE,
    FEATHER,
    FILTER,
    FIXED_SIZE,
    FLIP,
    FOLDER_ORDER,
    FONT,
    FRAME_W,
    GAP_W,
    GRADIENT,
    GRADIENT_ANGLE,
    GRADIENT_TYPE,
    HARDNESS,
    HEXAGON_TYPE,
    HSL,
    IMAGE_NAME,
    IMAGE_TYPE,
    INNER_FRAME_W,
    INTENSITY,
    INVERT,
    LAYER_ORDER,
    LAYERED,
    LENGTH,
    LENGTH_SHIFT,
    LINE_W,
    LOOP,
    MASK_SCALE,
    MASK_TYPE,
    MAX_POSITIVE_X,
    MAX_POSITIVE_Y,
    MESH_SIZE,
    MESH_TYPE,
    MODE,
    NEATNESS,
    NOISE_AMOUNT,
    NOISE_TYPE,
    OCTAGON_TYPE,
    OFFSET_XY,
    OPACITY,
    OPAQUE,
    OVERLAY_MODE,
    OVERFLOW_OV_TYPE,
    PATTERN,
    PER,
    PERIOD,
    PHASE,
    PROFILE,
    RANDOM,
    R_C,
    RC_SLICE,
    RECTANGLE_TYPE,
    RESIZE_TYPE,
    REVERSE,
    SCATTER_COUNT,
    SEED,
    SHADOW_BLUR,
    SHAPED_TYPE,
    SLICE,
    SPECK_NOISE,
    SLICE_ORDER,
    SMOOTH,
    STENCIL_TYPE,
    SPREAD_WRAP_CR,
    STEPS,
    STRIP_HEIGHT,
    SWITCH,
    TAB,
    TAPE_WIDTH,
    TEXT,
    TRIANGLE_TYPE,
    UNSHARP_AMOUNT,
    UNSHARP_RADIUS,
    UNSHARP_THRESHOLD,
    WHIRL,
    WIDTH,
    WIRE_THICKNESS,
    WOBBLE_FACTOR,
    WRAP_TYPE
)
from roller_one_tip import Tip
from roller_port_generic import (
    PortAdd,
    PortAddAbove,
    PortAddAlt,
    PortBacking,
    PortBelow,
    PortBrush,
    PortBrushPD,
    PortBump,
    PortOverlayCamo,
    PortFillerCeramic,
    PortFillerChecker,
    PortFillerCircuit,
    PortFillerFence,
    PortFillerHoley,
    PortFillerMecha,
    PortFillerMirror,
    PortFillerRad,
    PortFillerStained,
    PortFillerStretch,
    PortFillerStripe,
    PortOverlayBevel,
    PortOverlayColor,
    PortOverlayOver,
    PortMargin,
    PortMod,
    PortNoise,
    PortResize,
    PortShadowBasic,
    PortStencil,
    PortStrip,
    PortTape,
    PortWrap,
    PortWrapAddAbove,
    PortWrapAlt,
    PortWrapBevel,
    PortWrapBurst,
    PortWrapClear,
    PortWrapCrumble,
    PortWrapDecay,
    PortWrapFill,
    PortWrapGlue,
    PortWrapGradual,
    PortWrapJoint,
    PortWrapPattern,
    PorWraptPipe,
    PortWrapWobble
)
from roller_port_option_list import PortFrame
from roller_port_image_choice import PortImageChoice
from roller_port_mask import PortMask
from roller_port_shadow import PortShadow
from roller_widget_button import FileButton, FolderButton
from roller_widget_check_button import CheckButton
from roller_widget_label import (
    CoverLabel,
    FilledLabel,
    LockedLabel,
    NextXLabel,
    PreviousXLabel,
    TrimLabel
)
from roller_widget_option_button import OptionButton, OptionListButton
from roller_widget_row import WidgetRow

# Define Dialog accessible Preset. Define Row configuration.
# Bump_________________________________________________________________________
BUMP = {
    wk.STILL: True,
    wk.DIALOG: PortBump,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TYPE, deepcopy(BUMP_TYPE)),
        (ok.MODE, deepcopy(OVERLAY_MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BLUR_X, deepcopy(BLUR_XY)),
        (ok.BLUR_Y, deepcopy(BLUR_XY)),
        (ok.NOISE, deepcopy(SPECK_NOISE)),
        (ok.BUMP_DEPTH, deepcopy(BUMP_DEPTH)),
        (ok.INVERT, deepcopy(INVERT))
    ]),
    wk.WIDGET: OptionButton
}
a_ = BUMP[wk.SUB]
a_[ok.BLUR_X][wk.VAL] = 48.
a_[ok.BLUR_Y][wk.VAL] = 6.
BUMP[wk.SUB][ok.TYPE][wk.VAL] = fb.NOISE

BUMP[wk.SUB][ok.NOISE].update({wk.LIMIT: (.0, 1.), wk.VAL: .075})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Brush Dialog_________________________________________________________________
BRUSH_DIALOG = {
    wk.STILL: True,
    wk.DIALOG: PortBrush,
    wk.SUB: OrderedDict([
        (ok.BRUSH_SIZE, deepcopy(BRUSH_SIZE)),
        (ok.BRUSH_SPACING, deepcopy(BRUSH_SPACING)),
        (ok.BRUSH_ANGLE, deepcopy(BRUSH_ANGLE)),
        (ok.ANGLE_JITTER, deepcopy(ANGLE_JITTER)),
        (ok.HARDNESS, deepcopy(HARDNESS)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.SEED, deepcopy(SEED)),
        (ok.BRUSH, deepcopy(BRUSH))
    ]),
    wk.WIDGET: OptionButton
}
BRUSH_DIALOG[wk.SUB][ok.OPACITY][wk.ISSUE] = vo.MATTER
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Image Choice_________________________________________________________________
IMAGE_CHOICE = {
    wk.STILL: True,
    wk.DIALOG: PortImageChoice,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TYPE, deepcopy(IMAGE_TYPE)),
        (ok.TAB, deepcopy(TAB)),
        (ok.IMAGE_NAME, deepcopy(IMAGE_NAME)),
        (ok.NEXT, {wk.WIDGET: NextXLabel}),
        (ok.PREVIOUS, {wk.WIDGET: PreviousXLabel}),
        (ok.LOOP, deepcopy(LOOP)),
        (ok.FILE, {
            wk.ISSUE: vo.MATTER,
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: FileButton
        }),
        (ok.FOLDER, {
            wk.ISSUE: vo.MATTER,
            wk.TIPPER: make_text_tip,
            wk.VAL: "",
            wk.WIDGET: FolderButton
        }),
        (ok.FILTER, deepcopy(FILTER)),
        (ok.FOLDER_ORDER, deepcopy(FOLDER_ORDER)),
        (ok.LAYERED, deepcopy(LAYERED)),
        (ok.LAYER_ORDER, deepcopy(LAYER_ORDER)),
        (ok.SLICE, deepcopy(SLICE)),
        (ok.ROW, deepcopy(RC_SLICE)),
        (ok.COLUMN, deepcopy(RC_SLICE)),
        (ok.SLICE_ORDER, deepcopy(SLICE_ORDER)),
        (ok.AUTOCROP, deepcopy(AUTOCROP)),
        (ok.SEED, deepcopy(SEED))
    ]),
    wk.WIDGET: OptionButton
}

# Mask_________________________________________________________________________
MASK = {
    wk.STILL: True,
    wk.DIALOG: PortMask,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TYPE, deepcopy(MASK_TYPE)),
        (ok.CORNER_TYPE, deepcopy(CORNER_TYPE)),
        (ok.HEXAGON_TYPE, deepcopy(HEXAGON_TYPE)),
        (ok.OCTAGON_TYPE, deepcopy(OCTAGON_TYPE)),
        (ok.RECTANGLE_TYPE, deepcopy(RECTANGLE_TYPE)),
        (ok.TRIANGLE_TYPE, deepcopy(TRIANGLE_TYPE)),
        (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
        (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
        (ok.TEXT, deepcopy(TEXT)),
        (ok.HORZ_SCALE, deepcopy(MASK_SCALE)),
        (ok.VERT_SCALE, deepcopy(MASK_SCALE)),
        (ok.PUPIL_SCALE, deepcopy(MASK_SCALE)),
        (ok.PARALLELOGRAM_SCALE, deepcopy(MASK_SCALE)),
        (ok.FEATHER, deepcopy(FEATHER)),
        (ok.STEPS, deepcopy(STEPS)),
        (ok.AMP, deepcopy(AMP)),
        (ok.SMOOTH, deepcopy(SMOOTH)),
        (ok.ANGLE, deepcopy(ANGLE)),
        (ok.CONTRACT, deepcopy(CONTRACT)),
        (ok.SEED, deepcopy(SEED)),
        (ok.CUT_OUT, deepcopy(CUT_OUT)),
        (ok.FONT, deepcopy(FONT)),
        (ok.RW1, {
            wk.SUB: OrderedDict([
                (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
                (ok.BRUSH_D, deepcopy(BRUSH_DIALOG))
            ]),
            wk.WIDGET: WidgetRow
        })
    ]),
    wk.WIDGET: OptionButton
}
a_ = MASK[wk.SUB]
a_[ok.FEATHER][wk.VAL] = 0.
a_[ok.PUPIL_SCALE][wk.VAL] = .33
a_[ok.PARALLELOGRAM_SCALE][wk.VAL] = .5
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Resize ______________________________________________________________________
RESIZE = {
    wk.STILL: True,
    wk.DIALOG: PortResize,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(RESIZE_TYPE)),
        (ok.LOCKED, {wk.WIDGET: LockedLabel}),
        (ok.TRIM, {wk.WIDGET: TrimLabel}),
        (ok.FILLED, {wk.WIDGET: FilledLabel}),
        (ok.COVER, {wk.WIDGET: CoverLabel}),
        (ok.FIXED_W, deepcopy(FIXED_SIZE)),
        (ok.FIXED_H, deepcopy(FIXED_SIZE)),
        (ok.WIDTH, deepcopy(FACTOR_SIZE)),
        (ok.HEIGHT, deepcopy(FACTOR_SIZE)),
        (ok.CROP_X, deepcopy(CROP_X)),
        (ok.CROP_Y, deepcopy(CROP_Y)),
        (ok.CROP_W, deepcopy(FIXED_SIZE)),
        (ok.CROP_H, deepcopy(FIXED_SIZE))
    ]),
    wk.WIDGET: OptionButton
}
a_ = RESIZE[wk.SUB]
a_[ok.FIXED_W][wk.TOOLTIP] = Tip.FIXED_W
a_[ok.WIDTH][wk.TOOLTIP] = Tip.WH_FACTOR
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Noise _______________________________________________________________________
NOISE_D = {
    wk.STILL: True,
    wk.DIALOG: PortNoise,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TYPE, deepcopy(NOISE_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BLUR, deepcopy(BLUR)),
        (ok.NOISE_AMOUNT, deepcopy(NOISE_AMOUNT)),
        (ok.SPECK_NOISE, deepcopy(SPECK_NOISE)),
        (ok.SEED, deepcopy(SEED)),
        (ok.BUMP, deepcopy(BUMP))
    ]),
    wk.WIDGET: OptionButton
}
NOISE_D[wk.SUB][ok.BLUR].update({wk.RANDOM_Q: (.0, 15.), wk.VAL: 1.5})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Margin_______________________________________________________________________
# Use for both Caption and for an option group.
MARGIN = OrderedDict([
    (wk.STILL, True),
    (wk.DIALOG, PortMargin),
    (wk.SUB, OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TOP, deepcopy(MAX_POSITIVE_Y)),
        (ok.BOTTOM, deepcopy(MAX_POSITIVE_Y)),
        (ok.LEFT, deepcopy(MAX_POSITIVE_X)),
        (ok.RIGHT, deepcopy(MAX_POSITIVE_X)),
        (ok.PER, deepcopy(PER))
    ])),
    (wk.WIDGET, OptionButton)
])

# Shadow_______________________________________________________________________
SELECTED_ROW = {'node': {'selected_row': {wk.VAL: 0}}}
SWITCH_GROUP = {ok.SWITCH: deepcopy(SWITCH)}
INNER_SHADOW = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.INTENSITY, deepcopy(INTENSITY)),
    (ok.BLUR, deepcopy(SHADOW_BLUR)),
    (ok.OFFSET_X, deepcopy(OFFSET_XY)),
    (ok.OFFSET_Y, deepcopy(OFFSET_XY)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (bk.RANDOM, deepcopy(RANDOM))
])
SHADOW_NUM = OrderedDict([
    (ok.MODE, deepcopy(MODE)),
    (ok.INTENSITY, deepcopy(INTENSITY)),
    (ok.BLUR, deepcopy(SHADOW_BLUR)),
    (ok.OFFSET_X, deepcopy(OFFSET_XY)),
    (ok.OFFSET_Y, deepcopy(OFFSET_XY)),
    (ok.COLOR_1, deepcopy(COLOR_1)),
    (bk.RANDOM, deepcopy(RANDOM))
])
SHADOW_1 = deepcopy(SHADOW_NUM)
SHADOW_2 = deepcopy(SHADOW_NUM)
SHADOW = {
    wk.STILL: True,
    wk.DIALOG: PortShadow,
    wk.SUB: OrderedDict([
        (sk.SHADOW_SWITCH, deepcopy(SWITCH_GROUP)),
        (sk.SHADOW, deepcopy(SELECTED_ROW)),
        (sk.SHADOW_1, deepcopy(SHADOW_1)),
        (sk.SHADOW_2, deepcopy(SHADOW_2)),
        (sk.INNER_SHADOW, deepcopy(INNER_SHADOW)),
    ]),
    wk.WIDGET: OptionButton
}
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Shadow Basic_________________________________________________________________
SHADOW_BASIC = {
    wk.STILL: True,
    wk.DIALOG: PortShadowBasic,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.INTENSITY, deepcopy(INTENSITY)),
        (ok.BLUR, deepcopy(SHADOW_BLUR)),
        (ok.COLOR_1, deepcopy(COLOR_1))
    ]),
    wk.WIDGET: OptionButton
}

# Tape__________________________________________________________________
WRAP_TA = {
    wk.STILL: True,
    wk.DIALOG: PortTape,
    wk.SUB: OrderedDict([
        (ok.LENGTH, deepcopy(LENGTH)),
        (ok.WIDTH, deepcopy(TAPE_WIDTH)),
        (ok.ANGLE_SHIFT, deepcopy(ANGLE_SHIFT)),
        (ok.CORNER_SHIFT, deepcopy(CORNER_SHIFT)),
        (ok.LENGTH_SHIFT, deepcopy(LENGTH_SHIFT)),
        (ok.SEED, deepcopy(SEED))
    ]),
    wk.WIDGET: OptionButton
}

# Mod__________________________________________________________________________
MOD = {
    wk.STILL: True,
    wk.DIALOG: PortMod,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.BLUR, deepcopy(BLUR)),
        (ok.SATURATION, deepcopy(HSL)),
        (ok.BRIGHTNESS, deepcopy(HSL)),
        (ok.INVERT, deepcopy(INVERT)),
        (ok.FLIP_H, deepcopy(FLIP)),
        (ok.FLIP_V, deepcopy(FLIP))
    ]),
    wk.WIDGET: OptionButton
}

# Below________________________________________________________________________
BELOW = {
    wk.STILL: True,
    wk.DIALOG: PortBelow,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.OPAQUE, deepcopy(OPAQUE)),
        (ok.MOD, deepcopy(MOD))
    ]),
    wk.WIDGET: OptionButton
}

# Add__________________________________________________________________________
ADD = {
    wk.STILL: True,
    wk.DIALOG: PortAdd,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.RW1, deepcopy({
            wk.SUB: OrderedDict([
                (ok.NOISE_D, deepcopy(NOISE_D)),
                (ok.BELOW, deepcopy(BELOW))
            ]),
            wk.WIDGET: WidgetRow
        })),
        (ok.BRW, {
            wk.SUB: OrderedDict([
                (ok.BUMP, deepcopy(BUMP)),
                (ok.SHADOW, deepcopy(SHADOW))
            ]),
            wk.WIDGET: WidgetRow
        })
    ]),
    wk.WIDGET: OptionButton
}

# Add Above___________________________________________________________________
ADD_ABOVE = {
    wk.STILL: True,
    wk.DIALOG: PortAddAbove,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.NOISE_D, deepcopy(NOISE_D)),
        (ok.BUMP, deepcopy(BUMP))
    ]),
    wk.WIDGET: OptionButton
}

# Add Alt______________________________________________________________________
ADD_ALT = {
    wk.STILL: True,
    wk.DIALOG: PortAddAlt,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.NOISE_D, deepcopy(NOISE_D)),
        (ok.BELOW, deepcopy(BELOW)),
        (ok.BUMP, deepcopy(BUMP))
    ]),
    wk.WIDGET: OptionButton
}

# Backing______________________________________________________________________
BACKING = {
    wk.STILL: True,
    wk.DIALOG: PortBacking,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.TYPE, deepcopy(BACKING_TYPE)),
        (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
        (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
        (ok.SEED, deepcopy(SEED)),
        (ok.FILLED, {
            wk.ISSUE: vo.MATTER,
            wk.TIPPER: make_bool_tip,
            wk.VAL: 1,
            wk.WIDGET: CheckButton
        }),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.PATTERN, deepcopy(PATTERN)),
        (ok.IMAGE_CHOICE, IMAGE_CHOICE),
        (ok.GRADIENT, deepcopy(GRADIENT)),
        (ok.RW1, deepcopy(
            {
                wk.SUB: OrderedDict([
                    (ok.MOD, deepcopy(MOD)),
                    (ok.BUMP, deepcopy(BUMP))
                ]),
                wk.WIDGET: WidgetRow
            }
        ))
    ]),
    wk.WIDGET: OptionButton
}

# Brushy Brush_________________________________________________________________
BRUSH_D1 = {
    wk.STILL: True,
    wk.DIALOG: PortBrushPD,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BRUSH_SIZE, deepcopy(BRUSH_SIZE)),
        (ok.BRUSH_SPACING, deepcopy(BRUSH_SPACING)),
        (ok.BRUSH_ANGLE, deepcopy(BRUSH_ANGLE)),
        (ok.ANGLE_JITTER, deepcopy(ANGLE_JITTER)),
        (ok.HARDNESS, deepcopy(HARDNESS)),
        (ok.SEED, deepcopy(SEED)),
        (ok.CLIP, deepcopy(CLIP)),
        (ok.BRW, {
            wk.SUB: OrderedDict([
                (ok.BRUSH, deepcopy(BRUSH)),
                (ok.ADD_ALT, deepcopy(ADD_ALT))
            ]),
            wk.WIDGET: WidgetRow
        }),
    ]),
    wk.WIDGET: OptionButton
}
BRUSH_D1[wk.SUB][ok.CLIP][wk.VAL] = 1
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Ceramic Filler_______________________________________________________________
FILLER_CE = {
    wk.STILL: True,
    wk.DIALOG: PortFillerCeramic,
    wk.SUB: OrderedDict([
        (ok.MESH_TYPE, deepcopy(MESH_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.MESH_SIZE, deepcopy(MESH_SIZE)),
        (ok.SEED, deepcopy(SEED)),
        (ok.BRW, {
            wk.SUB: OrderedDict([
                (ok.MOD, deepcopy(MOD)),
                (ok.ADD_ALT, deepcopy(ADD_ALT))
            ]),
            wk.WIDGET: WidgetRow
        })
    ]),
    wk.WIDGET: OptionButton
}

# Checker Filler_______________________________________________________________
FILLER_CH = {
    wk.STILL: True,
    wk.DIALOG: PortFillerChecker,
    wk.SUB: OrderedDict([
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.ROW, deepcopy(R_C)),
        (ok.COLUMN, deepcopy(R_C)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

for i_ in (ok.ROW, ok.COLUMN):
    FILLER_CH[wk.SUB][i_][wk.VAL] = 15.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Circuit Filler___________________________________________________________
FILLER_CI = {
    wk.STILL: True,
    wk.DIALOG: PortFillerCircuit,
    wk.SUB: OrderedDict([
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.CFW, deepcopy(CFW)),
        (ok.ROW, deepcopy(R_C)),
        (ok.COLUMN, deepcopy(R_C)),
        (ok.SEED, deepcopy(SEED))
    ]),
    wk.WIDGET: OptionButton
}

# Fence Filler_________________________________________________________________
FILLER_FE = {
    wk.STILL: True,
    wk.DIALOG: PortFillerFence,
    wk.SUB: OrderedDict([
        (ok.MESH_TYPE, deepcopy(MESH_TYPE)),
        (ok.MESH_SIZE, deepcopy(MESH_SIZE)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.WIRE_THICKNESS, deepcopy(WIRE_THICKNESS)),
        (ok.NEATNESS, deepcopy(NEATNESS)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

# Holey Filler_________________________________________________________________
FILLER_HO = {
    wk.STILL: True,
    wk.DIALOG: PortFillerHoley,
    wk.SUB: OrderedDict([
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.CIRCLE_DIAMETER, deepcopy(CIRCLE_DIAMETER)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

# Mecha Filler__________________________________________________________
FILLER_ME = {
    wk.STILL: True,
    wk.DIALOG: PortFillerMecha,
    wk.SUB: OrderedDict([
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.GAP_W, deepcopy(GAP_W)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

# Mirror Filler________________________________________________________________
FILLER_MI = {
    wk.STILL: True,
    wk.DIALOG: PortFillerMirror,
    wk.SUB: OrderedDict([
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.CFW, deepcopy(CFW)),
        (ok.ROW, deepcopy(R_C)),
        (ok.COLUMN, deepcopy(R_C)),
        (ok.SCATTER_COUNT, deepcopy(SCATTER_COUNT)),
        (ok.SEED, deepcopy(SEED)),
    ]),
    wk.WIDGET: OptionButton
}

for i_ in (ok.ROW, ok.COLUMN):
    FILLER_MI[wk.SUB][i_][wk.LIMIT] = 3, 100
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Rad Filler___________________________________________________________________
FILLER_RA = {
    wk.STILL: True,
    wk.DIALOG: PortFillerRad,
    wk.SUB: OrderedDict([
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.CFW, deepcopy(CFW)),
        (ok.ROW, deepcopy(R_C)),
        (ok.COLUMN, deepcopy(R_C)),
        (ok.AMPLITUDE, deepcopy(AMPLITUDE)),
        (ok.PERIOD, deepcopy(PERIOD)),
        (ok.WHIRL, deepcopy(WHIRL))
    ]),
    wk.WIDGET: OptionButton
}

for i_ in (ok.ROW, ok.COLUMN):
    FILLER_CI[wk.SUB][i_][wk.LIMIT] = 4, 999
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Stained Filler_______________________________________________________________
FILLER_S1 = {
    wk.STILL: True,
    wk.DIALOG: PortFillerStained,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.PANE_W, deepcopy(WIDTH)),
        (ok.ANGLE, deepcopy(ANGLE)),
        (ok.SEED, deepcopy(SEED)),
        (ok.BRW, {
            wk.SUB: OrderedDict([
                (ok.MOD, deepcopy(MOD)),
                (ok.ADD_ALT, deepcopy(ADD_ALT))
            ]),
            wk.WIDGET: WidgetRow
        })
    ]),
    wk.WIDGET: OptionButton
}

a_ = FILLER_S1[wk.SUB]
a_[ok.PANE_W][wk.RANDOM_Q] = 25, 100
a_[ok.PANE_W][wk.VAL] = 72.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Stretch Filler_______________________________________________________________
FILLER_S2 = {
    wk.STILL: True,
    wk.DIALOG: PortFillerStretch,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BRW, {
            wk.SUB: OrderedDict([
                (ok.MOD, deepcopy(MOD)),
                (ok.ADD_ALT, deepcopy(ADD_ALT))
            ]),
            wk.WIDGET: WidgetRow
        })
    ]),
    wk.WIDGET: OptionButton
}
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Stripe Filler__________________________________________________________
FILLER_S3 = {
    wk.STILL: True,
    wk.DIALOG: PortFillerStripe,
    wk.SUB: OrderedDict([
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.LINE_W, deepcopy(LINE_W)),
        (ok.GAP_W, deepcopy(GAP_W)),
        (ok.ANGLE, deepcopy(ANGLE))
    ]),
    wk.WIDGET: OptionButton
}

# Overlay Bevel________________________________________________________________
OVERLAY_BE = {
    wk.STILL: True,
    wk.DIALOG: PortOverlayBevel,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.PATTERN, deepcopy(PATTERN)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}
OVERLAY_BE[wk.SUB][ok.MODE][wk.VAL] = "Overlay"
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Overlay Camo_________________________________________________________________
OVERLAY_CA = {
    wk.STILL: True,
    wk.DIALOG: PortOverlayCamo,
    wk.SUB: OrderedDict([
        (ok.CAMO_TYPE, deepcopy(CAMO_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.SATURATION, deepcopy(HSL)),
        (ok.SEED, deepcopy(SEED)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}
a_ = OVERLAY_CA[wk.SUB]
a_[ok.MODE][wk.VAL] = "Hard Light"
a_[ok.SATURATION][wk.VAL] = 30.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Overlay Color________________________________________________________________
OVERLAY_CO = {
    wk.STILL: True,
    wk.DIALOG: PortOverlayColor,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(OVERLAY_MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}
a_ = OVERLAY_CO[wk.SUB]
a_[ok.COLOR_1][wk.VAL] = 231, 231, 194
a_[ok.OPACITY][wk.VAL] = 30.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Overlay Over___________________________________________________________
OVERLAY_OV = {
    wk.STILL: True,
    wk.DIALOG: PortOverlayOver,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(OVERFLOW_OV_TYPE)),
        (ok.GRADIENT_TYPE, deepcopy(GRADIENT_TYPE)),
        (ok.GRADIENT_ANGLE, deepcopy(GRADIENT_ANGLE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.SEED, deepcopy(SEED)),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
        (ok.GRADIENT, deepcopy(GRADIENT)),
        (ok.PATTERN, deepcopy(PATTERN)),
        (ok.BRW, {
            wk.SUB: OrderedDict([
                (ok.MOD, deepcopy(MOD)),
                (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
            ]),
            wk.WIDGET: WidgetRow
        })
    ]),
    wk.WIDGET: OptionButton
}

# Strip________________________________________________________________________
STRIP = {
    wk.STILL: True,
    wk.DIALOG: PortStrip,
    wk.SUB: OrderedDict([
        (ok.SWITCH, deepcopy(SWITCH)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.HEIGHT, deepcopy(STRIP_HEIGHT)),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.ADD, deepcopy(ADD))
    ]),
    wk.WIDGET: OptionButton
}
a_ = STRIP[wk.SUB]
a_[ok.COLOR_1][wk.VAL] = 127, 127, 127
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap_________________________________________________________________________
WRAP = {
    wk.STILL: True,
    wk.DIALOG: PortWrap,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.DEPTH, deepcopy(BLUR)),
        (ok.CONTRAST, deepcopy(CONTRAST)),
        (ok.SOFTEN, deepcopy(BLUR)),
        (ok.EMBOSS, deepcopy(EMBOSS)),
        (ok.COLOR_1, deepcopy(COLOR_1))
    ]),
    wk.WIDGET: OptionButton
}

# Wrap Above___________________________________________________________________
WRAP_AB = {
    wk.STILL: True,
    wk.DIALOG: PortWrapAddAbove,
    wk.SUB: OrderedDict([]),
    wk.WIDGET: OptionButton
}
WRAP_AB[wk.SUB].update(WRAP[wk.SUB])
WRAP_AB[wk.SUB][ok.ADD_ABOVE] = deepcopy(ADD_ABOVE)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Alt_____________________________________________________________________
WRAP_AL = {
    wk.STILL: True,
    wk.DIALOG: PortWrapAlt,
    wk.SUB: OrderedDict([]),
    wk.WIDGET: OptionButton
}
WRAP_AL[wk.SUB].update(WRAP[wk.SUB])
WRAP_AL[wk.SUB][ok.ADD_ALT] = deepcopy(ADD_ALT)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Bevel___________________________________________________________________
WRAP_BE = {
    wk.STILL: True,
    wk.DIALOG: PortWrapBevel,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.BEVEL_W, deepcopy(BEVEL_W)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Burst___________________________________________________________________
WRAP_BU = {
    wk.STILL: True,
    wk.DIALOG: PortWrapBurst,
    wk.SUB: OrderedDict([
        (ok.SHAPED_TYPE, deepcopy(SHAPED_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.UNSHARP_AMOUNT, deepcopy(UNSHARP_AMOUNT)),
        (ok.UNSHARP_RADIUS, deepcopy(UNSHARP_RADIUS)),
        (ok.UNSHARP_THRESHOLD, deepcopy(UNSHARP_THRESHOLD)),
        (ok.RW1, {
            wk.SUB: OrderedDict([
                (ok.INVERT, deepcopy(INVERT)),
                (ok.REVERSE, deepcopy(REVERSE))
            ]),
            wk.WIDGET: WidgetRow
        }),
        (ok.GRADIENT, deepcopy(GRADIENT))
    ]),
    wk.WIDGET: OptionButton
}
WRAP_BU[wk.SUB][ok.GRADIENT][wk.VAL] = "Brushed Aluminium"
WRAP_BU[wk.SUB][ok.WIDTH][wk.VAL] = 50.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Clear___________________________________________________________________
WRAP_CL = {
    wk.STILL: True,
    wk.DIALOG: PortWrapClear,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.INNER_FRAME_W, deepcopy(INNER_FRAME_W)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}
WRAP_CL[wk.SUB][ok.WIDTH][wk.VAL] = 30.
WRAP_CL[wk.SUB][ok.OPACITY][wk.VAL] = 50.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Crumble_________________________________________________________________
WRAP_CR = {
    wk.STILL: True,
    wk.DIALOG: PortWrapCrumble,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.SPREAD, deepcopy(SPREAD_WRAP_CR)),
        (ok.DISTRESS, deepcopy(DISTRESS)),
        (ok.SEED, deepcopy(SEED)),
    ]),
    wk.WIDGET: OptionButton
}

WRAP_CR[wk.SUB][ok.WIDTH].update({wk.RANDOM_Q: (15, 35), wk.VAL: 15.})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Decay___________________________________________________________________
WRAP_DE = {
    wk.STILL: True,
    wk.DIALOG: PortWrapDecay,
    wk.SUB: OrderedDict([
        (ok.EDGE_TYPE, deepcopy(EDGE_TYPE)),
        (ok.EDGE_MODE, deepcopy(EDGE_MODE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.POST_BLUR, deepcopy(BLUR)),
        (ok.COLORIZE_OPACITY, deepcopy(OPACITY)),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.COLORIZE, deepcopy(COLORIZE)),
    ]),
    wk.WIDGET: OptionButton
}
WRAP_DE[wk.SUB][ok.WIDTH][wk.VAL] = 80.
WRAP_DE[wk.SUB][ok.COLOR_1][wk.VAL] = 175, 90, 10
WRAP_DE[wk.SUB][ok.COLORIZE_OPACITY][wk.VAL] = 70.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Fill____________________________________________________________________
WRAP_FI = {
    wk.STILL: True,
    wk.DIALOG: PortWrapFill,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.FILLER_W, deepcopy(WIDTH)),
        (ok.DEPTH, deepcopy(BLUR)),
        (ok.CONTRAST, deepcopy(CONTRAST)),
        (ok.SOFTEN, deepcopy(BLUR)),
        (ok.EMBOSS, deepcopy(EMBOSS)),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.ADD_ALT, deepcopy(ADD_ALT))
    ]),
    wk.WIDGET: OptionButton
}

# Wrap Glue____________________________________________________________________
WRAP_GL = {
    wk.STILL: True,
    wk.DIALOG: PortWrapGlue,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.SOFTEN, deepcopy(BLUR)),
        (ok.AMPLITUDE, deepcopy(AMPLITUDE)),
        (ok.PERIOD, deepcopy(PERIOD)),
        (ok.PHASE, deepcopy(PHASE)),
        (ok.SEED, deepcopy(SEED))
    ]),
    wk.WIDGET: OptionButton
}
WRAP_GL[wk.SUB][ok.MODE][wk.VAL] = "Overlay"
WRAP_GL[wk.SUB][ok.WIDTH][wk.VAL] = 5.
WRAP_GL[wk.SUB][ok.SOFTEN].update({wk.RANDOM_Q: (1., 3.), wk.VAL: 2.})
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Gradual_________________________________________________________________
WRAP_GR = {
    wk.STILL: True,
    wk.DIALOG: PortWrapGradual,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.COLOR_2A, deepcopy(COLOR_2A))
    ]),
    wk.WIDGET: OptionButton
}

WRAP_GR[wk.SUB][ok.COLOR_2A][wk.VAL] = (160, 105, 28, 255), (116, 77, 43, 255)
WRAP_GR[wk.SUB][ok.WIDTH][wk.VAL] = 30.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Joint___________________________________________________________________
WRAP_JO = {
    wk.STILL: True,
    wk.DIALOG: PortWrapJoint,
    wk.SUB: OrderedDict([
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.BRUSH_SIZE, deepcopy(BRUSH_SIZE)),
        (ok.CLIP, deepcopy(CLIP))
    ]),
    wk.WIDGET: OptionButton
}
WRAP_JO[wk.SUB][ok.CLIP][wk.VAL] = 1
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

# Wrap Pipe____________________________________________________________________
WRAP_PI = {
    wk.STILL: True,
    wk.DIALOG: PorWraptPipe,
    wk.SUB: OrderedDict([
        (ok.PROFILE, deepcopy(PROFILE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(WIDTH)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}

# Wrap Pattern_________________________________________________________________
WRAP_PA = {
    wk.STILL: True,
    wk.DIALOG: PortWrapPattern,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.FILLER_W, deepcopy(WIDTH)),
        (ok.DEPTH, deepcopy(BLUR)),
        (ok.CONTRAST, deepcopy(CONTRAST)),
        (ok.SOFTEN, deepcopy(BLUR)),
        (ok.EMBOSS, deepcopy(EMBOSS)),
        (ok.COLOR_1, deepcopy(COLOR_1))
    ]),
    wk.WIDGET: OptionButton
}

# Wrap Wobble__________________________________________________________________
WRAP_WO = {
    wk.STILL: True,
    wk.DIALOG: PortWrapWobble,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(WRAP_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.WIDTH, deepcopy(FRAME_W)),
        (ok.DEPTH, deepcopy(BLUR)),
        (ok.CONTRAST, deepcopy(CONTRAST)),
        (ok.SOFTEN, deepcopy(BLUR)),
        (ok.WOBBLE_FACTOR, deepcopy(WOBBLE_FACTOR)),
        (ok.SEED, deepcopy(SEED)),
        (ok.EMBOSS, deepcopy(EMBOSS)),
        (ok.COLOR_1, deepcopy(COLOR_1)),
    ]),
    wk.WIDGET: OptionButton
}
a = WRAP_WO[wk.SUB]
a[ok.TYPE][wk.VAL] = ff.ROUNDED
a[ok.WIDTH].update({wk.RANDOM_Q: (1, 50), wk.VAL: 12.})
a[ok.DEPTH][wk.VAL] = 10.
a[ok.CONTRAST][wk.VAL] = -36
a[ok.SOFTEN][wk.VAL] = 7.
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


for i_ in (WRAP, WRAP_AB, WRAP_AL, WRAP_FI, WRAP_PA, WRAP_WO):
    a_ = i_[wk.SUB]
    a_[ok.EMBOSS][wk.VAL] = 1
    a_[ok.COLOR_1][wk.VAL] = 127, 127, 127

    a_[ok.DEPTH].update({
        wk.LIMIT: (1., 100.), wk.RANDOM_Q: (1., 25.), wk.VAL: 1.
    })
    a_[ok.SOFTEN].update({
        wk.LIMIT: (.0, 50.),
        wk.RANDOM_Q: (.0, 8.), wk.STEP_INCR: .1, wk.VAL: .0
    })

# Stencil Over_________________________________________________________________
STENCIL = {
    wk.STILL: True,
    wk.DIALOG: PortStencil,
    wk.SUB: OrderedDict([
        (ok.TYPE, deepcopy(STENCIL_TYPE)),
        (ok.MODE, deepcopy(MODE)),
        (ok.OPACITY, deepcopy(OPACITY)),
        (ok.ADD_ABOVE, deepcopy(ADD_ABOVE))
    ]),
    wk.WIDGET: OptionButton
}

# Basic________________________________________________________________________
BASIC = OrderedDict([(ok.BRW, {
    wk.SUB: OrderedDict([
        (ok.WRAP, deepcopy(WRAP)),
        (ok.ADD, deepcopy(ADD))
    ]),
    wk.WIDGET: WidgetRow
})])

# Frame________________________________________________________________________
FRAME = {
    wk.STILL: True,
    wk.DIALOG: PortFrame,
    wk.ISSUE: vo.NULL,              # Needed by PerGroup.
    wk.VAL: {
        ok.SWITCH: SWITCH[wk.VAL],
        ek.BASIC: scour({}, BASIC, wk.VAL)
    },
    wk.WIDGET: OptionListButton
}

# Row _________________________________________________________________________
ARW = {
    wk.SUB: OrderedDict([
        (ok.ADD_ALT, deepcopy(ADD_ALT)),
        (bk.RANDOM, deepcopy(RANDOM))
    ]),
    wk.WIDGET: WidgetRow
}

# Font / Color Row_____________________________________________________________
FCM = {
    wk.SUB: OrderedDict([
        (ok.FONT, deepcopy(FONT)),
        (ok.COLOR_1, deepcopy(COLOR_1)),
        (ok.MARGIN, deepcopy(MARGIN))
    ]),
    wk.WIDGET: WidgetRow
}
FCM[wk.SUB][ok.COLOR_1][wk.VAL] = 0, 0, 0
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

GMR = {
    wk.SUB: OrderedDict([
        (ok.GRADIENT, deepcopy(GRADIENT)),
        (ok.MOD, deepcopy(MOD))
    ]),
    wk.WIDGET: WidgetRow
}
IDR = {
    wk.SUB: OrderedDict([
        (ok.INVERT, deepcopy(INVERT)),
        (ok.DESATURATE, deepcopy(DESATURATE)),
    ]),
    wk.WIDGET: WidgetRow
}
IMR = {
    wk.SUB: OrderedDict([
        (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
        (ok.MASK, deepcopy(MASK)),
    ]),
    wk.WIDGET: WidgetRow
}
IRM = {
    wk.SUB: OrderedDict([
        (ok.IMAGE_CHOICE, deepcopy(IMAGE_CHOICE)),
        (ok.RESIZE, deepcopy(RESIZE)),
        (ok.MASK, deepcopy(MASK))
    ]),
    wk.WIDGET: WidgetRow
}

# Lead / Trail Row_____________________________________________________________
LTR = {
    wk.COLUMN_TEXT: "Lead / Trail Text",
    wk.SUB: OrderedDict([
        (ok.LEAD, deepcopy(TEXT)),
        (ok.TRAIL, deepcopy(TEXT)),
    ]),
    wk.WIDGET: WidgetRow
}
LTR[wk.SUB][ok.LEAD][wk.TOOLTIP] = Tip.LEAD
LTR[wk.SUB][ok.TRAIL][wk.TOOLTIP] = Tip.TRAIL
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯

MAF = {
    wk.SUB: OrderedDict([
        (ok.MOD, deepcopy(MOD)),
        (ok.ADD, deepcopy(ADD)),
        (ok.FRAME, deepcopy(FRAME))
    ]),
    wk.WIDGET: WidgetRow
}
MAW = {
    wk.SUB: OrderedDict([
        (ok.MOD, deepcopy(MOD)),
        (ok.ADD, deepcopy(ADD))
    ]),
    wk.WIDGET: WidgetRow
}
MFR = {
    wk.SUB: OrderedDict([
        (ok.MASK, deepcopy(MASK)),
        (ok.FRAME, deepcopy(FRAME))
    ]),
    wk.WIDGET: WidgetRow
}
P3R = {
    wk.SUB: OrderedDict([
        (ok.PATTERN_1, deepcopy(PATTERN)),
        (ok.PATTERN_2, deepcopy(PATTERN)),
        (ok.PATTERN_3, deepcopy(PATTERN))
    ]),
    wk.WIDGET: WidgetRow
}
MAR = {
    wk.SUB: OrderedDict([
        (ok.MOD, deepcopy(MOD)),
        (ok.ADD_ALT, deepcopy(ADD_ALT)),
        (bk.RANDOM, deepcopy(RANDOM))
    ]),
    wk.WIDGET: WidgetRow
}
