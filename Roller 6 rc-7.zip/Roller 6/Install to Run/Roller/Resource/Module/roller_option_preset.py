#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_a_contain import The
from roller_a_oz import make_preset_path, pickle_load
from roller_constant_for import Signal as si
from roller_constant_key import (
    BackdropStyle as by,
    Button as bk,
    Frame as ff,
    Group as gk,
    Item as ie,
    Material as ma,
    Option as ok,
    Step as sk,
    Widget as wk
)
from roller_def_access import get_default_value, get_group_keys
from roller_def_tree import DEFAULT_MODEL_BRANCH, SPLIT_KEY
from roller_model_id import ModelId
from roller_one_extract import get_option_list_key
from roller_one_helm import Helm
from roller_view_step import (
    get_branch_value_d,
    make_panel_key,
    make_nav_key,
    translate_to_id,
    translate_to_name
)
from roller_widget_button import ManagePresetButton, SaveButton
from roller_widget_node import add_node_to_list
from roller_widget_row import WidgetRow
from roller_port_preset import PortPreset
from roller_port_save import PortSave
import os


def _sync_backdrop_style(d):
    """
    Insert a default Backdrop Style Preset into
    an OptionList Preset for syncing the option.

    d: dict
        BackdropStyle.OptionList Preset

    Return: dict
        OptionList Preset
    """
    k = get_option_list_key(d)
    if k not in by.KEY_LIST:
        # Replace a missing Backdrop Style option.
        k = by.KEY_LIST[0]
    return _do_option_list(k)


def _sync_frame(d):
    """
    Insert a default Frame Preset into
    an OptionList Preset for syncing the option.

    d: dict
        Frame.OptionList Preset

    Return: dict
        OptionList Preset
    """
    k = get_option_list_key(d)
    if k not in ff.KEY_LIST:
        # Replace a missing Frame option.
        k = ff.KEY_LIST[0]
    return _do_option_list(k)


def _sync_heat(d):
    """
    Make a default Heat Preset from a loading option.

    d: dict
        a loading Heat Preset

    Return: dict
        a matching default Heat Preset
    """
    # a matching default Heat Preset, 'e'
    e = {}

    # Verify Material key.
    for i in d:
        if i in ma.KEY_Q:
            e[i] = d[i]
    return e


def _do_option_list(k):
    """
    Make a default OptionList Preset with a new option.

    _k: string
        Frame or Backdrop Style key

    Return: dict
        OptionList Preset
    """
    return {k: get_default_value(k), ok.SWITCH: 0}


ROUTE_SYNC = {
    ok.BACKDROP_STYLE: _sync_backdrop_style,
    ok.FRAME: _sync_frame,
    ok.HEAT: _sync_heat
}


def add_to_d(d, e):
    """
    Recursively add missing dict key/items to a loaded
    dict using a default dictionary as a source.

    d: dict
        Receive missing option.

    e: dict
        default
    """
    for k, a in e.items():
        if k == ok.PRESET:
            pass
        elif k not in d:
            d[k] = a
        else:
            m, m1 = isinstance(d[k], dict), isinstance(a, dict)

            if m and m1:
                add_to_d(d[k], a)
            elif m or m1:
                d[k] = a


def fix_preset(d, e, any_group):
    """
    Recursively synchronize a loading Preset with its default Preset value.

    d: dict
        loading Preset

    e: dict
        default Preset

    any_group: AnyGroup
        owner of the option
    """
    if not (any_group.item.item == ie.TYPE and ok.PER in d):
        # Has a Preset dict for Per Cell cell value.
        sync_per(d, e)
        sync_dynamic(d, e)
    sync_preset(d, e)


def get_model_default_value(any_group):
    """
    Create a SuperPreset with a Model's default value.

    group_key: string
        Identify Model SuperPreset.

    Return: dict
        Model specific SuperPreset
    """
    d = {}
    group_key = any_group.item.key
    model_type = group_key.split(",")[1].strip()
    name = ModelId.get_name(any_group.item.model.model_id)

    # the default Model branch list, 'q'
    q = DEFAULT_MODEL_BRANCH[model_type]

    for i in q:
        if i[-1] not in SPLIT_KEY:
            e = get_default_value(i[-1])

        else:
            e = get_default_value(make_split_key(model_type, i[-1]))
        d[(name,) + i] = e

    d[(name,)] = None
    return d


def get_option_default_value(any_group):
    """
    Get the default value for an option.

    any_group: AnyGroup
    """
    return get_default_value(any_group.item.key)


def get_steps_default(any_group):
    """
    Make a Steps Preset having a default value.

    any_group: AnyGroup
        not used
    """
    return {
        sk.GROUP_2_STEP_D[i]: get_default_value(i)
        for i in sk.GROUP_2_STEP_D
    }


def load_steps_preset(d):
    """
    There are two phases to loading a Steps SuperPreset:

    (1) Create option group.
    (2) Load option group value.

    d: dict
        Steps SuperPreset
        {key: step, value: group dict}
    """
    # list of loading step, 'q'
    q = d.keys() + [sk.PRESET_STEPS]

    # list of loading step key with Node step key, 'q'
    add_node_to_list(q)

    d = translate_to_id(d)
    load_super(d)


def load_super(d):
    """
    Load Widget from a SuperPreset dictionary.

    d: dict
        SuperPreset
        {navigation step key: AnyGroup value dict}
    """
    # Set the values of the options.
    # an AnyGroup value dict, 'e'
    # navigation step key, 'k'
    for k, e in d.items():
        any_group = Helm.get_group(k)
        if any_group:
            if any_group.item.group_type == 'preset':
                d1 = get_default_value(any_group.item.key)

                # Check both dict. If one is missing, then Roller fails hard.
                if e and d1:
                    fix_preset(e, d1, any_group)

                d.pop(k)
                for k1, a in e.items():
                    any_group.widget_d[k1].set_a(a)
    select_node_from_d(d)


def make_split_key(model_type, item_key):
    """
    When Preset diverge on a common item key,
    the Model key is used to create the key.
    For example, the Table Property Preset
    has a group key, "Property, Table".

    model_type: string
        Identify Model.

    item_key: string
        Describe a Node item.

    Return: string
        group key formatted as a split key
    """
    return "{}, {}".format(item_key, model_type)


def remove_from_d(d, e):
    """
    Recursively remove invalid dict item from a loaded
    dict using a default dictionary for comparison.

    d: dict
        Check for extraneous option.

    e: dict
        default
    """
    # In some cases, 'e' is empty for the Shadow SuperPreset.
    if e:
        q = [k for k in d if k != ok.PRESET]
        for k in q:
            # The Shadow SuperPreset has tuple keys.
            if not isinstance(k, tuple):
                if k not in e:
                    d.pop(k)
                else:
                    m = isinstance(d[k], dict)
                    m1 = isinstance(e[k], dict)

                    if m and m1:
                        remove_from_d(d[k], e[k])
                    elif m or m1:
                        d[k] = e[k]
            else:
                # Leave the tuple key. It could be a Node selection.
                if k in e:
                    m = isinstance(d[k], dict)
                    m1 = isinstance(e[k], dict)

                    if m and m1:
                        remove_from_d(d[k], e[k])
                    elif m or m1:
                        d[k] = e[k]


def select_node_from_d(d):
    """
    Signal Node to select a row.

    d: dict
        SuperPreset value
        {navigation step key: Preset dict}
    """
    get_group = Helm.get_group

    # value dict, 'e'
    for nav_k, e in d.items():
        any_group = get_group(nav_k)
        if any_group and e:
            if any_group.item.group_type == 'node':
                d.pop(nav_k)
                node = any_group.item.node
                if node:
                    node.emit(si.SELECT_ITEM, e['node'][sk.SELECTED_ROW])


def sync_preset(d, e):
    """
    Recursively synchronize a Preset with its default Preset value.

    d: dict
        loading Preset

    e: dict
        default Preset
    """
    remove_from_d(d, e)
    add_to_d(d, e)


def sync_dynamic(d, e):
    """
    Recursively synchronize a Preset with its default Preset,
    but only for dynamic Preset such as OptionList and Heat.

    d: dict
        loading Preset

    e: dict
        default Preset
    """
    for i in d:
        if i in (ok.BACKDROP_STYLE, ok.FRAME, ok.HEAT):
            e[i] = ROUTE_SYNC[i](d[i])
        else:
            if i in e:
                if isinstance(d[i], dict) and isinstance(e[i], dict):
                    sync_dynamic(d[i], e[i])


def sync_per(d, e):
    """
    Synchronize a loading Preset with its default Preset values for Per.

    d: dict
        loading Preset

    e: dict
        default Preset

    any_group: AnyGroup
        owner of the option
    """
    if d and ok.PER in d:
        for _, d1 in d[ok.PER].items():
            sync_dynamic(d1, e)
            sync_preset(d1, e)


def update_model_tree(any_group, d):
    """
    When loading a Model Preset, the navigation
    tree is transformed by the incoming step list.

    any_group: AnyGroup
    d: dict
        Steps SuperPreset
        {panel step key: Preset value dict}
    """
    # list of Model that are referenced in the load dict, 'model_def'
    model_def = []

    get_group = Helm.get_group
    get_branch_step_q = Helm.get_branch_step_q

    # list of panel step key, 'step_q'
    step_q = d.keys()

    node = get_group(sk.STEPS).item.node
    name = ModelId.get_name(any_group.item.model.model_id)

    # list of active Model name, 'name_q'
    name_q = node.get_label_q()[1:]

    # ModelList definition with all Models,
    # shelved and active Model definition list, 'all_def'
    all_def = get_group(sk.MODEL).widget_d[ok.MODEL_LIST].get_model_def()

    for model_name, model_type in all_def:
        if model_name in name_q:
            model_def += [(model_name, model_type)]

    for i in name_q:
        if i != name:
            q = get_branch_step_q((ModelId.get_id(i),))
            for i1 in q:
                step_q += [make_panel_key(i1)]
        else:
            i1 = (name,) + (ie.PRESET,)
            if i1 not in step_q:
                step_q += [i1]

    # Update the UI navigation tree.
    node.emit(si.UPDATE_TREE, (step_q + sk.DEFAULT_STEP, model_def))


class Preset(WidgetRow):
    """Manage option group Widget value from a WidgetRow."""

    def __init__(self, **d):
        """
        d: dict
            Initialize the Preset WidgetRow.
        """
        self.group_key = d[wk.ITEM].key

        # A SuperPreset does not have a default value.
        self._default_value = get_default_value(self.group_key)

        d.update(
            {wk.SUB: OrderedDict([
                (bk.MANAGE_PRESET, {
                    wk.DIALOG: PortPreset,
                    wk.WIDGET: ManagePresetButton
                }),
                (bk.SAVE_PRESET, {
                    wk.DIALOG: PortSave,
                    wk.WIDGET: SaveButton
                })
            ])}
        )
        WidgetRow.__init__(self, **d)

    def get_a(self):
        """
        Return the Preset value dictionary extracted from option group Widget.
        """
        d = OrderedDict()
        e = self.any_group.widget_d

        for i in get_group_keys(self.group_key):
            if hasattr(e[i], 'get_a'):
                d[i] = e[i].get_a()
        return d

    @staticmethod
    def load_default(d, k):
        """
        Load the default settings for an option group.

        d: dict
            {Option key: Widget}

        k: string
            Preset or group key
        """
        e = get_default_value(k)
        for i in e:
            if i in d:
                d[i].set_a(e[i])

    def load_file(self, n, group_key):
        """
        Load a Preset dict.

        n: string
            name of Preset; a key

        group_key: string
            integral to path

        Return: dict
            the loaded Preset
        """
        file_path = make_preset_path(group_key, n)

        if os.path.isfile(file_path):
            # Preset dict, 'd'
            d = pickle_load(file_path)

        else:
            # If the Preset is a SuperPreset, then it's an empty list, 'd'.
            d = get_default_value(group_key)

        self.set_a(d)
        return d

    @staticmethod
    def load_super(d):
        """
        Is a routing mechanism for a circular import problem.

        d: dict
            SuperPreset
        """
        load_super(d)

    def set_a(self, d):
        """
        Load this Preset's option group from a dictionary.

        d: dict
            incoming Preset
        """
        e = self.any_group.widget_d
        q = e.keys()

        fix_preset(d, self._default_value, self.any_group)

        q1 = d.keys()
        for i in q:
            if i in q1:
                e[i].set_a(d[i])

    def set_without_per(self, d):
        """
        Load this Preset option group from a
        dictionary while ignoring the Per option.

        d: dict
            incoming Preset
        """
        e = self.any_group.widget_d
        q = e.keys()

        fix_preset(d, self._default_value, self.any_group)

        q1 = d.keys()
        for i in q:
            if i in q1 and i != ok.PER:
                e[i].set_a(d[i])


class SuperPreset(Preset):
    """
    Has multiple Preset.
    it's value -> {panel step key: Preset value dict}
    """

    def __init__(self, **d):
        """
        d: dict
            Has keyword init values.
        """
        self._default_super_d = {
            gk.PRESET_STEPS: get_steps_default,
            gk.PRESET_BOX: get_model_default_value,
            gk.PRESET_CELL: get_model_default_value,
            gk.PRESET_STACK: get_model_default_value,
            gk.PRESET_TABLE: get_model_default_value,
            gk.SHADOW_PRESET: get_option_default_value
        }
        Preset.__init__(self, **d)

    def get_a(self):
        """
        Assemble a SuperPreset dictionary for saving.

        Return: dict
            SuperPreset
            {panel step key: Preset value dict}
        """
        k = () if self.group_key == gk.PRESET_STEPS \
            else self.any_group.nav_k[:-1]
        d = get_branch_value_d(k)
        return translate_to_name(d)

    @staticmethod
    def get_init(*_):
        """A SuperPreset group init is empty having no Widget."""
        return {}, []

    def set_a(self, d):
        """
        Override the 'set_a' function in the Preset class.

        d: dict
            SuperPreset
            {panel step key: Preset value dict}
        """
        The.load_count += 1

        if not d:
            # Use default dict.
            d = deepcopy(self._default_super_d[self.group_key](self.any_group))

        elif self.group_key in gk.SUPER_MODEL:
            # SuperPreset key is in panel step key format.
            # Replace old Model name with this Model name.
            e = {}
            n = ModelId.get_name(self.any_group.item.model.model_id)

            for k, a in d.items():
                e[make_panel_key(k, model_name=n)] = a
            d = e

        if self.group_key in gk.SUPER_MODEL:
            update_model_tree(self.any_group, d)

            # Convert to navigation step key for loading Preset.
            for k, a in d.items():
                d[make_nav_key(k)] = a
                d.pop(k)

        p = load_steps_preset if self.group_key == gk.PRESET_STEPS \
            else load_super

        p(d)
        The.load_count -= 1
