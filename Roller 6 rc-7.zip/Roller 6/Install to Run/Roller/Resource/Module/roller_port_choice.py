#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Dog
from roller_constant_key import Widget as wk
from roller_port_preview import PortPreview
from roller_widget_node import Pit
from roller_widget_tree import ChoiceList


class PortChoice(PortPreview):
    """Display ChoiceWindow Widget."""
    window_key = "Choose Option"

    def __init__(self, d, g):
        """
        d: dict
            Initialize the Port.

        g: OptionButton
            Has a Widget value.
        """
        self.treeview = self._choice_list = None
        self._list = g.get_list()
        PortPreview.__init__(self, d, g)

    def _draw_list_group(self, g):
        """
        Draw the list group.

        g: GTK container
            for list group
        """
        self._choice_list = ChoiceList(
            **{
                wk.ANY_GROUP: self.any_group,
                wk.FUNCTION: self.get_choice_list,
                wk.CHOICE: self.repo.get_a(),
                wk.RELAY: [self.on_port_change],
                wk.ROLLER_WIN: self.roller_win,
                wk.TREE_COLOR: self.color
            }
        )
        self.treeview = self._choice_list.treeview
        g.pack_start(self._choice_list, expand=True)

    def draw(self):
        """
        Draw Widget.

        g: VBox
            Contain Widget.
        """
        # The NoneGroup is needed for signal and change processing.
        self.any_group = Dog.none_group(**{wk.ITEM: Pit()})

        self.draw_list(
            (self._draw_list_group, self.draw_random_process_group),
            ("Available {}".format(self.repo.key), "")
        )
        self.roller_win.gtk_win.vbox.set_size_request(400, 400)

    def get_choice_list(self):
        return self._list[:]

    def get_group_value(self):
        """
        Fetch the value of the list selection.

        Return: string
            Is the choice from the choice list.
        """
        sel = self.treeview.get_selection()

        if sel:
            model, iter_ = sel.get_selected()
            if iter_:
                return model.get_value(iter_, 0)

        if self._list:
            return self._list[0]
        return ""
