#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import pdb
from roller_backdrop_style_gradient_fill import GradientFill
from roller_one import One
from roller_one_constant import (
    ForFormat as ff,
    ForGradient,
    OptionKey as ok
)
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay
from roller_render_hub import RenderHub


class ImageGradient:
    """Create a gradient from an image."""

    def __init__(self, one):
        """
        Create an Image Gradient backdrop-style.

        one: One
            Has variables.
        """
        stat = self.stat = one.stat
        self.layer = one.z
        self.session = one.session
        d = one.d
        j = stat.render.image
        a = d[ok.SAMPLE_POINTS]
        d1 = deepcopy(d)
        d1[ok.OFFSET] = 0
        self.color = [0] * a
        x = ForGradient.VECTOR.index(d[ok.SAMPLE_VECTOR])
        grad = d1[ok.GRADIENT] = pdb.gimp_gradient_new(d[ok.NAME])

        q = (
            self._do_vertical,
            self._do_horizontal,
            self._do_topleft,
            self._do_bottom_left
        )

        pdb.gimp_context_set_sample_transparent(1)

        if a > 2:
            pdb.gimp_gradient_segment_range_split_uniform(grad, 0, 0, a - 1)

        d1[ok.START_X], d1[ok.START_Y], d1[ok.END_X], d1[ok.END_Y] = q[x](d1)

        for x in range(a - 1):
            opacity = self.color[x].alpha * 100

            pdb.gimp_gradient_segment_set_left_color(
                grad,
                x,
                self.color[x],
                opacity
            )

            opacity = self.color[x + 1].alpha * 100
            pdb.gimp_gradient_segment_set_right_color(
                grad,
                x,
                self.color[x + 1],
                opacity
            )

        z = Lay.clone(j, one.z)

        GradientFill(
            One(
                d=d1,
                k=one.k,
                session=one.session,
                stat=stat,
                z=z
            )
        )
        z = pdb.gimp_image_get_active_drawable(j)

        if d[ok.BUMP][ok.BUMP] == ff.HAS_BUMP:
            RenderHub.bump(j, Lay.clone(j, z), d[ok.BUMP])

        if not d[ok.KEEP_GRADIENT]:
            pdb.gimp_gradient_delete(grad)

        else:
            # Track image gradients so they can
            # be deleted before the program closes:
            stat.image_gradients_created.append(grad)

    def _do_bottom_left(self, d):
        """
        Sample colors and return a gradient's start and end points.

        d: dict
            Has options.

        return: tuple
            start point, end point
        """
        a = d[ok.SAMPLE_POINTS]
        w = self.session['w'] // (a + 1)
        h = self.session['h'] // (a + 1)
        x, y = w, self.session['h'] - 1 - h

        for i in range(a):
            self.color[i] = self._pick_color(d, x, y)
            x = min(x + w, self.session['w'] - 1)
            y = max(y - h, 0)
        return 0., 1., 1., 0.

    def _do_horizontal(self, d):
        """
        Sample colors and return a gradient's start and end points.

        d: dict
            Has options.

        return: tuple
            start point, end point
        """
        a = d[ok.SAMPLE_POINTS]
        w = self.session['w'] // (a + 1)
        x, y = w, self.session['h'] // 2

        for i in range(a):
            self.color[i] = self._pick_color(d, x, y)
            x = min(x + w, self.session['w'] - 1)
        return 0., .5, 1., .5

    def _do_topleft(self, d):
        """
        Sample colors and return a gradient's start and end points.

        d: dict
            Has options.

        return: tuple
            start point, end point
        """
        a = d[ok.SAMPLE_POINTS]
        w = self.session['w'] // (a + 1)
        h = self.session['h'] // (a + 1)
        x, y = w, h

        for i in range(a):
            self.color[i] = self._pick_color(d, x, y)
            x = min(x + w, self.session['w'] - 1)
            y = min(y + h, self.session['h'] - 1)
        return 0., 0., 1., 1.

    def _do_vertical(self, d):
        """
        Sample colors and return a gradient's start and end points.

        d: dict
            Has options.

        return: tuple
            start point, end point
        """
        a = d[ok.SAMPLE_POINTS]
        h = self.session['h'] // (a + 1)
        x, y = self.session['w'] // 2, h

        for i in range(a):
            self.color[i] = self._pick_color(d, x, y)
            y = min(y + h, self.session['h'] - 1)
        return .5, 0., .5, 1.

    def _pick_color(self, d, x, y):
        """
        Pick a color from the canvas.

        d: dict
            Has options.

        x, y: int
            coordinate to pick from

        Return: color
            the color
            RGBA
        """
        return pdb.gimp_image_pick_color(
            self.stat.render.image,
            self.layer,
            x,
            y,
            Pdb.PickColor.NO_SAMPLE_MERGED,
            Pdb.PickColor.YES_SAMPLE_RADIUS,
            d[ok.SAMPLE_RADIUS]
        )
