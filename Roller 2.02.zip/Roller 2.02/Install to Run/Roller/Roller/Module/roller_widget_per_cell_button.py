#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_tip import Tip
from roller_widget_button import RollerButton


class PerCellButton(RollerButton):
    """This is a custom GTK Button."""

    def __init__(self, **d):
        """
        Create a GTK Button that is attached to an GTK Alignment.

        Use to open per cell port.

        d: dict
            Has keyword arguments for the Widget.
        """
        self._open_window = d['button_action']
        d['on_widget_change'] = self.do_open_window
        d['tooltip'] = Tip.PER_CELL_BUTTON

        RollerButton.__init__(self, **d)
        self.value = []

    def do_open_window(self, g):
        """
        Call when button is clicked.

        g: self
        """
        q = self.check_button.get_value()
        self._open_window(self.check_button, self.key, q)
