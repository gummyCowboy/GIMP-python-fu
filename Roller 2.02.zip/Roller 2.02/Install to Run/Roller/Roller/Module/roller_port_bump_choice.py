#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_base import Base
from roller_one_constant import (
    ForWidget as fw,
    OptionKey as ok,
    OptionLimitKey as olk,
    UIKey
)
from roller_one_preset import Preset
from roller_port import Port
from roller_widget_box import RollerBox
from roller_widget_button_pair import ButtonPair
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_radio import RollerRadioList
from roller_widget_table import RollerTable
import gtk

LABEL = "Bump", "No Bump"


class PortBumpChoice(Port):
    """Provide widgets for defining a bump layer."""

    def __init__(self, d, g):
        """
        Create the port.

        g: OptionButton
            Has values.
        """
        self.do_accept_callback = d[UIKey.ON_ACCEPT]
        self.do_cancel_callback = d[UIKey.ON_CANCEL]
        self._dict = g.get_value()
        self._button = g
        self._do_preview = g.preview
        self.stat = g.stat
        Port.__init__(self, d)

    def _draw_bump_group(self, g):
        """
        Draw the Next options.

        g: GTK container
            to receive group
        """
        default = Preset.get_default(ok.BUMP)
        pure = self.stat.option_limit.pure
        q = []
        d1 = dict(
            on_key_press=self.on_key_press,
            on_widget_change=self.on_widget_change,
            stat=self.stat,
            win=self.roller_window
        )

        default.pop(ok.BUMP)

        for k in default:
            widget = pure[k][olk.WIDGET]
            e = self.stat.option_limit.collect_widget_arg(k, ok.BUMP, self)
            e['key'] = k1 = k

            e.update(d1)

            q1 = [k1, widget, e]
            q.append(q1)

        q += [
            [
                "{} Preset:".format(ok.BUMP),
                Preset,
                dict(
                    d1,
                    key=ok.BUMP,
                    on_widget_change=self.on_widget_change,
                    stat=self.stat,
                    win=self.roller_window
                )
            ],
            [
                "",
                ButtonPair,
                dict(
                    d1,
                    button_action=(
                        self._preview,
                        self._randomize
                    ),
                    on_widget_change=lambda *a: None,
                    text=("Preview", "Randomize")
                )
            ]
        ]
        q = RollerTable.populate_table(
            container=g,
            q=q,
            color=self.color,
            bottom_pad=fw.MARGIN
        )
        self.preset = q[-2]
        self.controls += q
        self.preset.widget_list = self.controls[:-2]

    def _draw_choices(self, g):
        """
        Draw the choices group.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        box = RollerBox(
            gtk.VBox,
            align=(1, 1, 1, 1),
            padding=(w // 2, w, 0, 0)
        )

        g.add(box)

        g = self._radio_list = RollerRadioList(
            container=box,
            key=ok.BUMP,
            labels=LABEL,
            on_widget_change=self.on_list_change,
            padding=(1, 0, w, w)
        )
        self.controls += [g]

    def _draw_options(self, g):
        """
        Create option groups that sync with the radio-list.

        g: VBox
            container for the groups
        """
        g1 = self._radio_list
        g1.switch_group_box = g
        group = self._draw_bump_group, self._draw_none_group

        self.none_index = len(group) - 1
        for x, p in enumerate(group):
            vbox = gtk.VBox()

            g1.group_box.append(vbox)
            vbox.add(
                RollerLabel(
                    padding=(2, 0, 4, fw.MARGIN),
                    text=LABEL[x] + " Options:"
                )
            )
            p(vbox)

    def _draw_none_group(self, g):
        """
        Draw the none options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        g1 = RollerLabel(
            padding=(w, w, w, w),
            text="No bump will be applied\n"
            "when this reference is used."
        )
        g.pack_start(g1, expand=True)

    def _preview(self, g):
        """
        Do a preview.

        g: RollerButton
            Is responsible.
        """
        self._button.set_value(self.preset.get_value())

        self._button.option_group.changed = 1

        self._do_preview(self._button)
        self._button.set_value(self._dict)

    def _randomize(self, g):
        Port.loading += 1
        k = ok.BUMP
        d = self.preset.get_value()

        Base.random_option(d, k, self.stat.option_limit.pure)

        self.preset.set_value(d)
        Port.loading -= 1
        self.preset.preset_is_undefined()

    def do_accept(self, *_):
        """
        Accept the choice.

        Return: true
            The key-press is handled.
        """
        return self.do_accept_callback(self.preset.get_value())

    def do_cancel(self, *_):
        """
        Cancel the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        q = (
            self._draw_choices,
            self._draw_options,
            self.draw_process_group
        )
        group_name = "Define Bump Choices", "", ""

        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if group_name[x]:
                vbox.pack_start(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=group_name[x] + ":"
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()

            if x == 0:
                hbox = gtk.HBox()
                g.pack_start(hbox, expand=False)

            if x < 2:
                hbox.pack_start(box, expand=False)

            else:
                g.pack_start(box, expand=False)

        self.preset.load_preset(fw.UNDEFINED, self._dict)

        a = Port.loading
        Port.loading = 0

        self.on_list_change(self._radio_list, self._radio_list.get_value())
        Port.loading = a

    def on_widget_change(self, g):
        """
        Call when a widget is changed.

        g: Widget
            Is responsible.
        """
        return
