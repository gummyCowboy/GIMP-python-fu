#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_grid import Grid
from roller_one_fu import Sel

# Connection vector types (line type enum).
# Graph boundaries are 'virtual' connections:
DISCONNECTED, REAL, VIRTUAL = 0, 1, 2

# direction indices:
LEFT, DOWN, UP, RIGHT = range(4)

# opposing vector connections:
CONNECTOR = RIGHT, UP, DOWN, LEFT


class LineGraph:
    """ Create randomized connections for Maze Mirror. """

    # (x, y) ordered vector directions:
    directions = [(-1, 0), (0, -1), (1, 0), (0, 1)]
    real = REAL

    def __init__(self, size, row, col, stat, line_width, m=0):
        """
        size: tuple
            w, h
            of render

        row: int
            row count

        col: int
            column count

        stat: Stat
            global variables

        line_width: int
            width of the line to draw

        m: flag
            When it is true, rows and columns are unchanged.
        """
        self.stat = stat
        self.line_width = line_width

        if m:
            # Add one to the row and columns
            # because the far edges are connectors too:
            self.row, self.col = row + 1, col + 1

        else:
            self.row = ((row + 1) // 2) + 1
            self.col = ((col + 1) // 2) + 1

        r, c = self.row, self.col
        self._grid = Grid(size, row, col).table

        if self.row > 1 and self.col > 1:
            # Initialize point matrix to disconnected:
            self.graph = [0] * r

            for i in range(r):
                self.graph[i] = [0] * c
                for j in range(c):
                    self.graph[i][j] = [0] * 4

        # 'a' is connection type for edges.
        # 'b' is the connection type for out of bounds:
        if m:
            a = REAL

        else:
            a = VIRTUAL

        b = VIRTUAL
        a1 = self.graph

        # Set initial vectors for graph boundaries:
        for i in range(r):
            for j in range(c):
                # Set the top and bottom edges:
                if i == 0 or i == r - 1:
                    a1[i][j][RIGHT] = a
                    a1[i][j][LEFT] = a

                # Set the left and right edges:
                if j == 0 or j == c - 1:
                    a1[i][j][DOWN] = a
                    a1[i][j][UP] = a

        # The graph boundaries are connected by virtual connections:
        for i in range(r):
            for j in range(c):
                # Set the out-of-bounds:
                if i == 0:
                    a1[i][j][UP] = b

                elif i == r - 1:
                    a1[i][j][DOWN] = b

                if j == 0:
                    a1[i][j][LEFT] = b

                elif j == c - 1:
                    a1[i][j][RIGHT] = b

    @staticmethod
    def _get_direction(u, v):
        """
        Returns direction vectors from points "u" and "v".

        u: tuple
            of int
            (row, column)

        v: tuple
            of int
            (row, column)
        """
        if u[0] > v[0]:
            return UP, DOWN

        elif u[0] < v[0]:
            return DOWN, UP

        elif u[1] > v[1]:
            return LEFT, RIGHT
        return RIGHT, LEFT

    def add_line(self, u, v, a):
        """
        Depicts a line in the graph to connect "u" to "v".

        Points are a top-left cell point.

        u: tuple
            (row, column)
            of int

        v: tuple
            (row, column)
            of int

        a: int
            enum
            line type
        """
        b = self.graph
        a1, a2 = LineGraph._get_direction(u, v)
        b[u[0]][u[1]][a1] = b[v[0]][v[1]][a2] = a
        return a1

    def add_line_to_disconnects(self):
        """
        Scan through the 'self.graph' table for disconnected points.

        When all disconnected points are connected, the scan stops.

        Connections end at the graph boundaries or with self-contained loops.

        A line segment has end points. Each point has up to four directions
        that lines can connect. There are two connection vector types.
        Once a line segment has two connections that are
        real and/or virtual, then the point is connected.
        """
        graph = self.graph
        m = 1
        while m:
            m1 = 1
            for i in range(self.row):
                for j in range(self.col):
                    connect_cnt = is_real = 0
                    for k in range(4):
                        a = graph[i][j][k]
                        if a in (REAL, VIRTUAL):
                            connect_cnt += 1
                            if a == REAL:
                                is_real = 1

                    # If the connect count is less than 2, and
                    # one vector is real, the point is disconnected:
                    if connect_cnt < 2 and is_real:
                        u = i, j

                        # Randomly select a disconnect vector:
                        while 1:
                            typ = randint(0, 3)
                            if graph[i][j][typ] == DISCONNECTED:
                                break

                        # Add a line from this point:
                        b = CONNECTOR[typ]

                        if typ == LEFT:
                            v = i, j - 1

                        elif typ == RIGHT:
                            v = i, j + 1

                        elif typ == UP:
                            v = i - 1, j

                        else:
                            v = i + 1, j

                        graph[u[0]][u[1]][typ] = \
                            graph[v[0]][v[1]][b] = REAL
                        m1 = 0
            m = not m1

    def do_line(self, u, v, a):
        """
        Add a line to the graph.

        Draw a line on the screen.

        u: tuple
            row, column
            of int

        v: tuple
            row, column
            of int

        a: int
            enum
            line type
        """
        b = self.add_line(u, v, a)
        if a == REAL:
            x, y = self._grid[u[0]][u[1]].position
            w, h = self._grid[u[0]][u[1]].size
            w *= (1, 0, 0, 1)[b]
            h *= (0, 1, 1, 0)[b]
            Sel.rect(self.stat.render.image, x, y, w, h)

    def draw_lines(self):
        """ Draw lines depicted as 'REAL' in the 'self.graph'. """
        r, c = self.row, self.col
        q = self._grid
        a = self.graph
        for i in range(r):
            for j in range(c):
                # Draw only right and down vectors:
                if a[i][j][RIGHT] == REAL:
                    x, y = q[i][j].position
                    w = q[i][j].width
                    h = self.line_width
                    w += self.line_width
                    Sel.rect(self.stat.render.image, x, y, w, h)
                if a[i][j][DOWN] == REAL:
                    x, y = q[i][j].position
                    h = q[i][j].height
                    w = self.line_width
                    Sel.rect(self.stat.render.image, x, y, w, h)

    def get_connected_points(self, u):
        """
        Collect a list of points connected to point 'u'.

        u: tuple
            row, column
            of int

        return: list
            of connected points
        """
        q = []

        for x in range(4):
            if self.graph[u[0]][u[1]][x] == REAL:
                # left, down, up, right
                q += [(u[0] + (0, 1, -1, 0)[x], u[1] + (-1, 0, 0, 1)[x])]
        return q

    def get_line(self, u, v):
        """
        Determine the line state between points 'u' and 'v'.

        u: tuple
            row, column
            of int

        v: tuple
            row, column
            of int
        """
        a = LineGraph._get_direction(u, v)[0]
        return self.graph[u[0]][u[1]][a]
