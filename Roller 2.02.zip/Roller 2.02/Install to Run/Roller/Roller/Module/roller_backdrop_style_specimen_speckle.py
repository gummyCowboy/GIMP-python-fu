#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_style_gradient_fill import GradientFill
from roller_one import One
from roller_one_constant import ForFormat as ff, OptionKey as ok
from roller_one_constant_fu import Pdb
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
DIRECTION = range(4)


class SpecimenSpeckle:
    """
    Mix three patterns using layer modes.

    Shred the patterns with wind.

    Use colorize to give it extra interest.

    Use a gradient to improve organic randomness.
    """

    def __init__(self, one):
        """
        Create the Specimen Speckle backdrop-style.

        one: One
            Has variables.
        """
        stat = one.stat
        j = stat.render.image
        d = deepcopy(one.d)
        group = Lay.group(j, one.k, parent=one.z.parent)
        group1 = Lay.group(j, one.k, parent=group)

        Lay.order(j, one.z, group1)
        SpecimenSpeckle._do_wind(j, one.z)

        z = Lay.clone(j, one.z)
        n = d[ok.MODE]
        f = d[ok.OPACITY]
        d[ok.MODE] = "Normal"
        d[ok.OPACITY] = 100.
        d[ok.START_X] = d[ok.START_Y] = 0.
        d[ok.END_X] = d[ok.END_Y] = 1.
        d[ok.BUMP] = {ok.BUMP: ff.HAS_NO_BUMP}

        GradientFill(
            One(
                d=d,
                k=one.k,
                session=one.session,
                stat=stat,
                z=one.z
            )
        )

        d[ok.MODE] = n
        d[ok.OPACITY] = f
        z = SpecimenSpeckle._do_overlay(j, z)

        # gradient:
        z = Lay.clone(j, z)
        d[ok.END_X] = d[ok.END_Y] = 0.
        d[ok.START_X] = d[ok.START_Y] = 1.

        GradientFill(
            One(
                d=d,
                k=one.k,
                session=one.session,
                stat=stat,
                z=z
            )
        )

        z = j.active_layer
        z.opacity = 50.
        z.mode = fu.LAYER_MODE_NORMAL

        RenderHub.set_fill_context(
            {
                ok.THRESHOLD: .6,
                ok.OPACITY: 100.,
                ok.MODE: "Normal",
                ok.CRITERION: "Composite"
            }
        )

        # pattern #1:
        z = SpecimenSpeckle._do_hard_mix(j, z, d[ok.PATTERN_1])
        z = SpecimenSpeckle._do_overlay(j, z)

        # pattern #2:
        z = SpecimenSpeckle._do_hard_mix(j, z, d[ok.PATTERN_2])
        z = SpecimenSpeckle._do_overlay(j, z)

        # pattern #3:
        z = SpecimenSpeckle._do_hard_mix(j, z, d[ok.PATTERN_3])

        SpecimenSpeckle._do_overlay(j, z)

        # phase two:
        z = Lay.merge_group(j, group1)
        z1 = Lay.clone(j, z)
        z2 = Lay.clone(j, z1)

        Lay.clone(j, z2)
        Lay.blur(j, z1, 6)
        Lay.blur(j, z2, 6)
        pdb.gimp_drawable_invert(z1, Pdb.DrawableInvert.NO_LINEAR)

        z = Lay.merge_group(j, group)
        z = Lay.clone(j, z)
        z.mode = fu.LAYER_MODE_HARD_MIX
        z = Lay.clone(j, z)

        pdb.plug_in_colorify(j, z, d[ok.COLOR])
        z.mode = fu.LAYER_MODE_LCH_COLOR

    @staticmethod
    def _do_hard_mix(j, z, pattern):
        """
        Create a hard mix layer.

        j: GIMP image
            work-in-progress

        z: layer
            to clone

        pattern: string
            pattern id

        Return:
            z: layer
                the hard mix layer
        """
        z = Lay.clone(j, z)
        z.opacity = 50.
        z.mode = fu.LAYER_MODE_HARD_MIX

        pdb.gimp_context_set_pattern(pattern)
        pdb.gimp_drawable_edit_bucket_fill(
            z,
            fu.FILL_PATTERN,
            Pdb.BucketFill.X_IS_1,
            Pdb.BucketFill.Y_IS_1
        )

        SpecimenSpeckle._do_wind(j, z)
        return z

    @staticmethod
    def _do_overlay(j, z):
        """
        Create an overlay layer.

        j: GIMP image
            work-in-progress

        z: layer
            to clone

        Return: layer
            the overlay layer
        """
        z = Lay.clone(j, z)
        z.opacity = 100.
        z.mode = fu.LAYER_MODE_OVERLAY

        pdb.gimp_drawable_invert(z, 0)
        Lay.blur(j, z, 5)
        return z

    @staticmethod
    def _do_wind(j, z):
        """
        Do the wind for each direction.

        z: layer
            to receive wind
        """
        for i in DIRECTION:
            pdb.plug_in_wind(
                j,
                z,
                Pdb.Wind.THRESHOLD_0,
                i,
                Pdb.Wind.STRENGTH_25,
                Pdb.Wind.BLAST,
                Pdb.Wind.LEADING_EDGE
            )
