#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_constant import (
    ForFormat as ff,
    ForWidget as fw,
    OptionKey as ok,
    OptionLimitKey as olk,
    UIKey
)
from roller_port import Port
from roller_widget_box import RollerBox
from roller_widget_button import RollerColorButton
from roller_widget_eventbox import RollerEventBox
from roller_widget_label import RollerLabel
from roller_widget_radio import RadioBox, RollerRadioList
from roller_widget_slider import RollerSlider
from roller_widget_table import RollerTable
import gtk

OPTION_LABEL = "Drop Shadow", "Inlay Shadow", "None"
INDEX = ff.Shadow.Index


class PortShadow(Port):
    """Offer options for defining a shadow."""

    def __init__(self, d, g):
        """
        Create a shadow-choice port.

        d: dict
            Has init values.

        g: OptionButton
            Has option values.
        """
        self.do_accept_callback = d[UIKey.ON_ACCEPT]
        self.do_cancel_callback = d[UIKey.ON_CANCEL]
        self.color = g.color
        self._option_data = g.get_value()
        Port.__init__(self, d)

    def _draw_drop_shadow_group(self, g):
        """
        Draw the drop shadow group.

        g: GTK container
            to receive group
        """
        q = [i for i in ff.Shadow.DROP_SHADOW_DICT]
        self._drop_shadow_widget = self._draw_widgets(g, q)

        # 'x' is the index to the first item in the drop shadow settings:
        x = INDEX.SHADOW_BLUR

        for x1, i in enumerate(self._drop_shadow_widget):
            i.set_value(self._option_data[x + x1])

    def _draw_inlay_shadow_group(self, g):
        """
        Draw the inlay shadow group.

        g: GTK container
            to receive group
        """
        q = [i for i in ff.Shadow.INLAY_SHADOW_DICT]
        self._inlay_shadow_widget = self._draw_widgets(g, q)

        # 'x' is the index to the first item in the inlay shadow settings:
        x = INDEX.INLAY_BLUR

        for x1, i in enumerate(self._inlay_shadow_widget):
            i.set_value(self._option_data[x + x1])

    def _draw_no_shadow_group(self, g):
        """
        Draw the no shadow options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        g1 = RollerLabel(
            padding=(w, w, w, w),
            text=" No shadow is provided with this option. "
        )
        g.pack_start(g1, expand=True)

    def _draw_shadow_choice(self, g):
        """
        Draw the shadow choices group.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        label = OPTION_LABEL
        box = RollerBox(
            gtk.VBox,
            align=(1, 1, 1, 1),
            padding=(w // 2, w, 0, 0)
        )

        g.add(box)

        g = self._radio_list = RollerRadioList(
            container=box,
            key='choice',
            labels=label,
            on_widget_change=self.on_list_change,
            padding=(1, 0, w, w)
        )
        self.keep(g.buttons)

    def _draw_shadow_options(self, g):
        """
        Draw the option groups for radio-list choices.

        g: VBox
            container for widgets
        """
        g1 = self._radio_list
        g1.switch_group_box = g
        process = (
            self._draw_drop_shadow_group,
            self._draw_inlay_shadow_group,
            self._draw_no_shadow_group
        )
        label = OPTION_LABEL

        for x, p in enumerate(process):
            vbox = gtk.VBox()

            g1.group_box.append(vbox)

            if label[x]:
                vbox.add(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=label[x] + " Options:"
                    )
                )
            p(vbox)

    def _draw_widgets(self, g, q):
        """
        Draw widgets in a table.

        g: VBox
            container for widgets

        q: iterable
            of strings
            keys to widgets
        """
        widgets = []
        a = self.stat.option_limit

        for k in q:
            d = dict(
                key=k,
                on_key_press=self.on_key_press,
                on_widget_change=self.on_widget_change,
                stat=self.stat
            )
            widget = a.pure[k][olk.WIDGET]

            if widget == RollerSlider:
                widget = RollerSlider
                d.update(a.collect_widget_arg(k, None, None))

            elif widget == RollerColorButton:
                widget = RollerColorButton

            elif widget == RadioBox:
                widget = RadioBox
                d1 = self.stat.option_limit.pure[ok.MAKE_OPAQUE]
                d['labels'] = d1[olk.LABEL]
                d['tooltip'] = d1[olk.TOOLTIP]
                k = "Make Shadow Source Opaque?"
            widgets.append([k, widget, d])

        q = RollerTable.populate_table(
            **dict(d, container=g, q=widgets, color=self.color)
        )

        self.keep(q)
        return q

    def do_accept(self, *_):
        """
        Accept the shadow choice.

        Return: true
            The key-press is handled.
        """
        x = INDEX.SHADOW_BLUR
        q = self._option_data = list(self._option_data)
        for x1, i in enumerate(self._drop_shadow_widget):
            q[x + x1] = i.get_value()

        x = INDEX.INLAY_BLUR

        for x1, i in enumerate(self._inlay_shadow_widget):
            q[x + x1] = i.get_value()

        q[INDEX.CHOICE] = ff.Shadow.SHADOW_OPTION[
            self._radio_list.get_value()]
        return self.do_accept_callback(tuple(q))

    def do_cancel(self, *_):
        """
        Cancel the window.

        Return: true
            The key-press is handled.
        """
        return self.do_cancel_callback()

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        q = (
            self._draw_shadow_choice,
            self._draw_shadow_options,
            self.draw_process_group
        )
        group_name = "Shadow Choices", "", ""

        for x, p in enumerate(q):
            box = RollerEventBox(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if group_name[x]:
                vbox.pack_start(
                    RollerLabel(
                        padding=(2, 0, 4, fw.MARGIN),
                        text=group_name[x] + ":"
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()

            if x == 0:
                hbox = gtk.HBox()
                g.pack_start(hbox, expand=False)

            if x < 2:
                hbox.pack_start(box, expand=False)

            else:
                g.pack_start(box, expand=False)

        a = Port.loading
        Port.loading = 0
        n = self._option_data[INDEX.CHOICE]
        x = ff.Shadow.SHADOW_OPTION.index(n)

        self._radio_list.set_value(x)
        self.on_list_change(self._radio_list, x)
        Port.loading = a

    def on_widget_change(self, *_):
        """Call when a widget is changed."""
        return
