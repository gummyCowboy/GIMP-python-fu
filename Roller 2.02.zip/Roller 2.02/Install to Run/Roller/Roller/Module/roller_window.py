#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_base import Base
from roller_one_constant import ForWidget as fw, UIKey
import gtk

# For GTK, let it know that the function handled an event:
DONE = 1

NO_BUTTONS = None


class RollerWindow:
    """
    Create a window.

    Has common user-interface functions.
    """
    is_dialog = False

    def __init__(self, d):
        """
        Create a window.

        The new window can be a normal window with it's own event
        handler, or be a dialog. There can only be one open window
        with an event handler at a time.

        d: dict
            Has init variables.
        """
        self.is_dialog = RollerWindow.is_dialog

        # 'self.pose_key' is the window's key in the window position dict:
        self.pose_key = d[UIKey.WINDOW_KEY]

        self.stat = d[UIKey.STAT]

        if RollerWindow.is_dialog:
            g = self.win = gtk.Dialog(
                d[UIKey.WINDOW_TITLE],
                d[UIKey.WINDOW],
                gtk.DIALOG_MODAL | gtk.DIALOG_DESTROY_WITH_PARENT,
                NO_BUTTONS
            )

        else:
            g = self.win = d[UIKey.WINDOW] = gtk.Window()
            self.switch_box = gtk.VBox()

            g.add(self.switch_box)
            g.set_position(gtk.WIN_POS_CENTER)

        a = self.win.allocation

        if self.pose_key in self.stat.window_pose:
            # Make sure the position isn't off screen:
            w, h = RollerWindow.get_screen_res()
            self.width, self.height = a.width, a.height
            x, y = self.stat.window_pose[self.pose_key]
            x = Base.seal(x, 0, w - self.width)
            y = Base.seal(y, 0, h - self.height - fw.SCROLL_SPAN)
            g.move(x, y)

        else:
            w, h = RollerWindow.get_screen_res()
            self.width, self.height = a.width, a.height
            g.move(w // 2 - self.width // 2, h // 2 - self.height // 2)

        self.win.connect('delete_event', self.close)
        RollerWindow.is_dialog = True

    def close(self, *_):
        """
        Close the window.
        Exit the main loop.

        Return: true
            Tell GTK that the closing operation is handled.
        """
        g = self.win
        self.stat.window_pose[self.pose_key] = g.get_position()

        if self.is_dialog:
            g.hide()
            g.response(0)

        else:
            g.destroy()
            gtk.main_quit()
        return DONE

    def get_remaining_dim(self, w, h):
        """
        Use to keep the window from drawing off screen.

        Return the width and height of the screen space
        to the right and bottom of the window.
        """
        w1, h1 = RollerWindow.get_screen_res()

        if self.pose_key in self.stat.window_pose:
            x, y = self.stat.window_pose[self.pose_key]

        else:
            x = w1 // 2
            y = h1 // 2

        x = Base.seal(x, x + fw.SCROLL_SPAN, w1 - 200)
        y = Base.seal(y, y + fw.SCROLL_SPAN, h1 - 200)
        return min(w, w1 - x), min(h, h1 - y)

    @staticmethod
    def get_screen_res():
        """
        Return: tuple
             width, height
             of the screen's dimension
        """
        return gtk.gdk.screen_width(), gtk.gdk.screen_height()

    def resize(self):
        """
        Resize a window, but the allocation isn't correct so the process
        only works on the second resize attempt with the old window size.
        In other words, the process is one-step behind the current state.
        """
        self.win.resize(1, 1)

        w, h = RollerWindow.get_screen_res()
        g = self.win.allocation
        self.width, self.height = g.width, g.height
        x, y = q = self.win.get_position()
        x = Base.seal(x, 0, w - self.width)
        y = Base.seal(y, 0, h - self.height - fw.SCROLL_SPAN)
        if (x, y) != q:
            self.win.move(x, y)
