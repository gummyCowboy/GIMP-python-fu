#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from math import sqrt
from random import choice, randint, uniform
from roller_one_constant import (
    ForCell as fc,
    ForFormat as ff,
    FormatKey as fk,
    ForPreset,
    OptionKey as ok,
    OptionLimitKey as olk,
    PickleKey as pk,
)
from roller_one_tip import Tip
import cPickle
import gimpfu as fu
import gtk
import os

pdb = fu.pdb


class Base:
    """Has functions used my multiple classes."""

    @staticmethod
    def create_2d_table(r, c, init=0):
        """
        Return a 2D list.

        r, c: int
            size of the table

        init: value
            to init table with
        """
        b = [init] * r

        for i in range(r):
            b[i] = [init] * c
        return b

    @staticmethod
    def enumerate_name(n, q):
        """
        Enumerate a name given a list of names.

        Ensure the name is unique as in a key.

        n: string
            name

        q: list
            list of names
            of string

        Return: string
            the enumerated name
        """
        while n[-1].isdigit():
            n = n[:-1]

        n = n.strip()
        a = len(q) + 1
        go = 1

        while go:
            go = 0
            n1 = n + " " + str(a)
            if n1.lower() in q:
                a += 1
                go = 1
        return n1

    @staticmethod
    def make_bump_tooltip(d):
        """
        Create a tooltip for a bump option button.

        d: dict
            with bump settings

        Return: string
            tooltip
        """
        if d[ok.BUMP] == 0:
            return Tip.BASE_BUMP.format(
                d[ok.BUMP_DEPTH],
                round(d[ok.BUMP_ELEVATION], 1),
                round(d[ok.NOISE], 2),
                round(d[ok.LIGHT_ANGLE], 1)
            )

        else:
            return " Is no bump. "

    @staticmethod
    def make_cell_grid_tooltip(d):
        """
        Create a tooltip for a merged cell grid.

        d: dict
            with row and column settings

        Return: string
            tooltip
        """
        a = fk.Cell.Grid
        if d[a.TYPE] == ff.Grid.Index.CELL_COUNT:
            if d[a.SHAPE] in ff.Cell.Shape.DOUBLE:
                return Tip.BASE_BY_COUNT_SHIFT.format(
                    d[a.ROW],
                    d[a.COLUMN],
                    d[a.SHAPE],
                    bool(d[a.SHIFT])
                )
            return Tip.BASE_BY_COUNT.format(d[a.ROW], d[a.COLUMN], d[a.SHAPE])

        elif d[a.TYPE] == ff.Grid.Index.CELL_SIZE:
            if d[a.SHAPE] in ff.Cell.Shape.DOUBLE:
                return Tip.BASE_FIXED_SIZE_SHIFT.format(
                    d[a.ROW_HEIGHT],
                    d[a.COLUMN_WIDTH],
                    d[a.PIN],
                    d[a.SHAPE],
                    bool(d[a.SHIFT])
                )
            return Tip.BASE_FIXED_SIZE.format(
                d[a.ROW_HEIGHT],
                d[a.COLUMN_WIDTH],
                d[a.PIN],
                d[a.SHAPE]
            )

        else:
            if d[a.SHAPE] in ff.Cell.Shape.DOUBLE:
                return Tip.BASE_SHAPE_COUNT_SHIFT.format(
                    d[a.VERTICAL],
                    d[a.HORIZONTAL],
                    d[a.PIN],
                    d[a.SHAPE],
                    bool(d[a.SHIFT])
                )

            else:
                return Tip.BASE_SHAPE_COUNT.format(
                    d[a.VERTICAL],
                    d[a.HORIZONTAL],
                    d[a.PIN],
                    d[a.SHAPE]
                )

    @staticmethod
    def make_folder_tooltip(q):
        """
        Create a tooltip for a folder image reference.

        q: tuple
            of string
            folder, filter

        Return: string
            tooltip
        """
        return Tip.BASE_FOLDER.format(*q)

    @staticmethod
    def make_margin_tooltip(q, fraction_of_type):
        """
        Return a tooltip for a margin tuple.

        The tuple is composed of four fixed-value
        and four fraction-of values.

        q: tuple
            of margins

        Return: string
            tooltip
        """
        a = ff.Margin.Index
        q1 = (
            q[a.TOP],
            q[a.BOTTOM],
            q[a.LEFT],
            q[a.RIGHT],
            fraction_of_type,
            q[a.TOP + 4],
            q[a.BOTTOM + 4],
            q[a.LEFT + 4],
            q[a.RIGHT + 4],
        )
        return Tip.BASE_MARGIN.format(*q1)

    @staticmethod
    def make_shadow_tooltip(q):
        """
        Create a tooltip for a shadow tuple.

        q: tuple
            of shadow

        Return: string
            tooltip
        """
        a = ff.Shadow.Index
        if q[a.CHOICE] == ok.NONE:
            return Tip.BASE_NO_SHADOW

        elif q[a.CHOICE] == ff.Shadow.DROP_SHADOW:
            q1 = (
                q[a.CHOICE],
                q[a.SHADOW_BLUR],
                q[a.DROP_SHADOW_INTENSITY],
                q[a.OFFSET_X],
                q[a.OFFSET_Y],
                q[a.DROP_SHADOW_COLOR][0],
                q[a.DROP_SHADOW_COLOR][1],
                q[a.DROP_SHADOW_COLOR][2],
                q[a.MAKE_OPAQUE]
            )
            return Tip.BASE_DROP_SHADOW.format(*q1)

        elif q[a.CHOICE] == ff.Shadow.INLAY_SHADOW:
            q1 = (
                q[a.CHOICE],
                q[a.INLAY_BLUR],
                q[a.INLAY_SHADOW_INTENSITY],
                q[a.INLAY_SHADOW_COLOR][0],
                q[a.INLAY_SHADOW_COLOR][1],
                q[a.INLAY_SHADOW_COLOR][2]
            )
            return Tip.BASE_INLAY_SHADOW.format(*q1)
        return ""

    @staticmethod
    def circumradius(w, h):
        """
        Calculate the half-diagonal of a rectangle.

        Return: int
        """
        return int(sqrt(w**2 + h**2) // 2)

    @staticmethod
    def random_option(d, opt_key, e):
        """
        Randomize option values.

        Is part of the PortOption template.

        d: dict
            option group

        opt_key: string
            either an effect or a style

        e: dict
            Is option limit 'pure'.
        """
        for k in d:
            if k in e:
                if olk.LIMIT in e[k]:
                    a = e[k][olk.LIMIT]
                    if olk.PRECISION in e[k]:
                        d[k] = uniform(a[0], a[1])

                    else:
                        d[k] = randint(a[0], a[1])

                elif olk.LIMIT_SELF in e[k]:
                    d[k] = e[k][olk.LIMIT_SELF](opt_key)

                elif olk.LIMIT_FUNCTION in e[k]:
                    d[k] = e[k][olk.LIMIT_FUNCTION]()

                elif olk.LIST in e[k]:
                    d[k] = choice(e[k][olk.LIST])

    @staticmethod
    def rnd_col():
        """Return a tuple of integers containing random colors (r, g, b)."""
        return randint(0, 255), randint(0, 255), randint(0, 255)

    @staticmethod
    def seal(a, b, c):
        """
        Limit a numeric value to be between two numbers.

        a: value
            to limit

        b: value
            minimum amount

        c: value
            maximum amount
        """
        return max(min(c, a), b)


class OZ:
    """
    Has functions that work with the
    operating system or with files.
    """

    @staticmethod
    def ensure_dir(n):
        """
        Ensure a directory exists.

        n: string
            path

        Return two flags.
            err: int
                error flag

            go: int
                If it is true, then the operation was successful.
        """
        go = err = 0

        if n and not os.path.isdir(os.path.dirname(n)):
            try:
                os.makedirs(os.path.dirname(n))

            except Exception as ex:
                err = 1
                Comm.show_err(ex)
                Comm.show_err("Roller is unable to store files at\n" + n)

        else:
            go = 1
        return err, go

    @staticmethod
    def get_preset_name(n, n1):
        """
        Construct a preset file name.

        n: string
            preset name

        n1: string
            file specific id

        Return: string
            preset name
        """
        return n + ForPreset.PRESET_SEPARATOR + n1 + ".pkl"

    @staticmethod
    def get_preset_path(n, n1, _dir):
        """
        Construct a path to a preset.

        n: string
            preset name or key

        n1: string
            file id

        _dir: string
            preset root directory

        Return: string
            preset path
        """
        n2 = os.path.join(_dir, n)
        n3 = os.path.join(n2, OZ.get_preset_name(n, n1))
        return n3

    @staticmethod
    def pass_version(d, e, is_format=False, is_expand=True, is_recursive=True):
        """
        Add missing dictionary items.

        Remove invalid dictionary items.

        Verify cell data length.

        Is recursive.

        d: dict
            Check content.

        e: dict
            Has default values.

        is_format: flag
            If it's true, the dict is a format type.

        is_expand: flag
            If it's true, the dict in question will receive any
            missing 'key, value' pairs from the default dict.

        is_recursive: flag
            If it's true, any sub-dictionaries are also scanned.
        """
        keys = []

        # Remove old:
        for k in d:
            if k not in e:
                keys.append(k)

        [d.pop(k) for k in keys]

        # Add new:
        if is_expand:
            for k in e:
                if k not in d:
                    d[k] = deepcopy(e[k])

        if is_format:
            # Check the cell value lengths:
            for k in fc.CELL_TABLE_DICT:
                invalid = 0

                if d[k]:
                    for r in range(len(d[k])):
                        for c in range(len(d[k][r])):
                            q = d[k][r][c]
                            if len(q) != fc.CELL_TABLE_DICT[k]['length']:
                                # The cell table is invalid:
                                invalid = 1
                                Comm.info_msg(
                                    "A cell table was invalid:\n"
                                    + d[fk.Layer.NAME] + ": "
                                    + fc.CELL_TABLE_DICT[k]['name'] + ",\n"
                                    "and was erased."
                                )
                                break
                        if invalid:
                            break
                if invalid:
                    d[k] = []

        # Do sub-dictionaries:
        if is_recursive:
            for k in d:
                if isinstance(d[k], dict):
                    OZ.pass_version(d[k], e[k])

    @staticmethod
    def pickle_dump(d):
        """
        Write a file using 'cPickle'.

        d: dict
            of Pickle

        Return:
            m: flag
                Is set to true if the operation succeeded.
        """
        m = 0
        n = d[pk.FILE]
        err, _ = OZ.ensure_dir(n)

        if not err:
            try:
                with open(n, "wb") as output_file:
                    cPickle.dump(d[pk.DATA], output_file)
                m = 1

            except Exception as ex:
                Comm.show_err(ex)
                Comm.show_err("Roller is unable to save\n" + n)
        return m

    @staticmethod
    def pickle_load(d):
        """
        Read a 'cPickle' type file.

        d: dict
            of Pickle

        Return: dict or None
            the data read in
        """
        e = None
        n = d[pk.FILE]
        err, go = OZ.ensure_dir(n)

        if go and not err:
            try:
                with open(n, "rb") as input_file:
                    e = cPickle.load(input_file)
                    if not isinstance(e, dict):
                        # failure:
                        e = {}

            except Exception as ex:
                if pk.SHOW_ERROR in d:
                    if d[pk.SHOW_ERROR]:
                        Comm.show_err(ex)
                        Comm.show_err("Roller is unable to load\n" + n)
        return e


class Comm:
    """Has functions that are used to communicate."""

    @staticmethod
    def info_msg(n):
        """
        Use to output messages to the error console.

        n: message
        """
        a = pdb.gimp_message_get_handler()
        n = n if isinstance(n, str) else str(n)

        pdb.gimp_message_set_handler(fu.ERROR_CONSOLE)
        fu.gimp.message(n)
        pdb.gimp_message_set_handler(a)

    @staticmethod
    def pop_up(window, x, n, title):
        """
        Display a message dialog.

        window: window
            GTK window
            parent

        x: int
            message type index
            (question, info)
            0, 1

        n: string
            message

        title: string
            window title

        Return: flag
            It is true if the user responded with yes.
        """
        g = gtk.MessageDialog(
            parent=window,
            flags=gtk.DIALOG_MODAL,
            type=(gtk.MESSAGE_QUESTION, gtk.MESSAGE_INFO)[x],
            buttons=(gtk.BUTTONS_YES_NO, gtk.BUTTONS_CLOSE)[x],
            message_format=n
        )

        g.set_title(title)

        a = g.run()

        g.destroy()
        return int(a == gtk.RESPONSE_YES)

    @staticmethod
    def show_err(a):
        """
        Post an error message to GIMP's error console.

        a: Exception or string
            to show
        """
        # Python 3 does not have basestring:
        if not isinstance(a, basestring):
            a = repr(a)
        Comm.info_msg(a)
