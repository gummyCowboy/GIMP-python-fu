#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_image_effect import ImageEffect
from roller_one_base import Comm, OZ
from roller_one_constant import (
    BackdropStyleKey as bsk,
    CaptionKey,
    CellKey,
    ForBackdropStyle as fbs,
    ForFill,
    ForFormat as ff,
    ForGradient,
    ForPreset,
    ForWidget as fw,
    FormatKey as fk,
    FreeCellKey as fck,
    FringeKey,
    LayoutKey as nk,
    MarginKey,
    MaskKey,
    OptionKey as ok,
    PickleKey,
    PlaceKey,
    PlaqueKey,
    PresetKey as pk,
    PropertyKey,
    SessionKey as sk,
    UIKey,
    WidgetKey as wk
)
from roller_port import Port
from roller_widget import Widget
from roller_widget_box import RollerBox
from roller_widget_button import RollerButton
from roller_widget_combo import RollerComboBoxEntry
from roller_window_save import RWSave
import glob
import gtk
import os

DEFAULT = u"Default"
ek = ImageEffect.Key
w, h = gtk.gdk.screen_width(), gtk.gdk.screen_height()
BUMP = OrderedDict([
    (ok.BUMP, ff.HAS_NO_BUMP),
    (ok.BUMP_DEPTH, 2),
    (ok.BUMP_ELEVATION, 30.),
    (ok.NOISE, .1),
    (ok.LIGHT_ANGLE, 45.)
])
BACKDROP_IMAGE = OrderedDict([
    (ok.RENDER_WIDTH, w),
    (ok.RENDER_HEIGHT, h),
    (ok.BACKDROP_IMAGE, fw.FIRST),
    (ok.BACKDROP_BLUR, 0),
    (ok.FIT_IMAGE, 1),
    (ok.INVERT, 0),
    (ok.BUMP, BUMP)
])
BACKDROP_STYLE = {ok.BACKDROP_STYLE: bsk.BACKDROP_IMAGE}
CELL = {
    CellKey.FIXED_HEIGHT: 500,
    CellKey.FIXED_POSITION_X: 0,
    CellKey.FIXED_POSITION_Y: 0,
    CellKey.FIXED_WIDTH: 500,
    CellKey.FRACTION_HEIGHT: 0.,
    CellKey.FRACTION_POSITION_X: 0.,
    CellKey.FRACTION_POSITION_Y: 0.,
    CellKey.FRACTION_WIDTH: 0.,
    CellKey.NAME: "Cell",
    CellKey.SHAPE: ff.Cell.Shape.RECTANGLE
}
CELL_CAPTION = {
    CaptionKey.CLIP_TO_CELL: 1,
    CaptionKey.COLOR: (0, 0, 0),
    CaptionKey.FONT: ff.SELECT_FONT,
    CaptionKey.JUSTIFICATION: ff.Caption.TOP_LEFT,
    CaptionKey.LEADING_TEXT: "",
    CaptionKey.MARGIN: ff.Margin.MARGINS,
    CaptionKey.OPACITY: 100.,
    CaptionKey.SHADOW: ff.Shadow.SHADOWS,
    CaptionKey.SIZE: 24,
    CaptionKey.START_NUMBER: 1,
    CaptionKey.TEXT: "",
    CaptionKey.TRAILING_TEXT: "",
    CaptionKey.TYPE: ok.NONE
}
CELL_FRINGE = {
    FringeKey.BRUSH_ANGLE: 0.,
    FringeKey.BRUSH: ff.SELECT_BRUSH,
    FringeKey.BRUSH_SIZE: 100.,
    FringeKey.CLIP_TO_CELL: 1,
    FringeKey.COLOR: (0, 0, 0),
    FringeKey.COLOR_1: (87, 87, 87),
    FringeKey.COLOR_2: (174, 174, 174),
    FringeKey.CONTRACT: 0,
    FringeKey.HARDNESS: 1.,
    FringeKey.GRADIENT: DEFAULT,
    FringeKey.GRADIENT_ANGLE: ForGradient.GRADIENT_ANGLE[0],
    FringeKey.GRADIENT_TYPE: ForGradient.GRADIENT_TYPE_LIST[0],
    FringeKey.IMAGE: ok.NONE,
    FringeKey.OPACITY: 100.,
    FringeKey.PATTERN: ff.SELECT_PATTERN,
    FringeKey.SHADOW: ff.Shadow.SHADOWS,
    FringeKey.SPACING: 100.,
    FringeKey.TYPE: ok.NONE
}
CELL_GRID = {
    fk.Cell.Grid.COLUMN: 1,
    fk.Cell.Grid.COLUMN_WIDTH: 500,
    fk.Cell.Grid.HORIZONTAL: 1,
    fk.Cell.Grid.PIN: ff.Grid.Pin.CENTER,
    fk.Cell.Grid.ROW: 1,
    fk.Cell.Grid.ROW_HEIGHT: 500,
    fk.Cell.Grid.SHAPE: ff.Cell.Shape.RECTANGLE,
    fk.Cell.Grid.SHIFT: 0,
    fk.Cell.Grid.TYPE: 0,
    fk.Cell.Grid.VERTICAL: 1
}
CELL_PLAQUE = {
    PlaqueKey.BLUR_BEHIND: 0,
    PlaqueKey.COLOR: (255, 255, 255),
    PlaqueKey.GRADIENT: DEFAULT,
    PlaqueKey.GRADIENT_ANGLE: ForGradient.GRADIENT_ANGLE[0],
    PlaqueKey.GRADIENT_TYPE: ForGradient.GRADIENT_TYPE_LIST[0],
    PlaqueKey.IMAGE: ok.NONE,
    PlaqueKey.OPACITY: 100.,
    PlaqueKey.PATTERN: ff.SELECT_PATTERN,
    PlaqueKey.TYPE: ok.NONE
}
FRAME_GRADIENT = OrderedDict([
    (ok.GRADIENT, DEFAULT),
    (ok.GRADIENT_TYPE, "Bilinear"),
    (ok.OPACITY, 100.),
    (ok.ROTATE, 0.),
    (ok.INVERT, 0),
    (ok.REVERSE, 0),
    (ok.OFFSET, 0),
    (ok.START_X, 0.),
    (ok.START_Y, 0.),
    (ok.END_X, 1.),
    (ok.END_Y, 1.)
])
FREE_CELL_IMAGE_PLACE = {
    PlaceKey.HORIZONTAL: ff.Place.CENTER,
    PlaceKey.IMAGE: fw.FIRST,
    PlaceKey.RESIZE: ff.Place.LOCKED,
    PlaceKey.VERTICAL: ff.Place.MIDDLE,
}
IMAGE_MASK = {
    MaskKey.CHAR: "A",
    MaskKey.FONT: ff.SELECT_FONT,
    MaskKey.HORZ_SCALE: 1.,
    MaskKey.IMAGE: ok.NONE,
    MaskKey.TYPE: ok.NONE,
    MaskKey.VERT_SCALE: 1.
}
IMAGE_PLACE = {
    PlaceKey.HORIZONTAL: ff.Place.CENTER,
    PlaceKey.IMAGE: ff.Image.NEXT_LINEAR,
    PlaceKey.RESIZE: ff.Place.LOCKED,
    PlaceKey.VERTICAL: ff.Place.MIDDLE,
}
IMAGE_PROPERTY = {
    PropertyKey.BLUR_BEHIND: 0,
    PropertyKey.FLIP_HORIZONTAL: 0,
    PropertyKey.FLIP_VERTICAL: 0,
    PropertyKey.OPACITY: 100.,
    PropertyKey.ROTATE: 0.
}
LAYER_CAPTION = {
    CaptionKey.CLIP_TO_CELL: 1,
    CaptionKey.COLOR: (0, 0, 0),
    CaptionKey.FONT: ff.SELECT_FONT,
    CaptionKey.JUSTIFICATION: ff.Caption.TOP_LEFT,
    CaptionKey.MARGIN: ff.Margin.MARGINS,
    CaptionKey.OBEY_MARGINS: 1,
    CaptionKey.OPACITY: 100.,
    CaptionKey.SHADOW: ff.Shadow.SHADOWS,
    CaptionKey.SIZE: 36,
    CaptionKey.TEXT: "",
    CaptionKey.TYPE: ok.NONE,
}
LAYER_FRINGE = {
    FringeKey.BRUSH_ANGLE: 0.,
    FringeKey.BRUSH: ff.SELECT_BRUSH,
    FringeKey.BRUSH_SIZE: 100.,
    FringeKey.CLIP_TO_CELL: 1,
    FringeKey.COLOR: (0, 0, 0),
    FringeKey.COLOR_1: (87, 87, 87),
    FringeKey.COLOR_2: (174, 174, 174),
    FringeKey.CONTRACT: 0,
    FringeKey.HARDNESS: 1.,
    FringeKey.GRADIENT: DEFAULT,
    FringeKey.GRADIENT_ANGLE: ForGradient.GRADIENT_ANGLE[0],
    FringeKey.GRADIENT_TYPE: ForGradient.GRADIENT_TYPE_LIST[0],
    FringeKey.IMAGE: ok.NONE,
    FringeKey.OBEY_MARGINS: 1,
    FringeKey.OPACITY: 100.,
    FringeKey.PATTERN: ff.SELECT_PATTERN,
    FringeKey.SHADOW: ff.Shadow.SHADOWS,
    FringeKey.SPACING: 100.,
    FringeKey.TYPE: ok.NONE
}
LAYER_PLAQUE = {
    PlaqueKey.BLUR_BEHIND: 0,
    PlaqueKey.COLOR: (0, 0, 0),
    PlaqueKey.GRADIENT: DEFAULT,
    PlaqueKey.GRADIENT_ANGLE: ForGradient.GRADIENT_ANGLE[0],
    PlaqueKey.GRADIENT_TYPE: ForGradient.GRADIENT_TYPE_LIST[0],
    PlaqueKey.IMAGE: ok.NONE,
    PlaqueKey.OBEY_MARGINS: 1,
    PlaqueKey.OPACITY: 100.,
    PlaqueKey.PATTERN: ff.SELECT_PATTERN,
    PlaqueKey.TYPE: ok.NONE
}


class Preset(Widget):
    """Use to manage format group presets."""

    # Read only:
    default = {
        bsk.AVERAGE_COLOR: OrderedDict([
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.INVERT, 0),
            (ok.BUMP, BUMP)
        ]),
        bsk.BACKDROP_IMAGE: BACKDROP_IMAGE,
        bsk.BACKDROP_STYLE: BACKDROP_STYLE,
        bsk.COLOR_FILL: OrderedDict([
            (ok.THRESHOLD, 1.),
            (ok.CRITERION, ForFill.CRITERION_LIST[0]),
            (ok.COLOR, (127, 127, 127)),
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.INVERT, 0),
            (ok.START_X, 0.),
            (ok.START_Y, 0.),
            (ok.BUMP, BUMP)
        ]),
        bsk.COLORED_GRID: OrderedDict([
            (ok.ROW, 4),
            (ok.COLUMN, 4),
            (ok.COLOR_1, (0, 0, 0)),
            (ok.COLOR_2, (255, 255, 255)),
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.ROTATE, 0.),
            (ok.INVERT, 0),
            (ok.BUMP, BUMP)
        ]),
        bsk.CORE_DESIGN: OrderedDict([
            (ok.GRADIENT, "Default"),
            (ok.ROW, 12),
            (ok.COLUMN, 12),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.OFFSET, 0)
        ]),
        bsk.CRYSTAL_CAVE: {ok.RANDOM_SEED: 0},
        bsk.DARK_FORT: OrderedDict([
            (ok.ROW, 8),
            (ok.COLUMN, 12),
            (ok.RANDOM_SEED, 0)
        ]),
        bsk.ETCH_SKETCH: OrderedDict([
            (ok.SKETCH_TEXTURE, fbs.NEWS_TYPE),
            (ok.CELL_SIZE, 9),
            (ok.LIGHT_ANGLE, 45.),
            (ok.OPACITY, 100.),
            (ok.EMBOSS, 0),
            (ok.INVERT, 0)
        ]),
        bsk.FLOOR_SAMPLE: OrderedDict([
            (ok.NUMBER_OF_SLICES, 6),
            (ok.STARTING_ANGLE, 0),
            (ok.COLOR_1, (255, 255, 255)),
            (ok.COLOR_2, (0, 0, 0)),
            (ok.INTENSITY, 100),
            (ok.SHADOW_BLUR, 50),
            (ok.INVERT, 0)
        ]),
        bsk.GRID_WORK:  OrderedDict([
            (ok.ROW, 8),
            (ok.COLUMN, 12),
            (ok.LIGHT_ANGLE, 45.)
        ]),
        bsk.GLASS_GAW: OrderedDict([
            (ok.RANDOM_SEED, 0),
            (ok.BUMP, BUMP)
        ]),
        bsk.GRADIENT_FILL: OrderedDict([
            (ok.GRADIENT, "Default"),
            (ok.GRADIENT_TYPE, "Linear"),
            (ok.ROTATE, 0.),
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.OFFSET, 0),
            (ok.START_X, 0.),
            (ok.START_Y, 0.),
            (ok.END_X, 1.),
            (ok.END_Y, 1.),
            (ok.BUMP, BUMP)
        ]),
        bsk.HONEY_BEE:  OrderedDict([
            (ok.MESH_SIZE, 50),
            (ok.MESH_TYPE, "Hexagon"),
            (ok.NEATNESS, 1.),
            (ok.RANDOM_SEED, 0),
            (ok.BUMP, BUMP)
        ]),
        bsk.IMAGE_GRADIENT: OrderedDict([
            (ok.NAME, "Sampled Gradient"),
            (ok.SAMPLE_RADIUS, 1),
            (ok.SAMPLE_POINTS, 2),
            (ok.SAMPLE_VECTOR, "Mid-Vertical"),
            (ok.KEEP_GRADIENT, 0),
            (ok.GRADIENT_TYPE, "Linear"),
            (ok.ROTATE, 0.),
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.BUMP, BUMP)
        ]),
        bsk.LIGHT_SHAFT: OrderedDict([
            (ok.ROTATE, 0.),
            (ok.SCALE, 7),
        ]),
        bsk.LOST_MAZE: OrderedDict([
            (ok.ROW_MAZE, 10),
            (ok.COLUMN_MAZE, 10),
            (ok.GRADIENT, "Default"),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.OFFSET, 0),
            (ok.RANDOM_SEED, 0)
        ]),
        bsk.MAZE_BLEND: OrderedDict([
            (ok.ROW_MAZE, 4),
            (ok.COLUMN_MAZE, 100),
            (ok.LIGHT_ANGLE, 45.),
            (ok.RANDOM_SEED, 0)
        ]),
        bsk.MYSTERY_GRATE: OrderedDict([
            (ok.GRADIENT, "Default"),
            (ok.COLUMN_1, 8),
            (ok.COLUMN_2, 80),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.OFFSET, 0)
        ]),
        bsk.PATTERN_FILL: OrderedDict([
            (ok.PATTERN, "Paper"),
            (ok.CRITERION, ForFill.CRITERION_LIST[0]),
            (ok.THRESHOLD, 1.),
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.INVERT, 0),
            (ok.START_X, 0.),
            (ok.START_Y, 0.),
            (ok.BUMP, BUMP)
        ]),
        bsk.RAINBOW_VALLEY: OrderedDict([
            (ok.TEXTURE, 0),
            (ok.EMBOSS, 0),
            (ok.RANDOM_SEED, 0),
            (ok.POWER, 30)
        ]),
        bsk.ROCKY_LANDING:  OrderedDict([
            (ok.BLEND, 12),
            (ok.RANDOM_SEED, 0)
        ]),
        bsk.SPACETIME_FABRIC: OrderedDict([
            (ok.ROW, 10),
            (ok.COLUMN, 10),
            (ok.COMPONENT, "Green"),
            (ok.EMBOSS, 0)
        ]),
        bsk.SPECIMEN_SPECKLE: OrderedDict([
            (ok.PATTERN_1, "Crack"),
            (ok.PATTERN_2, "Leopard"),
            (ok.PATTERN_3, "Paper"),
            (ok.COLOR, (176, 82, 0)),
            (ok.GRADIENT, "Default"),
            (ok.GRADIENT_TYPE, "Linear"),
            (ok.ROTATE, 0.),
            (ok.MODE, "Normal"),
            (ok.OPACITY, 100.),
            (ok.INVERT, 0),
            (ok.REVERSE, 0),
            (ok.OFFSET, 0)
        ]),
        bsk.TRAILING_VINE: OrderedDict([
            (ok.LAYER_COUNT, 7),
            (ok.WAVE_PER_LAYER, 5),
            (ok.RANDOM_SEED, 0)
        ]),
        ok.BUMP: BUMP,
        CaptionKey.CELL_CAPTION: CELL_CAPTION,
        CaptionKey.FREE_CELL_CAPTION: CELL_CAPTION,
        CaptionKey.LAYER_CAPTION: LAYER_CAPTION,
        ek.BALL_JOINT: OrderedDict([
            (ok.BRUSH_SIZE, 100),
            (ok.LIGHT_ANGLE, 45.)
        ]),
        ek.BORDER_LINE: OrderedDict([
            (ok.FRAME_WIDTH, 10),
            (ok.LIGHT_ANGLE, 45.),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0),
            (ok.RANDOM_SEED, 0),
            (ok.POWER, 30)
        ]),
        ek.BRUSH_PUNCH: OrderedDict([
            (ok.BRUSH, "Default"),
            (ok.BRUSH_SIZE, 100),
            (ok.BRUSH_SPACING, 90.),
            (ok.FRAME_WIDTH, 6),
            (ok.LIGHT_ANGLE, 45.),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0),
            (ok.RANDOM_SEED, 0),
            (ok.POWER, 30)
        ]),
        ek.CERAMIC_CHIP: OrderedDict([
            (ok.WIDTH, 45),
            (ok.FRAME_WIDTH, 4),
            (ok.MESH_TYPE, "Triangle"),
            (ok.MESH_SIZE, 33),
            (ok.COLOR, (0, 255, 0)),
            (ok.LIGHT_ANGLE, 45.),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0),
            (ok.RANDOM_SEED, 0),
            (ok.POWER, 30)
        ]),
        ek.CIRCLE_PUNCH: OrderedDict([
            (ok.CIRCLE_DIAMETER, 50),
            (ok.WIDTH, 45),
            (ok.ROTATE, 0.),
            (ok.FRAME_WIDTH, 4),
            (ok.LIGHT_ANGLE, 45.),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0),
            (ok.RANDOM_SEED, 0),
            (ok.POWER, 30)
        ]),
        ek.CLEAR_FRAME: OrderedDict([
            (ok.FRAME_WIDTH, 45),
            (ok.FRAME_TYPE, 1),
            (ok.COLOR, (255, 255, 255))
        ]),
        ek.COLORED_BOARD: OrderedDict([
            (ok.FRAME_WIDTH, 1),
            (ok.FRAME_TYPE, 1),
            (ok.COLOR, (255, 255, 255)),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.COSMETIC_PIPE: OrderedDict([
            (ok.PATTERN, "Paper"),
            (ok.FRAME_WIDTH, 20),
            (ok.LIGHT_ANGLE, 45.),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.DROP_SHADOW: ff.Shadow.DROP_SHADOW_DICT,
        ek.FEATHER_REDUCTION: OrderedDict([
            (ok.FEATHER, 200),
            (ok.STEPS, 6)
        ]),
        ek.FILL_LIGHT_SHADOW: OrderedDict([
            (ok.SHADOW_BLUR, 30),
            (ok.INTENSITY, 30),
            (ok.OFFSET_X, 0),
            (ok.OFFSET_Y, 0),
            (ok.SHADOW_COLOR, (0, 0, 0)),
            (ok.MAKE_OPAQUE, 0),
            (ok.KEY_LIGHT_COMPLIMENT, ImageEffect.APPLY)
        ]),
        ek.FRAME_GRADIENT: FRAME_GRADIENT,
        ek.GRADIENT_BEVEL: OrderedDict([
            (ok.FRAME_WIDTH, 40),
            (ok.COLOR_1, (0, 0, 0)),
            (ok.COLOR_2, (255, 255, 255)),
        ]),
        ek.IMAGE_EDGE_SHADOW: OrderedDict([
            (ok.INLAY_BLUR, 25),
            (ok.INTENSITY, 130),
            (ok.SHADOW_COLOR, (0, 0, 0))
        ]),
        ek.IMAGE_SHADOW: OrderedDict([
            (ok.SHADOW_BLUR, 25),
            (ok.INTENSITY, 120),
            (ok.OFFSET_X, 0),
            (ok.OFFSET_Y, 0),
            (ok.SHADOW_COLOR, (0, 0, 0)),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.INLAY_SHADOW: ff.Shadow.INLAY_SHADOW_DICT.copy(),
        ek.JAGGED_EDGE: OrderedDict([
            (ok.AMPLITUDE, 3),
            (ok.SMOOTHNESS, 4),
            (ok.RANDOM_SEED, 0),
            (ok.SHADOW, ek.INLAY_SHADOW),
            (ok.SHADOW_BLUR, 20),
            (ok.INTENSITY, 100),
            (ok.SHADOW_COLOR, (0, 0, 0)),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.KEY_LIGHT_SHADOW: OrderedDict([
            (ok.SHADOW_BLUR, 15),
            (ok.INTENSITY, 110),
            (ok.OFFSET_X, 0),
            (ok.OFFSET_Y, 0),
            (ok.SHADOW_COLOR, (0, 0, 0)),
            (ok.MAKE_OPAQUE, 0)
        ]),
        ek.LINE_FASHION: OrderedDict([
            (ok.WIDTH, 45),
            (ok.LINE_WIDTH, 12),
            (ok.GAP_WIDTH, 48),
            (ok.FRAME_WIDTH, 4),
            (ok.ROTATE, 0.),
            (ok.LIGHT_ANGLE, 45.),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0),
            (ok.RANDOM_SEED, 0),
            (ok.POWER, 30)
        ]),
        ek.MAZE_MIRROR: OrderedDict([
            (ok.ROW, 10),
            (ok.COLUMN, 8),
            (ok.MAZE_TYPE, fbs.SCATTERED_CONNECTORS),
            (ok.DIRECTION, fbs.CLOCKWISE),
            (ok.CELL_GAP, 3),
            (ok.GAP_TYPE, fbs.RANDOM),
            (ok.STOP_LENGTH, 25),
            (ok.SCATTER_COUNT, 4),
            (ok.FRAME_WIDTH, 8),
            (ok.COMPOSITION_FRAME_WIDTH, 8),
            (ok.LINE_WIDTH, 3),
            (ok.LIGHT_ANGLE, 45.),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0),
            (ok.RANDOM_SEED, 0),
            (ok.POWER, 30)
        ]),
        ek.NO_EFFECT: {},
        ek.RAD_WAVE: OrderedDict([
            (ok.FRAME_WIDTH, 10),
            (ok.LINE_WIDTH, 8),
            (ok.COMPOSITION_FRAME_WIDTH, 8),
            (ok.ROW, 2),
            (ok.COLUMN, 2),
            (ok.WAVE_AMPLITUDE, 10),
            (ok.WAVELENGTH, 25.),
            (ok.WHIRL, 0),
            (ok.LIGHT_ANGLE, 45.),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0),
            (ok.RANDOM_SEED, 0),
            (ok.POWER, 30)
        ]),
        ek.RAISED_MAZE: OrderedDict([
            (ok.FRAME_WIDTH, 8),
            (ok.LINE_WIDTH, 8),
            (ok.COMPOSITION_FRAME_WIDTH, 8),
            (ok.ROW_MAZE, 10),
            (ok.COLUMN_MAZE, 10),
            (ok.LIGHT_ANGLE, 45.),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0),
            (ok.RANDOM_SEED, 0),
            (ok.POWER, 30)
        ]),
        ek.ROUNDED_EDGE: OrderedDict([
            (ok.ROUNDED_EDGE_BLUR, 15),
            (ok.ROUND_UP, 0),
        ]),
        ek.STAINED_GLASS: OrderedDict([
            (ok.WIDTH, 45),
            (ok.PANE_WIDTH, 100),
            (ok.PANE_HEIGHT, 100),
            (ok.ROTATE, 45.),
            (ok.FRAME_WIDTH, 5),
            (ok.LIGHT_ANGLE, 45.),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0),
            (ok.RANDOM_SEED, 0),
            (ok.POWER, 30)
        ]),
        ek.SQUARE_PUNCH: OrderedDict([
            (ok.WIDTH, 45),
            (ok.LINE_WIDTH, 12),
            (ok.GAP_WIDTH, 48),
            (ok.FRAME_WIDTH, 4),
            (ok.ROTATE, 0.),
            (ok.LIGHT_ANGLE, 45.),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0),
            (ok.RANDOM_SEED, 0),
            (ok.POWER, 30)
        ]),
        ek.IMAGE_EFFECT: {ok.IMAGE_EFFECT: ek.NO_EFFECT},
        ek.WIRE_FENCE: OrderedDict([
            (ok.MESH_TYPE, "Hexagon"),
            (ok.MESH_SIZE, 30),
            (ok.WIDTH, 35),
            (ok.WIRE_THICKNESS, 3),
            (ok.NEATNESS, 1.),
            (ok.FRAME_WIDTH, 4),
            (ok.LIGHT_ANGLE, 45.),
            (ok.FRAME_TYPE, 1),
            (ok.MAKE_OPAQUE, 0),
            (ok.RANDOM_SEED, 0),
            (ok.POWER, 30)
        ]),
        fck.CELL: CELL,
        fck.FREE_RANGE_CELL: {
            CaptionKey.FREE_CELL_CAPTION: CELL_CAPTION,
            fck.CELL: CELL,
            fck.Cell.MARGIN: ff.Margin.MARGINS,
            FringeKey.CELL_FRINGE: CELL_FRINGE,
            PlaqueKey.CELL_PLAQUE: CELL_PLAQUE,
            MaskKey.IMAGE_MASK: IMAGE_MASK,
            pk.PRESET: DEFAULT,
            PlaceKey.IMAGE_PLACE: FREE_CELL_IMAGE_PLACE,
            PropertyKey.IMAGE_PROPERTY: IMAGE_PROPERTY
        },
        fk.Cell.Grid.CELL_GRID: CELL_GRID,
        fk.FORMAT: {
            CaptionKey.CELL_CAPTION: CELL_CAPTION,
            CaptionKey.LAYER_CAPTION: LAYER_CAPTION,
            fk.Cell.MARGIN: ff.Margin.MARGINS,
            fk.Cell.Caption.PER_CELL: [],
            fk.Cell.Fringe.PER_CELL: [],
            fk.Cell.Grid.CELL_GRID: CELL_GRID,
            fk.Cell.Grid.PER_CELL: [],
            fk.Cell.Image.Mask.PER_CELL: [],
            fk.Cell.Margin.PER_CELL: [],
            fk.Cell.Image.Place.PER_CELL: [],
            fk.Cell.Image.Property.PER_CELL: [],
            fk.Cell.Plaque.PER_CELL: [],
            fk.Layer.CELL_LIST: [],
            fk.Layer.NAME: "Format",
            fk.Layer.PLACE_FREE_CELL_ABOVE: 1,
            fk.Layer.SHOW_IN_LAYOUT: 1,
            fk.Layer.MARGIN: ff.Margin.MARGINS,
            FringeKey.CELL_FRINGE: CELL_FRINGE,
            FringeKey.LAYER_FRINGE: LAYER_FRINGE,
            pk.PRESET: DEFAULT,
            MaskKey.IMAGE_MASK: IMAGE_MASK,
            PlaceKey.IMAGE_PLACE: IMAGE_PLACE,
            PlaqueKey.CELL_PLAQUE: CELL_PLAQUE,
            PlaqueKey.LAYER_PLAQUE: LAYER_PLAQUE,
            PropertyKey.IMAGE_PROPERTY: IMAGE_PROPERTY,
        },
        FringeKey.CELL_FRINGE: CELL_FRINGE,
        FringeKey.LAYER_FRINGE: LAYER_FRINGE,
        MarginKey.MARGINS: {
            MarginKey.FIXED_TOP: 0,
            MarginKey.FIXED_BOTTOM: 0,
            MarginKey.FIXED_LEFT: 0,
            MarginKey.FIXED_RIGHT: 0,
            MarginKey.FRACTION_TOP: 0.,
            MarginKey.FRACTION_BOTTOM: 0.,
            MarginKey.FRACTION_LEFT: 0.,
            MarginKey.FRACTION_RIGHT: 0.
        },
        MaskKey.IMAGE_MASK: IMAGE_MASK,
        PlaceKey.IMAGE_PLACE: IMAGE_PLACE,
        PlaqueKey.CELL_PLAQUE: CELL_PLAQUE,
        PlaqueKey.LAYER_PLAQUE: LAYER_PLAQUE,
        PropertyKey.IMAGE_PROPERTY: IMAGE_PROPERTY,
        sk.SESSION: {
            sk.CLOSE_FILE: 0,
            sk.FORMAT_LIST: [],
            sk.LAYOUT_OPTION: OrderedDict([
                (nk.CELL_CAPTION, 0),
                (nk.CELL_FRINGE, 0),
                (nk.CELL_MARGINS, 0),
                (nk.CELL_PLAQUE, 0),
                (nk.COORDINATES, 0),
                (nk.CORNERS, 0),
                (nk.DIMENSIONS, 0),
                (nk.GRID, 0),
                (nk.IMAGE_MASK, 0),
                (nk.LAYER_MARGINS, 0),
                (nk.NAME, 0),
                (nk.RATIOS, 0),
            ]),
            pk.PRESET: DEFAULT,
            sk.SESSION_OPT: {
                sk.FORMAT_NAME_LIST: [],
                ek.FRAME_GRADIENT: FRAME_GRADIENT,
                sk.BACKDROP: {
                    bsk.BACKDROP_IMAGE: BACKDROP_IMAGE,
                    bsk.BACKDROP_STYLE: BACKDROP_STYLE
                },
            }
        }
    }

    def __init__(self, **d):
        """
        Create a format group preset.

        Use the Widget template 'get_value' and 'set_value'
        functions to manage widget option groups.

        d: dict
            Has keyword arguments.
        """
        w = fw.MARGIN
        w1 = w // 2
        self.widget_list = d[wk.WIDGET_LIST] if wk.WIDGET_LIST in d else []
        self.verify = None

        # Backdrop-style and image-effect have a tuple for a key:
        k = d[wk.KEY] if isinstance(d[wk.KEY], str) else d[wk.KEY][1]
        self._default_dict = deepcopy(Preset.default[k])

        # Has preset path.
        # The key is a preset name. The value is a path:
        self._external_preset = {}

        vbox = self._vbox = RollerBox(gtk.VBox, align=(0, 0, 1, 1))
        hbox = RollerBox(gtk.HBox, align=(0, 0, 1, 1))
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)
        k = wk.ON_WIDGET_CHANGE
        self._update_window = d[k] if k in d else None
        d[wk.ON_WIDGET_CHANGE] = self._on_preset_change
        g = self.menu = RollerComboBoxEntry(**d)

        Widget.__init__(self, g, **d)

        g1 = self._save_button = RollerButton(
            on_widget_change=self.save,
            padding=(w1, 0, 0, w1),
            text="Save Preset"
        )
        g2 = self._delete_button = RollerButton(
            on_widget_change=self._delete,
            padding=(w1, 0, w1, 0),
            text="Delete Preset"
        )

        self.add(vbox)
        vbox.add(g)
        vbox.pack_start(hbox, expand=1)

        for i in (g1, g2):
            hbox.add(i)
            same_size.add_widget(i.widget)
        if 'container' in d:
            d['container'].add(self)

            if 'padding' in d:
                hbox.set_padding(*d['padding'])
                vbox.set_padding(*d['padding'])

            else:
                hbox.set_padding(w1, w, 0, 0)
                vbox.set_padding(w1, 0, w, w)

    def _collect_presets(self):
        """
        Create a list, 'self._option_list', of internal and external presets.

        Return: list
            of options
            to populate combobox
        """
        # menu options:
        q = self._option_list = []
        ext_files = []
        go = 0
        self._external_preset = {}

        try:
            search_path = OZ.get_preset_path(
                self.key,
                u"*",
                self.stat.preset_folder
            )

            # Ignore sub-directories:
            ext_files = glob.glob(search_path)
            go = 1

        except Exception as ex:
            Comm.show_err(ex)
            Comm.show_err("Roller was unable to load presets.")

        if go:
            # Load internal presets into a list:
            q.append(DEFAULT)

            # Make an external preset file list:
            for n in ext_files:
                file_name = os.path.basename(n)
                split_name = file_name.split(ForPreset.PRESET_SEPARATOR)
                combined_name = u""

                for n1 in range(1, len(split_name)):
                    combined_name = combined_name + split_name[n1]

                types = combined_name.split(u".")
                name = types[0]
                self._external_preset[name] = n
                q.append(name)
        return q

    def _delete(self, *_):
        """Delete a preset file."""
        n = self.menu.get_text()
        is_external = False

        if n in self._external_preset:
            is_external = True
        if is_external:
            path = self._external_preset[n]
            if Comm.pop_up(
                self.win.win,
                0,
                "Do you want to delete:\n{}?".format(path),
                "Delete a File Confirmation"
            ):
                try:
                    os.remove(path)
                    Comm.pop_up(
                        self.win.win,
                        1,
                        "The file:\n" + path + "\nwas removed.",
                        "File Deleted"
                    )

                    if n in self._external_preset:
                        self._external_preset.pop(n)
                    self.refresh(fw.UNDEFINED)

                except Exception as ex:
                    Comm.show_err(ex)
                    Comm.show_err("Roller was unable to delete the file.")

    def _get_preset(self, n):
        """
        Find a preset dictionary from internal or external sources.

        n: string
            name of preset

        Return: dict
            of preset
        """
        if n in self._external_preset:
            d = OZ.pickle_load(
                {
                    PickleKey.FILE: self._external_preset[n],
                    PickleKey.SHOW_ERROR: True
                }
            )

            # The preset name must match the file name:
            d[pk.PRESET] = n

            if self.key == sk.SESSION:
                self._proof_session(d)

            else:
                OZ.pass_version(d, self._default_dict)

        else:
            d = deepcopy(self._default_dict)
            n = DEFAULT
        return d, n

    def _load_preset(self, n, d):
        """
        Load a preset dictionary.

        n: string
            name of preset

        d: dict
            of preset
        """
        Port.loading += 1

        if n != fw.UNDEFINED:
            d, n = self._get_preset(n)

        self.set_value(d)
        self.menu.set_text(n)
        self.verify_del_button()
        Port.loading -= 1

    def _on_preset_change(self, g):
        """
        Call after loading a preset.

        g: ComboBox
            Has changed.
            not used
        """
        if not Port.loading:
            n = self.get_text()

            if n != fw.UNDEFINED:
                self._load_preset(n, self._default_dict)
            if self._update_window:
                self._update_window(self)

    def _proof_session(self, d):
        """
        Check the contents of the session dict for compatibility.

        d: dict
            of session
        """
        for e in d[sk.FORMAT_LIST]:
            OZ.pass_version(e, Preset.default[fk.FORMAT], is_format=1)
            for cell in e[fk.Layer.CELL_LIST]:
                OZ.pass_version(cell, Preset.default[fck.FREE_RANGE_CELL])

        d1 = self._default_dict

        OZ.pass_version(d, d1, is_recursive=False)

        for k in d1[sk.SESSION_OPT]:
            if k not in d[sk.SESSION_OPT]:
                d[sk.SESSION_OPT][k] = deepcopy(d1[sk.SESSION_OPT][k])

        q = [i for i in d[sk.SESSION_OPT]]

        for i in q:
            if i == ek.FRAME_GRADIENT:
                OZ.pass_version(d[sk.SESSION_OPT][i], Preset.default[i])

            else:
                q1 = [j for j in d[sk.SESSION_OPT][i]]
                for j in q1:
                    if i != sk.FORMAT_NAME_LIST:
                        if j in Preset.default:
                            OZ.pass_version(
                                d[sk.SESSION_OPT][i][j],
                                Preset.default[j]
                            )

                        else:
                            # an invalid option:
                            d[sk.SESSION_OPT][i].pop(j)

    @staticmethod
    def get_default(key):
        return deepcopy(Preset.default[key])

    def get_text(self):
        """
        Return the value displayed in the Entry.

        The text may or may not be a row in the drop-menu.

        Return: string
            from the Entry
        """
        g = self.menu.widget.child
        if g:
            return g.get_text()
        return ""

    def get_value(self, has_preset=False):
        """
        Return the preset dictionary.

        Skip widget(s) without keys in the dictionary.
        ZList widgets don't have preset dictionary values.

        has_preset: flag
            If it's true, the dictionary has a preset,
            and its value is stored.
        """
        d = {}

        for i in self.widget_list:
            if i.key in self._default_dict:
                d[i.key] = i.get_value()

        if has_preset:
            d[pk.PRESET] = self.get_text()
        return d

    def load(self, n):
        """
        Load a preset.

        n: string
            name of preset
        """
        Port.loading += 1

        self.menu.populate_list(self._collect_presets())

        d, n = self._get_preset(n)

        self.set_value(d)
        self.menu.set_text(n)
        self.verify_del_button()
        Port.loading -= 1

    def load_preset(self, n, d):
        """
        Load a preset dictionary.

        n: string
            to display

        d: dict
            of preset
        """
        Port.loading += 1

        self.menu.populate_list(self._collect_presets())
        self.set_value(d)
        self.menu.set_text(n)
        self.verify_del_button()
        Port.loading -= 1

    def preset_is_undefined(self, ignore_loading=False):
        """
        Set the preset ComboBox display to undefined.

        ignore_loading: flag
            If true, then ignore the 'Port.loading' state.
        """
        if not Port.loading or ignore_loading:
            if self.get_text() != fw.UNDEFINED:
                self.set_text(fw.UNDEFINED)
                self.verify_del_button()

    def refresh(self, n):
        """
        The state of the preset menu has changed.

        n: string
            the name to display on the menu
        """
        Port.loading += 1

        self.menu.populate_list(self._collect_presets())

        p = self.menu.set_value if n in self._option_list \
            else self.menu.set_text

        p(n)

        self.verify_del_button()
        Port.loading -= 1

    def save(self, *_):
        """Save a preset file."""
        d = {
            pk.GET_DATA: self.get_value,
            UIKey.WINDOW: self.win.win,
            UIKey.STAT: self.stat,
            'key': self.key
        }
        if RWSave(d).is_write:
            # Get result from the init dict:
            self.refresh(d[pk.FILE_NAME])

    def set_text(self, n):
        """
        Set the text in the Entry.

        The text does not have to be a row in the drop-menu.

        n: string
            to display in the Entry
        """
        g = self.menu.widget.child
        if g:
            g.set_text(n)

    def set_value(self, d):
        """
        Load the preset on a menu change.

        d: dict
            preset dict or None
        """
        Port.loading += 1
        k = self.key

        for i in self.widget_list:
            if i.key:
                if i.key in d:
                    if isinstance(i, Preset):
                        if pk.PRESET in d:
                            n = d[pk.PRESET] if i.key == k else fw.UNDEFINED

                        else:
                            n = fw.UNDEFINED
                        i.load_preset(n, d[i.key])

                    else:
                        i.set_value(d[i.key])

                else:
                    i.set_value(self._default_dict[i.key])

        Port.loading -= 1
        if self.verify:
            self.verify(self)

    def verify_del_button(self):
        """The delete Button is valid for an external preset."""
        n = self.get_text()

        if n != fw.UNDEFINED:
            x = 0 if n == DEFAULT else 1

        else:
            x = 0
        (self._delete_button.disable, self._delete_button.enable)[x]()
