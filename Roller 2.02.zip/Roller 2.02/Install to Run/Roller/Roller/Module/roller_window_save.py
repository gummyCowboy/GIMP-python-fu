#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_one_base import OZ, Comm
from roller_one_constant import (
    PickleKey,
    PortKey,
    PresetKey as pk,
    UIKey,
    WindowKey
)
from roller_port_save import PortSave
from roller_window import RollerWindow
import os


class RWSave(RollerWindow):
    """Is a GTK dialog used to save a preset."""
    preset_name = "New Preset"

    DUPLICATE_FILE = \
        "The file,\n\n{},\n\nalready exists. " \
        "Do you want to overwrite?"

    def __init__(self, d):
        """
        Create a window.

        d: dict
            Has init values.
        """
        self._init_dict = d
        self.get_data = d[pk.GET_DATA]
        self.key = d['key']
        self.is_write = False
        n = d[UIKey.WINDOW_TITLE] = "Name the " + self.key + " Preset"
        d[UIKey.WINDOW_KEY] = WindowKey.SAVE

        RollerWindow.__init__(self, d)

        e = {
            UIKey.ON_ACCEPT: self.do_accept,
            UIKey.ON_CANCEL: self.do_cancel,
            UIKey.WINDOW: self,
            UIKey.PORT_KEY: PortKey.NOT_USED,
            UIKey.STAT: d[UIKey.STAT],
            UIKey.WINDOW_TITLE: n
        }
        self.port = PortSave(e, RWSave.preset_name, self.key)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()

    def do_accept(self, n):
        """
        Write the preset, and if successful, close the window.

        n: string
            name of preset

        Return: flag
            If true, the window is done.
        """
        d = deepcopy(self.get_data())

        if pk.PRESET in d:
            d[pk.PRESET] = n
        if RWSave.write(self.win, d, self.key, n, self.stat):
            self._init_dict[pk.FILE_NAME] = RWSave.preset_name = n
            self.is_write = 1
            return self.close()

    def do_cancel(self, *_):
        """
        Close the window.

        Return: true
            GTK, it is done.
        """
        return self.close()

    @staticmethod
    def write(win, d, key, file_name, stat, do_not_overwrite=True):
        """
        Write the preset, after checking if it already
        exists and asking permission to over-write.

        d: dict
            Has preset data.

        file_name: string
            second part of the file path

        stat: Stat
            globals

        do_not_overwrite: flag
            If its true, a dialog will confirm a file over-write.

        Return: flag
            Is true if the file was written.
        """
        path = OZ.get_preset_path(
            key,
            file_name,
            stat.preset_folder
        )
        m = 1

        if do_not_overwrite:
            if path:
                if os.path.isfile(path):
                    n = RWSave.DUPLICATE_FILE.format(path)
                    m = Comm.pop_up(win, 0, n, "Duplicate File")

        if m:
            m = OZ.pickle_dump({PickleKey.DATA: d, PickleKey.FILE: path})
        return m
