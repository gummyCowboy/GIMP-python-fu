#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Tip:
    """Has tooltip text strings."""

    BASE_BUMP = \
        " Bump Depth:\t{} \n" \
        " Bump Elevation:\t{} \n" \
        " Noise:\t\t\t{} \n" \
        " Light Angle:\t\t{} "

    BASE_BY_COUNT = \
        " Row Count:\t\t{} \n" \
        " Column Count:\t{} \n" \
        " Shape:\t\t\t{} "

    BASE_BY_COUNT_SHIFT = \
        " Row Count:\t\t{} \n" \
        " Column Count:\t{} \n" \
        " Shape:\t\t\t{} \n" \
        " Shift:\t\t\t{} "

    BASE_DROP_SHADOW = \
        " Shadow:\n" \
        "\tType:\t\t\t{} \n" \
        "\tShadow Blur:\t\t{} \n" \
        "\tIntensity:\t\t{} \n" \
        "\tOffset X:\t\t\t{} \n" \
        "\tOffset Y:\t\t\t{} \n" \
        "\tShadow Color:\n" \
        "\t\tRed:\t\t{}\n" \
        "\t\tGreen:\t\t{} \n" \
        "\t\tBlue:\t\t{}\n" \
        "\tMake Opaque:\t{} "

    BASE_FOLDER = \
        " Folder:\t\t{} \n" \
        " File Filter:\t{} "

    BASE_FIXED_SIZE = \
        " Row Height:\t\t{} \n" \
        " Column Width:\t{} \n" \
        " Table Position:\t{} \n" \
        " Shape:\t\t\t{} "

    BASE_FIXED_SIZE_SHIFT = \
        " Row Height:\t\t{} \n" \
        " Column Width:\t{} \n" \
        " Table Position:\t{} \n" \
        " Shape:\t\t\t{} \n" \
        " Shift:\t\t\t{} "

    BASE_MARGIN = \
        " Fixed-Value Margins: \n" \
        "\tTop:\t\t{} \n" \
        "\tBottom:\t\t{} \n" \
        "\tLeft:\t\t{} \n" \
        "\tRight:\t\t{} \n" \
        " Fraction-of-{}-Size Margins: \n" \
        "\tTop:\t\t{} \n" \
        "\tBottom:\t\t{} \n" \
        "\tLeft:\t\t{} \n" \
        "\tRight:\t\t{} "

    BASE_NO_SHADOW = \
        " No Shadow "

    BASE_INLAY_SHADOW = \
        " Shadow:\n" \
        "\tType:\t\t\t{} \n" \
        "\tInlay Blur:\t\t{} \n" \
        "\tIntensity:\t\t{} \n" \
        "\tShadow Color:\n" \
        "\t\tRed:\t\t{}\n" \
        "\t\tGreen:\t\t{} \n" \
        "\t\tBlue:\t\t{} "

    BASE_SHAPE_COUNT = \
        " Row Count:\t\t{} \n" \
        " Column Count:\t{} \n" \
        " Table Position:\t{} \n" \
        " Shape:\t\t\t{} "

    BASE_SHAPE_COUNT_SHIFT = \
        " Row Count:\t\t{} \n" \
        " Column Count:\t{} \n" \
        " Table Position:\t{} \n" \
        " Shape:\t\t\t{} \n" \
        " Shift:\t\t\t{} "

    BLEND = " Use a higher value to create less textural variation. "
    CAPTION_IMAGE_NAME = \
        " Has Image?\t\t{}\n" \
        " Type:\t\t\t{} \n" \
        " Leading Text:\t{} \n" \
        " Trailing Text:\t\t{} \n" \
        " Font:\t\t\t{}\n" \
        " Font Size:\t\t{}\n" \
        " Color:\n" \
        "\tRed:\t\t{}\n" \
        "\tGreen:\t\t{} \n" \
        "\tBlue:\t\t{}\n" \
        " Margin:\n" \
        "{}\n" \
        " Justification:\t\t{} \n" \
        " Opacity:\t\t{} \n" \
        " Clip to Cell:\t\t{} \n" \
        "{}"

    CAPTION_LEADING_TEXT = \
        " Is a prefix to a sequenced number or an image name. "

    CAPTION_LIMIT_SPREAD = \
        " Will crop caption text if it exceeds the boundary of a {}. "

    CAPTION_START_NUMBER = \
        " Is the first number to be displayed in a numeric sequence, \n" \
        " where each successive image increases this number by one. "

    CAPTION = \
        " Has Image?\t\t{}\n" \
        " Type:\t\t\t{}\n" \
        " Text:\t\t\t{} \n" \
        " Font:\t\t\t{}\n" \
        " Font Size:\t\t{}\n" \
        " Color:\n" \
        "\tRed:\t\t{}\n" \
        "\tGreen:\t\t{} \n" \
        "\tBlue:\t\t{}\n" \
        " Margin:" \
        "{}\n" \
        " Justification:\t\t{} \n" \
        " Opacity:\t\t{} \n" \
        " Clip to Cell:\t\t{} \n" \
        "{}"

    CAPTION_TRAILING_TEXT = \
        " Is a suffix to a sequenced number or an image name. "

    CELL_GAP = " Is the number of sequenced-cells between mazes. "
    COLUMN_1 = \
        " Modifies the number of slats to draw \n" \
        " for the lower layer of the grate. "

    COLUMN_2 = \
        " Modifies the number of slats to draw \n" \
        " for the upper layers of the grate. "

    END_COORDINATE = \
        " The end coordinate is a fraction of the layer size \n" \
        " value. The coordinates will scale with the render size. "

    FEATHER = \
        " The initial feather is this number divided \n" \
        " by steps. Subsequent steps add the initial \n" \
        " value to the feather. This value becomes the \n" \
        " feather amount applied on the last step. "

    FORMAT_BOUNDS = \
        " When selected, the layer boundaries\n" \
        " are contained within the layer margins. "

    FORMAT_CLIP = \
        " If selected, the fringe material\n" \
        " is contained within a {}'s boundaries. "

    FREE_CELL_POSITION = \
        " The fixed-values and the computed fraction of the layer \n" \
        " size values are combined to set the cell location and size. \n" \
        " With the range of settings, It is possible that the cell and \n" \
        " its image will not be visible in the render. \n" \
        " In any event, the enforced minimum image size is 1 x 1 pixels. "

    FRINGE_ABOUT_GRADIENT = \
        " A gradient is applied over the fringe \n" \
        " rectanglar bounds. The fringe brush-strokes \n" \
        " are then painted with the overlapping gradient. "

    FRINGE_ABOUT_IMAGE = \
        " An image is sized to the fringe rectanglar bounds. The fringe \n" \
        " brush-strokes are then painted with the overlapping image. "

    FRINGE_ABOUT_MASK = \
        " The mask is made from fringe brush-strokes that are \n" \
        " cut into a required plaque. If there is no plaque, then \n" \
        " the fringe-mask will not produce anything. "

    FRINGE_ABOUT_ONE_COLOR = \
        " The fringe brush-strokes are painted with a single color. "

    FRINGE_ABOUT_PATTERN = \
        " The fringe rectanglar bounds are filled with \n" \
        " a pattern. The fringe brush-strokes are then \n" \
        " painted with the overlapping pattern. "

    FRINGE_ABOUT_TWO_COLOR = \
        " The fringe brush-strokes are painted with alternating colors. "

    FRINGE_CONTRACT = \
        " At zero, the fringe is drawn on the edge \n" \
        " of a cell. With contract, the edge moves \n" \
        " inward to the center of the cell. To get \n" \
        " the whole brush tip inside the cell, set \n" \
        " contract value to half of the brush size. "

    FRINGE_GRADIENT = \
        " Has Image?\t\t{} \n" \
        " Type:\t\t\t{} \n" \
        " Brush:\t\t\t{} \n" \
        " Brush Size:\t\t{}\n" \
        " Spacing:\t\t{}\n" \
        " Opacity:\t\t{}\n" \
        " Angle:\t\t\t{}\n" \
        " Hardness:\t\t{}\n" \
        " Contract:\t\t{} \n" \
        " Clip to Cell:\t\t{} \n" \
        " Gradient:\t\t{} \n" \
        " Gradient Type:\t{} \n" \
        " Gradient Angle:\t{} \n" \
        "{}"

    FRINGE_IMAGE = \
        " Has Image?\t{} \n" \
        " Type:\t\t{} \n" \
        " Brush:\t\t{} \n" \
        " Brush Size:\t{}\n" \
        " Spacing:\t{}\n" \
        " Opacity:\t{}\n" \
        " Angle:\t\t{}\n" \
        " Hardness:\t{}\n" \
        " Contract:\t{} \n" \
        " Clip to Cell:\t{} \n" \
        " Image:\t\t{} \n" \
        "{}"

    FRINGE_MASK = \
        " Has Image?\t{} \n" \
        " Type:\t\t{} \n" \
        " Brush:\t\t{} \n" \
        " Brush Size:\t{}\n" \
        " Spacing:\t{}\n" \
        " Opacity:\t{}\n" \
        " Angle:\t\t{}\n" \
        " Hardness:\t{}\n" \
        " Contract:\t{} "

    FRINGE_ONE_COLOR = \
        " Has Image?\t\t{} \n" \
        " Type:\t\t\t{} \n" \
        " Brush:\t\t\t{} \n" \
        " Brush Size:\t\t{}\n" \
        " Spacing:\t\t{}\n" \
        " Opacity:\t\t{}\n" \
        " Angle:\t\t\t{}\n" \
        " Hardness:\t\t{}\n" \
        " Color:\n" \
        "\tRed:\t\t{}\n" \
        "\tGreen:\t\t{} \n" \
        "\tBlue:\t\t{}\n" \
        " Contract:\t\t{} \n" \
        " Clip to Cell:\t\t{} \n" \
        "{}"

    FRINGE_PATTERN = \
        " Has Image?\t{} \n" \
        " Type:\t\t{} \n" \
        " Brush:\t\t{} \n" \
        " Brush Size:\t{}\n" \
        " Spacing:\t{}\n" \
        " Opacity:\t{}\n" \
        " Angle:\t\t{}\n" \
        " Hardness:\t{}\n" \
        " Contract:\t{} \n" \
        " Clip to Cell:\t{} \n" \
        " Pattern:\t\t{} \n" \
        "{}"

    FRINGE_TWO_COLOR = \
        " Has Image?\t{} \n" \
        " Type:\t\t{} \n" \
        " Brush:\t\t{} \n" \
        " Brush Size:\t{}\n" \
        " Spacing:\t{}\n" \
        " Opacity:\t{}\n" \
        " Angle:\t\t{}\n" \
        " Hardness:\t{}\n" \
        " Contract:\t{} \n" \
        " Clip to Cell:\t{} \n" \
        " Color #1:\n" \
        "\tRed:\t{}\n" \
        "\tGreen:\t{} \n" \
        "\tBlue:\t{}\n" \
        " Color #2:\n" \
        "\tRed:\t{}\n" \
        "\tGreen:\t{} \n" \
        "\tBlue:\t{}\n" \
        "{}"

    GRID_NORMALIZED = \
        " The layer space is filled with normalized \n" \
        " shapes using the shape counts. "

    GRID_FIXED_SIZE = \
        " The layer space is divided by these quantities to \n" \
        " calculate the row and column counts. If either the row \n" \
        " or column span exceeds the layer space size, then \n" \
        " the layer space size is used. \n" \
        " Thus there will always be at least one row and column. "

    GRID_BY_COUNT = \
        " The layer space is divided by these quantities to calculate \n" \
        " the row and column sizes. If the division has a remainder, \n " \
        " then the remainder is distributed evenly through the table. \n" \
        " Thus the entire layer space is utilized. "

    GRID_PIN = " The table will pin to one of these points. "
    GRID_LABEL = \
        " The layer space is the render size of the \n" \
        " backdrop image less the layer margins. \n "

    GRID_SHAPE = \
        " A cell shape differs from an image mask, \n" \
        " in that a mask is applied to the cell \n" \
        " instead of an image. \n" \
        " The shape of the cell changes \n" \
        " how the images are assigned on the cell grid. \n" \
        " \nThe Trim or Crop resize-types will fill a cell \n" \
        " better than the Locked-type. "

    GRID_SHIFT = \
        " When shifted, the grid's first \n" \
        " cell is row: 1, column: 2 "

    IMAGE_CHOICE_FLUX_DEC = \
        " Assign images using a circular-type index variable. \n" \
        " It will decrement itself before assigning an image. \n" \
        " Its value will rollover to the last opened image\n" \
        " after the first opened image.\n" \
        " Both the Increment and Decrement use the\n" \
        " same index variable. If the Decrement\n" \
        " index is used before the Increment index, the last\n" \
        " opened image will be the first opened image reference. " \

    IMAGE_CHOICE_FLUX_INC = \
        " Assign images using a circular-type index variable. This \n" \
        " Fluctuate index will increment before assigning an \n" \
        " image. Its value will rollover to the first opened image \n" \
        " after the last opened image.\n" \
        " Both the Increment and Decrement use the\n" \
        " same index variable. If the Increment \n" \
        " index is used before the Decrement index, the first\n" \
        " opened image will be the first opened image reference. " \

    IMAGE_CHOICE_NAME = \
        " The order of image name list is \n" \
        " from GIMP's opened image order. "

    IMAGE_CHOICE_NEXT_LINEAR = \
        " Assign images using an index variable.\n" \
        " Assign the first opened image,\n" \
        " increment after assigning an image,\n" \
        " and end image assignment with the last opened image. "

    IMAGE_CHOICE_NEXT_CIRCULAR = \
        " Assign images using an index variable.\n" \
        " It will assign the first opened image,\n" \
        " increment after assigning an image,\n" \
        " and will rollover to the first opened image \n" \
        " after the last opened image is used."

    IMAGE_CHOICE_NUMERIC = \
        " The order of the numeric list is \n" \
        " from GIMP's opened image order. "

    IMAGE_CHOICE_PRE_LINEAR = \
        " Assign images using an index variable.\n" \
        " It will assign the last opened image,\n" \
        " decrement after assigning an image, and end\n" \
        " image assignment with the first opened image. "

    IMAGE_CHOICE_PRE_CIRCULAR = \
        " Assign images using an index variable. \n" \
        " It will assign the last opened image, \n" \
        " decrement after assigning an image,\n" \
        " and rollover to the last opened image \n" \
        " after the first opened image is used. "

    IMAGE_MASK_SHAPE = \
        " Has Image?\t\t{}\n" \
        " Type:\t\t\t{} \n" \
        " Horizontal Scale:\t{} \n" \
        " Vertical Scale:\t{} "

    IMAGE_MASK_CHARACTER = \
        " Has Image?\t\t{} \n" \
        " Type:\t\t\t{} \n" \
        " Character:\t\t{} \n" \
        " Font:\t\t\t{} \n" \
        " Horizontal Scale:\t{} \n" \
        " Vertical Scale:\t{} "

    IMAGE_MASK_IMAGE = \
        " Has Image?\t\t{} \n" \
        " Type:\t\t\t{} \n" \
        " Image:\t\t\t{} "

    IMAGE_PROPERTY = \
        " Flip Horizontal:\t{} \n" \
        " Flip Vertical:\t\t{} \n" \
        " Rotate:\t\t\t{} \n" \
        " Opacity: \t\t{} \n" \
        " Blur Behind:\t\t{} "

    JAG_AMPLITUDE = " Use a higher value to increase the jag projection. "
    KEEP_GRADIENT = \
        " Have GIMP store the sampled gradient \n" \
        " in the user's gradient folder. "

    KEY_LIGHT_COMPLIMENT = \
        " Copy the Key-Light Shadow settings, but \n" \
        " lighter and with the light-direction reversed. "

    LAYOUT_FRINGE = " The Cell Fringe mask-type requires a Cell Plaque. "
    LAYOUT_MARGINS = " Cell Margins will typically overlay Cell Fringe. "
    LAYOUT_COORDINATES = \
        " Display the top-left screen coordinate of \n" \
        " an image's bounding rectangle."

    LAYOUT_CORNERS = \
        " Display the location of a cell's bounding \n" \
        " rectangle in screen coordinates."

    LAYOUT_DIMENSIONS = \
        " Dimensions are the size of the image's \n" \
        " bounding rectangle."

    LAYOUT_GRID = " The grid is made with rows and columns. "
    LAYOUT_RATIOS = \
        " A ratio is an image center point divided by the render size. "

    MAIN_CLOSE_FILE = \
        " If selected, any opened images will be closed \n" \
        " after their first use, freeing up the memory. The \n" \
        " downside is that if the image is referenced by \n" \
        " another cell, the image will be reloaded which will \n" \
        " take a lot longer than using an already opened image. "

    MAIN_OPTIONS = \
        " Open a backdrop-style and image-effect options window. "

    MAIN_RENDER = \
        " Render a composition using the format settings \n" \
        " with the backdrop-style and the image-effect options. "

    MAIN_LAYOUT = \
        " Create a sketch-up image of the render \n" \
        " using the above Layout Options."

    MAKE_OPAQUE = \
        " Make an item opaque to give it a solid or \n" \
        " stronger appearance. A side effect of the \n" \
        " opaque effect is the antialiasing will be gone. "

    MARGIN = \
        " Per margin, the fixed-value margin and the fraction-of \n" \
        " margin are added together to form a single margin. "

    MASK_CHARACTER = \
        " The character mask is made from the text in the\n" \
        " 'Character' entry with the font in the 'Font' entry. \n\n" \
        " Where the text-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and the text-height equals:\n" \
        "\timage height x vertical scale."

    MASK_CIRCLE = \
        " The circle mask's diameter is calculated from the image \n" \
        " size and the horizontal and vertical scale fractions.\n\n" \
        " Where width-diameter equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and height-diameter equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."

    MASK_CUT_CORNERS = \
        " The cut corners mask calculates an octagon that defines \n" \
        " the corners. This octagon is calculated from the image \n" \
        " size and the horizontal and vertical scale fractions.\n\n" \
        " Where uncut-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and uncut-height equals:\n" \
        "\timage height x vertical scale."

    MASK_DIAMOND = \
        " The diamond mask's diagonals are calculated from the image \n" \
        " size and the horizontal and vertical scale fractions.\n\n" \
        " Where width-diagonal equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and height-diagonal equals:\n" \
        "\timage height x vertical scale."

    MASK_IMAGE = \
        " The image mask uses an image's alpha channel as a mask. \n" \
        " This image's scale will be transformed to fill the cell. "

    MASK_OVAL = \
        " The oval mask's diameters are calculated from the image \n" \
        " size and the horizontal and vertical scale fractions.\n\n" \
        " Where width-diameter equals: \n" \
        "\timage width x horizontal scale,\n" \
        " and height-diameter equals:\n" \
        "\timage height x vertical scale."

    MASK_RECTANGLE = \
        " The rectangle mask's sides are calculated from the image size \n" \
        " and the horizontal and vertical scale fractions.\n\n" \
        " Where rectangle-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and rectangle-height equals:\n" \
        "\timage height x vertical scale."

    MASK_RHOMBUS = \
        " The rhombus mask's diagonal is calculated from the image size \n" \
        " and the horizontal and vertical scale fractions.\n\n" \
        " Where diagonal-value-1 equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and diagonal-value-2 equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."

    MASK_ROUND_CORNERS = \
        " The rounded corners mask calculates a ellipse that defines \n" \
        " the corners. This ellipse is calculated the from the image \n" \
        " size and the horizontal and vertical scale fractions.\n\n" \
        " Where ellipse-width equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and ellipse-height equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " This ellipse is drawn at each corner to form the rounded\n" \
        " corners."

    MASK_SQUARE = \
        " The square mask's side is calculated from the image size \n" \
        " and the horizontal and vertical scale fractions.\n\n" \
        " Where side-value-1 equals:\n" \
        "\timage width x horizontal scale,\n" \
        " and side-value-2 equals:\n" \
        "\timage height x vertical scale.\n\n" \
        " From these two values, the lesser value is used."

    MASK_TRIANGLE_DOWN = \
        " The triangle is pointing down and is squeezed \n " \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "

    MASK_TRIANGLE_LEFT = \
        " The triangle is pointing left and is squeezed \n " \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "

    MASK_TRIANGLE_RIGHT = \
        " The triangle is pointing right and is squeezed \n " \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "

    MASK_TRIANGLE_UP = \
        " The triangle is pointing up and is squeezed \n " \
        " into the rectangle created by the image's \n" \
        " dimensions multiplied by the scale values. "

    MAZE_GAP_TYPE = " Gaps between the mazes can be ordered or random. "
    MERGE_CELL = " X:\t\t{} \n Y:\t\t{} \n Width:\t{} \n Height:\t{} "

    n = " Apply cell data and show cell to the "
    NAVIGATION = (
        n + "north (ctrl + ↑). ",
        n + "south (ctrl + ↓). ",
        n + "west (ctrl + ←). ",
        n + "east (ctrl + →). "
    )

    NO_CAPTION = \
        " Has Image?\t{}\n" \
        " There is no text. "

    NO_FRINGE = \
        " Has Image?\t{}\n" \
        " There is no fringe. "

    NO_IMAGE_MASK = \
        " Has Image?\t{} \n" \
        " Type:\t\tNone "

    NO_PLAQUE = \
        " Has Image?\t{} \n" \
        " Type:\t\t{} "

    NOISE_POWER = \
        " Use a higher value to increase \n" \
        " the noise effect on the frame. "

    PER_CELL_BUTTON = \
        " Open a per cell window in order \n" \
        " to modify settings cell-by-cell. "

    PLACE = \
        " Image:\t\t{} \n" \
        " Resize:\t\t{} \n" \
        " Horizontal:\t{} \n" \
        " Vertical: \t{} "

    PLACE_WITH_FOLDER = \
        " Image:\t\t{} \n" \
        " Filter:\t\t{} \n" \
        " Resize:\t\t{} \n" \
        " Horizontal:\t{} \n" \
        " Vertical: \t{} "

    PLAQUE_AVERAGE_COLOR = \
        " Has Image?\t{} \n" \
        " Type:\t\t{} \n" \
        " Opacity:\t{} \n" \
        " Blur Behind:\t{} "

    PLAQUE_COLOR = \
        " Has Image?\t{} \n" \
        " Type:\t\t{} \n" \
        " Color:\n" \
        "\tRed:\t{} \n" \
        "\tGreen:\t{} \n" \
        "\tBlue:\t{} \n" \
        " Opacity:\t{} \n" \
        " Blur Behind:\t{} "

    PLAQUE_GRADIENT = \
        " Has Image?\t\t{} \n" \
        " Type:\t\t\t{} \n" \
        " Gradient:\t\t{} \n " \
        " Gradient Type:\t{} \n " \
        " Gradient Angle:\t{} \n" \
        " Opacity:\t\t{} \n" \
        " Blur Behind:\t\t{} "

    PLAQUE_IMAGE = \
        " Has Image?\t{} \n" \
        " Type:\t\t{} \n" \
        " Image:\t\t{} \n" \
        " Opacity:\t{} \n" \
        " Blur Behind:\t{} "

    PLAQUE_PATTERN = \
        " Has Image?\t{} \n" \
        " Type:\t\t{} \n" \
        " Pattern:\t\t{} \n" \
        " Opacity:\t{} \n" \
        " Blur Behind:\t{} "

    RANDOM_SEED = " Change this value to produce a different result. "
    RESIZE_CROP_VALUE = \
        " Crop the image from a topleft coordinate \n" \
        " defined by x and y. The size of the crop is \n" \
        " from the width and height options. \n" \
        " If the image doesn't fit in the cell, \n" \
        " a selection is made from the image using \n" \
        " the cell's justification and size. "

    RESIZE_FIXED_VALUE = \
        " The image is resized to these dimensions. \n" \
        " If the image doesn't fit in the cell, \n" \
        " a selection is made from the image using \n" \
        " the cell's justification and size. "

    RESIZE_FRACTION_VALUE = \
        " The image is resized by multiplying the \n" \
        " fractional values by the image size. If \n" \
        " the image doesn't fit in the cell, a \n" \
        " selection is made from the image using \n" \
        " using the cell's justification and size. "

    ROUNDED = " The Rounded process is faster. "
    SAMPLE_POINTS = " Sample points are evenly distributed between the edges. "
    SAMPLE_VECTOR = \
        " Is an imaginary line that connects the edges of the \n" \
        " image and is used to make the sample points. "

    SCALE = " Use a higher value to make the texture effect larger. "
    SCATTER_COUNT = " Is the number of mazes to draw. "
    START_X = \
        " The start coordinate is a fraction of the layer size \n" \
        " value. The coordinate will scale with the render size. "

    STEPS = " The image feather effect repeats by this quantity. "
    STOP_LENGTH = \
        " Is the lowest value of pixels \n" \
        " for drawing a line in a maze. "

    THRESHOLD = \
        " A threshold of 1.0 is to match all \n" \
        " and a threshold of 0.0 is to mach none. "

    WHIRL = " As if there were a hole at the center of the image. "
