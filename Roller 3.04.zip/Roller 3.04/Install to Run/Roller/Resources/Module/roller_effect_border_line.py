#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_constant_fu import Fu
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

em = Fu.Emboss
pdb = fu.pdb
BRIGHTNESS_ZERO = 0
CONTRAST_50 = 50
ELEVATION_30 = 30.


def add_noise_layer(z, d):
    """
    Add a bump layer.

    z: layer
        to clone from

    d: dict
        Has options.
    """
    n = z.name
    z, z1 = RenderHub.add_noise(z, d)

    if z1:
        z1.mode = fu.LAYER_MODE_HARDLIGHT
        z1.opacity = d[ok.NOISE_OPACITY]
        z = pdb.gimp_image_merge_down(z.image, z1, fu.CLIP_TO_IMAGE)
        z.name = n
    return z


class BorderLine:
    """Create a metallic-like border around images."""

    @staticmethod
    def do(one, filler=None, framer=None):
        """
        Do the Border Line image-effect.

        one: One
            Has variables.

        filler: function
            Call to fill a frame.

        framer: function
            Call to add more frame.

        Return: layer
            with metal frame
        """
        cat = Hat.cat
        parent = one.parent
        d = one.d
        j = cat.render.image
        z = Lay.add(j, Lay.make_name(parent, one.k), parent=parent)

        Sel.make_layer_sel(one.image_layer)

        one.image_sel = cat.save_short_term_sel()

        Sel.grow(j, d[ok.FRAME_WIDTH], d[ok.FRAME_TYPE])

        sel = cat.save_short_term_sel()
        sel1 = None

        if filler or (filler and framer):
            # Create filler and outer selections:
            Sel.grow(j, d[ok.WIDTH], d[ok.FRAME_TYPE])
            Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
            Sel.grow(j, 1, d[ok.FRAME_TYPE])

            # for filler:
            sel1 = cat.save_short_term_sel()

            Sel.grow(
                j,
                max(int(d[ok.FRAME_WIDTH] / 3.5), 3),
                d[ok.FRAME_TYPE]
            )
            Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)
            Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

        if framer:
            # Pass the frame and filler selections:
            framer(one, cat.save_short_term_sel(), sel1)

        Sel.load(j, one.image_sel, option=fu.CHANNEL_OP_SUBTRACT)
        Sel.fill(z, (127, 127, 127))
        pdb.gimp_selection_none(j)
        pdb.plug_in_emboss(
            j, z,
            cat.light_angle,
            ELEVATION_30,
            em.DEPTH_1,
            em.EMBOSS
        )
        pdb.gimp_brightness_contrast(z, BRIGHTNESS_ZERO, CONTRAST_50)
        pdb.plug_in_antialias(j, z)

        z = add_noise_layer(z, d)
        z = GradientLight.apply_light(z, ok.METAL_FRAME)

        if filler:
            # Pass the filler selection:
            z1 = filler(z, one, sel1)
            if z1:
                z = pdb.gimp_image_merge_down(z.image, z1, fu.CLIP_TO_IMAGE)

        one.shadow_layer = [z, one.image_layer]
        return z
