#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk, Window as wi
from roller_port_choice import PortChoice
from roller_window import Window


class RWChoice(Window):
    """Is a GTK dialog with a list for the user to select an item."""

    def __init__(self, g):
        """
        Create a choice window.

        g: OptionButton
            Has values.
            Is responsible.
        """
        self.safe = g
        d = {}
        k = g.key
        d[wk.WIN] = g.win.win
        d[wk.WINDOW_TITLE] = "Choose a {}".format(k)
        d[wk.WINDOW_KEY] = wi.CHOOSER

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self
            }
        )

        self.port = PortChoice(d, g, k)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()
