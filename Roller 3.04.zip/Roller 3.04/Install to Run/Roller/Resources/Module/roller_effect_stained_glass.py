#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from random import randint, seed
from roller_constant_key import Option as ok
from roller_constant_fu import Fu
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

hs = Fu.HueSaturation
pdb = fu.pdb


def do_job(_, one, fill_sel):
    """
    Receive task from BorderLine to draw glass.

    _: layer
        no use

    one: One
        Has options.

    sel: Selection
        of fill space
    """
    cat = Hat.cat
    j = cat.render.image
    d = one.d
    z = Lay.add(j, one.k, parent=one.parent)
    z = RenderHub.do_rotated_layer(z, d, draw_glass)
    z.name = Lay.make_name(one.parent, one.k)
    e = deepcopy(d)
    e[ok.ROTATE] = randint(-45, 0)
    z = Lay.add(j, one.k, parent=one.parent)
    z = RenderHub.do_rotated_layer(z, e, draw_glass)
    z.mode = fu.LAYER_MODE_DIFFERENCE
    z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    pdb.gimp_drawable_hue_saturation(
        z,
        fu.HUE_RANGE_ALL,
        hs.HUE_OFFSET_0,
        hs.LIGHTNESS_0,
        hs.SATURATION_MINUS_35,
        hs.OVERLAP_0
    )
    Sel.isolate(z, fill_sel)

    z = GradientLight.apply_light(z, ok.TRANSLUCENT_FRAME)
    z.opacity = 50.
    return z


def draw_glass(z, d):
    """
    Draw the glass panes.

    z: layer
        to receive glass panes

    d: dict
        Has options.

    Return: layer
        the glass layer
    """
    return RenderHub.draw_color_rectangles(
        z,
        d[ok.PANE_WIDTH], d[ok.PANE_HEIGHT]
    )


class StainedGlass:
    """Create a frame with colorful transparent glass."""

    @staticmethod
    def do(one):
        """
        Do the Stained Glass image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer
            with Stained Glass
        """
        seed(one.d[ok.RANDOM_SEED])
        return BorderLine.do(one, filler=do_job)
