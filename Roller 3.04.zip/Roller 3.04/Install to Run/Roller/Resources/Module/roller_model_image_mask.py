#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Format as ff,
    Plan as fy,
    Mask as ms,
    Shape as sh,
    Triangle as ft
)
from roller_constant_key import Layer as nk, Option as ok
from roller_effect_feather_steps import FeatherSteps
from roller_model_image import Image
from roller_model_text import Text
from roller_one import Comm, Hat
from roller_one_fu import Lay, Mage, Sel
from roller_one_extract import Form, Shape
import gimpfu as fu

pdb = fu.pdb
NO_ANTIALIAS = 0
RATIO = sh.TRIANGLE_SCALE_RATIO_DOWN
UP_RATIO = sh.TRIANGLE_SCALE_RATIO_UP


def do_circle(j, one):
    """
    Add a circle selection to the selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    # Make into circle.
    # x, y are topleft:
    w = min(one.w, one.h)
    Sel.ellipse(
        j,
        one.center_x - w // 2, one.center_y - w // 2,
        w, w,
        option=fu.CHANNEL_OP_REPLACE
    )


def do_cut_corners_mask(j, one):
    """
    Add a cut corners selection to the selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    # Make into diamond:
    x, y, w, h = one.x, one.y, one.w, one.h
    w1 = (one.image_w - w) // 2
    h1 = (one.image_h - h) // 2

    # eight segments:
    q = (
        x + w1, y,
        x + one.image_w - w1, y,
        x + one.image_w, y + h1,
        x + one.image_w, y + one.image_h - h1,
        x + one.image_w - w1, y + one.image_h,
        x + w1, y + one.image_h,
        x, y + one.image_h - h1,
        x, y + h1
    )
    Sel.polygon(j, q)


def do_diamond(j, one):
    """
    Add a diamond selection to the selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    w, h = one.w // 2, one.h // 2
    x = one.center_x
    y = one.center_y

    # four segments:
    q = (
        x, y - h,
        x + w, y,
        x, y + h,
        x - w, y
    )
    Sel.polygon(j, q)


def do_hexagon_horizontal(j, one):
    """
    Add a hexagonal horizontally aligned shape to the selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    w, h = one.w, one.h

    # There are two possible solutions.
    # first solution:
    w1, h1 = w, w * UP_RATIO

    # Check for overflow:
    if h1 > h:
        # second solution:
        w1, h1 = h * RATIO, h

    q = Shape.calc_hexagon_horizontal_offset(w1, h1)
    Sel.polygon(
        j,
        Shape.calc_hexagon_horizontal_shape(
            one.center_x - q[0], one.center_y - q[2],
            w1, h1,
            q
        )
    )


def do_hexagon_vertical(j, one):
    """
    Add a hexagonal vertically aligned shape to the selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    w, h = one.w, one.h

    # There are two possible solutions.
    # first solution:
    w1, h1 = h * UP_RATIO, h

    # Check for overflow:
    if w1 > w:
        # second solution:
        w1, h1 = w, w * RATIO

    q = Shape.calc_hexagon_vertical_offset(w1, h1)
    x = one.center_x - q[1]
    y = one.center_y - q[3]
    Sel.polygon(
        j,
        Shape.calc_hexagon_vertical_shape(x, y, w1, h1, q)
    )


def do_image(j, one):
    """
    Add an image selection to the selection.

    Image masks transform their shape to a cell rectangle.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    j1 = Image.get_image(one.d[ok.IMAGE], one.image_index)
    if j1:
        Mage.copy_all(j1.j)

        j2 = pdb.gimp_edit_paste_as_new_image()

        # Shape, copy, and delete image:
        Mage.shape(j2, one.w, one.h)

        z = Lay.paste(j.layers[-1])

        # x, y is topleft:
        x = one.center_x - one.w // 2
        y = one.center_y - one.h // 2

        pdb.gimp_layer_set_offsets(z, x, y)
        Sel.item(z)
        pdb.gimp_image_remove_layer(j, z)
        Image.close_image(j1)


def do_octagon(j, one):
    """
    Add an octagon selection to the selection.

    The web address with a helpful formula:
        math.stackexchange.com/
        questions/22064/
        calculating-a-point-that-lies-on-an-ellipse-given-an-angle

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    w = min(one.w, one.h)

    # x, y is topleft:
    x = one.center_x - w // 2
    y = one.center_y - w // 2

    q = Shape.calc_octagon_offset(w, w)
    Sel.polygon(
        j,
        Shape.calc_octagon_shape(x, y, w, w, q)
    )


def do_octagon_aligned(j, one):
    """
    Add an octagon selection to the selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    w = min(one.w, one.h)

    # x, y is topleft:
    x = one.center_x - w // 2
    y = one.center_y - w // 2

    q = Shape.calc_octagon_aligned_offset(w, w)
    Sel.polygon(
        j,
        Shape.calc_octagon_aligned_shape(x, y, w, w, q)
    )


def do_oval(j, one):
    """
    Add a oval selection to the selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    # x, y are topleft:
    w, h = one.w, one.h
    Sel.ellipse(
        j,
        one.center_x - w // 2,
        one.center_y - h // 2,
        w, h,
        option=fu.CHANNEL_OP_REPLACE
    )


def do_rectangle(j, one):
    """
    Add a rectangle selection to the selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    w, h = one.w, one.h
    x = one.center_x - w // 2
    y = one.center_y - h // 2
    Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)


def do_rhombus(j, one):
    """
    Add a rhombus selection to the selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    w = min(one.w, one.h) // 2
    x = one.center_x
    y = one.center_y
    q = (
        x, y - w,
        x + w, y,
        x, y + w,
        x - w, y
    )
    Sel.polygon(j, q)


def do_rounded_corners(j, one):
    """
    Add a square selection to the selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    x, y, w, h = one.x, one.y, one.w, one.h

    # top-left:
    Sel.ellipse(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)

    # top-right:
    x1 = x + one.image_w - w

    Sel.ellipse(j, x1, y, w, h)

    # bottom-left:
    y1 = y + one.image_h - h

    Sel.ellipse(j, x, y1, w, h)

    # bottom-right:
    Sel.ellipse(j, x1, y1, w, h)

    # vertical rectangle:
    x2 = x + w // 2
    w1 = one.image_w - w

    Sel.rect(j, x2, y, w1, one.image_h)

    # horizontal rectangle:
    y2 = y + h // 2
    h1 = one.image_h - h

    Sel.rect(j, x, y2, one.image_w, h1)


def do_square(j, one):
    """
    Add a square selection to the selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    w = min(one.w, one.h)
    x = one.center_x - w // 2
    y = one.center_y - w // 2
    Sel.rect(j, x, y, w, w, option=fu.CHANNEL_OP_REPLACE)


def do_text(j, one):
    """
    Add a character selection to the selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    font = one.d[ok.FONT]

    if font not in Hat.cat.font_list:
        Comm.info_msg(ff.MISSING_ITEM.format("Image-Mask", "font", font))
    else:
        font_size = max(one.w, one.h)
        character = one.d[ok.TEXT]
        if character:
            z = Lay.add(j, "text")
            go, z1 = Text.make_text_layer(
                j, z,
                NO_ANTIALIAS,
                one.x, one.y,
                character,
                font_size,
                font,
                (255, 255, 255),
                one.w, one.h
            )
            if go:
                Sel.item(z1)

                is_sel, x, y, x1, y1 = pdb.gimp_selection_bounds(j)

                if is_sel:
                    x = one.center_x - ((x1 - x) // 2)
                    y = one.center_y - ((y1 - y) // 2)

                    pdb.gimp_layer_set_offsets(z1, x, y)
                    Sel.item(z1)
                for i in (z, z1):
                    pdb.gimp_image_remove_layer(j, i)


def do_triangle_down(j, one):
    """
    Add an down-facing-triangle selection
    to the existing selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    w = one.w // 2
    h = one.h // 2
    x = one.center_x
    y = one.center_y
    q = (
        x - w, y - h,
        x + w, y - h,
        x, y + h
    )
    Sel.polygon(j, q)


def do_triangle_left(j, one):
    """
    Add an left-facing-triangle selection
    to the existing selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    w = one.w // 2
    h = one.h // 2
    x = one.center_x
    y = one.center_y
    q = (
        x + w, y - h,
        x + w, y + h,
        x - w, y
    )
    Sel.polygon(j, q)


def do_triangle_right(j, one):
    """
    Add an right-facing-triangle selection
    to the existing selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    w = one.w // 2
    h = one.h // 2
    x = one.center_x
    y = one.center_y
    q = (
        x - w, y - h,
        x - w, y + h,
        x + w, y
    )
    Sel.polygon(j, q)


def do_triangle_up(j, one):
    """
    Add an up-facing-triangle selection
    to the existing selection.

    j: GIMP image
        to receive selection

    one: One
        Has cell data.
    """
    w = one.w // 2
    h = one.h // 2
    x = one.center_x
    y = one.center_y
    q = (
        x - w, y + h,
        x + w, y + h,
        x, y - h
    )
    Sel.polygon(j, q)


mask_function = {
    ms.CIRCLE: do_circle,
    ms.CUT_CORNERS: do_cut_corners_mask,
    ms.DIAMOND: do_diamond,
    ms.HEXAGON_HORIZONTAL: do_hexagon_horizontal,
    ms.HEXAGON_VERTICAL: do_hexagon_vertical,
    ms.IMAGE: do_image,
    ms.OCTAGON: do_octagon,
    ms.OCTAGON_ALIGNED: do_octagon_aligned,
    ms.OVAL: do_oval,
    ms.RECTANGLE: do_rectangle,
    ms.RHOMBUS: do_rhombus,
    ms.ROUNDED_CORNERS: do_rounded_corners,
    ms.SQUARE: do_square,
    ms.TEXT: do_text,
    ft.TRIANGLE_DOWN: do_triangle_down,
    ft.TRIANGLE_LEFT: do_triangle_left,
    ft.TRIANGLE_RIGHT: do_triangle_right,
    ft.TRIANGLE_UP: do_triangle_up
}


class ImageMask:
    """Manage image mask related tasks with a static class."""

    @staticmethod
    def do_custom_cell(one):
        """
        Make a mask layer for the image layer.
        The masks are defined by the user in
        the image / mask option.

        one: One
            Has variables.

        Return: layer or None
            Has a layer with an image if it received a mask.
        """
        cat = Hat.cat
        j = cat.render.image
        d = one.d
        name = one.model_name
        has_mask = False
        r = fy.CUSTOM_CELL
        sel = cat.get_image_sel(name, r, r)
        _type = d[ok.MASK_TYPE]

        if _type != "None" and sel:
            a = one.cell.mold
            x, y = a.position
            w, h = a.size
            one.x, one.y = x, y
            one.image_w, one.image_h = w, h
            one.center_x, one.center_y = x + w // 2, y + h // 2

            # scale:
            one.w = w * d[ok.HORZ_SCALE]
            one.h = h * d[ok.VERT_SCALE]

            # Add mask:
            if _type in mask_function:
                mask_function[_type](j, one)
                has_mask = True
        if Sel.is_sel(j) and has_mask:
            FeatherSteps.feather_sel(j, d)
        if Sel.is_sel(j) and has_mask:
            cat.save_mask_sel(name, r, r)

            # image layer, 'z':
            z = cat.get_layer((one.render_type, one.model_name, nk.IMAGE))
            mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)

            pdb.gimp_layer_add_mask(z, mask)
            return z

    @staticmethod
    def do_grid(one):
        """
        Make a mask layer for the image layer.
        The masks are defined by the user in
        the image / mask option.

        one: One
            Has variables.

        Return: layer or None
            Has a layer with an image if it received a mask.
        """
        cat = Hat.cat
        j = cat.render.image
        row, column = one.grid.division
        d = one.d
        grid_d = one.grid.grid_d
        is_merge_cell = one.grid.is_merge_cell
        name = one.model_name
        has_mask = False
        go = True

        if not d[ok.PER_CELL] and d[ok.MASK_TYPE] == "None":
            go = False

        if go:
            for r in range(row):
                for c in range(column):
                    go = True
                    e = one.d = Form.get_form(d, r, c)

                    if e[ok.MASK_TYPE] == "None":
                        go = False

                    if go:
                        go = Shape.is_allocated_cell(one.grid, r, c)

                    if go:
                        go = cat.is_image_sel(name, r, c)

                    if go:
                        if (
                            is_merge_cell and
                            grid_d[ok.PER_CELL][r][c] == (-1, -1)
                        ):
                            go = False

                    if go:
                        rect = one.grid.get_mold(r, c)
                        x, y, = one.x, one.y = rect.position
                        w, h = one.w, one.h = rect.size

                        one.image_w, one.image_h = w, h
                        one.center_x, one.center_y = x + w // 2, y + h // 2
                        n = e[ok.MASK_TYPE]

                        # scale:
                        one.w *= e[ok.HORZ_SCALE]
                        one.h *= e[ok.VERT_SCALE]

                        # Add mask:
                        if n in mask_function:
                            mask_function[n](j, one)

                            if Sel.is_sel(j):
                                FeatherSteps.feather_sel(j, e)

                            cat.save_mask_sel(name, r, c)
                            has_mask = True

        # Preserve an image view by adding its selection to the mask layer:
        q = []

        if has_mask:
            for r in range(row):
                for c in range(column):
                    sel = cat.get_image_sel(name, r, c)
                    sel1 = cat.get_mask_sel(name, r, c)
                    if sel and not sel1:
                        q += [sel]

        pdb.gimp_selection_none(j)

        # Combine the image mask selections:
        if has_mask:
            for r in range(row):
                for c in range(column):
                    sel = cat.get_mask_sel(name, r, c)
                    Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)

        # Were there any masks?
        # If so, then create a layer mask for the image layer:
        if Sel.is_sel(j):
            for i in q:
                Sel.load(j, i, option=fu.CHANNEL_OP_ADD)

            # image layer, 'z':
            z = cat.get_layer((one.render_type, one.model_name, nk.IMAGE))
            mask = pdb.gimp_layer_create_mask(z, fu.ADD_MASK_SELECTION)

            pdb.gimp_layer_add_mask(z, mask)
            return z
