#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import seed
from roller_constant_for import BackdropStyle as bs
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
mo = Fu.Mosaic


def do_job(_, one, sel):
    """
    Draw the ceramic chip.

    _: layer
        not used

    one: One
        with options

    sel: Selection
        for ceramic chips

    Return: layer
        the ceramic chip layer
    """
    d = one.d

    # A random sequence is reproducible given the same seed:
    seed(d[ok.RANDOM_SEED])
    cat = Hat.cat
    j = cat.render.image
    z = Lay.add(j, "Chip", parent=one.parent)
    s = cat.render.size
    a = min(int(d[ok.MESH_SIZE] * 1.2), s[0], s[1])
    z = RenderHub.draw_color_rectangles(z, a, a)

    pdb.gimp_selection_all(j)
    pdb.plug_in_waves(j, z, 10, 1, 50, 0, 1)
    pdb.plug_in_mosaic(
        j, z,
        d[ok.MESH_SIZE],
        mo.TILE_HEIGHT_1,
        mo.TILE_SPACING_MIN,
        mo.TILE_NEATNESS_MIDDLE,
        mo.NO_SPLIT,
        Hat.cat.light_angle,
        mo.MIN_COLOR_VARIATION,
        mo.YES_ANTIALIAS,
        mo.YES_COLOR_AVERAGING,
        bs.MESH_TYPE.index(d[ok.MESH_TYPE]),
        mo.SMOOTH_SURFACE,
        mo.BLACK_AND_WHITE_GROUT
    )

    z = Lay.clone(z)
    z.opacity = 50.
    z.mode = fu.LAYER_MODE_LCH_COLOR

    pdb.plug_in_colorify(j, z, d[ok.COLOR])

    z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

    Sel.isolate(z, sel)

    z = GradientLight.apply_light(z, ok.OTHER_FRAME)
    return z


class CeramicChip:
    """Create a frame with colorful ceramic pieces."""

    @staticmethod
    def do(one):
        """
        Do the Ceramic Chip image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer
            with Ceramic Chip
        """
        return BorderLine.do(one, filler=do_job)
