#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Group as og
from roller_constant_key import (
    BackdropStyle as by,
    Effect as ek,
    Group as gk,
    Option as ok,
    Widget as wk
)
from roller_option_preset import (
    BEHIND_TYPE,
    NonPreset,
    PerCell,
    Preset,
    SuperPreset
)
from roller_option_group import OptionGroup
from roller_widget_box import Eventful, VBow
from roller_widget_label import Label
from roller_widget_tree import Node

# Are flags used to add buttons to an option group:
BUTTON_KEY = (
    wk.HAS_EFFECT_PAIR,
    wk.HAS_GRID_PAIR,
    wk.HAS_PREVIEW,
    wk.HAS_RANDOM
)

# for groups without a Per Cell option:
GRID_TYPE = {
    wk.WIDGET: Preset,
    wk.HAS_GRID_PAIR: True,
    wk.HAS_PRESET: True
}

# for groups with a Per Cell option:
PER_CELL_TYPE = {wk.WIDGET: PerCell, wk.HAS_PRESET: True}

# Use with backdrop-styles and image-effect groups:
RENDER_EFFECT = {
    wk.HAS_PRESET: True,
    wk.HAS_EFFECT_PAIR: True,
    wk.WIDGET: Preset
}

# Use with the Tri-Shadow group in its satellite window:
SHADOW_EFFECT = {
    wk.HAS_PRESET: True,
    wk.HAS_RANDOM: True,
    wk.WIDGET: Preset
}

# for groups with only a preset:
SUPER_PRESET = {wk.WIDGET: SuperPreset, wk.HAS_PRESET: True}


def draw_per_cell(d, group_key):
    """
    Draw an option group for a Per Cell type group.

    Per Cell groups have an option group that applies
    to all cells in a grid, and a Per Cell option
    that applies to cells individually.

    d: dict
        Has group options.

    group_key: string
        identifier
    """
    g = d[wk.CONTAINER]
    d[wk.HAS_PRESET] = d[wk.HAS_GRID_PAIR] = True
    vbox = d[wk.CONTAINER] = VBow()

    # Get group key of option for all cells:
    k = d[wk.GROUP_KEY] = og.SOURCE_GROUP_KEY[group_key]
    d[wk.KEYS] = Preset.get_keys(k)
    d[wk.BOTTOM_PAD] = 0
    d[wk.GROUP_TYPE] = Preset
    g.add(vbox)

    d1 = OptionGroup.draw_group(**d)

    # per cell:
    d[wk.GROUP_KEY] = group_key
    d[wk.GROUP_TYPE] = PerCell
    d[wk.CONTAINER] = g
    d[wk.KEYS] = ok.PER_CELL,
    d[wk.TOP_PAD] = 1
    d[wk.PATH] = d[wk.PATH][:-1] + (group_key,)

    for i in (wk.BOTTOM_PAD, wk.HAS_GRID_PAIR):
        d.pop(i)

    d2 = OptionGroup.draw_group(**d)
    g1 = d2[ok.PER_CELL]

    if ok.GRID_TYPE in d1:
        d1[ok.GRID_TYPE].group.per_cell = g1

    # Connect the VBox to the PerCellGroup
    # so its cell table can be accessed:
    vbox.per_cell_group = g1


# 'object' is a new style class reference for Python 2.7:
class PortNode(object):
    """Has functions used to create Node navigation."""

    def __init__(self, d):
        """Initialize variables."""
        a = self.color
        self.column_color = []

        for i in range(9):
            self.column_color += [self.color]
            self.reduce_color()

        self.color = a

        if hasattr(self, 'd'):
            self.d.update(
                {
                    wk.ON_KEY_PRESS: self.on_key_press,
                    wk.ON_WIDGET_CHANGE: self.on_widget_change,
                    wk.PORT: self,
                    wk.SAVE_WINDOW: d[wk.SAVE_WINDOW]
                }
            )

            # Is used to make the navigation option groups:
            self.group_def = {
                by.BACKDROP_IMAGE: RENDER_EFFECT,
                ek.SHADOW_2: SHADOW_EFFECT,
                ek.INNER_SHADOW: SHADOW_EFFECT,
                ek.SHADOW_1: SHADOW_EFFECT,
                gk.BACKDROP: {
                    wk.LABELS: (by.BACKDROP_IMAGE, gk.BACKDROP_STYLE),
                    wk.WIDGET: Node
                },
                gk.BACKDROP_STYLE: {wk.WIDGET: NonPreset, wk.HAS_RANDOM: True},
                gk.BLUR_BEHIND: {
                    wk.LABELS: (gk.IMAGE_BEHIND, gk.CAPTION_BEHIND),
                    wk.WIDGET: Node
                },
                gk.CAPTION_BEHIND: BEHIND_TYPE,
                gk.CUSTOM_CELL_CAPTION: GRID_TYPE,
                gk.CUSTOM_CELL_BORDER: GRID_TYPE,
                gk.CUSTOM_CELL_CELL: {
                    wk.LABELS: (
                        gk.CUSTOM_CELL_PROPERTY,
                        gk.RECTANGLE,
                        gk.CUSTOM_CELL_MARGIN,
                        gk.CUSTOM_CELL_PLAQUE,
                        gk.CUSTOM_CELL_FRINGE,
                        gk.CUSTOM_CELL_BORDER
                    ),
                    wk.PARENT_TYPE: gk.CUSTOM_CELL_CELL,
                    wk.WIDGET: Node
                },
                gk.CUSTOM_CELL_FRINGE: GRID_TYPE,
                gk.CUSTOM_CELL_IMAGE: {
                    wk.LABELS: (
                        gk.CUSTOM_CELL_IMAGE_PLACE,
                        gk.CUSTOM_CELL_IMAGE_MASK,
                        gk.CUSTOM_CELL_CAPTION
                    ),
                    wk.PARENT_TYPE: gk.CUSTOM_CELL_CELL,
                    wk.WIDGET: Node
                },
                gk.CUSTOM_CELL_IMAGE_MASK: GRID_TYPE,
                gk.CUSTOM_CELL_IMAGE_PLACE: GRID_TYPE,
                gk.CUSTOM_CELL_MARGIN: GRID_TYPE,
                gk.CUSTOM_CELL_MODEL: {
                    wk.LABELS: (
                        gk.CUSTOM_CELL_CELL,
                        gk.CUSTOM_CELL_IMAGE,
                        gk.PRESET_CUSTOM_CELL,
                        gk.IMAGE_EFFECT,
                        gk.BLUR_BEHIND
                    ),
                    wk.WIDGET: Node
                },
                gk.CUSTOM_CELL_PLAQUE: GRID_TYPE,
                gk.CUSTOM_CELL_PROPERTY: {wk.WIDGET: NonPreset},
                gk.EFFECT: {
                    wk.LABELS: (gk.MODEL,),
                    wk.WIDGET: Node
                },
                gk.MODEL: {wk.HAS_GRID_PAIR: True, wk.WIDGET: NonPreset},
                gk.GRID_CELL: {
                    wk.LABELS: (
                        gk.PER_CELL_GRID,
                        gk.PER_CELL_MARGIN,
                        gk.PER_CELL_PLAQUE,
                        gk.PER_CELL_FRINGE,
                        gk.PER_CELL_BORDER
                    ),
                    wk.PARENT_TYPE: gk.GRID_CELL,
                    wk.WIDGET: Node
                },
                gk.GRID_IMAGE: {
                    wk.LABELS: (
                        gk.PER_CELL_IMAGE_PLACE,
                        gk.PER_CELL_IMAGE_MASK,
                        gk.PER_CELL_CAPTION
                    ),
                    wk.PARENT_TYPE: gk.GRID_CELL,
                    wk.WIDGET: Node
                },
                gk.GRID_LAYER: {
                    wk.LABELS: (
                        gk.LAYER_MARGIN,
                        gk.LAYER_PLAQUE,
                        gk.LAYER_FRINGE,
                        gk.LAYER_BORDER,
                        gk.LAYER_CAPTION
                    ),
                    wk.PARENT_TYPE: gk.GRID_LAYER,
                    wk.WIDGET: Node
                },
                gk.TABLE_MODEL: {
                    wk.LABELS: (
                        gk.TABLE_PROPERTY,
                        gk.GRID_LAYER,
                        gk.GRID_CELL,
                        gk.GRID_IMAGE,
                        gk.PRESET_TABLE,
                        gk.IMAGE_EFFECT,
                        gk.BLUR_BEHIND
                    ),
                    wk.WIDGET: Node
                },
                gk.TABLE_PROPERTY: {wk.WIDGET: NonPreset},
                gk.GLOBAL: {wk.WIDGET: NonPreset, wk.HAS_RANDOM: True},
                gk.GRADIENT_LIGHT: RENDER_EFFECT,
                gk.IMAGE_BEHIND: BEHIND_TYPE,
                gk.IMAGE_EFFECT: {wk.WIDGET: NonPreset, wk.HAS_RANDOM: True},
                gk.LAYER_BORDER: GRID_TYPE,
                gk.LAYER_CAPTION: GRID_TYPE,
                gk.LAYER_FRINGE: GRID_TYPE,
                gk.LAYER_MARGIN: GRID_TYPE,
                gk.LAYER_PLAQUE: GRID_TYPE,
                gk.PER_CELL_BORDER: PER_CELL_TYPE,
                gk.PER_CELL_CAPTION: PER_CELL_TYPE,
                gk.PER_CELL_FRINGE: PER_CELL_TYPE,
                gk.PER_CELL_GRID: PER_CELL_TYPE,
                gk.PER_CELL_IMAGE_PLACE: PER_CELL_TYPE,
                gk.PER_CELL_IMAGE_MASK: PER_CELL_TYPE,
                gk.PER_CELL_MARGIN: PER_CELL_TYPE,
                gk.PER_CELL_PLAQUE: PER_CELL_TYPE,
                gk.PRESET_CUSTOM_CELL: SUPER_PRESET,
                gk.PRESET_TABLE: SUPER_PRESET,
                gk.PRESET_STEPS: SUPER_PRESET,
                gk.PRESET_TRI_SHADOW: {
                    wk.WIDGET: SuperPreset,
                    wk.HAS_PRESET: True
                },
                gk.RECTANGLE: GRID_TYPE,
                gk.SHADOW_TYPE: {wk.WIDGET: NonPreset},
                gk.STEPS: {
                    wk.LABELS: (
                        gk.GLOBAL,
                        gk.BACKDROP,
                        gk.GRADIENT_LIGHT,
                        gk.EFFECT,
                        gk.PRESET_STEPS
                    ),
                    wk.WIDGET: Node
                },
                gk.TRI_SHADOW: {
                    wk.LABELS: (
                        gk.SHADOW_TYPE,
                        ek.SHADOW_1,
                        ek.SHADOW_2,
                        ek.INNER_SHADOW,
                        gk.PRESET_TRI_SHADOW
                    ),
                    wk.WIDGET: Node
                }
            }

    def _create_node(self, d, group_key, level, path, group_id=None):
        """
        Create a Node option group.

        Is recursive with 'self._draw_options'.

        d: dict
            Has node options.

        group_key: string
            identifier

        level: int
            navigation depth

        path: tuple
            of nodes to an option group
        """
        if group_id is None:
            group_id = group_key

        labels = self.group_def[group_id][wk.LABELS]
        d[wk.LABELS] = [i.split(",")[0] for i in labels]
        d[wk.LEVEL] = level
        d[wk.COLOR] = self.column_color[level]
        d[wk.GROUP_TYPE] = Node
        k = wk.PARENT_TYPE

        if k in self.group_def[group_id]:
            d[k] = self.d[k] = self.group_def[group_id][k]

        node = Node(**d)
        node.group = d[wk.GROUP] = OptionGroup(**d)
        node.group.d = {group_id: node}
        node.group.node = node
        for x1, i in enumerate(labels):
            vbox = PortNode.add_group_to_node(node, i)
            level, path = self._draw_options(
                vbox,
                i,
                level + 1,
                path
            )

    def _draw_options(self, g, group_key, level, path):
        """
        Draw the options.

        Is recursive with 'self._create_node'.

        g: container
            container for options

        group_key: string
            group key

        level: int
            level of navigation

        path: tuple
            Use with group keys for tracing steps.
        """
        def _add_junction():
            if len(nav_box.junctions) <= level:
                junction = VBow()
                box = Eventful(self.column_color[level])

                nav_box.junctions.append(junction)
                box.add(junction)
                nav_box.add(box)

                # The default behavior of the 'add' function
                # doesn't guarantee that they are visible:
                junction.show()
                box.show()

        d = self.group_def
        nav_box = self.d[wk.NAV_BOX]
        path += group_key.split(",")[0],

        if group_key in d:
            _add_junction()

            e = {
                wk.COLOR: self.column_color[level],
                wk.CONTAINER: g,
                wk.GROUP_KEY: group_key,
                wk.PATH: path
            }
            a = e[wk.GROUP_TYPE] = d[group_key][wk.WIDGET]

            e.update(self.d)

            if a == Node:
                self._create_node(e, group_key, level, path)

            elif a == PerCell:
                draw_per_cell(e, group_key)
            else:
                for i in BUTTON_KEY:
                    if i in d[group_key]:
                        e[i] = True
                        break

                if wk.HAS_PRESET in d[group_key]:
                    e[wk.HAS_PRESET] = True

                e[wk.KEYS] = a.get_keys(group_key)
                OptionGroup.draw_group(**e)
        return level - 1, path[:-1]

    @staticmethod
    def add_group_to_node(node, label):
        """
        Add a group to a node.

        node: Node
            to receive the group

        label: string
            name of the option for the group label

        Return: VBow
            group container
            a gtk.VBox
        """
        vbox = VBow()
        label = label.split(",")[0]
        g = vbox.label_ = Label(
            text="{}:".format(label),
            padding=(4, 4, 4, 4),
            expand=True
        )

        node.group_box.append(vbox)
        vbox.pack_start(g, expand=True)
        return vbox
