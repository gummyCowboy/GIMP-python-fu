#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat, One
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
DIRECTION = range(4)
X_IS_1 = Y_IS_1 = 1


def do_hard_mix(z, pattern):
    """
    Create a hard mix layer.

    z: layer
        to clone

    pattern: string
        pattern id

    Return:
        z: layer
            the hard mix layer
    """
    z = Lay.clone(z)
    z.opacity = 50.
    z.mode = fu.LAYER_MODE_HARD_MIX

    pdb.gimp_context_set_pattern(pattern)
    pdb.gimp_drawable_edit_bucket_fill(
        z,
        fu.FILL_PATTERN,
        X_IS_1, Y_IS_1
    )

    do_wind(z)
    return z


def do_overlay(z):
    """
    Create an overlay layer.

    j: GIMP image
        work-in-progress

    z: layer
        to clone

    Return: layer
        the overlay layer
    """
    z = Lay.clone(z)
    z.opacity = 100.
    z.mode = fu.LAYER_MODE_OVERLAY

    pdb.gimp_drawable_invert(z, 0)
    Lay.blur(z, 5)
    return z


def do_wind(z):
    """
    Do the wind for each direction.

    z: layer
        to receive wind
    """
    for i in DIRECTION:
        pdb.plug_in_wind(
            z.image, z,
            Fu.Wind.THRESHOLD_0,
            i,
            Fu.Wind.STRENGTH_25,
            Fu.Wind.BLAST,
            Fu.Wind.LEADING_EDGE
        )


class SpecimenSpeckle:
    """
    Mix three patterns using layer modes.

    Shred the patterns with wind.

    Use colorize to give it extra interest.

    Use a gradient to improve organic randomness.
    """

    @staticmethod
    def do(one):
        """
        Create the Specimen Speckle backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            with Specimen Speckle
        """
        cat = Hat.cat
        j = cat.render.image
        d = one.d
        if d[ok.OPACITY]:
            group = Lay.group(j, one.k)
            group1 = Lay.group(j, one.k, parent=group)
            one.z = Lay.clone(one.z)

            pdb.gimp_image_reorder_item(j, one.z, group1, 0)
            do_wind(one.z)

            n = d[ok.MODE]
            f = d[ok.OPACITY]
            d[ok.MODE] = "Normal"
            d[ok.OPACITY] = 100.
            d[ok.START_X] = d[ok.START_Y] = 0.
            d[ok.END_X] = d[ok.END_Y] = 1.
            d[ok.BUMP] = {ok.BUMP_TYPE: "None"}
            one1 = One(d=d)
            z = GradientFill.do_layer(j, one1)

            pdb.gimp_image_reorder_item(j, z, group1, 0)

            d[ok.MODE] = n
            d[ok.OPACITY] = f
            do_overlay(z)

            # gradient:
            d[ok.END_X] = d[ok.END_Y] = 0.
            d[ok.START_X] = d[ok.START_Y] = 1.
            z = GradientFill.do_layer(j, one1)
            z.opacity = 50.
            z.mode = fu.LAYER_MODE_NORMAL

            pdb.gimp_image_reorder_item(j, z, group1, 0)
            RenderHub.set_fill_context(
                {
                    ok.THRESHOLD: .6,
                    ok.OPACITY: 100.,
                    ok.MODE: "Normal",
                    ok.CRITERION: "Composite"
                }
            )

            # pattern #1:
            z = do_hard_mix(z, d[ok.PATTERN_1])
            z = do_overlay(z)

            # pattern #2:
            z = do_hard_mix(z, d[ok.PATTERN_2])
            z = do_overlay(z)

            # pattern #3:
            z = do_hard_mix(z, d[ok.PATTERN_3])

            do_overlay(z)

            # phase two:
            z = Lay.merge_group(group1)
            z1 = Lay.clone(z)
            z2 = Lay.clone(z1)

            Lay.clone(z2)
            Lay.blur(z1, 6)
            Lay.blur(z2, 6)
            pdb.gimp_drawable_invert(z1, Fu.DrawableInvert.NO_LINEAR)

            z = Lay.merge_group(group)
            z = z1 = Lay.clone(z)
            z.mode = fu.LAYER_MODE_HARD_MIX
            z = Lay.clone(z)
            z.mode = fu.LAYER_MODE_LCH_COLOR

            pdb.plug_in_colorify(j, z, d[ok.COLOR])
            pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)
            return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
