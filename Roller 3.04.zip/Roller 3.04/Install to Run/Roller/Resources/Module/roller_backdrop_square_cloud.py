#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

er = Fu.Erode
pdb = fu.pdb
COLOR = (0, 255, 255), (255, 255, 0), (255, 0, 255)


class SquareCloud:
    """Make a cloud of bright squares."""

    @staticmethod
    def do(one):
        """
        Create a Square Cloud backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            with Square Cloud
        """
        j = Hat.cat.render.image
        d = one.d
        if d[ok.OPACITY]:
            group = Lay.group(j, one.k)
            base = Lay.add(j, one.k)

            pdb.gimp_image_reorder_item(j, base, group, 0)

            z = Lay.clone(base)

            pdb.plug_in_plasma(
                j,
                z,
                d[ok.RANDOM_SEED],
                Fu.Plasma.MEDIUM_TURBULENCE
            )

            z1 = Lay.clone(z)

            for i in range(10):
                Lay.dilate(z1)
                pdb.plug_in_erode(
                    j,
                    z,
                    er.PROPAGATE_OPAQUE,
                    er.RGB_CHANNELS,
                    er.FULL_RATE,
                    er.RGB_CHANNELS,
                    er.LOW_LIMIT_0,
                    er.UPPER_LIMIT_255
                )

            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
            pdb.plug_in_colortoalpha(j, z1, (0, 0, 0))
            Lay.color_fill(base, (127, 127, 127))

            z2 = Lay.clone(base)
            z2.mode = fu.LAYER_MODE_HSV_SATURATION

            pdb.gimp_image_reorder_item(j, z2, group, 0)

            z3 = Lay.clone(z)
            z3.mode = fu.LAYER_MODE_OVERLAY
            z3.opacity = 75.

            pdb.gimp_image_reorder_item(j, z3, group, 0)

            z4 = Lay.clone(z3)
            z4.mode = fu.LAYER_MODE_DARKEN_ONLY
            z4.opacity = 30.
            z = Lay.merge_group(group)
            z = Lay.clone(z)
            z.opacity = 50.

            pdb.plug_in_colorify(j, z, d[ok.COLOR])

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            z.mode, z.opacity = RenderHub.get_mode(d)

            Lay.clone(one.z)
            return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
