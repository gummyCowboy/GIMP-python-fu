#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import (
    Plan as fy,
    Plaque as aq
)
from roller_constant_key import (
    Group as gk,
    Layer as nk,
    Model as md,
    Option as ok,
    Plan as ak
)
from roller_model_border import Border
from roller_model_caption import Caption
from roller_model_fringe import Fringe
from roller_model_image import Rect
from roller_model_image_mask import ImageMask
from roller_model_place import Place
from roller_model_plaque import Plaque
from roller_one import Hat, One
from roller_one_extract import Form, Path
from roller_one_fu import Lay
import gimpfu as fu

pdb = fu.pdb
PLAN = 'plan'
PRODUCT = 'product'


def remove_layers(a):
    """
    Remove zero or more layers.
    """
    if a:
        if isinstance(a, tuple):
            for i in a:
                Lay.remove(i)
        else:
            Lay.remove(a)


def undo_caption(q):
    """
    Undo a caption operation.

    q: tuple
        (layer, stripe dict)
    """
    z, Hat.cat.caption_stripe_sel = q
    Lay.remove(z)


class Render:
    """Is factored from the classes Product and Plan."""

    backdrop_image_layer = None

    def __init__(self, render_type):
        """Initialize common variables."""
        self.render_type = render_type
        self.plan_group = self.model_group = self.model_name = None
        self.undo = {}
        self.plan_flags = {}
        self.cell = self.grid = self.backdrop_layer = None
        self.layer_margin = []
        self.image_index = deepcopy(Place.IMAGE_INDEX)
        self.context = ""

        # Do not have dependency with layer margins:
        self.non_layer_d = {
            gk.GLOBAL: self._do_globals,

            # grid cell:
            gk.CELL_BORDER: self._do_cell_border,
            gk.CELL_CAPTION: self._do_caption,
            gk.CELL_FRINGE: self._do_cell_fringe,
            gk.CELL_IMAGE_MASK: self._do_image_mask,
            gk.CELL_IMAGE_PLACE: self._do_image_place,
            gk.CELL_PLAQUE: self._do_cell_plaque,
            gk.TABLE_PROPERTY: self._init_table_property,

            # custom cell:
            gk.CUSTOM_CELL_BORDER: self._do_cell_border,
            gk.CUSTOM_CELL_CAPTION: self._do_caption,
            gk.CUSTOM_CELL_MARGIN: self._do_custom_cell_margins,
            gk.CUSTOM_CELL_FRINGE: self._do_cell_fringe,
            gk.CUSTOM_CELL_IMAGE_MASK: self._do_image_mask,
            gk.CUSTOM_CELL_IMAGE_PLACE: self._do_image_place,
            gk.CUSTOM_CELL_PLAQUE: self._do_cell_plaque,
            gk.CUSTOM_CELL_PROPERTY: self._init_custom_cell_property,
            gk.RECTANGLE: self._init_rectangle
        }

        # Have dependency with layer margins:
        self.layer_d = {
            gk.LAYER_BORDER: self._do_layer_border,
            gk.LAYER_CAPTION: self._do_layer_caption,
            gk.LAYER_FRINGE: self._do_layer_fringe,
            gk.LAYER_PLAQUE: self._do_layer_plaque
        }

    def _do_caption(self, one):
        """
        Perform a caption process.

        one: One
            Has variables.

        Return: tuple
            caption layer, caption stripe selection dict
        """
        cat = Hat.cat
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.CAPTION]:
                go = False
            else:
                is_plan = True
                one.color = fy.CELL_STRIPE_COLOR
        if go:
            d = deepcopy(cat.caption_stripe_sel)
            cat.caption_stripe_sel = {}

            if one.k == gk.CELL_CAPTION:
                z = Caption.do_grid(one, is_plan)

            else:
                z = Caption.do_custom_cell(one, is_plan)

            if is_plan and z:
                z.name = "Cell Caption"
                z.opacity = 66.

            self.undo[one.path] = (z, d), undo_caption
            if not is_plan:
                # for blur behind:
                cat.register_layer(
                    (self.model_name, nk.CELL_CAPTION),
                    z
                )

    def _do_cell_border(self, one):
        """
        Draw cell borders.

        one: One
            Has variables.
        """
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.BORDER]:
                go = False
            else:
                is_plan = True
                one.color = fy.CELL_BORDER_COLOR

        if go:
            if one.k == gk.CELL_BORDER:
                z = Border.do_grid(one, is_plan)

            else:
                z = Border.do_custom_cell(one, is_plan)
            if is_plan and z:
                z.name = "Cell Border"
                z.opacity = 66.
            self.undo[one.path] = z, Lay.remove

    def _do_cell_fringe(self, one):
        """
        Do cell fringe.

        one: One
            Has variables.
        """
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.CELL_FRINGE]:
                go = False
            else:
                is_plan = True
                one.color = fy.CELL_FRINGE_COLOR

        if go:
            d = deepcopy(self.image_index)
            one.plaque_layer = Hat.cat.get_layer(
                (self.render_type, one.model_name, nk.CELL_PLAQUE)
            )
            if one.k == gk.CELL_FRINGE:
                z = Fringe.do_grid(one, is_plan)

            else:
                z = Fringe.do_custom_cell(one, is_plan)

            if is_plan and z:
                z.opacity = 66.
                z.name = "Cell Fringe"
            self.undo[one.path] = (
                (z, one.plaque_layer, one.is_mask, one.is_paint, d),
                self._undo_fringe
            )

    def _do_cell_plaque(self, one):
        """
        Perform a cell plaque process for a custom cell or grid.

        one: One
            Has variables.

        Return: tuple
            (plaque layer, plaque selection dict)
        """
        cat = Hat.cat
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.CELL_PLAQUE]:
                go = False
            else:
                is_plan = True
                one.color = fy.CELL_PLAQUE_COLOR
        if go:
            d = deepcopy(cat.plaque_sel)
            e = deepcopy(self.image_index)
            cat.plaque_sel = {}

            if one.k == gk.CELL_PLAQUE:
                z = Plaque.do_grid(one, is_plan)

            else:
                z = Plaque.do_custom_cell(one, is_plan)

            if z and is_plan:
                z.name = "Cell Plaque"
                z.opacity = 66.

            self.undo[one.path] = (z, d, e), self._undo_cell_plaque
            Hat.cat.register_layer(
                (self.render_type, self.model_name, nk.CELL_PLAQUE),
                z
            )

    def _do_custom_cell_margins(self, one):
        """
        Calculate the cell pocket for the cell.
        A pocket is a rectangle calculated from
        the cell rectangle minus the cell's margins.

        one: One
            Has variable, 'path'.
        """
        a = self.cell.rect
        d = Path.get_cell_margin(one.path)
        x, y = a.position
        w, h = a.size
        top, bottom, left, right = Form.combine_margin(d, w, h)
        self.cell.pocket = Rect(
            (x + left, y + top),
            (w - left - right, h - top - bottom)
        )

    def _do_globals(self, one):
        """
        Set the globals in cat. There is no
        compliment for this group's change.

        one: One
            Has globals dict.
        """
        d = one.d
        cat = Hat.cat
        cat.elevation = d[ok.ELEVATION]
        cat.light_angle = d[ok.LIGHT_ANGLE]
        cat.is_close_file = d[ok.CLOSE_FILE]
        cat.render.size = d[ok.RENDER_WIDTH], d[ok.RENDER_HEIGHT]

        # Trigger a reset if it's needed:
        cat.render.image

        if self.render_type == PLAN and not self.plan_group:
            self.plan_group = Lay.group(cat.render.image, "Plan")

    def _do_image_mask(self, one):
        """
        Perform an image mask operation for a custom cell or grid.

        one: One
            Has variables.
        """
        cat = Hat.cat
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.IMAGE_MASK]:
                go = False
        if go:
            d = deepcopy(cat.mask_sel)
            e = deepcopy(self.image_index)
            cat.mask_sel = {}

            if one.k == gk.CELL_IMAGE_MASK:
                z = ImageMask.do_grid(one)

            else:
                z = ImageMask.do_custom_cell(one)
            self.undo[one.path] = (z, d, e), self._undo_image_mask

    def _do_image_place(self, one):
        """
        Perform an image place process for a custom cell and grid.

        one: One
            Has variables.

        Return: tuple
            image layer, image selection dict
        """
        cat = Hat.cat
        go = True
        is_plan = False

        if self.render_type == PLAN:
            is_plan = True
            if not self.plan_flags[ak.IMAGE]:
                go = False
        if go:
            d = deepcopy(cat.image_sel)
            e = deepcopy(self.image_index)
            cat.image_sel = {}

            if one.k == gk.CELL_IMAGE_PLACE:
                z = Place.do_grid(one, is_plan)

            else:
                z = Place.do_custom_cell(one, is_plan)

            if is_plan and z:
                z.name = "Image"
                z.opacity = 66.

            cat.register_layer(
                (self.render_type, self.model_name, nk.IMAGE),
                z
            )
            self.undo[one.path] = (z, d, e), self._undo_image_place

    def _do_layer_border(self, one):
        """
        Draw layer border.

        one: One
            Has a border dict.
        """
        go = True
        is_plan = False

        if self.render_type == PLAN:
            if not self.plan_flags[ak.BORDER]:
                go = False
            else:
                is_plan = True
                one.color = fy.LAYER_BORDER_COLOR
        if go:
            z = Border.do_layer(one, is_plan)

            if is_plan and z:
                z.opacity = 66.
                z.name = "Layer Border"
            self.undo[one.path] = z, Lay.remove

    def _do_layer_caption(self, one):
        """
        Plan a layer caption.

        one: One
            Has variables.
        """
        go = True
        is_plan = False

        if self.render_type == PLAN:
            if not self.plan_flags[ak.CAPTION]:
                go = False
            else:
                is_plan = True
                one.color = fy.LAYER_CAPTION_COLOR
        if go:
            z = Caption.do_layer(one, is_plan)

            if is_plan and z:
                z.opacity = 66.
                z.name = "Layer Caption"
            self.undo[one.path] = z, Lay.remove

    def _do_layer_fringe(self, one):
        """
        Draw layer fringe.

        one: One
            Has layer fringe dict.
        """
        go = True
        is_plan = False

        if self.render_type == PLAN:
            is_plan = True
            if not self.plan_flags[ak.LAYER_FRINGE]:
                go = False
            else:
                one.color = fy.LAYER_FRINGE_COLOR
        if go:
            d = deepcopy(self.image_index)
            one.plaque_layer = Hat.cat.get_layer(
                (self.render_type, self.model_name, nk.LAYER_PLAQUE)
            )
            z = Fringe.do_layer(one, is_plan)

            if is_plan and z:
                z.opacity = 66.
                z.name = "Layer Fringe"
            self.undo[one.path] = (
                (z, one.plaque_layer, one.is_mask, one.is_paint, d),
                self._undo_fringe
            )

    def _do_layer_plaque(self, one):
        """
        Draw a layer plaque on its own layer.

        one: One
            Has layer plaque dict.
        """
        cat = Hat.cat
        d = one.d
        e = deepcopy(cat.plaque_sel)
        d1 = deepcopy(self.image_index)
        cat.plaque_sel = {}
        is_plan = False
        go = True

        if self.render_type == PLAN:
            if not self.plan_flags[ak.LAYER_PLAQUE]:
                go = False
            else:
                is_plan = True
                one.color = fy.LAYER_PLAQUE_COLOR
                if d[ok.PLAQUE_TYPE] != "None":
                    d[ok.PLAQUE_TYPE] = aq.COLOR
        if go and d[ok.PLAQUE_TYPE] != "None":
            z = Plaque.do_layer(one, is_plan)

            if is_plan and z:
                z.name = "Layer Plaque"
                z.opacity = 66.

            self.undo[one.path] = (z, e, d1), self._undo_layer_plaque
            Hat.cat.register_layer(
                (self.render_type, self.model_name, nk.LAYER_PLAQUE),
                z
            )

    def _init_rectangle(self, one):
        """
        Calculate the global custom cell rectangle.

        one: One
            Has rectangle dictionary.

        Return: tuple
            the previous cell rectangle,
        """
        a = self.cell.rect
        d = one.d
        self.cell.rect = Form.get_custom_cell_rect(d)
        self.undo[one.path] = (None, a), self._undo_rectangle

    def _init_custom_cell_property(self, one):
        """
        Set the custom cell's globals.

        one: One
            Has option dictionary.

        Return: tuple
            of custom cell property variables
        """
        cat = Hat.cat
        d = one.d
        n = d[ok.CELL_NAME]
        z = Lay.group(
            cat.render.image,
            n,
            offset=cat.plan.get_offset()
        )
        q = (
            z,
            self.cell,
            self.context,
            self.model_group,
            self.model_name,
            deepcopy(self.plan_flags)
        )
        self.model_group = z
        self.model_name = n
        self.cell = One(
            image=None,
            image_name=None,
            mold=None,
            rect=None,
            shape=d[ok.CUSTOM_CELL_SHAPE]
        )
        self.context = md.CELL
        self.plan_flags = d[ok.CELL_PLAN]
        self.undo[one.path] = q, self._undo_custom_cell_property

    def _init_table_property(self, one):
        """
        Create a table model group.

        one: One
            Has option dict.

        Return: tuple
            of grid-specific variables
        """
        cat = Hat.cat
        d = one.d
        n = d[ok.TABLE_NAME]
        group = self.model_group
        z = self.model_group = Lay.group(
            cat.render.image,
            n,
            offset=cat.plan.get_offset()
        )

        q = z, self.context, self.model_name, group, deepcopy(self.plan_flags)

        self.context = md.TABLE
        self.model_name = n
        self.plan_flags = d[ok.TABLE_PLAN]
        self.undo[one.path] = q, self._undo_table_property

    def _undo_fringe(self, q):
        """
        Undo a cell fringe operation.

        q: tuple
            (
                fringe layer,
                plaque layer,
                is mask flag,
                is paint flag,
                image index dict
            )
        """
        z, z1, is_mask, is_paint, self.image_index = q

        if is_mask:
            Lay.discard_mask(z1)
        if is_paint:
            Lay.remove(z)

    def _undo_cell_plaque(self, q):
        """
        Undo a cell plaque operation.

        q: tuple
            (layer, plaque selection dict, image index dict)
        """
        cat = Hat.cat
        z, d, self.image_index = q

        Hat.cat.unregister_layer(
            None,
            key=(self.render_type, self.model_name, nk.CELL_PLAQUE)
        )
        Lay.remove(z)
        cat.del_channels(cat.plaque_sel)
        cat.plaque_sel = d

    def _undo_custom_cell_property(self, q):
        """
        Undo a custom cell property group's change.

        q: tuple
            Has property values.
        """
        z, self.cell, self.context, self.model_group, \
            self.model_name, self.plan_flags = q
        Lay.remove(z)

    def _undo_table_property(self, q):
        """
        Undo a grid property operation.

        q: tuple
            with grid property variables
        """
        z, self.context, self.model_name, self.model_group, self.plan_flags = q
        Lay.remove(z)

    def _undo_image_mask(self, q):
        """
        Undo an image layer mask.

        q: tuple
            undo variables
        """
        cat = Hat.cat
        z, d, self.image_index = q

        Lay.discard_mask(z)
        cat.del_channels(cat.mask_sel)
        cat.mask_sel = d

    def _undo_image_place(self, q):
        """
        Undo image place.

        q: tuple
            (layer, image selection dict, image index dict)
        """
        cat = Hat.cat
        z, d, self.image_index = q

        cat.unregister_layer(
            None,
            key=(self.render_type, self.model_name, nk.IMAGE)
        )
        remove_layers(z)
        cat.del_channels(cat.image_sel)
        cat.image_sel = d

    def undo_layer(self, q):
        """
        Undo a layer addition.

        q: tuple
            (layer(s), image index dict)
        """
        z, self.image_index = q
        if z is not None:
            if isinstance(z, list):
                for i in z:
                    Lay.remove(i)
            else:
                Lay.remove(z)

    def _undo_layer_plaque(self, q):
        """
        Undo a layer plaque operation.

        q: tuple
            (plaque layer, plaque sel dict)
        """
        cat = Hat.cat
        z, d, self.image_index = q

        cat.unregister_layer(
            None,
            key=(self.render_type, self.model_name, nk.LAYER_PLAQUE)
        )
        Lay.remove(z)
        cat.del_channels(cat.plaque_sel)
        cat.plaque_sel = d

    def _undo_rectangle(self, q):
        """
        Undo the rectangle group.

        q: tuple
            (layer, Rect: of custom cell)
        """
        z, self.cell.rect = q
        Lay.remove(z)

    def undo_steps(self, q, steps):
        """
        Perform the undo functions of expired steps.

        q: list
            of changed steps

        steps: list
            of render steps
        """
        d = Hat.cat.group_dict
        for path in q:
            if path in self.undo:
                a, p = self.undo[path]
                p(a)

            # A reset may have removed path:
            if path in self.undo:
                self.undo.pop(path)

            # Update group status and button sensitivity:
            if path not in steps:
                b = d[path]
                if self.render_type == PRODUCT:
                    b.changed = True
                    if b.preview_button:
                        b.preview_button.set_sensitive(1)
                elif self.render_type == PLAN:
                    b.unseen = True
                    if b.plan_button:
                        b.plan_button.set_sensitive(1)
