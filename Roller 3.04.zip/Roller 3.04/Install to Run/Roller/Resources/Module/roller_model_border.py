#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Shape as sh
from roller_constant_fu import Fu
from roller_constant_key import Layer as nk, Option as ok
from roller_one import Hat
from roller_one_extract import dispatch, Shape
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

em = Fu.Emboss
pdb = fu.pdb
ELLIPSE = (
    sh.ELLIPSE_HORIZONTAL,
    sh.ELLIPSE_VERTICAL,
    sh.CIRCLE_HORIZONTAL,
    sh.CIRCLE_VERTICAL,
    sh.ELLIPSE
)


def add_border_layer(j, one, group):
    """
    Add a border layer to the bottom of the group.

    j: GIMP image
        Is render.

    one: One
        Has variables.

    group: layer
        parent of layer

    Return: layer
        for border material
    """
    return Lay.add(j, n=one.layer_name, parent=group)


def blur_behind(z, d):
    """
    Blur behind border material.

    z: layer
        with material

    d: dict
        Has the blur behind option.

    Return: layer
        with material
    """
    z1 = RenderHub.blur_behind(z, d, has_mode=True)

    if z1:
        z = z1
    return z


def cast_shadow(z, d):
    """
    Merge a shadow layer with the plaque if needed.

    z: layer
        with material

    d: dict
        of options

    Return: layer
        with plaque material
    """
    if Shadow.get_type(d[ok.TRI_SHADOW]):
        n = z.name
        z = Shadow.do_shadows(d[ok.TRI_SHADOW], z)
        z.name = n
    return z


def do_common_ellipse_grid(j, one):
    """
    Draw border for a square grid
    without merged cells or per cell.

    j: GIMP image
        Is render.

    one: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    d = one.d
    row, column = one.grid.division
    w = d[ok.BORDER_WIDTH]
    w1 = w // 2
    z = grid_sel = None

    for r in range(row):
        for c in range(column):
            if Shape.is_allocated_cell(one.grid, r, c):
                Sel.select_shape(j, one.grid.get_plaque(r, c))
                Sel.grow(j, w1, 1)

                sel = pdb.gimp_selection_save(j)

                pdb.gimp_selection_shrink(j, w)

                sel1 = pdb.gimp_selection_save(j) if Sel.is_sel(j) else \
                    None

                # Make border selection by subtracting
                # the inner selection from the outer:
                Sel.load(j, sel)

                if sel1:
                    Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

                if grid_sel:
                    Sel.load(j, grid_sel, option=fu.CHANNEL_OP_ADD)
                    pdb.gimp_image_remove_channel(j, grid_sel)

                grid_sel = pdb.gimp_selection_save(j)

                if sel:
                    pdb.gimp_image_remove_channel(j, sel)
                if sel1:
                    pdb.gimp_image_remove_channel(j, sel1)
    if grid_sel:
        Sel.load(j, grid_sel)

        z = do_ellipse_sel(j, one)
        pdb.gimp_image_remove_channel(j, grid_sel)

    if not one.is_plan:
        z = cast_shadow(z, d)
        z = blur_behind(z, d)
    return z


def do_common_rect_grid(j, one):
    """
    Do a common border for a rectangular cell grid.

    j: GIMP image
        Is render.

    one: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    d = one.d
    row, column = one.grid.division
    rect = one.grid.get_merge_cell_rect(0, 0)
    left, top = rect.x, rect.y
    rect = one.grid.get_merge_cell_rect(row - 1, column - 1)
    right, bottom = rect.x + rect.w, rect.y + rect.h
    x = left
    h1 = d[ok.BORDER_WIDTH]
    h2 = h1 - h1 // 2
    w1 = right - left + h1

    for r in range(row):
        rect = one.grid.get_merge_cell_rect(r, 0)
        Sel.rect(j, x - h2, rect.y - h2, w1, h1)

    Sel.rect(j, x - h2, rect.y + rect.h - h2, w1, h1)

    w1, w2 = h1, h2
    h1 = bottom - top + w1
    y = top

    for c in range(column):
        rect = one.grid.get_merge_cell_rect(0, c)
        Sel.rect(j, rect.x - w2, y - w2, w1, h1)

    Sel.rect(j, rect.x + rect.w - w2, y - w2, w1, h1)

    z = process_selection(add_border_layer(j, one, one.parent), one)

    if not one.is_plan:
        z = cast_shadow(z, d)
        z = blur_behind(z, d)
    return z


def do_common_polygon_grid(j, one):
    """
    Do a common border for a polygon, not rectangular, cell grid.

    j: GIMP image
        Is render.

    one: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    # Preserve:
    foreground = pdb.gimp_context_get_foreground()

    d = one.d
    row, column = one.grid.division
    z = None
    a = set()
    color = get_color(one)
    w = d[ok.BORDER_WIDTH]
    w1 = w // 2
    w2 = w - w1

    RenderHub.set_brush_details()
    pdb.gimp_context_set_brush_size(w)
    pdb.gimp_context_set_foreground(color)
    pdb.gimp_context_set_stroke_method(fu.STROKE_LINE)
    pdb.gimp_context_set_brush_spacing(.03)

    for r in range(row):
        for c in range(column):
            if Shape.is_allocated_cell(one.grid, r, c):
                b = one.grid.get_plaque(r, c)
                for x, i in enumerate(range(len(b) - 1)):
                    if not x % 2:
                        if x < len(b) - 3:
                            if b[x] < b[x + 2]:
                                a.add((b[x], b[x + 1], b[x + 2], b[x + 3]))
                            else:
                                a.add((b[x + 2], b[x + 3], b[x], b[x + 1]))
                        else:
                            a.add((b[x], b[x + 1], b[0], b[1]))
    for x, y, x1, y1 in a:
        if x != x1 and y != y1:
            if not z:
                z = add_border_layer(j, one, one.parent)
            pdb.gimp_paintbrush(
                z,
                0.,
                4,
                (x, y, x1, y1),
                fu.PAINT_CONSTANT,
                .0
            )
        else:
            if not z:
                z = add_border_layer(j, one, one.parent)

            # Use selection to skip smudgy antialiasing:
            Sel.polygon(
                j,
                (
                    x - w1, y - w1,
                    x + w2, y + w2,
                    x1 + w2, y1 + w2,
                    x1 - w1, y1 - w1
                ),
                option=fu.CHANNEL_OP_ADD
            )
            Sel.fill(z, get_color(one))
            pdb.gimp_selection_none(j)

    if z:
        Sel.item(z)
        z = process_selection(z, one, is_fill=False)

    # Restore:
    pdb.gimp_context_set_foreground(foreground)

    if not one.is_plan:
        z = cast_shadow(z, d)
        z = blur_behind(z, d)
    return z


def do_common_square_grid(j, one):
    """
    Do a common border for a square cell grid.

    j: GIMP image
        Is render.

    one: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    row, column = one.grid.division
    d = one.d
    w = d[ok.BORDER_WIDTH]
    rect = one.grid.get_merge_cell_rect(0, 0)
    w1 = rect.w * column + w
    h1 = rect.h * row + w
    w2 = w - w // 2

    for r in range(row):
        rect = one.grid.get_merge_cell_rect(r, 0)
        Sel.rect(j, rect.x - w2, rect.y - w2, w1, w)

    Sel.rect(j, rect.x - w2, rect.y + rect.h - w2, w1, w)

    for c in range(column):
        rect = one.grid.get_merge_cell_rect(0, c)
        Sel.rect(j, rect.x - w2, rect.y - w2, w, h1)

    Sel.rect(j, rect.x + rect.w - w2, rect.y - w2, w, h1)

    z = process_selection(add_border_layer(j, one, one.parent), one)

    if not one.is_plan:
        z = cast_shadow(z, d)
        z = blur_behind(z, d)
    return z


def do_ellipse_sel(j, one):
    """
    Increase the opacity of the ellipse.

    j: GIMP image
        Is render.

    one: One
        Has variables.

    Return: layer
        Has border material.
    """
    d = one.d
    group = make_group(j, one)
    f = d[ok.OPACITY]
    d[ok.OPACITY] = 100.
    z = add_border_layer(j, one, group)

    Sel.fill(z, get_color(one))

    d[ok.OPACITY] = f

    for i in range(3):
        Lay.clone(z)

    z = Lay.merge_group(group)

    Sel.item(z)
    return process_selection(z, one, is_fill=False)


def do_rect_custom_cell(j, one):
    """
    Draw a rectangle border for a custom cell border.

    j: GIMP image
        Is render.

    one: One
        Has custom cell variables.
    """
    a = one.cell.rect
    x, y = a.position
    w, h = a.size
    d = one.d
    w1 = d[ok.BORDER_WIDTH]
    w2 = w1 + w1
    Sel.rect(j, x, y, w, h)
    Sel.rect(
        j,
        x + w1,
        y + w1,
        max(w - w2, 1),
        max(h - w2, 1),
        option=fu.CHANNEL_OP_SUBTRACT
    )
    z = process_selection(add_border_layer(j, one, one.group), one)

    if not one.is_plan:
        z = blur_behind(z, d)
        z = cast_shadow(z, d)
    return z


def do_rect_grid(j, one):
    """
    Draw border for a rectangle grid without merged cells.

    j: GIMP image
        Is render.

    one: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    d = one.d
    row, column = one.grid.division
    rect = one.grid.get_merge_cell_rect(0, 0)
    left, top = rect.x, rect.y
    rect = one.grid.get_merge_cell_rect(row - 1, column - 1)
    right, bottom = rect.x + rect.w, rect.y + rect.h
    w1 = right - left
    x = left
    h1 = d[ok.BORDER_WIDTH]

    for r in range(row):
        rect = one.grid.get_merge_cell_rect(r, 0)
        Sel.rect(j, x, rect.y, w1, h1)
        Sel.rect(j, x, max(rect.y + rect.h - h1, rect.y), w1, h1)

    w1 = h1
    h1 = bottom - top
    y = top

    for c in range(column):
        rect = one.grid.get_merge_cell_rect(0, c)
        Sel.rect(j, rect.x, y, w1, h1)
        Sel.rect(j, max(rect.x + rect.w - w1, rect.x), y, w1, h1)
    z = process_selection(add_border_layer(j, one, one.parent), one)

    if not one.is_plan:
        z = cast_shadow(z, d)
        z = blur_behind(z, d)
    return z


def do_rect_per_cell(j, one):
    """
    Draw border for a rectangle grid with
    merged cells and / or per cell.

    j: GIMP image
        Is render.

    one: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    d = one.d
    row, column = one.grid.division
    z = group = None
    is_per_cell = one.is_per_cell

    for r in range(row):
        for c in range(column):
            go = True

            if one.is_merge_cell:
                if one.grid.grid_d[ok.PER_CELL][r][c] == (-1, -1):
                    go = False
            if go:
                if is_per_cell:
                    e = one.d = d[ok.PER_CELL][r][c]
                    go = e[ok.BORDER_WIDTH] and e[ok.OPACITY]
                    w = e[ok.BORDER_WIDTH]

                else:
                    e = d
                    w = d[ok.BORDER_WIDTH]
            if w and go:
                w1 = w + w
                rect = one.grid.get_merge_cell_rect(r, c)

                Sel.rect(j, rect.x, rect.y, rect.w, rect.h)
                Sel.rect(
                    j,
                    rect.x + w, rect.y + w,
                    max(rect.w - w1, 1), max(rect.h - w1, 1),
                    option=fu.CHANNEL_OP_SUBTRACT
                )
                if Sel.is_sel(j):
                    if is_per_cell:
                        if not group:
                            group = make_group(j, one)
                        z = process_selection(
                            add_border_layer(j, one, group),
                            one
                        )
                        if not one.is_plan:
                            z = cast_shadow(z, e)
                            z = blur_behind(z, e)
    if not is_per_cell:
        z = process_selection(add_border_layer(j, one, one.parent), one)
        z = cast_shadow(z, d)
        z = blur_behind(z, d)
    if group:
        z = Lay.merge_group(group)
    return z


def do_shape_custom_cell(j, one, n):
    """
    Draw a non-rectangle shaped custom cell border.

    j: GIMP image
        Is render.

    one: One
        Has variables.

    n: string
        shape descriptor

    Return: layer or None
        with border material
    """
    z = None
    a = one.cell.rect
    d = one.d

    Sel.select_shape(j, dispatch[n](a))

    if Sel.is_sel(j):
        sel = pdb.gimp_selection_save(j)

        pdb.gimp_selection_shrink(j, d[ok.BORDER_WIDTH])

        if Sel.is_sel(j):
            sel1 = pdb.gimp_selection_save(j)

        else:
            sel1 = None

        Sel.load(j, sel)
        Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

        if not Sel.is_sel(j):
            Sel.load(j, sel)

        if n in ELLIPSE:
            z = do_ellipse_sel(j, one)
        else:
            z = process_selection(add_border_layer(j, one, one.group), one)
            if not one.is_plan:
                z = cast_shadow(z, d)
                z = blur_behind(z, d)

        pdb.gimp_image_remove_channel(j, sel)
        if sel1:
            pdb.gimp_image_remove_channel(j, sel1)
    return z


def do_shape_grid(j, one, n):
    """
    Draw border for a square grid
    without merged cells or per cell.

    j: GIMP image
        Is render.

    one: One
        Has variables.

    n: string
        shape descriptor

    Return: layer or None
        Has border material.
    """
    d = one.d
    row, column = one.grid.division
    w = d[ok.BORDER_WIDTH]
    z = grid_sel = None

    for r in range(row):
        for c in range(column):
            if Shape.is_allocated_cell(one.grid, r, c):
                Sel.select_shape(j, one.grid.get_plaque(r, c))

                sel = pdb.gimp_selection_save(j)

                pdb.gimp_selection_shrink(j, w)

                if Sel.is_sel(j):
                    sel1 = pdb.gimp_selection_save(j)

                else:
                    sel1 = None

                # Make border selection by subtracting
                # the inner selection from the outer:
                Sel.load(j, sel)
                Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

                if grid_sel:
                    Sel.load(j, grid_sel, option=fu.CHANNEL_OP_ADD)
                    pdb.gimp_image_remove_channel(j, grid_sel)

                grid_sel = pdb.gimp_selection_save(j)

                pdb.gimp_image_remove_channel(j, sel)
                if sel1:
                    pdb.gimp_image_remove_channel(j, sel1)
    if grid_sel:
        Sel.load(j, grid_sel)
        pdb.gimp_image_remove_channel(j, grid_sel)

        if n in ELLIPSE:
            z = do_ellipse_sel(j, one)
        else:
            z = process_selection(
                add_border_layer(j, one, one.parent),
                one
            )

    if not one.is_plan:
        z = cast_shadow(z, d)
        z = blur_behind(z, d)
    return z


def do_shape_per_cell(j, one):
    """
    Draw border for a square grid
    without merged cells or per cell.

    j: GIMP image
        Is render.

    one: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    d = one.d
    z = group = None
    row, column = one.grid.division
    n = one.grid.cell_shape

    for r in range(row):
        for c in range(column):
            if Shape.is_allocated_cell(one.grid, r, c):
                e = one.d = d[ok.PER_CELL][r][c]
                w = e[ok.BORDER_WIDTH]
                if w and e[ok.OPACITY]:
                    Sel.select_shape(
                        j,
                        one.grid.get_plaque(r, c)
                    )

                    if Sel.is_sel(j):
                        sel = pdb.gimp_selection_save(j)
                        pdb.gimp_selection_shrink(j, w)

                    sel1 = pdb.gimp_selection_save(j) if Sel.is_sel(j) \
                        else None

                    # Make border selection by subtracting
                    # the inner selection from the outer:
                    Sel.load(j, sel)
                    Sel.load(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

                    if not Sel.is_sel(j):
                        Sel.load(j, sel)

                    if not group:
                        group = make_group(j, one)

                    if n in ELLIPSE:
                        z = do_ellipse_sel(j, one)
                        pdb.gimp_image_reorder_item(j, z, group, 0)
                        if not one.is_plan:
                            z = cast_shadow(z, e)
                            z = blur_behind(z, e)

                    else:
                        if Sel.is_sel(j):
                            z = process_selection(
                                add_border_layer(j, one, group),
                                one
                            )
                            if not one.is_plan:
                                z = cast_shadow(z, e)
                                z = blur_behind(z, e)

                    if sel:
                        pdb.gimp_image_remove_channel(j, sel)
                    if sel1:
                        pdb.gimp_image_remove_channel(j, sel1)

    if group:
        z = Lay.merge_group(group)
    return z


def do_square_grid(j, one):
    """
    Draw border for a square grid
    without merged cells or per cell.

    j: GIMP image
        Is render.

    one: One
        Has variables.

    Return: layer or None
        Has border material.
    """
    d = one.d
    row, column = one.grid.division
    w = d[ok.BORDER_WIDTH]
    rect = one.grid.get_merge_cell_rect(0, 0)
    w1 = rect.w * column
    h1 = rect.h * row

    for r in range(row):
        rect = one.grid.get_merge_cell_rect(r, 0)
        Sel.rect(j, rect.x, rect.y, w1, w)
        Sel.rect(j, rect.x, max(rect.y + rect.h - w, rect.y), w1, w)

    for c in range(column):
        rect = one.grid.get_merge_cell_rect(0, c)
        Sel.rect(j, rect.x, rect.y, w, h1)
        Sel.rect(j, max(rect.x + rect.w - w, rect.x), rect.y, w, h1)

    z = process_selection(add_border_layer(j, one, one.parent), one)

    if not one.is_plan:
        z = cast_shadow(z, d)
        z = blur_behind(z, d)
    return z


def get_color(one):
    """
    Get the color for the border material.

    d: dict
        of border

    Return: tuple
        RGB
    """
    if one.is_plan:
        return one.color
    return one.d[ok.COLOR]


def make_group(j, one):
    """
    Make a group layer for cell border layers.

    j: GIMP image
        work-in-progress

    one: One
        Has layer name and parent.

    Return: layer
        of group type
    """
    return Lay.group(j, one.layer_name, parent=one.parent)


def process_selection(z, one, is_fill=True):
    """
    The selection is the border. Fill,
    blur, and emboss complete the process.

    z: layer
        for border material

    one: One
        Has variables.

    is_fill: flag
        When true, the layer selection is filled with the border color.

    Return: layer or None
        with border
    """
    j = z.image
    d = one.d
    cat = Hat.cat
    if Sel.is_sel(j):
        if is_fill:
            Sel.fill(z, get_color(one))

        pdb.gimp_selection_none(j)

        if d[ok.BORDER_BLUR]:
            Lay.blur(z, d[ok.BORDER_BLUR])

        if d[ok.EMBOSS] and not one.is_plan:
            z = Lay.clone(z)
            z.mode = fu.LAYER_MODE_OVERLAY

            pdb.plug_in_emboss(
                j, z,
                cat.light_angle,
                cat.elevation,
                d[ok.BUMP_DEPTH],
                em.EMBOSS
            )
            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

        z.opacity = d[ok.OPACITY]
        pdb.gimp_selection_none(j)
    return z


class Border:
    """Manage Border operation."""

    @staticmethod
    def do_custom_cell(one, is_plan):
        """
        Do border for free range cells.

        one: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: tuple or None
            with border
        """
        cat = Hat.cat
        z = group = None
        d = one.d
        one.is_plan = is_plan
        one.layer_name = Lay.make_name(one.parent, nk.CELL_BORDER)

        if d[ok.BORDER_WIDTH] and d[ok.OPACITY]:
            j = cat.render.image
            n = one.cell.shape

            if n == sh.RECTANGLE:
                group = one.group = make_group(j, one)
                do_rect_custom_cell(j, one)
            else:
                one.group = one.parent
                z = do_shape_custom_cell(j, one, n)

            if group:
                z = Lay.merge_group(group)
            if not is_plan:
                z = GradientLight.apply_light(z, ok.DECO)
            if not one.is_plan:
                z = blur_behind(z, d)
        return z

    @staticmethod
    def do_grid(one, is_plan):
        """
        Do border for grid cells.

        j: GIMP image
            Is render.

        one: One
            Has variables.

        is_plan: bool
            Is true when the caller is the Plan class.

        Return: tuple or None
            Has border material.
        """
        cat = Hat.cat
        j = cat.render.image
        z = None
        d = one.d
        n = one.grid.cell_shape
        one.is_merge_cell = one.grid.is_merge_cell
        one.is_plan = is_plan
        is_per_cell = one.is_per_cell = d[ok.PER_CELL]
        is_one_border = not any((one.is_merge_cell, is_per_cell))
        one.layer_name = Lay.make_name(one.parent, nk.CELL_BORDER)
        go = True

        if not is_per_cell:
            go = d[ok.BORDER_WIDTH] and d[ok.OPACITY]

        if go:
            pdb.gimp_selection_none(j)
            if n == sh.RECTANGLE:
                if is_one_border:
                    if d[ok.COMMON_BORDER]:
                        z = do_common_rect_grid(j, one)
                    else:
                        z = do_rect_grid(j, one)
                else:
                    z = do_rect_per_cell(j, one)

            elif n == sh.SQUARE:
                if is_one_border:
                    if d[ok.COMMON_BORDER]:
                        z = do_common_square_grid(j, one)
                    else:
                        z = do_square_grid(j, one)
                else:
                    z = do_rect_per_cell(j, one)

            elif n in ELLIPSE:
                if is_one_border:
                    if d[ok.COMMON_BORDER]:
                        z = do_common_ellipse_grid(j, one)
                    else:
                        z = do_shape_grid(j, one, n)
                else:
                    z = do_shape_per_cell(j, one)
            else:
                if is_one_border:
                    if d[ok.COMMON_BORDER]:
                        z = do_common_polygon_grid(j, one)
                    else:
                        z = do_shape_grid(j, one, n)
                else:
                    z = do_shape_per_cell(j, one)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.DECO)
        return z

    @staticmethod
    def do_layer(one, is_plan):
        """
        Do a border for a grid layer.

        one: One
            Has init variables

        Return: tuple or None
            Has border material.
        """
        cat = Hat.cat
        j = cat.render.image
        d = one.d
        z = None
        w, h = cat.render.size
        one.is_plan = is_plan
        w1 = d[ok.BORDER_WIDTH]

        if w1 and d[ok.OPACITY]:
            w2 = w1 * 2
            w3 = w1 // 2
            w4 = w1 - w3

            pdb.gimp_selection_none(j)

            if d[ok.OBEY_MARGINS]:
                top, bottom, left, right = one.layer_margin
                width = w - left - right + w1
                height = h - top - bottom + w1
                Sel.rect(j, left - w3, top - w3, width, height)
                Sel.rect(
                    j,
                    left + w4, top + w4,
                    width - w2, height - w2,
                    option=fu.CHANNEL_OP_SUBTRACT
                )

            else:
                Sel.rect(j, 0, 0, w, h)
                Sel.rect(
                    j,
                    w1, w1,
                    w - w2, h - w2,
                    option=fu.CHANNEL_OP_SUBTRACT
                )

            one.layer_name = Lay.make_name(one.parent, nk.LAYER_BORDER)
            z = add_border_layer(j, one, one.parent)
            z = process_selection(z, one)
            if not is_plan:
                z = cast_shadow(z, d)
                z = GradientLight.apply_light(z, ok.DECO)
                z = blur_behind(z, d)
        return z
