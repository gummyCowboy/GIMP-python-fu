#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import atan2, cos, sin, radians
from random import randint, seed, uniform
from roller_constant_for import Bump as fb, Plan as fy
from roller_constant_key import Effect as ek, Model as md, Option as ok
from roller_one_fu import Lay, Sel
from roller_one import Hat, One, Rect
from roller_one_extract import Path
from roller_option_preset import Preset
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

pdb = fu.pdb
FOUR_COORDINATES = 4
RC = fy.CUSTOM_CELL

# oriented with zero at north:
RADIAN_135 = 2.35619
RADIAN_180 = 3.14159
RADIAN_225 = 3.92699
RADIAN_270 = 4.71239
RADIAN_315 = 5.49779
RADIAN_45 = .785398
RADIAN_90 = 1.5708


def calc_bounds(j, one):
    """
    Calculate the rotated bounds of the
    work-in-progress image in its original size.

    Calculate the transform amount for the x, y vectors.
    The goal of the transform is to calculate
    the corner points of the cell-sized image.

    j: Image
        Has size.
    """
    q = one.corners = []
    w, h = j.size

    # center:
    w, h = w // 2, h // 2

    for i in range(4):
        if not i:
            x, y = -w, h

        elif i == 1:
            x, y = w, h

        elif i == 2:
            x, y = w, -h

        else:
            x, y = -w, -h

        x, y = get_point(
            0,
            0,
            atan2(x, y) + one.rotate,
            ((x**2) + (y**2))**0.5
        )
        one.corners.append((x, y))

    x_points = q[0][0], q[1][0], q[2][0], q[3][0]
    y_points = q[0][1], q[1][1], q[2][1], q[3][1]
    u = min(x_points), min(y_points)
    v = max(x_points), max(y_points)
    u = abs(u[0] - v[0]), abs(u[1] - v[1])
    one.transform = (
        one.rect.w / 1. / u[0],
        one.rect.h / 1. / u[1]
    )


def do_bottom_left(one, x, y):
    """
    Make a selection for the bottom-left corner.

    one: One
        with options

    x, y: int
        corner point
    """
    d = one.d
    angle = RADIAN_135 + get_angle_shift(d) + one.rotate
    x, y = get_rotated_corner(one, x, y, 3)
    w = get_tape_length(d)
    x1, y1 = get_point(x, y, angle, w // 2)
    select_tape_rect(d, angle, x1, y1, w)


def do_bottom_right(one, x, y):
    """
    Make a selection for the bottom-right corner.

    one: One
        with options

    x, y: int
        corner point
    """
    d = one.d
    angle = RADIAN_45 + get_angle_shift(d) + one.rotate
    x, y = get_rotated_corner(one, x, y, 2)
    w = get_tape_length(d)
    x1, y1 = get_point(x, y, angle, w // 2)
    select_tape_rect(d, angle, x1, y1, w)


def do_topleft(one, x, y):
    """
    Make a selection for the topleft corner.

    one: One
        Has options.

    x, y: int
        corner point
    """
    d = one.d
    angle = RADIAN_225 + get_angle_shift(d) + one.rotate
    x, y = get_rotated_corner(one, x, y, 0)
    w = get_tape_length(d)
    x1, y1 = get_point(x, y, angle, w // 2)
    select_tape_rect(d, angle, x1, y1, w)


def do_top_right(one, x, y):
    """
    Make a selection for the top-right corner.

    one: One
        with options

    x, y: int
        center point
    """
    d = one.d
    angle = RADIAN_315 + get_angle_shift(d) + one.rotate
    x, y = get_rotated_corner(one, x, y, 1)
    w = get_tape_length(d)
    x1, y1 = get_point(x, y, angle, w // 2)
    select_tape_rect(d, angle, x1, y1, w)


def get_angle_shift(d):
    """
    Make a randomized angle-shift amount.

    d: dict
        Has angle shift.

    Return: int
        angle shift
    """
    f = d[ok.ANGLE_SHIFT]
    return uniform(radians(-f), radians(f))


def get_corner_shift(d):
    """
    Make a randomized corner-shift amount.

    d: dict
        Has corner shift.

    Return: int
        corner shift
    """
    a = d[ok.CORNER_SHIFT]
    return randint(-a, a)


def get_rotated_corner(one, x, y, corner_x):
    """
    one: One
        Has options.

    x: int
        index to corner point

    Return: tuple
        of int
        corner point
    """
    if one.rotate:
        x1, y1 = one.corners[corner_x]
        x1 *= one.transform[0]
        y1 *= one.transform[1]
        x = x1 + one.center[0]
        y = y1 + one.center[1]

    x += get_corner_shift(one.d)
    y += get_corner_shift(one.d)
    return x, y


def get_tape_length(d):
    """
    Calculate a tape length.

    d: dict
        Has options.

    Return: int
        tape length
    """
    return max(
        1,
        d[ok.TAPE_LENGTH] + randint(-d[ok.LENGTH_SHIFT], d[ok.LENGTH_SHIFT])
    )


def process_custom_cell(z, one):
    """
    Do the effect for any free-range cells.

    z: layer
        to receive effect

    one: One
        Has options.
    """
    cat = Hat.cat
    j = cat.render.image
    cat.join_selection(one.model_name, RC, RC)
    if Sel.is_sel(j):
        one.rotate = radians(
            Path.get_cell_place_form(one.path, RC, RC)[ok.ROTATE]
        )
        process_image(one, z)


def process_grid(z, one):
    """
    Do the effect for grid cells.

    z: layer
        to receive effect

    one: One
        Has options.
    """
    # Do one image at a time:
    cat = Hat.cat
    j = cat.render.image
    d = one.grid.grid_d
    is_merge_cell = one.grid.is_merge_cell

    if not is_merge_cell:
        s = 1
    for r in range(one.r):
        for c in range(one.c):
            if is_merge_cell:
                s = d[ok.PER_CELL][r][c]

            # Is it a dependent cell?
            if s != (-1, -1):
                Hat.cat.join_selection(one.model_name, r, c)
                if Sel.is_sel(j):
                    one.rotate = radians(
                        Path.get_cell_place_form(one.path, r, c)[ok.ROTATE]
                    )
                    process_image(one, z, r=r, c=c)


def process_image(one, z, r=0, c=0):
    """
    one: One
        Has variables.

    z: layer
        Has tape material.

    r, c: int
        cell table index
        Use with cell table grid.
    """
    cat = Hat.cat
    j = cat.render.image

    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    w = x1 - x
    h = y1 - y
    one.center = x + w // 2, y + h // 2
    one.rect = Rect((x, y), (w, h))
    d = one.d

    if one.rotate:
        j1 = one.grid.get_image(r, c) \
            if one.context == md.TABLE else one.cell.image
        calc_bounds(j1, one)

    pdb.gimp_selection_none(j)
    do_topleft(one, x, y)
    do_top_right(one, x + w, y)
    do_bottom_left(one, x, y + h)
    do_bottom_right(one, x + w, y + h)
    Sel.fill(z, d[ok.COLOR])


def select_tape_rect(d, angle, x, y, w):
    """
    Define and select a tape rectangle.

    d: dict
        Has options.

    x, y: int
        start point

    w: int
        length of tape
    """
    w1 = d[ok.TAPE_WIDTH]
    x1, y1 = get_point(x, y, angle - RADIAN_90, w1)
    x2, y2 = get_point(x1, y1, angle - RADIAN_180, w)
    x3, y3 = get_point(x2, y2, angle - RADIAN_270, w1)
    Sel.polygon(
        Hat.cat.render.image,
        (x, y, x1, y1, x2, y2, x3, y3),
        option=fu.CHANNEL_OP_ADD
    )


def blur_behind_tape(z):
    """
    Blur behind the tape.

    z: layer
        with tape material

    Return: layer
        with blurred tape material
    """
    if z:
        z1 = Lay.clone_background(z)

        Lay.blur(z1, 5)
        pdb.gimp_curves_spline(
            z1,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 0, 255, 235]
        )
        Sel.item(z)
        Sel.invert_clear(z1)
        return Lay.merge(z)


def get_point(x, y, angle, radius):
    """
    Returns a point the circle that corresponds to the rotation.

    x, y: int
        center point

    angle : float
        the rotation angle
        of radians

    radius: float
        the radius of the circle

    Returns:
        x : float
        y : float
        the point on the circle
    """
    x = (sin(angle) * radius) + x
    y = (cos(angle) * -radius) + y
    return round(x), round(y)


class CornerTape:
    """Simulate a tape image holder."""

    @staticmethod
    def do(one):
        """
        Do a Corner Tape image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer
            with Corner Tape
        """
        cat = Hat.cat
        j = cat.render.image
        parent = one.parent
        d = one.d
        e = Preset.get_default(ek.SHADOW_1)
        e.update(d)
        e[ok.OFFSET_X] = e[ok.OFFSET_Y] = 0

        seed(d[ok.RANDOM_SEED])
        image_shadow = Shadow.do(
            One(
                cast=(one.image_layer,),
                d=e,
                model_name=one.model_name,
                name=Lay.make_name(parent, one.k + " Shadow"),
                parent=parent
            )
        )

        group = Lay.group(j, Lay.make_name(parent, one.k), parent=parent)
        z = Lay.add(j, one.k, parent=group)

        if one.context == md.TABLE:
            process_grid(z, one)

        else:
            process_custom_cell(z, one)

        z1 = Lay.clone(z)
        e = Preset.get_default(ok.BUMP)
        e[ok.BUMP_TYPE] = fb.NOISE
        e[ok.BUMP_DEPTH] = 1
        z1 = RenderHub.bump(z1, e)

        Lay.blur(z1, 2)
        pdb.gimp_drawable_invert(z1, 0)

        z1.mode = fu.LAYER_MODE_DIFFERENCE
        z1.opacity = 66.
        z2 = Lay.clone(z1)
        z2.mode = fu.LAYER_MODE_LCH_HUE
        z2.opacity = 24.
        z3 = Lay.clone(z2)
        z3.mode = fu.LAYER_MODE_NORMAL
        z3.opacity = 2.
        z4 = Lay.clone(z)
        z4.mode = fu.LAYER_MODE_HSL_COLOR

        # Darken the edge:
        Sel.item(z4)
        pdb.gimp_selection_shrink(j, 1.)
        Sel.invert(j)
        pdb.gimp_curves_spline(
            z4,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 10, 255, 80]
        )

        # Place on top:
        pdb.gimp_image_reorder_item(j, z4, group, 0)

        z5 = Lay.clone(z4)
        z5.mode = fu.LAYER_MODE_OVERLAY
        z6 = Lay.clone(z)

        pdb.plug_in_shift(j, z6, 2, 0)
        pdb.plug_in_shift(j, z6, 2, 1)
        Lay.blur(z6, 2)
        pdb.gimp_curves_spline(
            z6,
            fu.HISTOGRAM_VALUE,
            FOUR_COORDINATES,
            [0, 0, 255, 0]
        )

        for i in (z, z1, z2, z3, z4, z5):
            Lay.create_mask(i)

        pdb.gimp_image_remove_layer(j, z6)
        pdb.gimp_drawable_invert(z1, 0)

        z = Lay.merge_group(group)

        Sel.item(z)
        Lay.clear_sel(image_shadow)

        z.opacity = d[ok.OPACITY]
        z = blur_behind_tape(z)
        return z, image_shadow
