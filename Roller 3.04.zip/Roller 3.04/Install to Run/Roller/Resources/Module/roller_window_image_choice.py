#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk, Window as wi
from roller_port_image_choice import PortImageChoice
from roller_window import Window


class RWImageChoice(Window):
    """Is a GTK dialog with multiple options for assigning an image."""
    def __init__(self, g):
        """
        Create a window.

        g: OptionButton
            Has values.
        """
        self.safe = g
        d = {
            wk.WIN: g.win.win,
            wk.WINDOW_TITLE: "Choose Image Source",
            wk.WINDOW_KEY: wi.IMAGE_CHOOSER
        }

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self
            }
        )

        self.port = PortImageChoice(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()
