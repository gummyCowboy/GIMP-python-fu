#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub, PROFILE
import gimpfu as fu

pdb = fu.pdb
em = Fu.Emboss


class MetallicProfile:
    """Create a metallic frame from a profile."""

    @staticmethod
    def do(one):
        """
        Do the image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer or None
            Is border.
        """
        cat = Hat.cat
        d = one.d
        j = cat.render.image
        parent = one.parent
        group = Lay.group(j, Lay.make_name(parent, one.k), parent=parent)
        z = Lay.add(j, one.k, parent=group)
        z1 = Lay.clone_opaque(one.image_layer, True)
        color = 255, 255, 255
        w = d[ok.FRAME_WIDTH]
        q = PROFILE[d[ok.PROFILE]](w, *(color,))

        Sel.make_layer_sel(z1)
        RenderHub.draw_color_profile(z, w, q, color)
        pdb.gimp_image_remove_layer(j, z1)
        pdb.plug_in_emboss(
            j, z,
            cat.light_angle,
            cat.elevation,
            2,
            em.BUMP
        )

        z = Lay.merge_group(group)
        z = GradientLight.apply_light(z, ok.METAL_FRAME)
        z = RenderHub.make_polar_mask(j, z, is_dark=True)
        z.mode = fu.LAYER_MODE_VIVID_LIGHT
        z.opacity = 50.
        z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        one.shadow_layer = [z, one.image_layer]
        return z
