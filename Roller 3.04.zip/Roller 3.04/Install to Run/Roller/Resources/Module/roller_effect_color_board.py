#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
import gimpfu as fu

pdb = fu.pdb


class ColorBoard:
    """Create a an color edge around an image(s)."""

    @staticmethod
    def do(one):
        """
        Do the Colored Board image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer or None
            with Color Board
        """
        cat = Hat.cat
        j = cat.render.image
        d = one.d
        if d[ok.OPACITY]:
            parent = one.parent
            Sel.make_layer_sel(one.image_layer)

            sel = cat.save_short_term_sel()

            Sel.grow(j, d[ok.FRAME_WIDTH], d[ok.FRAME_TYPE])
            Sel.load(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

            z = Lay.add(j, Lay.make_name(parent, one.k), parent=parent)

            Sel.fill(z, d[ok.COLOR])
            pdb.plug_in_antialias(j, z)

            z = GradientLight.apply_light(z, ok.TRANSLUCENT_FRAME)
            z.opacity = d[ok.OPACITY]
            one.shadow_layer = [z, one.image_layer]
            return z
