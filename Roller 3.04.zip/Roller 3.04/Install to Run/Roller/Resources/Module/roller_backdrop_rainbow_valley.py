#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_fu import Fu
from roller_constant_for import BackdropStyle as bs
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Hat, One
from roller_one_fu import Lay
from roller_option_preset import Preset
import gimpfu as fu

pdb = fu.pdb
sn = Fu.SolidNoise


def noise(j, z, d):
    """
    Adds noise to a layer.

    j: GIMP image
        Is render.

    z: layer
        layer that receives noise

    d: dict
        Has options.
    """
    if d[ok.POWER]:
        pdb.plug_in_solid_noise(
            j, z,
            sn.NO_TILEABLE,
            sn.YES_TURBULENT,
            d[ok.RANDOM_SEED],
            sn.MEDIUM_DETAIL,
            sn.HORIZONTAL_SIZE_2,
            sn.VERTICAL_SIZE_2
        )
        pdb.plug_in_hsv_noise(
            j, z,
            Fu.HSVNoise.MEDIUM_HOLDNESS,
            d[ok.POWER],
            d[ok.POWER],
            d[ok.POWER]
        )


class RainbowValley:
    """Fill the backdrop with a colorful abstract."""

    @staticmethod
    def do(one):
        """
        Create the Rainbow Valley backdrop-style.

        one: One
            Has variables.

        Return: layer
            Has material.
        """
        d = one.d
        j = Hat.cat.render.image
        group = Lay.group(j, one.k)
        n = d[ok.BACKDROP_TYPE]
        go = True

        if n == bs.BACKDROP_IMAGE:
            # If the backdrop-image is empty,
            # Rainbow Valley will produce nothing:
            if Lay.has_pixel(one.z):
                z = Lay.clone(one.z)
                pdb.gimp_image_reorder_item(j, z, group, 0)
            else:
                go = False
                pdb.gimp_image_remove_layer(j, group)

        elif n == bs.PLASMA:
            z = Lay.add(j, one.k, parent=group)
            pdb.plug_in_plasma(j, z, d[ok.RANDOM_SEED], 3)

        else:
            e = Preset.get_default(by.GRADIENT_FILL)
            e[ok.GRADIENT_TYPE] = d[ok.GRADIENT_TYPE]
            e[ok.GRADIENT] = d[ok.GRADIENT]

            if d[ok.GRADIENT_TYPE] == "Linear":
                e[ok.END_X] = e[ok.START_X] = .5
                e[ok.START_Y] = .0
                e[ok.END_Y] = 1.

            else:
                e[ok.START_X] = e[ok.START_Y] = .5
                e[ok.END_X] = e[ok.END_Y] = .0

            z = Lay.add(j, one.k, parent=group)
            z = GradientFill.do_layer(j, One(d=e, z=z))

            pdb.gimp_image_reorder_item(j, z, group, 0)
            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

        if go:
            for i in range(10):
                z = Lay.clone(z)
                z.name = "Layer #{} of 10".format(i + 1)
                z.mode = fu.LAYER_MODE_DIFFERENCE

                pdb.plug_in_despeckle(j, z, i, 0, 0, 255)

                if i % 2:
                    z = Lay.clone(z)
                    z.mode = fu.LAYER_MODE_LIGHTEN_ONLY

                    noise(j, z, d)

                    d[ok.RANDOM_SEED] += 1

                    pdb.plug_in_despeckle(j, z, i, 0, 0, 255)
                    z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

                do_engrave = 0

                if d[ok.TEXTURE]:
                    if i < 7 or i == 9:
                        do_engrave = 1

                elif i < 7:
                    do_engrave = 1
                if do_engrave:
                    z = Lay.clone(z)

                    pdb.plug_in_engrave(j, z, max(i, 2), 1)

                    z.mode = fu.LAYER_MODE_BURN
                    z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
                    pdb.plug_in_wind(
                        j, z,
                        Fu.Wind.THRESHOLD_0,
                        Fu.Wind.FROM_TOP,
                        Fu.Wind.STRENGTH_50,
                        Fu.Wind.BLAST,
                        Fu.Wind.LEADING_EDGE
                    )

            z = Lay.merge_group(group)

            if d[ok.EMBOSS]:
                z = Lay.clone(z)
                z.mode = fu.LAYER_MODE_OVERLAY

                pdb.plug_in_emboss(j, z, Hat.cat.light_angle, 30., 1, 1)
                z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            return z
