#!/usr/bin/env python
# -*- coding: utf-8 -*-


class NoEffect:
    """
    Don't do anything. Use so a preview
    without an effect can show images.
    """

    @staticmethod
    def do(one):
        """
        Is an image-effect template function.

        one: One
            Has variables.
            not used
        """
        return
