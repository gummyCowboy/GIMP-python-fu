#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Frame as fo
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub, PROFILE
import gimpfu as fu

em = Fu.Emboss
pdb = fu.pdb
um = Fu.UnsharpMask


class GlassReveal:
    """Create a glass-like border."""

    @staticmethod
    def do(one):
        """
        Do the image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer or None
            with Glass Reveal
        """
        cat = Hat.cat
        d = one.d
        j = cat.render.image
        if d[ok.OPACITY]:
            parent = one.parent
            group = Lay.group(
                j,
                Lay.make_name(parent, one.k),
                parent=parent
            )
            z = Lay.add(j, one.k, parent=group)
            z1 = Lay.clone_opaque(one.image_layer, True)
            color = 255, 255, 255
            w = d[ok.FRAME_WIDTH]
            q = PROFILE[d[ok.PROFILE]](w, *(color,))

            Sel.make_layer_sel(z1)
            RenderHub.draw_color_profile(z, w, q, color)
            pdb.gimp_image_remove_layer(j, z1)

            if d[ok.CURVE] != "None":
                q = fo.CURVE_DICT[d[ok.CURVE]]
                pdb.gimp_curves_spline(z, fu.HISTOGRAM_VALUE, len(q), q)

            if d[ok.EMBOSS]:
                z = Lay.clone(z)

                pdb.plug_in_emboss(
                    j, z,
                    cat.light_angle,
                    cat.elevation,
                    w // 3,
                    em.BUMP
                )
                z.opacity = 50. if w < 60. else 100.
                z.mode = fu.LAYER_MODE_MULTIPLY
                z = Lay.clone(z)
                z.mode = fu.LAYER_MODE_SCREEN

            z = Lay.merge_group(group)
            z.opacity = d[ok.OPACITY]
            z = GradientLight.apply_light(z, ok.TRANSLUCENT_FRAME)
            one.shadow_layer = [z, one.image_layer]
            return z
