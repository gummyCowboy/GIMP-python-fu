#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Fill as fl, Frame as ff
from roller_constant_key import Option as ok
from roller_frame import Overlay, do_selection_material
from roller_frame_build import Build
from roller_fu import (
    clear_inverse_selection,
    color_fill_selection,
    copy_all_image,
    get_layer_position,
    get_select_bounds,
    merge_layer,
    paste_image,
    paste_layer,
    select_item,
    select_rect,
    shape_image
)
from roller_maya import check_matter, check_mix_wrap, make_frame_group
from roller_maya_blur_behind import BlurBehind
from roller_maya_bump import Bump
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_one_gegl import edge
from roller_view_hub import set_gimp_pattern, set_fill_context
from roller_view_real import LIGHT, OVERLAY, clone_background
import gimpfu as fu

pdb = fu.pdb


def apply_backdrop(v, maya, z):
    """
    Copy the background. Clip material around the existing selection.

    v: View
    maya: Maya
    Return: layer
        with backdrop
    """
    j = v.j
    z1 = maya.bg_z

    pdb.gimp_image_reorder_item(j, z1, maya.group, get_layer_position(z))
    select_item(z)
    clear_inverse_selection(z1)
    j.remove_layer(z)
    return z1


def apply_image(v, maya, z):
    """
    Apply an image to the frame.

    v: View
    maya: Maya
    z: layer
        Has the frame.

    Return: layer
        with the frame
    """
    j = v.j
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    j1 = maya.cause.get_frame_image(maya.k)

    if j1:
        j2 = j1.j

        copy_all_image(j2)

        j3 = paste_image()

        shape_image(j3, x1 - x, y1 - y)

        z = paste_layer(z)

        pdb.gimp_layer_set_offsets(z, x, y)
        return merge_layer(z)
    return z


def apply_pattern(v, maya, z):
    """
    Fill an existing selection with a pattern.

    v: View
    maya: Maya
    Return: layer
        with pattern
    """
    d = maya.value_d

    set_fill_context(fl.FILL_DICT)
    set_gimp_pattern(d[ok.PATTERN])
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, .0, .0)
    return z


def do_color(v, maya):
    go = True
    z = None
    super_ = maya.super_maya

    if maya.value_d[ok.TYPE] == ff.BACKDROP:
        z = super_.matter

        if z:
            maya.bg_z = clone_background(v, z)
        else:
            go = False

    if go:
        maya.group = super_.group
        z = do_selection_material(v, maya, do_overlay, embellish, "")
    return z


def do_color_fill(v, maya, z):
    d = maya.value_d[ok.WRW][ok.WRAP_NP]
    z.name = z.parent.name + " Wrap"

    grow_sel(v, d[ok.WIDTH])
    color_fill_selection(z, d[ok.COLOR_1])
    return z


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: FrameOver
    Return: layer or None
        with the frame
    """
    return do_selection_material(v, maya, do_color_fill, embellish, "")


def do_overlay(v, maya, z):
    j = v.j
    super_ = maya.super_maya
    z1 = super_.matter

    if z1:
        pdb.gimp_image_reorder_item(j, z, super_.group, get_layer_position(z1))

        grow_sel(v, super_.value_d[ok.WRW][ok.WRAP_NP][ok.WIDTH])

        z = FILL_D[maya.value_d[ok.TYPE]](v, maya, z)

        pdb.gimp_selection_none(j)
        edge(z)
        pdb.plug_in_colortoalpha(j, z, (0, 0, 0))

    z.name = z.parent.name + " Overlay"
    return z


def grow_sel(v, a):
    """
    Make a frame from a selection.

    v: View
    maya: Maya
    a: float
        amount to expand selection
    """
    j = v.j
    is_sel, x, y, x1, y1 = get_select_bounds(j)

    if is_sel:
        x -= a
        y -= a
        w = x1 + a - x
        h = y1 + a - y
        select_rect(j, x, y, w, h)


def embellish(v, maya, z):
    """
    Is a callback from 'do_selection_material'.

    v: View
    maya: NailPolish
    z: layer
        to embellish

    Return: layer
        with embellishment
    """
    return z


class NailPolish(Build):
    """Make an overlay for material."""
    is_seeded = True
    issue_q = 'matter', 'mode', 'opacity', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP_NP

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        self.bg_z = None

        Build.__init__(
            self,
            any_group,
            super_maya,
            k_path + (ok.WRW, ok.WRAP_NP),
            do_matter
        )

        self.sub_maya[OVERLAY] = Overlay(
            any_group, self, k_path + (ok.WRW, ok.OVERLAY_NP), do_color
        )
        self.sub_maya[ok.BUMP] = Bump(
            any_group, self, k_path + (ok.SRW, ok.BUMP)
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self.cause, self)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.OTHER)
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(
            any_group, self, k_path, ok.SRW
        )

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame Over Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        is_back = v.is_back
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[OVERLAY].do(
            v, d[ok.WRW][ok.OVERLAY_NP], self.is_matter, self.is_matter
        )
        self.sub_maya[ok.BUMP].do(v, d[ok.SRW][ok.BUMP], self.is_matter)

        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], self.is_matter, is_change
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.sub_maya[ok.BLUR_BEHIND].do(
            v, d[ok.SRW][ok.BLUR_BEHIND], m or is_back, self.is_matter
        )
        self.reset_issue()
        return m


FILL_D = {
    ff.BACKDROP: apply_backdrop,
    ff.IMAGE: apply_image,
    ff.PATTERN: apply_pattern
}
