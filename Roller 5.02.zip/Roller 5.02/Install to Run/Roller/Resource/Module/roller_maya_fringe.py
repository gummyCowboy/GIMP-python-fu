#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Plan as fy, Signal as si
from roller_constant_key import Node as ny, Option as ok, Plan as ak
from roller_deco_fringe import (
    do_main_cell,
    do_main_face,
    do_main_facing,
    do_canvas,
    do_cell,
    do_face,
    do_facing
)
from roller_maya import (
    MAIN,
    PER,
    Canvas,
    Cell,
    FaceRoute,
    Plasma,
    assign_image,
    check_matter,
    check_mix_basic,
    take_type_vote
)
from roller_maya_blur_behind import BlurBehind
from roller_maya_bump import Bump
from roller_maya_light import Light
from roller_option_group import DecoGroup
from roller_view_option_list import Frame
from roller_view_real import LIGHT, make_canvas_group, make_cast_group
from roller_view_step import get_planner


class Fringe(DecoGroup):
    """
    Create Widget group. Assign a View processor
    and connect responsible signal handler.
    """

    def __init__(self, **d):
        """
        d: dict
            Has init value.
        """
        DecoGroup.__init__(self, **d)

        node_k = self.nav_k[-2]
        self.plan = {
            ny.CANVAS: PlanCanvas,
            ny.CELL: PlanCell,
            ny.FACE: PlanFace,
            ny.FACING: PlanFacing
        }[node_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas,
            ny.CELL: WorkCell,
            ny.FACE: WorkFace,
            ny.FACING: WorkFacing
        }[node_k](self)
        baby = self.item.model.baby
        if node_k in (ny.FACE, ny.FACING):
            self.handle_d[
                baby.connect(si.CELL_SHIFT_CALC, self.on_cell_calc)
            ] = baby


class Chi(Plasma):
    """Factor Plan and Work."""

    def __init__(self, any_group, view_x, q):
        """
        view_x: int
            0 or 1; Plan or Work index

        q: iterable
            of function for producing View output
        """
        Plasma.__init__(
            self,
            any_group,
            view_x,
            q,
            k_path=[(), (ok.OCR,), (ok.IMAGE_CHOICE,), (ok.BRW, ok.BRUSH_D,)]
        )
        self.set_issue()


class Plan(Chi):
    """Manage Plan layer output."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, self.put)

        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.FRINGE)
        self.handle_d[
            planner.connect(fy.SIGNAL_D[ak.FRINGE], self.on_plan_option_change)
        ] = planner

    def bore(self, v):
        """
        Manage layer output during a View run.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH] and self.is_planned

        if self.go:
            self.is_matter |= self.is_switched
        self.realize(v)

    def on_plan_option_change(self, _, arg):
        """
        Respond to change in Planner's Fringe option.

        _: Signal
        arg: tuple
            (bool, bool)
            (
                boolean state of the Fringe option,
                boolean state of the Fringe option since the last view run
            )
        """
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage Work layer output."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 1, self.put)
        self.sub_maya[ok.FRAME] = Frame(any_group, self, (ok.FRW, ok.FRAME))
        self.sub_maya[ok.BUMP] = Bump(any_group, self, (ok.BRW, ok.BUMP))
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(any_group, self, (), ok.FRW)
        self.sub_maya[LIGHT] = Light(any_group, self, ok.FRINGE)
        self.handle_d[
            self.any_group.connect(si.BACK_CHANGE, self.on_back_change)
        ] = self.any_group

    def bore(self, v):
        """
        Manage layer output during a View run.

        v: View
        """
        d = self.value_d
        self.go = self.value_d[ok.SWITCH]
        is_back = v.is_back

        if self.go:
            self.is_matter |= take_type_vote(v, d)

        self.realize(v)
        if self.go:
            self.go = bool(self.matter)

            self.sub_maya[ok.BUMP].do(v, d[ok.BRW][ok.BUMP], self.is_matter)

            if not self.is_face:
                is_back |= self.sub_maya[ok.FRAME].do(
                    v, d[ok.FRW][ok.FRAME], self.is_matter
                )

            self.sub_maya[ok.BLUR_BEHIND].do(
                v, d[ok.FRW][ok.BLUR_BEHIND], is_back, self.is_matter
            )
            self.sub_maya[LIGHT].do(v, self.is_matter)
            v.is_back |= is_back


class Main:
    """Identify the View step processor as being the main option settings."""
    vote_type = MAIN

    def __init__(self):
        return


class WorkMain(Main, Work):
    """Factor Work's the main option settings."""

    def __init__(self, *arg):
        """
        arg: tuple
            Work spec
        """
        Main.__init__(self)
        Work.__init__(self, *arg)


# Canvas_______________________________________________________________________
class Cloth:
    """Is factored from Plan and Work Canvas."""
    def __init__(self):
        self.do_matter = do_canvas


class PlanCanvas(Plan, Canvas, Main, Cloth):
    """Manage Plan/Canvas layer output."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Plan.__init__(self, any_group)
        Canvas.__init__(self)
        Main.__init__(self)
        Cloth.__init__(self)


class WorkCanvas(WorkMain, Canvas, Cloth):
    """Manage Work/Canvas layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'shade'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        WorkMain.__init__(self, any_group)
        Canvas.__init__(self)
        Cloth.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class Cellular:
    """Manage Cell branch layer output."""
    is_face = False

    def __init__(self):
        self.do_matter = do_main_cell


class PlanCell(Plan, Cell, Main, Cellular):
    """Manage Plan/Cell layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Plan.__init__(self, any_group)
        Main.__init__(self)
        Cell.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(WorkMain, Cell, Cellular):
    """Manage Work/Cell layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per', 'shade'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            owner
        """
        WorkMain.__init__(self, any_group)
        Cell.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per__________________________________________________________________________
class Per:
    """Manage Per layer output."""
    vote_type = PER

    def __init__(self, do_matter, k):
        self.do_matter = do_matter
        self.k = k
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per Cell_____________________________________________________________________
class PlanCellPer(Plan, Per):
    """Manage Cell/Per layer output for Plan and Draft views."""
    is_face = False
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        Create a Maya for Per Cell.

        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(self, any_group)
        Per.__init__(self, do_cell, k)


class WorkCellPer(Work, Per):
    """Manage Cell/Per layer output for Peek, Preview, and render."""
    is_face = False
    issue_q = 'matter', 'mode', 'opacity', 'shade'

    def __init__(self, any_group, k):
        """
        Create a Maya for Per Cell.

        k: tuple
            (r, c); cell index; of int
        """
        Work.__init__(self, any_group)
        Per.__init__(self, do_cell, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face_________________________________________________________________________
class Face:
    """Manage Face layer output."""
    is_face = True

    def __init__(self):
        self.do_matter = do_main_face

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_image(v, self, self.model.face_q)


class PlanFace(Face, Main, Plan, FaceRoute):
    """Manage Plan/Face layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group)
        FaceRoute.__init__(self, PlanFacePer)


class WorkFace(Face, WorkMain, FaceRoute):
    """Manage Work/Face layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per', 'shade'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            with Face options
        """
        Face.__init__(self)
        WorkMain.__init__(self, any_group)
        FaceRoute.__init__(self, WorkFacePer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face Per Cell________________________________________________________________
class FacePer(Per):
    """Manage Work/Face/Per layer output."""
    is_face = True

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacePer(Plan, FacePer):
    """Manage Plan/Face/Per layer output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        k: tuple
            (row, column, face)
        """
        Plan.__init__(self, any_group)
        FacePer.__init__(self, do_face, k)


class WorkFacePer(Work, FacePer):
    """Manage Work/Face/Per Cell layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'shade'

    def __init__(self, any_group, k):
        """
        k: tuple
            (row, column, face)
        """
        Work.__init__(self, any_group)
        FacePer.__init__(self, do_face, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing_______________________________________________________________________
class Facing:
    """Factor Plan and Work Facing."""
    is_face = False

    def __init__(self):
        self.do_matter = do_main_facing

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_image(v, self, self.model.face_q)


class PlanFacing(Facing, Main, Plan, FaceRoute):
    """Manage Plan/Facing layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Facing.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group)
        FaceRoute.__init__(self, PlanFacingPer)


class WorkFacing(Facing, WorkMain, FaceRoute):
    """Manage Work/Facing layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per', 'shade'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Facing.__init__(self)
        WorkMain.__init__(self, any_group)
        FaceRoute.__init__(self, WorkFacingPer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing Per Cell______________________________________________________________
class FacingPer(Per):
    """Factor Plan and Work Facing/Per."""
    is_face = False

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacingPer(Plan, FacingPer):
    """Manage Plan/Facing/Per output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            the enclosing Preset's

        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(self, any_group)
        FacingPer.__init__(self, do_facing, k)


class WorkFacingPer(Work, FacingPer):
    """Manage Work/Facing/Per output."""
    issue_q = 'matter', 'mode', 'opacity', 'shade'

    def __init__(self, any_group, k):
        """
        Create a Maya for Per Cell.

        k: tuple
            (r, c); cell index; of int
        """
        Work.__init__(self, any_group)
        FacingPer.__init__(self, do_facing, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
