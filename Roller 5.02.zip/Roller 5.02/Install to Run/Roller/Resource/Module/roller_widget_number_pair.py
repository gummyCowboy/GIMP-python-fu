#!/usr/bin/env python
# -*- coding: utf-8 -*-
from math import sqrt
from random import uniform
from roller_constant_for import MAX_SIZE_F, Signal as si
from roller_constant_key import Widget as wk
from roller_one import seal
from roller_one_the import The, calc_factor
from roller_one_tip import Tip
from roller_widget_voter import Voter
from roller_widget_fixed import Fixed
from roller_widget_label import Label
from roller_widget_row import Row
from roller_widget_slider import Slider


class NumberPair(Row, Voter):
    """The Widget value is a tuple (fixed value, factor value)."""
    has_table_label = True

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        # Init early for a on-change-response timing issue.
        self._factor_slider = None

        Row.__init__(self, **d)

        self._limit = map(float, d[wk.LIMIT])
        self.is_x_axis = d[wk.AXIS] == 'x'
        self.is_y_axis = d[wk.AXIS] == 'y'
        d[wk.GREATER_G] = self
        self._precision = 0

        # The type can be either an int or a float with a variable precision.
        precision = d.get(wk.PRECISION)

        if precision:
            self._precision = precision

        d[wk.RELAY].insert(0, self.on_number_pair_change)

        # fixed-value Slider
        # Can be an integer or a float.
        d[wk.TOOLTIP] = d[wk.TIPS][0] if wk.TIPS in d else ""
        g = self._fixed = Fixed(**d)

        # The factor Slider value is a fraction of a context size.
        d[wk.PRECISION] = 6
        d[wk.LIMIT] = self._random_range = (.0, 1.) if self._limit[0] >= .0 \
            else (-1., 2.)
        d[wk.TOOLTIP] = d[wk.TIPS][1] if wk.TIPS in d else ""
        g1 = self._factor_slider = Slider(**d)

        # value Label
        # Display the net value.
        d.pop(wk.KEY)

        d[wk.TEXT] = " 0"
        d[wk.TOOLTIP] = " Is the net value. "
        g2 = self._value_label = Label(**d)

        for i in (g, g1, g2):
            self.hbox.pack_start(i, expand=0)

        Voter.__init__(self, **d)
        self.any_group.connect(si.RANDOMIZE, self.randomize)

    def _make_net_label(self):
        """Make a string for the net value Label."""
        return " " + str(int(self.get_net_value()))

    def on_number_pair_change(self, _):
        """
        Respond to change in the Slider.

        _: Slider
            Could be either one.
            no use
        """
        if self._factor_slider:
            self._value_label.set_label_value(self._make_net_label())

    def get_net_value(self):
        """
        Calculate the net value of the Slider.

        Return: numeric
            same type as the fixed value
        """
        q = self.get_a()
        a = q[0] + calc_factor(q[1], self._limit[1])
        a = seal(a, self._limit[0], self._limit[1])
        return round(a, self._precision)

    def get_a(self):
        """
        Get the values of the Slider.

        Return: tuple
            (fixed value, factor value)
        """
        # Is called during the init.
        if self._factor_slider:
            return (
                self._fixed.get_lesser_a(),
                self._factor_slider.get_lesser_a()
            )
        return 0, .0

    def randomize(self, *_):
        """Get a random value for the NumberPair."""
        self.set_a((
            .0,
            uniform(self._random_range[0], self._random_range[1])
        ))

    def set_a(self, a):
        """
        Set the value of the Slider.

        a: numeric or tuple
            the value to apply to the Sliders
            If the value is numeric, then the fixed value Slider
            is set to 'a', and the factored value Slider is set to zero.
        """
        if isinstance(a, (tuple, list)):
            self._fixed.set_lesser_a(a[0])
            self._factor_slider.set_a(a[1])

        else:
            if isinstance(a, int):
                self._fixed.set_lesser_a(a)
                self._factor_slider.set_a(.0)
            else:
                # float
                self._fixed.set_lesser_a(0)
                self._factor_slider.set_a(a)
        self._value_label.set_label_value(self._make_net_label())

    def update_net_label(self):
        """Update the net value Label on a dependency change."""
        self._value_label.set_label_value(self._make_net_label())


class Pair(NumberPair):
    """Is factored sub-NumberPair."""

    def __init__(self, **d):
        """
        d: dict
            Has keyword, value pairs.
        """
        d[wk.PAGE_INCR] = .1
        tips = d.get(wk.TIPS)

        if tips:
            if d[wk.AXIS] == 'x':
                d[wk.TIPS] = tips[0], Tip.FACTOR_W
            else:
                # 'y'
                d[wk.TIPS] = tips[0], Tip.FACTOR_H

        NumberPair.__init__(self, **d)

        self.handle_d[
            The.power.connect(si.VIEW_SIZE_CHANGE, self.check_limit)
        ] = The.power
        self.check_limit()


class CanvasPair(Pair):
    """
    Use with canvas space dependent options.
    Update the net value Label on view size change.
    """

    def __init__(self, **d):
        """
        d: dict
            Has keyword, value pairs.
        """
        d[wk.LIMIT] = .0, MAX_SIZE_F
        Pair.__init__(self, **d)

    def check_limit(self, *_):
        """
        Update the Widget on a view size change.
        Is used by the net value Label.
        """
        w, h = The.view.wip.size
        self._limit = (.0, w) if self.is_x_axis else (.0, h)
        self.update_net_label()


class RectPair(Pair):
    """
    Use with cell rectangle size options. Update
    the net value Label on view size change.
    """

    def __init__(self, **d):
        """
        d: dict
            Has keyword, value pairs.
        """
        Pair.__init__(self, **d)

    def check_limit(self, *_):
        """Update the net value Label on view size change."""
        self.update_net_label()

    def get_net_value(self):
        """
        Calculate the net value of the Widget.
        Override the base function as the limit is not the same.

        Return: numeric
            same type as the fixed value
        """
        q = self.get_a()
        w, h = The.view.wip.size
        limit = w if self.is_x_axis else h
        a = q[0] + calc_factor(q[1], limit)
        a = seal(a, -MAX_SIZE_F, MAX_SIZE_F)
        return round(a, self._precision)


class RenderPair(Pair):
    """
    Use with view size dependent options.
    Update the net value Label on view size change.
    """

    def __init__(self, **d):
        """
        d: dict
            Has keyword, value pairs.
        """
        Pair.__init__(self, **d)

    def check_limit(self, *_):
        """Update the net value Label on render size change."""
        w, h = The.view.wip.size

        if self._limit[0] == .0:
            if self.is_x_axis:
                self._limit = (.0, w)

            elif self.is_y_axis:
                self._limit = (.0, h)
            else:
                self._limit = (.0, sqrt(w * h))

        else:
            self._limit = (-w, w) if self.is_x_axis else (-w, h)
        self.update_net_label()
