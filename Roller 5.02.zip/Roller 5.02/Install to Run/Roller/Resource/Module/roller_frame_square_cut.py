#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_color_grid import draw_color_grid
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_frame import Metal, do_soft_metal_material
from roller_def import get_default_value
from roller_one_the import The
import gimpfu as fu

pdb = fu.pdb


def make_pattern(z, d):
    """
    Make a black and white rectangle pattern.

    z: layer
        to receive pattern

    d: dict
        Square Cut Preset
        {Option key: value}

    Return: layer
        with Square Cut material
    """
    j = The.cat.render.image()

    pdb.gimp_selection_none(j)

    e = get_default_value(by.COLOR_FILL)

    e.update(d)

    z = draw_color_grid(z, e)

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    return z


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: SquareCut
    Return: layer
        with the frame
    """
    return do_soft_metal_material(
        v, maya, make_pattern, "Square Cut", ok.FILLER_SC
    )


class SquareCut(Metal):
    """Create a frame with a square grid."""

    def __init__(self, any_group, super_maya, k_path):
        Metal.__init__(
            self, any_group, super_maya, k_path, do_matter, ok.FILLER_SC
        )
