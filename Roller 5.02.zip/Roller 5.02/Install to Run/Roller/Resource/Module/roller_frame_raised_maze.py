#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import MetalCanvas, make_canvas_frame_sel, soften_metal_sel
from roller_fu import (
    dilate, load_selection, remove_z, select_item, select_opaque
)
from roller_view_real import add_wip_layer
import gimpfu as fu

pdb = fu.pdb


def do_filler(v, maya):
    """
    Make the frame.

    v: View
    maya: Frame
    Return: layer
        with the Frame
    """
    def _add():
        """Add a layer to the bottom of the Maya's group."""
        return add_wip_layer(v, "Raised Maze", group, offset=len(group.layers))

    j = v.j
    d = maya.value_d[ok.WRW][ok.FILLER_RM]
    super_ = maya.super_maya
    group = super_.group
    cause = super_.cause.matter

    # layer for the maze, 'z'
    z = _add()

    sel = make_canvas_frame_sel(v, d)

    pdb.gimp_selection_none(j)
    pdb.gimp_context_set_foreground((0, 0, 0))
    pdb.gimp_context_set_background((255, 255, 255))
    pdb.plug_in_maze(
        j, z,
        int(max(1, v.wip.w // d[ok.COLUMN])),   # passage scale
        int(max(1, v.wip.h // d[ok.ROW])),      # passage scale
        1,                                      # yes, tileable
        0,                                      # depth first algorithm
        int(d[ok.SEED] + v.glow_ball.seed),
        0,                                      # multiple, not clearly defined
        0                                       # offset, not clearly defined
    )

    # amount, '1.'; no wrap, '0'; Sobel, '0'
    pdb.plug_in_edge(j, z, 1., 0, 0)

    w = max(1., d[ok.LINE_W] // 2. - 1.)

    for _ in range(int(w)):
        dilate(z)

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    select_item(z)
    remove_z(z)

    # layer for the emboss, 'z'
    z = _add()

    if sel:
        load_selection(j, sel, option=fu.CHANNEL_OP_ADD)
        pdb.gimp_image_remove_channel(j, sel)

    select_opaque(cause, option=fu.CHANNEL_OP_SUBTRACT)
    return soften_metal_sel(v, z, super_.value_d[ok.WRW][ok.WRAP])


class RaisedMaze(MetalCanvas):
    """Is a metallic-like border with a raised maze across the image."""

    def __init__(self, any_group, super_maya, k_path):
        """
        q: tuple
            Metal spec

        d: dict
            Metal spec
        """
        MetalCanvas.__init__(
            self,
            any_group,
            super_maya,
            k_path,
            do_filler,
            (ok.WRW, ok.FILLER_RM)
        )
