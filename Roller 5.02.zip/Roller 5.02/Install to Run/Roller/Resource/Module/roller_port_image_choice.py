#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_one_tip import Tip
from roller_port_preview import PortPreview
from roller_widget_button import Button
from roller_widget_node import Piece


class PortImageChoice(PortPreview):
    """Is a display container for the Image Choice Preset."""
    window_key = "Image"

    def __init__(self, d, g):
        """
        Create the Port.

        d: dict
            Has Port init values.

        g: OptionButton
            Is responsible.
        """
        PortPreview.__init__(self, d, g)

    def _draw_image_options(self, box):
        """
        Draw the Image Choice Preset.

        box : VBox
            container for the Widgets
        """
        self.draw_group(Piece(ok.IMAGE_CHOICE, box, self.safe.any_group.item))

    def draw(self):
        """Draw Widget."""
        self.draw_column((self._draw_image_options, self.draw_process))

    def get_group_value(self):
        """
        Fetch the Preset value.

        Return: dict
            Image Preset
        """
        return self.preset.get_a()

    def on_port_change(self, g, *_):
        """
        Respond to Widget change.

        g: Widget
            Is responsible.
        """
        # ComboBox tool-tips don't stick during
        # initialization, so the tips are made on the go.
        if not isinstance(g, Button):
            d = g.any_group.widget_d
            for _, g1 in d.items():
                if g1.key == ok.NUMERIC_SEQUENCE:
                    g1.widget.set_tooltip_text(Tip.IMAGE_NUMERIC)
                elif g1.key == ok.IMAGE_NAME:
                    g1.widget.set_tooltip_text(Tip.IMAGE_NAME)
        return super(PortImageChoice, self).on_port_change(g)
