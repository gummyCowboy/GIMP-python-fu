#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import BackdropStyle as bs, Issue as vo
from roller_constant_key import (
    BackdropStyle as by, Group as gk, Option as ok
)
from roller_one_extract import get_model_list_group, get_option_list_choice
from roller_fu import hide_layer, show_layer, validate_layer
from roller_view_output import Output
import gimpfu as fu

READY = "Backdrop Image Ready"
WORKING = "Backdrop Image Working"
pdb = fu.pdb


class Work(Output):
    """Create a render."""

    def __init__(self):
        Output.__init__(self)

    def do(self, v, step_q):
        """
        Perform a peek, preview or finish the render.

        v: View
        step_q: list
            of Step
        """
        def _refresh():
            # Remove selection because the marching ants are slow to draw.
            # Flush the display will fail if ignored for too long.
            pdb.gimp_selection_none(v.j)
            pdb.gimp_displays_flush()

        is_start = True

        self.show_view()
        v.plan.hide_view()

        # [(navigation step key: AnyGroup)], 'step_q'
        for k, any_group in step_q:
            if is_start:
                # Rename the BackdropImage layer to show activity.
                if validate_layer(self.backdrop_layer):
                    self.backdrop_layer.name = WORKING
                    is_start = False
                else:
                    self.backdrop_layer = None

            any_group.do(v)

            # Image Gradient with a Show Sample status needs to be redone.
            if any_group.item.key == gk.BACKDROP and v.is_preview:
                style, style_d = get_option_list_choice(
                    any_group.value_d[ok.BACKDROP_STYLE]
                )
                if (
                    style == by.IMAGE_GRADIENT and
                    style_d[ok.PREVIEW_MODE] == bs.SHOW_SAMPLE
                ):
                    any_group.cast_vote(1, ok.SAMPLE_COUNT, vo.MATTER, True)

            _refresh()
            if any_group.item.key in gk.IMAGE_SOURCE_USER:
                v.source_d[k] = deepcopy(v.image_source)

        if validate_layer(self.backdrop_layer):
            self.backdrop_layer.name = READY
            v.j.active_layer = self.backdrop_layer
        _refresh()

    def hide_view(self):
        """Hide the Work group."""
        if validate_layer(self.backdrop_layer):
            hide_layer(self.backdrop_layer.parent)

            model_group = get_model_list_group()
            q = model_group.work.get_model_folder_list()

            for i in q:
                hide_layer(i)
            pdb.gimp_displays_flush()

    def show_view(self):
        """Show the Work group."""
        if (
            validate_layer(self.backdrop_layer) and
            not self.backdrop_layer.parent.visible
        ):
            show_layer(self.backdrop_layer.parent)

            model_group = get_model_list_group()
            q = model_group.work.get_model_folder_list()

            for i in q:
                show_layer(i)
            pdb.gimp_displays_flush()
