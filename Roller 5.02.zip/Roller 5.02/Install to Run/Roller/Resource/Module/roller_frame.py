#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice, randint, seed
from roller_constant_for import Frame as ff
from roller_constant_key import Group as gk, Option as ok
from roller_frame_build import Build, SubBuild
from roller_def import get_default_value
from roller_fu import (
    add_layer_below,
    blur_selection,
    clear_selection,
    clone_layer,
    color_fill_selection,
    color_fill_layer,
    get_select_bounds,
    isolate_selection,
    load_selection,
    merge_layer,
    remove_z,
    select_item,
    select_rect,
    set_saturation,
    verify_layer
)
from roller_maya import (
    check_overlay,
    check_filler,
    check_matter,
    check_metal_filler,
    check_mix_basic,
    check_mix_overlay,
    check_mix_noise,
    check_mix_wrap,
    check_noise,
    check_shadow,
    make_filler_group,
    make_frame_group
)
from roller_maya_blur_behind import BlurBehind
from roller_maya_light import Lamp, Light
from roller_maya_shadow import Shadow
from roller_one_gegl import (
    emboss, edge, median_blur, neon, noise_rgb, waterpixels
)
from roller_one_the import The
from roller_view_real import (
    OVERLAY,
    FILLER,
    LIGHT,
    add_base_layer,
    add_layer,
    add_wip_layer,
    clip_to_wip,
    do_rotated_layer,
    get_light,
    get_noise,
    mask_from_many_layer,
    mask_sel,
    mask_sub_maya
)
from roller_view_shadow import make_shadow
import gimpfu as fu

COLOR_TO_ALPHA = (
    (0, 0, 0),
    (255, 0, 0),
    (0, 255, 0),
    (0, 0, 255),
    (255, 255, 255)
)
MAIN = 'main'
pdb = fu.pdb


def do_filler_frame(v, maya):
    """
    Make an inner and outer metallic frame.

    v: View
    maya: Frame
    Return: layer
        with the frame
    """
    d = maya.value_d[ok.WRW][maya.filler_k]
    e = maya.value_d[ok.WRW][ok.WRAP]
    j = v.j
    group = maya.group
    cause = maya.cause.matter

    # layer for the emboss, 'z'
    z = add_wip_layer(
        v, "Wrap", group, offset=get_light(maya) + get_noise(maya)
    )

    # Grow the selection for each frame part.
    select_item(cause)
    grow_frame(j, e[ok.WIDTH], e[ok.TYPE])

    # inner frame selection, 'sel'
    sel = pdb.gimp_selection_save(j)

    grow_frame(j, d[ok.WIDTH], e[ok.TYPE])

    # inner and filler frame selection, 'sel1'
    sel1 = pdb.gimp_selection_save(j)

    grow_frame(j, e[ok.WIDTH], e[ok.TYPE])

    # inner, filler, and outer selection, 'sel2'
    sel2 = pdb.gimp_selection_save(j)

    load_selection(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

    # outer frame selection, 'sel3'
    sel3 = pdb.gimp_selection_save(j)

    load_selection(j, sel1)
    load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)

    # Cover-up the emboss on the inner and outer frame.
    grow_frame(j, 1., ff.ANGULAR)

    # filler selection
    if maya.filler_sel:
        pdb.gimp_image_remove_channel(v.j, maya.filler_sel)

    maya.filler_sel = pdb.gimp_selection_save(j)

    # Make an inner frame selection.
    load_selection(j, sel)
    select_item(cause, option=fu.CHANNEL_OP_SUBTRACT)
    load_selection(j, sel3, option=fu.CHANNEL_OP_ADD)

    z = soften_metal_sel(v, z, e)

    for i in (sel, sel1, sel2, sel3):
        pdb.gimp_image_remove_channel(j, i)
    return z


def do_ink_noise(v, d, z):
    """
    Make Ink Noise for a frame.

    v: View
    maya: Maya
        frame variety

    d: dict
        Metal Noise Preset

    z: layer
        WIP

    Return: layer
        with noise
    """
    # lowest turbulence, '1.'
    pdb.plug_in_plasma(v.j, z, int(d[ok.SEED] + v.glow_ball.seed), 1.)

    z.opacity = 100.
    name = z.name

    pdb.gimp_drawable_posterize(z, 3)
    neon(z, 1., 1.)
    pdb.plug_in_colortoalpha(v.j, z, (0, 0, 0))

    z1 = clone_layer(z)
    z1.mode = fu.LAYER_MODE_DIFFERENCE

    blur_selection(z, 1.5)

    z = merge_layer(z1)
    z.name = name

    median_blur(z, 3, 50.)
    return z


def do_metal_wrap(v, maya):
    """
    Make a frame around material.

    v: View
    maya: Maya
    Return: layer
        with the frame
    """
    j = v.j
    d = maya.value_d[ok.WRW][ok.WRAP]
    group = maya.group
    cause = maya.cause.matter

    # layer for the emboss, 'z'
    z = add_layer(
        j,
        group.name + " Wrap",
        parent=group,
        offset=get_light(maya) + get_noise(maya)
    )

    select_frame(j, cause, d[ok.WIDTH], d[ok.TYPE])
    return soften_metal_sel(v, z, d)


def do_noise_matter(v, maya):
    """
    Create a metal noise layer.

    v: View
    maya: Maya
    Return: layer
        with noise
    """
    d = maya.value_d
    group = maya.super_maya.group
    z = add_wip_layer(v, "Noise", group, offset=get_light(maya.super_maya))

    pdb.gimp_selection_none(v.j)

    z = {
        ff.INK: do_ink_noise,
        ff.RIFT: do_rift_noise,
        ff.SPECK: do_speck_noise,
        ff.WATER: do_water_noise
    }[d[ok.TYPE]](v, d, z)
    return z


def do_rift_noise(v, d, z):
    """
    Make Rift Noise for a frame.

    v: View
    d: dict
        Metal Noise Preset

    z: layer
        WIP

    Return: layer
        with noise
    """
    j = v.j
    seed_ = int(v.glow_ball.seed + d[ok.SEED])

    seed(seed_)

    # Generate line.
    # The horizontal and vertical sizes are randomized.
    pdb.plug_in_solid_noise(
        j, z,
        0,                      # no tile-able
        1,                      # yes, turbulent
        seed_,
        int(d[ok.NOISE_AMOUNT]),
        float(randint(1, 4)),
        float(randint(1, 4)),
    )

    # Harden the noise.
    # The radius is randomized.
    pdb.plug_in_unsharp_mask(
        j, z,
        choice((1., 4.)),
        54.,                    # amount
        .0                      # threshold
    )

    if d[ok.BLUR]:
        blur_selection(z, d[ok.BLUR])

    pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
    return z


def do_selection_material(v, maya, do_sel, embellish, n, is_clear=True):
    """
    Process the material for a frame.

    v: View
    maya: Maya
    do_sel: function
        Call to process selection.

    embellish: function
        Call to process the material layer.

    n: string
        group key
        layer name appendix

    is_clear: bool
        If True, then the cause layer's alpha
        selection is removed from the output layer.

    Return: layer or None
        with material
    """
    j = v.j
    model = maya.model
    super_ = maya.cause
    cause = super_.matter
    z = add_base_layer(v, maya.group, n=n)

    if super_.vote_type == MAIN:
        cause = super_.matter
        for k in super_.main_q:
            maya.k = k
            sel = model.get_image_sel(k)

            load_selection(j, sel)

            if cause.mask:
                pdb.gimp_image_select_item(
                    j, fu.CHANNEL_OP_INTERSECT, cause.mask
                )
            if not pdb.gimp_selection_is_empty(j):
                z = do_sel(v, maya, z)

    else:
        maya.k = super_.k

        select_item(cause)
        if not pdb.gimp_selection_is_empty(j):
            z = do_sel(v, maya, z)

    if is_clear:
        select_item(cause)
        clear_selection(z)

    z = verify_layer(z)

    if z:
        z = embellish(v, maya, z)
    return z


def do_cause_shadow(v, maya):
    """
    Do the shadow process for the cause material.

    v: View
    maya: Maya
        Frame type

    Return: layer or None
        with shadow
    """
    d = get_default_value(gk.SHADOW_1)
    frame = maya.super_maya
    cause = frame.cause
    group = cause.group.parent

    d.update(maya.value_d)
    return make_shadow(
        v,
        d,
        group,
        (cause.matter,),
        name=group.name + " Shadow",
        is_wrap=True
    )


def do_soft_metal_material(v, maya, make_pattern, n, k):
    """
    Make a metallic frame.

    v: View
    maya: Frame
    n: string
        group key
        Name output layer.

    k: string
        Filler Option key in the 'ok.WRW' row.

    Return: layer or None
        with the Frame
    """
    def _draw(_z):
        """
        Return a layer with pattern.

        _z: layer
            Maya matter layer
        """
        return do_rotated_layer(
            v,
            d[ok.WRW][k],
            make_pattern,
            maya.group,
            len(maya.group.layers) - 1
        )

    d = maya.value_d
    j = v.j
    cause = maya.cause.matter

    # Add a pattern layer to the bottom of the Maya's group layer, 'z'.
    z = add_wip_layer(v, n, maya.group, offset=len(maya.group.layers))
    make_pattern_frame(j, cause, d, _draw, k)
    return soften_metal_sel(v, z, d[ok.WRW][ok.WRAP])


def do_speck_noise(v, d, z):
    """
    Make Speck Noise for a frame.

    v: View
    d: dict
        Metal Noise Preset
        {Option key: value}

    z: layer
        WIP

    Return: layer
        with noise
    """
    j = v.j
    name = z.name
    z1 = clone_layer(z)
    f = (d[ok.SPECK_NOISE] + .5) / 7.

    # red, green, and blue noise, 'noise'
    pdb.plug_in_rgb_noise(
        j, z1,
        1,                  # independent
        0,                  # not correlated
        .0,
        .0,                # green
        .0,                # blue
        f
    )

    color_fill_layer(z, (255, 255, 255))

    z = merge_layer(z1)

    for i in range(4):
        pdb.plug_in_erode(
            j, z,
            1,                # propagate black
            7,                # RGB channels
            1.,               # full rate
            0,                # direction mask
            0,                # lower limit
            12                # upper limit
        )
        pdb.plug_in_rgb_noise(
            j, z,
            1,                # independent
            0,                # not correlated
            f,                # red
            f,                # green
            f,                # blue
            .0
        )

    pdb.plug_in_colortoalpha(v.j, z, (255, 255, 255))
    set_saturation(z, -75.)
    edge(z)
    blur_selection(z, 1.)
    pdb.plug_in_despeckle(
        j, z,
        1,                      # radius
        3,                      # recursive adaptive
        0,                      # white cut-off
        255                     # black cut-off
    )
    pdb.plug_in_unsharp_mask(
        j, z,
        12.,                    # radius
        50.,                    # amount
        .0                      # threshold
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_ALPHA,
        8,                      # coordinate count
        (.0, .0, .25, .0, .62, .62, .9, 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        4,                      # coordinate count
        (.0, .0, 1., .8)
    )

    z.name = name
    return z


def do_water_noise(v, d, z):
    """
    Make WaterPixel Noise for a frame.

    v: View
    d: dict
        Metal Noise Preset

    z: layer
        WIP

    Return: layer
        with noise
    """
    a = int(d[ok.SEED] + v.glow_ball.seed)

    for i in range(3):
        noise_rgb(z, 1., 1., 1., 1., a + i)

    waterpixels(z)
    pdb.gimp_brightness_contrast(z, 0, 75)

    for i in COLOR_TO_ALPHA:
        pdb.plug_in_colortoalpha(v.j, z, i)
    return z


def grow_frame(j, w, n):
    """
    Expand a frame selection depending on the Frame Type.

    j: GIMP image
        with selection

    w: float
        expansion amount

    n: string
        Frame Type
    """
    def _angular():
        pdb.gimp_context_set_antialias(0)
        for _ in range(int(w)):
            pdb.gimp_selection_grow(j, 1)

    def _rectangle():
        _is_sel, _x, _y, _x1, _y1 = get_select_bounds(j)
        if _is_sel:
            _x -= w
            _y -= w
            _w = _x1 + w - _x
            _h = _y1 + w - _y
            select_rect(j, _x, _y, _w, _h)

    def _rounded():
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_selection_grow(j, int(w))

    {ff.ANGULAR: _angular, ff.RECTANGLE: _rectangle, ff.ROUNDED: _rounded}[n]()


def make_canvas_frame_sel(v, d):
    """
    Make a selection border around the Canvas.

    v: View
    d: dict
        a Frame-subtype Preset

    Return: GIMP selection or None, state of selection
        Canvas border
    """
    w = d[ok.CFW]
    if w:
        j = v.j
        a = v.wip

        select_rect(j, *a.rect)
        select_rect(
            j,
            a.x + w, a.y + w,
            a.w - w - w, a.h - w - w,
            option=fu.CHANNEL_OP_SUBTRACT
        )
        return pdb.gimp_selection_save(j)


def make_pattern_frame(j, z, d, p, k):
    """
    Make a selection for frame material.

    j: GIMP image
        from View

    z: layer
        Maya matter

    d: dict
        Frame Preset

    p: function
        Call to make pattern.

    k: string
        Filler Option key in the 'ok.WRW' row.

    Return: state of selection
    """
    e = d[ok.WRW][ok.WRAP]
    d = d[ok.WRW][k]

    select_item(z)
    grow_frame(j, e[ok.WIDTH], e[ok.TYPE])

    sel = pdb.gimp_selection_save(j)

    grow_frame(j, d[ok.WIDTH], e[ok.TYPE])

    sel1 = pdb.gimp_selection_save(j)

    grow_frame(j, e[ok.WIDTH], e[ok.TYPE])

    sel2 = pdb.gimp_selection_save(j)

    load_selection(j, sel1, option=fu.CHANNEL_OP_SUBTRACT)

    # outer selection, 'sel3'
    sel3 = pdb.gimp_selection_save(j)

    z1 = p(z)

    load_selection(j, sel1)
    load_selection(j, sel, option=fu.CHANNEL_OP_SUBTRACT)
    select_item(z1, option=fu.CHANNEL_OP_INTERSECT)
    remove_z(z1)

    # filler selection, 'sel4'
    sel4 = pdb.gimp_selection_save(j)

    # Make an inner frame selection.
    load_selection(j, sel)
    select_item(z, option=fu.CHANNEL_OP_SUBTRACT)

    # Combine selections.
    load_selection(j, sel3, option=fu.CHANNEL_OP_ADD)
    load_selection(j, sel4, option=fu.CHANNEL_OP_ADD)
    for i in (sel, sel1, sel2, sel3, sel4):
        pdb.gimp_image_remove_channel(j, i)


def mask_filler_layer(j, filler, sel):
    """
    Mask a filler group from a selection created by a frame.

    j: GIMP image
        View output

    filler: Filler
        Has filler and group layer.

    sel: GIMP selection
        to apply to layer
    """
    if sel:
        load_selection(j, sel)
        mask_sel(filler.matter)


def select_frame(j, z, w, n, is_cut=True):
    """
    Make a frame selection around a layer's alpha.

    j: GIMP image
        with selection

    z: layer
        Is the material that the frame surrounds.

    w: float
        expansion amount

    n: string
        Frame Type

    is_cut: bool
        If True, then the cause layer's selection
        is removed from the frame selection.
    """
    f = z.opacity
    z.opacity = 100.

    select_item(z)
    grow_frame(j, w, n)

    if is_cut:
        select_item(z, option=fu.CHANNEL_OP_SUBTRACT)
    z.opacity = f


def soften_metal_sel(v, z, d):
    """
    Fill the selection with grey color and emboss it.

    v: View
    z: layer
        to fill
        WIP

    d: dict
        Metal Frame Preset

    Return: layer
        with material
    """
    j = v.j

    if d[ok.EMBOSS]:
        n = z.name
        sel = pdb.gimp_selection_save(j)

        color_fill_selection(z, (190, 190, 190))
        pdb.gimp_selection_none(j)

        z1 = add_layer_below(z)

        color_fill_layer(z1, (65, 65, 65))

        z = merge_layer(z)
        z.name = n

        blur_selection(z, d[ok.DEPTH])
        emboss(z, v.glow_ball.azimuth, v.glow_ball.elevation, int(d[ok.DEPTH]))

        # brightness, '0'
        if d[ok.CONTRAST]:
            pdb.gimp_brightness_contrast(z, 0, int(d[ok.CONTRAST]))

        blur_selection(z, d[ok.SOFTEN])
        isolate_selection(z, sel)
        pdb.gimp_image_remove_channel(j, sel)
        clip_to_wip(v, z)

    else:
        color_fill_selection(z, d[ok.COLOR_1])
    return z


class Overlay(SubBuild):
    """
    Process change for an overlay layer.
    Change its blend with its super Maya mask.
    """
    issue_q = 'overlay', 'mode', 'opacity'
    put = (check_overlay, 'matter'), (check_mix_overlay, None)

    def __init__(self, *q):
        """
        v: View
        super_maya: Maya
            Is the enclosing Maya.

        do_color: function
            Call to make a color layer.
        """
        SubBuild.__init__(self, *q)

    def do(self, v, d, is_change, is_mask):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            If it is True, then a mask is drawn on the Color layer.

        is_mask: bool
            Is True if the frame Maya has change.
        """
        self.value_d = d
        self.go = bool(self.super_maya.matter)
        self.is_overlay += is_change

        self.realize(v)

        if self.go and (self.is_overlay or is_mask):
            mask_sub_maya(self.super_maya.matter, self.matter)
        self.reset_issue()


class Filler(SubBuild):
    """Process change for a filler output."""
    issue_q = 'filler', 'mode', 'opacity', 'shade'
    put = (
        (make_filler_group, 'group'),
        (check_filler, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(
        self, any_group, super_maya, k_path, do_filler, is_lucid=False
    ):
        """
        super_maya: Maya
            Frame type

        do_filler: function
            Call to make a filler layer.

        k_path: tuple
            (Option key, ...)
            Are path key to its vote dict.

        is_lucid: bool
            If True, then Blur Behind is incorporated.
        """
        # Isn't an issue, 'matter', but is referenced by Shadow.
        self.is_matter = False

        SubBuild.__init__(self, any_group, super_maya, k_path, do_filler)
        self.sub_maya[LIGHT] = Light(
            any_group, self, [ok.OTHER, ok.TRANSLUCENT][is_lucid]
        )

    def do(self, v, d, is_change, is_mask):
        """
        Produce GIMP layer output. Has a filler
        layer and a Gradient Light layer.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is True if the cause Maya has change.

        is_mask: bool
            Is True if the super Maya has change.
        """
        self.value_d = d
        self.is_filler |= is_change

        # an external access adaptation
        self.is_matter = self.is_filler

        self.realize(v)

        if self.is_matter or is_mask:
            mask_filler_layer(v.j, self, self.super_maya.filler_sel)

        self.sub_maya[LIGHT].do(v, self.is_filler)
        self.reset_issue()


class MetalFillerCanvas(SubBuild):
    """Process change for canvas filler output."""
    # Wrap cast the 'emboss' vote.
    issue_q = 'filler', 'emboss', 'mode', 'opacity', 'shade'
    put = (
        (check_metal_filler, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path, do_filler, filler_path):
        """
        super_maya: Maya
            Frame type

        k_path: tuple
            (Option key, ...)
            path to this sub-Frame option

        do_filler: function
            Call to make a filler layer.

        filler_path: tuple
            (Option key, ...)
            Append to 'k_path' to create path to Filler option.
        """
        # Isn't an issue, 'matter', but is referenced by external Maya.
        self.is_matter = False

        SubBuild.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + filler_path,
                k_path + (ok.WRW, ok.WRAP)
            ],
            do_filler
        )

    def do(self, v, d, is_change):
        """
        Produce GIMP layer output. Has a filler
        layer and a Gradient Light layer.

        v: View
        d: dict
            sub-Frame Preset
        """
        self.value_d = d
        self.is_filler |= is_change

        # for shadow output
        self.is_matter = self.is_filler or self.is_emboss

        self.realize(v)
        self.reset_issue()


class Lucid(Build):
    """
    Is a translucent frame. Require 'wrap_k' attribute in the
    sub-class which is the Option key of the Wrap Button.
    """
    issue_q = 'matter', 'mode', 'opacity', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )

    def __init__(self, any_group, super_maya, k_path, do_matter, do_color, k):
        """
        any_group: AnyGroup
            owner option group

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)

        do_matter: function
            Call to make the matter layer.

        do_color: function
            Call to make the color layer.

        k: string
            Is the row's Overlay Button key.
        """
        self.overlay_k = k

        Build.__init__(
            self,
            any_group,
            super_maya,
            k_path + (ok.WRW, self.wrap_k),
            do_matter
        )

        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self.cause, self)
        )
        self.sub_maya[OVERLAY] = Overlay(any_group, self, k_path + (ok.WRW, k), do_color)
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(
            any_group, self, k_path, ok.SRW
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.TRANSLUCENT)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame-type Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        is_back = v.is_back
        self.is_matter |= is_change

        self.realize(v)

        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], self.is_matter, is_change
        )

        self.sub_maya[OVERLAY].do(
            v, d[ok.WRW][self.overlay_k], is_change, self.is_matter
        )
        self.sub_maya[ok.BLUR_BEHIND].do(
            v, d[ok.SRW][ok.BLUR_BEHIND], m or is_back, self.is_matter
        )
        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m


class MaskGroup(Build):
    """Create a group having a mask and parenting the cast layer."""
    issue_q = 'matter',
    put = (check_matter, 'matter'),

    def __init__(self, *q):
        Build.__init__(self, *q)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame type Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: False
            The background did not change.
        """
        self.value_d = d
        self.is_matter |= is_change
        self.realize_vote(v)
        return False


class Metal(Build):
    """Is a metallic-like frame."""
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path, do_matter, k):
        """
        any_group: AnyGroup
            owner option group

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Is the Key path of the Frame Button in its vote dict.

        do_matter: function
            Call to make the matter layer.

        k: string
            Filler Option key
        """
        q1 = [k_path + (ok.WRW, ok.WRAP), k_path + (ok.WRW, k)]

        Build.__init__(self, any_group, super_maya, q1, do_matter)

        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, k_path + (ok.SRW, ok.NOISE_D)
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self.cause, self)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.METAL)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[ok.NOISE_D].do(
            v, d[ok.SRW][ok.NOISE_D], is_change, self.is_matter
        )

        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], self.is_matter, is_change
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m


class MetalCanvas(Build):
    """Create a metal frame with a filler insert."""
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP

    def __init__(
        self, any_group, super_maya, k_path, do_filler, filler_path
    ):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)

        do_filler: function
            Call to make filler material

        k: string
            Wrap row key
        """
        self.filler_sel = None

        Build.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.WRW, ok.WRAP)],
            do_metal_wrap
        )

        self.sub_maya[FILLER] = MetalFillerCanvas(
            any_group, self, k_path, do_filler, filler_path
        )
        self.sub_maya[ok.NOISE_D] = Noisy(
            any_group,
            self,
            k_path + (ok.SRW, ok.NOISE_D),
            (self, self.sub_maya[FILLER])
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group,
            self,
            k_path + (ok.SRW, ok.SHADOW),
            (self.cause, self, self.sub_maya[FILLER]),
        )
        self.sub_maya[LIGHT] = Lamp(
            any_group, self, ok.METAL, (self.sub_maya[FILLER],)
        )

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change
        filler = self.sub_maya[FILLER]

        self.realize(v)
        filler.do(v, d, is_change)
        self.sub_maya[ok.NOISE_D].do(
            v,
            d[ok.SRW][ok.NOISE_D],
            is_change,
            self.is_matter or filler.is_matter
        )

        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], self.is_matter, is_change
        )

        self.sub_maya[LIGHT].do(v, self.is_matter or filler.is_matter)
        self.reset_issue()
        return m


class MetalAltFiller(Build):
    """Create a metal frame with a filler insert."""
    is_embossed = True
    issue_q = 'matter', 'mode', 'opacity', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path, do_filler, k):
        """
        any_group: AnyGroup
            owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Is the key path of the Frame Button in its vote dict.
            (Option key, ...)

        do_filler: function
            Call to make filler material

        k: string
            Is the Option key to the Filler dict found in the 'ok.WRW' row.
        """
        self.filler_sel = None
        self.filler_k = k

        Build.__init__(
            self,
            any_group,
            super_maya,
            [k_path, k_path + (ok.WRW, ok.WRAP), k_path + (ok.WRW, k)],
            do_filler_frame
        )

        self.sub_maya[ok.NOISE_D] = Noise(
            any_group, self, k_path + (ok.SRW, ok.NOISE_D)
        )
        self.sub_maya[FILLER] = Filler(
            any_group, self, k_path + (ok.WRW, k), do_filler
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group,
            self,
            k_path + (ok.SRW, ok.SHADOW),
            (self.cause, self, self.sub_maya[FILLER])
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.METAL)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[FILLER].do(
            v, d[ok.WRW][self.filler_k], is_change, self.is_matter
        )
        self.sub_maya[ok.NOISE_D].do(
            v, d[ok.SRW][ok.NOISE_D], is_change, self.is_matter
        )

        # background changed flag, 'm'
        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], self.is_matter, is_change
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.reset_issue()
        return m

    def reset(self):
        """Call when the View image is removed."""
        if self.filler_sel:
            pdb.gimp_image_remove_channel(The.view.j, self.filler_sel)
            self.filler_sel = None
        super(MetalAltFiller, self).reset()


class Chaos(SubBuild):
    """Process change for a Noise Metal Preset."""
    issue_q = 'noise', 'mode', 'opacity'
    is_seeded = True
    put = (check_noise, 'matter'), (check_mix_noise, None)

    def __init__(self, any_group, super_maya, k_path):
        """
        super_maya: Maya
            Has the Noise option.
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, do_noise_matter)

    def do(self, v, d, is_change, is_mask):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Noise Preset
            {Option key: value}

        is_change: bool
            Is True if the cause Maya has change.

        is_mask: bool
            Is True if the super Maya has change.
        """
        self.value_d = d
        self.go = d[ok.SWITCH] and bool(self.super_maya.matter)

        self.realize(v)

        if self.go and (self.is_noise or is_change or is_mask):
            self.mask_layer()
        self.reset_issue()


class Noise(Chaos):
    """Process change for a Noise Metal Preset."""

    def __init__(self, *q):
        """
        super_maya: Maya
            Has the Noise option.
        """
        Chaos.__init__(self, *q)

    def mask_layer(self):
        mask_sub_maya(self.super_maya.matter, self.matter)


class Noisy(Chaos):
    """Process change for a Noise Preset having multiple mask source."""

    def __init__(self, any_group, super_maya, k_path, mask_maya):
        """
        super_maya: Maya
            Has the Noise option.

        mask_maya: iterable
            [Maya, ...]
            Each Maya's 'matter' layer is used as part of the total Noise mask.
        """
        self.mask_maya = mask_maya
        Chaos.__init__(self, any_group, super_maya, k_path)

    def mask_layer(self):
        mask_from_many_layer(
            [i.matter for i in self.mask_maya], self.matter
        )


class ShadowBasic(SubBuild):
    """Process change for a shadow layer."""
    issue_q = 'shadow',
    put = (check_shadow, 'shadow'),

    def __init__(self, any_group, super_maya, k_path):
        """
        v: View
        super_maya: Maya
            Is the enclosing Maya.
        """
        SubBuild.__init__(self, any_group, super_maya, k_path, do_cause_shadow)

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame-type Preset

        Return: bool
            Is True when the Shadow has change.
        """
        is_back = v.is_back
        self.value_d = d
        self.is_shadow |= is_change
        self.realize_vote(v)
        return is_back != v.is_back
