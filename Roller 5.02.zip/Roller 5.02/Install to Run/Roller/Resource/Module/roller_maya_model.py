#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_constant_key import Option as ok, Step as sk
from roller_maya import MAIN, Maya
from roller_fu import get_layer_position, make_layer_group, remove_z
from roller_one import seal
from roller_one_the import The
from roller_option_group import ManyGroup
import gimpfu as fu

pdb = fu.pdb


def get_model_name_list():
    return The.helm.get_group(
        sk.MODEL
    ).widget_d[ok.MODEL_LIST].get_active_model_name_q()[::-1]


class Model(ManyGroup):
    """Assign a View processor and connect responsible signal handler."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)


class Chi(Maya):
    """From from Plan and Work."""
    issue_q = 'matter',
    vote_type = MAIN

    def __init__(self, any_group, view_x, prefix):
        """
        any_group: AnyGroup
            Has the Model options.

        view_x: int
            0 or 1; Plan or Work index

        prefix: string
            for Model layer group name
        """
        # Connect Model id with Model layer group, 'model_id_d'.
        # key, value -> {Model id: {'group': layer, 'name': Model name}}
        self.model_d = {}

        self._prefix = prefix

        Maya.__init__(self, any_group, view_x, ())
        self.set_issue()
        The.cat.render.connect(si.CLOSE_VIEW_IMAGE, self.on_close_view_image)
        for i in (
            (si.MODEL_CREATED, self.on_model_created),
            (si.MODEL_MOVE, self.on_active_model_change),
            (si.MODEL_RENAME, self.on_model_rename)
        ):
            The.power.connect(*i)

    def check(self, v, plan_offset, group):
        """
        Create Model layer group for a Model.

        v: VIew
        plan_offset: int
            layer offset for layer group insertion

        group: layer group
        """
        is_move = False
        sk.MODEL
        name_q = get_model_name_list()

        for i, d in self.model_d.items():
            if not d['group']:
                is_move = True
                n = d['name']
                if n in name_q:
                    n = self._prefix + n
                    d['group'] = make_layer_group(
                        v.j, n, offset=plan_offset, parent=group
                    )

        if is_move:
            self.on_active_model_change()
        self.reset_issue()

    def do(self, v):
        """
        Manage layer output during a View run.

        v: View
        """
        if self.is_matter:
            if self.view_x:
                # Work
                offset = v.plan.get_offset()
                group = None

            else:
                # Plan
                offset = 0
                group = v.plan.plan_group
            self.check(v, offset, group)

    def get_group(self, id_):
        """
        Get a Model's layer group by its Model id.

        id_: int
            Model id as used in a navigation step

        x: int
            0 or 1; Plan or Work index

        Return: layer group or None
            a Model group
        """
        d = self.model_d
        if id_ in d:
            return d[id_]['group']

    def on_model_created(self, _, model):
        """
        Record a Model that has been created.

        _: Power
            Sent the Signal.

        model: Model
            newly created
        """
        a = The.model_id
        i = model.model_id
        self.model_d[i] = {'group': None, 'name': a.get_name(i)}
        self.is_matter = True
        model.baby.connect(si.MODEL_DIE, self.on_model_die)

    def on_model_die(self, _, model):
        """
        A Model is gone. Remove any traces of it.

        model: Model
        """
        i = model.model_id

        remove_z(self.model_d[i]['group'])
        self.model_d.pop(i)

    def update_model_group(self, plan_offset):
        """
        Sync the order of Model folder with the navigation tree.
        The Model folder order is an inverted navigation tree order.

        plan_offset: int
            Is 0 or 1.
            Is one if the Plan layer group has been created.
        """
        # Reverse the order of the list, '[::-1]'.
        name_q = get_model_name_list()

        for i, d in self.model_d.items():
            n = d['name']
            if n in name_q:
                group = d['group']
                if group:
                    j = The.view.j
                    a = get_layer_position(group)

                    if group.parent:
                        z = group.parent
                        b = name_q.index(n)
                        b = seal(b, 0, len(z.layers) - 1)

                    else:
                        z = j
                        b = name_q.index(n) + plan_offset

                        # Keep the group above the Backdrop layer, '2'.
                        b = seal(b, 0, len(z.layers) - 2)

                    b = seal(b, 0, len(z.layers) - 1)
                    if a != b:
                        pdb.gimp_image_reorder_item(j, group, group.parent, b)
        pdb.gimp_displays_flush()

    def on_close_view_image(self, _, arg):
        """
        If the render image closes, any Model layer groups disappear.

        _: ViewImage
            Sent the Signal

        arg: GIMP image
            that was closed
        """
        for i, d in self.model_d.items():
            d['group'] = None

    def on_model_rename(self, _, arg):
        """
        Rename a Model's layers.

        _: Power
            Sent the Signal.

        arg: tuple
            (old name, new name)
        """
        def _rename(_z, _n, _x):
            """
            Recursively rename sub-Model layer.

            _z: group layer or GIMP image
            _n: string
                name prefix

            _x: int
                offset of layer name to replace
            """
            for _z1 in _z.layers:
                _z1.name = self._prefix + _n + _z1.name[_x:]
                if hasattr(_z1, 'layers'):
                    _rename(_z1, _n, _x)

        old_name, new_name = arg

        # Rename the layer output.
        for i, d in self.model_d.items():
            if d['name'] == old_name:
                z = d['group']

                if z:
                    # old layer name cut-off index, 'x'
                    x = len(old_name) + len(self._prefix)
                    z.name = self._prefix + new_name + z.name[x:]
                    _rename(z, new_name, x)

                d['name'] = new_name
                break

    def reset(self):
        """Reset on View image change."""
        self.model_d = {}
        super(Chi, self).reset()


class Plan(Chi):
    """Manage Model group layer for Plan."""

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0, "Plan ")

    def on_active_model_change(self, *_):
        """
        Respond to a change of a Model's
        layer group position in the layer dock.
        """
        self.update_model_group(0)


class Work(Chi):
    """Manage Model group layer for Work."""

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            Use to acquire the ModelList Widget.
        """
        self._model_list = any_group.widget_d[ok.MODEL_LIST]
        Chi.__init__(self, any_group, 1, "")

    def get_model_folder_list(self):
        """
        Collect a list of layer group used by a Model for output.

        Return: list
            of Model owned layer group
        """
        return [a['group'] for i, a in self.model_d.items() if a['group']]

    def on_active_model_change(self, *_):
        """
        Respond to a change of a Model's
        layer group position in the layer dock.
        """
        self.update_model_group(The.view.plan.get_offset())
