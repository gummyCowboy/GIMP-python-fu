#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_maya import NO_VOTE, Maya
from roller_preset_lookup import FRAME_D, BACKDROP_STYLE_D
from roller_one_extract import get_option_list_choice

# Is a generic key to a Frame sub-type. Identify current Maya.
LINK = 'link'


class OptionList(Maya):
    """
    The Backdrop Style and the Frame Button use
    an OptionList to manage their sub-types.
    """
    issue_q = 'switch',

    def __init__(self, any_group, super_maya, path_prefix, lookup_d):
        """
        any_group: AnyGroup
        super_maya: Maya
        path_prefix: tuple
            (Option key, ...)
            Are keys to a sub-vote dict in the super Maya's vote dict.
        lookup_d:
            {Backdrop Style key or Frame key: its output producing class}
        """
        self._maya_type = None
        self._handle_d = {}
        self.super_maya = super_maya
        self.vote_type = super_maya.vote_type
        self._lookup_d = lookup_d
        self._path_prefix = path_prefix

        Maya.__init__(self, any_group, 1, (), k_path=NO_VOTE)
        self.is_frame = lookup_d == FRAME_D

    def do(self, v, value_d, is_change):
        """
        Manage layer output.

        v: View
        value_d: dict
            Frame Preset

        is_change: bool
            Is the state of change of the super Maya's matter and mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        def _die():
            """
            Return: bool
                Is True if the OptionList Maya died.
            """
            _is_back = False
            if LINK in self.sub_maya:
                self.sub_maya[LINK].die(v)
                self.sub_maya.pop(LINK)
                _is_back = True
            self._maya_type = None
            return _is_back

        # Preset key, 'k'; Preset value dict, 'd'
        # The Preset is either sub-Backdrop Style or sub-Frame.
        k, d = get_option_list_choice(value_d)

        maya_type = self._lookup_d[k] if k in self._lookup_d else None
        is_back = False

        if LINK in self.sub_maya and maya_type != self._maya_type:
            # The Maya type changed. Remove the old output.
            is_back = _die()

        if maya_type:
            self.go = value_d[ok.SWITCH]

            if self.is_frame:
                self.go &= bool(self.super_maya.matter)

            if self.go:
                if LINK not in self.sub_maya:
                    self.sub_maya[LINK] = maya_type(
                        self.any_group, self, self._path_prefix
                    )
                is_back = self.sub_maya[LINK].do(v, d, is_change)
            else:
                is_back = _die()

        self._maya_type = maya_type
        return is_back


class Frame(OptionList):
    """Is used process change for a Frame Preset."""

    def __init__(self, *arg):
        """
        arg: tuple
            OptionList spec
        """
        OptionList.__init__(self, *arg + (FRAME_D,))


class BackdropStyle(OptionList):
    """Is used process change for tye Backdrop Style Preset."""

    def __init__(self, *arg):
        """
        arg: tuple
            OptionList spec
        """
        OptionList.__init__(self, *arg + (BACKDROP_STYLE_D,))
