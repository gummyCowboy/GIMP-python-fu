#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok, Step as sk
from roller_frame_build import SubBuild
from roller_maya import check_layer
from roller_view_shadow import make_inner_shadow, make_shadow
from roller_view_real import INNER, SHADOW1, SHADOW2
import gimpfu as fu

pdb = fu.pdb


def check_inner_shadow(v, maya):
    """
    Produce Inner Shadow material.

    v: View
    maya: Maya
    Return: tuple
        of shadow layer
    """
    if maya.is_inner_shadow:
        return check_layer(v, maya, 'inner_shadow', do_inner_shadow)
    return maya.inner_shadow


def check_shadow_1(v, maya):
    """
    Produce Shadow 1 material.

    v: View
    maya: Maya
    Return: tuple
        of shadow layer
    """
    if maya.is_shadow_1:
        return check_layer(v, maya, 'shadow_1', do_shadow_1)
    return maya.shadow_1


def check_shadow_2(v, maya):
    """
    Produce Shadow 2 material.

    v: View
    maya: Maya
    Return: tuple
        of shadow layer
    """
    if maya.is_shadow_2:
        return check_layer(v, maya, 'shadow_2', do_shadow_2)
    return maya.shadow_2


def do_shadow_1(v, maya):
    """
    Create a Shadow 1 layer.

    v: View
    maya: Shadow
    Return: layer or None
        with shadow
    """
    return do_shadow_num(v, maya, "1")


def do_shadow_2(v, maya):
    """
    Create a Shadow 2 layer.

    v: View
    maya: Shadow
    Return: layer or None
        with shadow
    """
    return do_shadow_num(v, maya, "2")


def do_shadow_num(v, maya, n):
    """
    Create a numbered Shadow layer. The shadow is
    an external shadow and not an internal one.

    v: View
    maya: Shadow
    n: string
        Shadow number
        1 or 2

    Return: layer or None
        with shadow
    """
    # list of layer to cast shadow, 'q'
    q = []

    for i in maya.maya_q:
        q += [getattr(i, 'matter')]

    z = q[0].parent.parent if maya.is_wrap else q[0].parent
    return make_shadow(
        v,
        maya.value_d,
        z,
        q,
        is_wrap=maya.is_wrap,
        name=z.name + " Shadow " + n
    )


def do_inner_shadow(v, maya):
    """
    Create an Inner Shadow layer.

    v: View
    maya: Shadow
    cast: layer
        to cast shadow

    Return: layer or None
        with shadow
    """
    z = maya.maya_q[0].matter
    return make_inner_shadow(
        v, maya.value_d, z, name=z.parent.name + " Inner Shadow"
    )


class Shadow1(SubBuild):
    """
    Manage Shadow 1 layer output. Shadow 1 can process multiple caster layer,
    and in the layer dock, its shadow output is below any caster layer.
    """
    issue_q = 'shadow_1',
    put = (check_shadow_1, 'shadow_1'),

    def __init__(self, any_group, super_maya, maya_q, k_path, is_wrap):
        """
        any_group: AnyGroup
            origin of option

        super_maya: Maya
            Is the super Shadow.

        maya_q: iterable
            of Maya, ...

            The Shadow-caller, a Maya, is expected to have a
            matter layer and a 'is_matter' attribute. The
            entire iterable is treated as a unified group where
            each of matter layer is merged into a single caster layer.

        is_wrap: bool
            If True, then an the Shadow 1 layer is placed
            at the bottom of the wrapping parent layer group.
        """
        self.maya_q = maya_q
        self.is_wrap = is_wrap
        SubBuild.__init__(
            self, any_group, super_maya, k_path + (sk.SHADOW_1,), None
        )

    def do(self, v, d, is_outer):
        """
        Manage layer output during a View run.

        v: View
        d: dict
            Shadow Preset
            {Option key: Widget value}

        is_outer: bool
            Is True if the shadow caster group has change.

        Return: bool
            Is True if there is background change.
        """
        self.value_d = d[sk.SHADOW_1]
        self.is_shadow_1 |= self.super_maya.is_shadow or is_outer

        if not self.is_shadow_1:
            for i in self.maya_q:
                if i.is_matter or i.is_shade:
                    self.is_shadow_1 = True
                    break

        is_back = self.is_shadow_1

        self.realize(v)
        self.reset_issue()
        return is_back


class Shadow2(SubBuild):
    """
    Produces in the same way as Shadow 1, but has different key attribute.
    """
    issue_q = 'shadow_2',
    put = (check_shadow_2, 'shadow_2'),

    def __init__(self, any_group, super_maya, maya_q, k_path, is_wrap):
        """
        any_group: AnyGroup
            Is where this option originates.

        super_maya: Maya
            Is the super Shadow.

        maya_q: iterable
            of Maya, ...

            The Shadow-caller, a Maya, is expected to have a
            matter layer and a 'is_matter' attribute. The
            entire iterable is treated as a unified group where
            each of matter layer is merged into a single caster layer.

        is_wrap: bool
            If True, then the Shadow 2 layer is placed
            at the bottom of the wrapping parent group.
        """
        self.maya_q = maya_q
        self.is_wrap = is_wrap
        SubBuild.__init__(
            self, any_group, super_maya, k_path + (sk.SHADOW_2,), None
        )

    def do(self, v, d, is_outer):
        """
        Manage layer output during a View run.

        v: View
        d: dict
            Shadow Preset

        is_outer: bool
            Is True if the shadow caster group has change.

        Return: bool
            Is True if the background changed.
        """
        self.value_d = d[sk.SHADOW_2]
        self.is_shadow_2 |= self.super_maya.is_shadow or is_outer

        if not self.is_shadow_2:
            for i in self.maya_q:
                if i.is_matter or i.is_shade:
                    self.is_shadow_2 = True
                    break

        is_back = self.is_shadow_2

        self.realize(v)
        self.reset_issue()
        return is_back


class Inner(SubBuild):
    """
    Manage Inner Shadow layer output. Inner Shadow processes one caster layer,
    and in the layer dock, its shadow output lies above the caster layer.
    """
    issue_q = 'inner_shadow',
    put = (check_inner_shadow, 'inner_shadow'),

    def __init__(self, any_group, super_maya, maya_q, k_path):
        """
        any_group: AnyGroup
            Is where this option originates.

        super_maya: Maya
            Is the super Shadow.

        maya_q: iterable
            of Maya, ...

            The Shadow-caller, a Maya, is expected to have a
            matter layer and a 'is_matter' attribute. The first
            Maya's matter layer is the Inner Shadow caster layer.

        k_path: tuple
            Is a key path to the Shadow option in the vote dict.
        """
        # Use to flag Inner Shadow's change
        # state after calling the 'do' function, 'had_change'.
        self.had_change = False

        self.maya_q = maya_q
        SubBuild.__init__(
            self, any_group, super_maya, k_path + (sk.INNER_SHADOW,), None
        )

    def do(self, v, d, is_inner):
        """
        Manage layer output during a View run.

        v: View
        d: dict
            Shadow Preset

        is_inner: bool
            Is True if the shadow caster has change.

        Return: bool
            Is True if there is matter change.
        """
        self.value_d = d[sk.INNER_SHADOW]
        self.is_inner_shadow |= self.super_maya.is_shadow or is_inner
        self.had_change = self.is_inner_shadow
        self.realize_vote(v)


class Shadow(SubBuild):
    """Manage layer output for a Shadow Preset Button."""
    issue_q = 'shadow',
    put = ()

    def __init__(
        self,
        any_group,
        super_maya,
        k_path,
        maya_q,
        is_wrap=True,
        has_inner=True
    ):
        """
        super_maya: Maya
            Has a Shadow option.

        k_path: tuple
            Is a key path to the Shadow option in the vote dict.

        maya_q: iterable
            of Maya, ...

            A Shadow-caller, a Maya, is expected to have
            a matter layer and a 'is_matter' attribute.

        is_wrap: bool
            If True, then Shadow 1 and Shadow 2 layer output
            is placed at the bottom of the wrapping parent group.

        has_inner: bool
            If False, then bypass the inner shadow option.
        """
        self.maya_q = maya_q
        self.has_inner = has_inner

        SubBuild.__init__(
            self, any_group, super_maya, k_path + (sk.SHADOW_SWITCH,), None
        )

        self.sub_maya[SHADOW1] = Shadow1(
            any_group, self, maya_q, k_path, is_wrap
        )
        self.sub_maya[SHADOW2] = Shadow2(
            any_group, self, maya_q, k_path, is_wrap
        )
        self.sub_maya[INNER] = Inner(any_group, self, maya_q, k_path)

    def do(self, v, d, is_outer, is_inner):
        """
        Manage layer output during a View run.

        v: View
        d: dict
            Shadow Preset

        is_outer: bool
            Is True if the shadow caster group has change.

        is_inner: bool
            Is True if the shadow caster has change.

        Return: bool
            If True, then the background has changed.
        """
        self.value_d = d
        self.go = d[sk.SHADOW_SWITCH][ok.SWITCH]
        is_back = False

        pdb.gimp_image_freeze_layers(v.j)

        if self.go:
            is_back |= self.sub_maya[SHADOW1].do(v, d, is_outer)
            is_back |= self.sub_maya[SHADOW2].do(v, d, is_outer)
            if self.has_inner:
                self.sub_maya[INNER].do(v, d, is_inner)
        else:
            if self.has_inner:
                is_back = any((
                    self.sub_maya[SHADOW1].shadow_1,
                    self.sub_maya[SHADOW2].shadow_2,
                    self.sub_maya[INNER].inner_shadow,
                ))

            else:
                is_back = any((
                    self.sub_maya[SHADOW1].shadow_1,
                    self.sub_maya[SHADOW2].shadow_2
                ))

            # Future developer, why call this here?
            self.die(v)

        self.reset_issue()
        pdb.gimp_image_thaw_layers(v.j)
        return is_back

    def get_any_vote(self):
        """
        Determine the status of Shadow vote.

        Return: bool
            Is True if there is change.
        """
        return any((
            self.is_shadow,
            self.sub_maya[SHADOW1].is_shadow_1,
            self.sub_maya[SHADOW2].is_shadow_2,
            self.sub_maya[INNER].is_inner_shadow
        ))

    def reset_all_issue(self):
        """Call to reset issue when the 'do' function isn't used."""
        self.reset_issue()
        self.sub_maya[SHADOW1].reset_issue()
        self.sub_maya[SHADOW2].reset_issue()
        self.sub_maya[INNER].reset_issue()
