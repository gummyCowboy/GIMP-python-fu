#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_constant_key import Node as ny, Option as ok
from roller_maya import MAIN, PER, Run
from roller_one_the import The
from roller_option_group import ModelGroup
from roller_view_step import find_canvas_margin, find_cell_margin


class Shift(ModelGroup):
    """
    Create Widget group. Assign View processor
    for the step and connect signal handler.
    """

    def __init__(self, **d):
        ModelGroup.__init__(self, **d)

        self._is_cell = False
        node_k = self.nav_k[-2]
        self.plan = {ny.CANVAS: PlanCanvas, ny.CELL: PlanCell}[node_k](self)
        self.work = {ny.CANVAS: WorkCanvas, ny.CELL: WorkCell}[node_k](self)
        baby = self.item.model.baby

        if node_k == ny.CELL:
            self._is_cell = True
            self._sequence_signal = si.CELL_SHIFT_CHANGE
            self.handle_d[
                baby.connect(si.CELL_RECT_CALC, self.on_cell_calc)
            ] = baby
            self.handle_d[
                self.widget_d[ok.PER].connect(
                    si.PER_CHANGE, self.update_model
                )
            ] = self.widget_d[ok.PER]

        elif node_k == ny.CANVAS:
            # Canvas hook
            self._sequence_signal = si.CANVAS_SHIFT_CHANGE
            self.handle_d[
                The.power.connect(si.RESIZE, self.on_sequence)
            ] = The.power

        self.handle_d[
            self.booth.connect(si.VOTE_CHANGE, self.update_model)
        ] = self.booth
        self.handle_d[self.connect(si.SEQUENCE, self.on_sequence)] = self

    def do(self, v):
        """
        Override the AnyGroup function so that Past's View Signal can be sent.

        v: View
        """
        super(Shift, self).do(v)

        p = self.item.model.past.emit

        if self._is_cell:
            p(si.CELL_SHIFT_VIEW, v.x)

            # Adapt to a missing Cell/Margin step.
            if not find_cell_margin(self.nav_k):
                p(si.CELL_MARGIN_VIEW, v.x)
        else:
            p(si.CANVAS_SHIFT_VIEW, v.x)

            # Adapt to a missing Canvas/Margin step.
            if not find_canvas_margin(self.nav_k):
                p(si.CANVAS_MARGIN_VIEW, v.x)

    def on_sequence(self, _, arg):
        """
        Update the Model pronto.

        _: AnyGroup
            Sent the Signal.

        arg: list
            [Plan vote, Work vote]
        """
        self.item.model.baby.feed(self._sequence_signal, (self.value_d, True))

    def update_model(self, *_):
        """Update the Model as time permits."""
        self.item.model.baby.give(self._sequence_signal, (self.value_d, False))


# Chi__________________________________________________________________________
class Chi(Run):
    """Factor Plan and Work."""
    issue_q = 'matter',

    def __init__(self, any_group, view_x):
        Run.__init__(self, any_group, view_x, ())
        self.set_issue()

    def prep(self, v):
        """
        For every view, there is an image, but not for Shift.

        v: View
        """
        return

    def dig(self, v):
        self.reset_issue()


class Plan(Chi):
    """Shift has no layer output. Is part of the AnyGroup template."""

    def __init__(self, any_group):
        Chi.__init__(self, any_group, 0)


class Work(Chi):
    """Shift has no layer output. Is part of the AnyGroup template."""

    def __init__(self, any_group):
        """
        Canvas and Cell Work.

        q: iterable
            output function
        """
        Chi.__init__(self, any_group, 1)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Canvas_______________________________________________________________________
class PlanCanvas(Plan):
    """Shift has no layer output. Is part of the AnyGroup template."""
    vote_type = MAIN

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Plan.__init__(self, any_group)


class WorkCanvas(Work):
    """Shift has no layer output. Is part of the AnyGroup template."""
    vote_type = MAIN

    def __init__(self, any_group):
        """
        any_group: AnyGroup
        """
        Work.__init__(self, any_group)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class PlanCell(Plan):
    """Shift has no layer output. Is part of the AnyGroup template."""
    issue_q = 'matter', 'per'
    vote_type = MAIN

    def __init__(self, any_group):
        Plan.__init__(self, any_group)


class WorkCell(Work):
    """Shift has no layer output. Is part of the AnyGroup template."""
    issue_q = 'matter', 'per'
    vote_type = MAIN

    def __init__(self, any_group):
        Work.__init__(self, any_group)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
