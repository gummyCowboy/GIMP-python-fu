#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import MetalCanvas, soften_metal_sel, select_frame
from roller_fu import (
    add_layer, clear_selection, clone_layer, merge_layer, select_item
)
from roller_one_gegl import antialias, emboss
from roller_view_hub import brush_stroke
from roller_view_preset import combine_seed
from roller_view_real import get_light, get_noise, FILLER
import gimpfu as fu

pdb = fu.pdb


def do_filler(v, maya):
    """
    Make a frame.

    v: View
    maya: Maya
        with frame material

    Return: layer or None
        with frame
    """
    pdb.gimp_context_set_opacity(100.)

    j = v.j
    d = maya.value_d[ok.WRW][ok.WRAP]
    e = maya.value_d[ok.WRW][ok.BRUSH_D]
    super_group = maya.super_maya.group
    cause = maya.cause.matter
    z = add_layer(
        j,
        super_group.name + " Stroke",
        parent=super_group,
        offset=len(super_group.layers)
    )
    select_item(cause)
    pdb.plug_in_sel2path(j, cause)

    if j.active_vectors:
        # Preserve.
        q = pdb.gimp_context_get_foreground()

        # Simulate depth by setting the color of the
        # brush to be a lighter color than the frame.
        if d[ok.EMBOSS]:
            pdb.gimp_context_set_foreground((144, 144, 144))

        else:
            pdb.gimp_context_set_foreground(
                tuple([min(255, i + 17) for i in d[ok.COLOR_1]])
            )

        z.opacity = e[ok.OPACITY]

        combine_seed(v, e)

        for stroke in j.active_vectors.strokes:
            brush_stroke(
                z,
                e[ok.BRUSH],
                e[ok.BRUSH_SIZE],
                stroke,
                e[ok.BRUSH_SPACING],
                e[ok.ANGLE_JITTER],
                hardness=e[ok.BRUSH_HARDNESS],
                angle=e[ok.BRUSH_ANGLE]
            )

        pdb.gimp_image_remove_vectors(j, j.active_vectors)

        # Restore.
        pdb.gimp_context_set_foreground(q)

        if d[ok.EMBOSS]:
            z1 = clone_layer(z)
            z1.mode = fu.LAYER_MODE_OVERLAY

            emboss(z, v.glow_ball.azimuth, v.glow_ball.elevation, 1)
            z = merge_layer(z1)

    z.name = z.parent.name + " Brush Punch"

    select_item(cause)
    clear_selection(z)
    antialias(z)
    return z


class BrushPunch(MetalCanvas):
    """Is a metallic border with an overlapping brush stroke."""

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            (Option key,)
            Is the key path to the responsible Frame Button.
        """
        MetalCanvas.__init__(
            self,
            any_group,
            super_maya,
            k_path,
            do_filler,
            (ok.WRW, ok.BRUSH_D,)
        )

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            frame Preset

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        m = super(BrushPunch, self).do(v, d, is_change)
        z = self.sub_maya[FILLER].matter

        if z:
            a = get_light(self) + get_noise(self)
            pdb.gimp_image_reorder_item(v.j, z, self.group, a)
        return m
