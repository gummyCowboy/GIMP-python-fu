#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Issue as vo, Signal as si
from roller_constant_key import Option as ok
from roller_frame_build import SubBuild
from roller_maya import check_mix_blur_behind, check_layer, on_global
from roller_fu import (
    blur_selection,
    invert_and_desaturate,
    select_item,
    select_opaque,
    select_rect,
    set_layer_mode,
    set_lightness
)
from roller_view_real import clone_background, mask_sel
import gimpfu as fu

pdb = fu.pdb


def blur_behind_matter(v, maya):
    """
    Blur Behind the super's matter layer.

    v: View
    maya: BlurBehind
    Return: layer or None
        with Blur Behind Material
    """
    z = maya.super_maya.matter
    d = maya.value_d

    # no Blur Behind layer, 'z1'
    z1 = None

    if z:
        # Blur Behind layer, 'z1'
        z1 = clone_background(v, z)
        z1.name = z1.parent.name + " Blur Behind"

        select_rect(v.j, *v.wip.rect)
        blur_selection(z1, d[ok.BLUR])
        set_lightness(z1, d[ok.LIGHTNESS])
    return z1


def check_blur_behind(v, maya):
    """
    Determine if there Blur Behind change. Make material if so.

    v: View
    maya: BlurBehind
    Return: layer or None
        with material
    """
    if maya.is_blur_behind:
        return check_layer(v, maya, 'matter', blur_behind_matter)
    return maya.matter


def mask_selectable(source_z, sub_z, p):
    """
    Make a mask for sub-Maya matter layer.

    source_z: layer
        Is the source layer with the alpha material to make a mask from.

    sub_z: layer or None
        Is the layer to receive the mask.

    p: function
        Select source layer.

    Return: layer
        mask
    """
    if sub_z and source_z:
        mode = None

        # Opacity doesn't change the selection.
        if source_z.mode != fu.LAYER_MODE_NORMAL:
            mode = source_z.mode
            set_layer_mode(source_z, fu.LAYER_MODE_NORMAL)

        p(source_z)
        mask_sel(sub_z)
        if mode is not None:
            source_z.mode = mode


class BlurBehind(SubBuild):
    """
    Manage Blur Behind option's layer output. Blur Behind
    is done after Frame and Shadow Maya during a View run.
    """
    issue_q = 'blur_behind', 'mode', 'opacity'
    put = (check_blur_behind, 'matter'), (check_mix_blur_behind, None)

    def __init__(self, any_group, super_maya, k_path, k):
        """
        super_maya: Maya
            Is the enclosing Preset's Maya.

        k: string
            Is the row Option key where the Blur Behind option is found.
        """
        q = (k_path + (k, ok.BLUR_BEHIND)) if k else k_path

        SubBuild.__init__(
            self, any_group, super_maya, [q, q + (ok.IDO,)], None
        )
        self.handle_d[
            self.any_group.connect(si.BACK_CHANGE, self.on_back_change)
        ] = self.any_group

    def do(self, v, d, is_back, is_mask):
        """
        Manage layer output during a View run.

        v: View
        d: dict or None
            Blur Behind Preset

        is_back: bool or None
            Is True when the background has change.

        is_mask: bool
            If True, then the Blur Behind is masked from its over-layer.
        """
        self.value_d = d
        e = d[ok.IDO]
        self.go = d[ok.SWITCH] and bool(self.super_maya.matter)

        if self.go:
            self.is_blur_behind |= is_back
            if self.matter and not self.is_blur_behind:
                pdb.gimp_image_reorder_item(
                    v.j,
                    self.matter,
                    self.matter.parent,
                    len(self.matter.parent.layers)
                )

        self.realize(v)

        if self.go and (self.is_blur_behind or is_mask):
            invert_and_desaturate(e, self.matter)
            mask_selectable(
                self.super_maya.matter,
                self.matter,
                select_opaque if e[ok.OPAQUE] else select_item
            )
        self.reset_issue()

    def on_back_change(self, _, x):
        """
        The background changed for the group.

        _: AnyGroup
            Sent the Signal.

        x: int
            Plan or Work index
        """
        if x == self.view_x:
            arg = [None, None]
            arg[x] = True
            on_global(self, arg, ok.IS_BACK, issue=vo.BLUR_BEHIND)
