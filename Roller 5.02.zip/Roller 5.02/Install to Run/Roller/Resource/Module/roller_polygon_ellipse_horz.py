#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_one_rect import Rect
from roller_polygon import get_h_ellipse_rect
from roller_polygon_hexagon import Hexagon


class EllipseHorz(Hexagon):
    """
    A Cell is ellipse shaped, aligned horizontally
    and are a double-spaced model-type.
    """

    @staticmethod
    def calc(model, o):
        """
        For Model cell, calculate cell and merge
        rectangle and their inscribed form polygon.

        model: Model
        o: One
            with Cell Type reference

        Return: list
            [Plan vote, Work vote]
        """
        vote_d = Hexagon.calc(model, o, ellipse_space=sh.ELLIPSE_RATIO)
        goo_d = model.goo_d

        if False if o.grid_type == gr.CELL_SIZE else True:
            # by count
            did_cell = model.past.did_cell

            for r_c in model.cell_q:
                a = goo_d[r_c]

                # The ellipse rect is smaller than the hexagon rect.
                a.cell = a.merged = Rect(*get_h_ellipse_rect(a.cell))
                vote_d[r_c] = did_cell(r_c)

        for r_c in model.cell_q:
            a = goo_d[r_c]
            a.form = a.cell.rect
        return vote_d
