#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Fill as fl, Frame as ff
from roller_constant_key import Option as ok
from roller_frame import Overlay, do_selection_material
from roller_frame_build import Build
from roller_def import get_default_value
from roller_fu import (
    blur_selection,
    color_fill_layer,
    copy_all_image,
    get_layer_position,
    get_select_coord,
    load_selection,
    make_clouds,
    merge_layer,
    paste_image,
    paste_layer,
    select_item,
    select_rect,
    shape_image,
    verify_layer
)
from roller_maya import check_matter, check_mix_wrap, make_frame_group
from roller_maya_blur_behind import BlurBehind
from roller_maya_bump import Bump
from roller_maya_light import Light
from roller_maya_shadow import Shadow
from roller_one_image import get_image_ref
from roller_one_the import The
from roller_view_real import OVERLAY, LIGHT, add_wip_layer, get_light
from roller_view_hub import (
    draw_gradient, get_gradient_points, set_fill_context, set_gimp_pattern
)
import gimpfu as fu
import os

MAIN = 'main'
pdb = fu.pdb


def apply_clouds(v, maya, z, d, k):
    """
    Make clouds for a frame selection.

    v: View
    maya: Maya
    z: layer
        Is frame.

    d: dict
        Frame Over Preset

    k: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        with frame material
    """
    make_clouds(z, int(d[ok.SEED] + v.glow_ball.seed))
    return z


def apply_color(v, maya, z, d, k):
    """
    Color the frame.

    v: View
    maya: Maya
    z: layer
        Is frame.

    d: dict
        Frame Over Preset

    k: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        with frame material
    """
    color_fill_layer(z, d[ok.CIR][ok.COLOR_1])
    return z


def apply_gradient(v, maya, z, d, k):
    """
    Color the frame with a gradient.

    v: View
    maya: Maya
    z: layer
        Is frame.

    d: dict
        Frame Over Preset

    k: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        with frame material
    """
    j = v.j
    x, y, x1, y1 = get_select_coord(j)
    w, h = x1 - x, y1 - y
    e = get_default_value("Gradient Fill")

    e.update(d)

    e[ok.GRADIENT] = d[ok.GPR][ok.GRADIENT]
    start_x, end_x, start_y, end_y = \
        get_gradient_points(
            d[ok.GRADIENT_ANGLE], x - v.wip.x, y - v.wip.y, w, h
        )

    select_rect(j, x, y, w, h)
    draw_gradient(z, e, start_x, start_y, end_x, end_y)
    blur_selection(z, d[ok.BLUR])
    return z


def apply_image(v, maya, z, d, k):
    """
    Apply an image to the frame.

    v: View
    maya: Maya
    z: layer
        Has the frame.

    d: dict
        Frame Over Preset

    k: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        with the frame
    """
    j = v.j
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    j1 = maya.cause.get_frame_image(k)

    if j1:
        j1 = j1.j
        n = z.name

        copy_all_image(j1)

        j1 = paste_image()

        blur_selection(j1.layers[0], d[ok.BLUR])
        shape_image(j1, x1 - x, y1 - y)

        z1 = paste_layer(z)

        pdb.gimp_layer_set_offsets(z1, x, y)

        z = merge_layer(z1)
        z.name = n
    return z


def apply_pattern(v, maya, z, d, k):
    """
    Paint the frame with a pattern.

    v: View
    maya: Maya
    z: layer
        Has the frame.

    d: dict
        Frame Over Preset

    k: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        with material
    """
    j = v.j

    set_fill_context(fl.FILL_DICT)
    set_gimp_pattern(d[ok.GPR][ok.PATTERN])

    # fill origin point, '0., 0,'
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, 0., 0.)

    blur_selection(z, d[ok.BLUR])
    return z


def apply_plasma(v, maya, z, d, k):
    """
    Paint the frame with plasma.

    v: View
    maya: Maya
    z: layer
        Has the frame.

    d: dict
        Frame Over Preset

    k: tuple
        (row, column) of int
        cell index and Goo key

    Return: layer
        with material
    """
    j = v.j

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(
        j, z,
        int(d[ok.SEED] + v.glow_ball.seed),
        1.                                 # lowest turbulence
    )
    blur_selection(z, d[ok.BLUR])
    return z


def do_color(v, maya):
    """
    Make an overlay layer for the frame.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    j = v.j

    # Frame Over Preset dict, 'd'
    d = maya.value_d

    a = maya.super_maya
    super_ = maya.cause
    n = d[ok.TYPE]
    if n in ROUTE:
        z = add_wip_layer(v, "Style", a.group, offset=get_light(a))

        if super_.vote_type == MAIN and n in ROUTE_MULTI:
            for r, c in super_.main_q:
                sel = maya.model.get_image_sel((r, c))
                load_selection(j, sel)
                if not pdb.gimp_selection_is_empty(j):
                    z = ROUTE_MULTI[n](v, maya, z, d, (r, c))
        else:
            select_item(super_.matter)
            if not pdb.gimp_selection_is_empty(j):
                z = ROUTE[n](v, maya, z, d, a.k)
        return verify_layer(z)


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: FrameOver
    Return: layer or None
        with the frame
    """
    d = maya.value_d[ok.WRW][ok.STENCIL]
    if d[ok.FRAME_OVER] != "None":
        return do_selection_material(
            v, maya, do_sel, embellish, "Frame Over", is_clear=False
        )


def do_sel(v, maya, z):
    """
    Make a frame for a selection.

    v: View
    maya: Maya
    z: layer
        to receive the frame
    """
    j = v.j

    # Frame Over Preset dict, 'd'
    d = maya.value_d[ok.WRW][ok.STENCIL]
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    n = "{}{}{}.png".format(The.frame_path, os.path.sep, d[ok.FRAME_OVER])
    e = get_default_value(ok.IMAGE_CHOICE)
    e[ok.FILE] = n
    e[ok.IMAGE_SOURCE] = ok.FILE

    # Get the GIMP image.
    j1 = get_image_ref(e, v.image_source)

    if j1:
        copy_all_image(j1.j)
        shape_image(paste_image(), x1 - x, y1 - y)

        n1 = z.name
        z = paste_layer(z, n="Frame")

        pdb.gimp_layer_set_offsets(z, x, y)

        z = merge_layer(z)
        z.name = n1
    return z


def embellish(v, maya, z):
    """Is a callback for 'do_selection_material'."""
    return z


class FrameOver(Build):
    """Make an overlay for image material."""
    is_seeded = True
    issue_q = 'matter', 'mode', 'opacity', 'shade'
    put = (
        (make_frame_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_wrap, None)
    )
    wrap_k = ok.STENCIL

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)
        """
        Build.__init__(
            self,
            any_group,
            super_maya,
            k_path + (ok.WRW, ok.STENCIL),
            do_matter
        )

        self.sub_maya[ok.BUMP] = Bump(
            any_group, self, k_path + (ok.SRW, ok.BUMP)
        )

        # base key path for Overlay, 'q'
        q = k_path + (ok.WRW, ok.OVERLAY_FO)
        self.sub_maya[OVERLAY] = Overlay(
            any_group,
            self,
            [q, q + (ok.CIR,),  q + (ok.GPR,)],
            do_color
        )
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, k_path + (ok.SRW, ok.SHADOW), (self, self.cause)
        )
        self.sub_maya[LIGHT] = Light(any_group, self, ok.OTHER)
        self.sub_maya[ok.BLUR_BEHIND] = BlurBehind(
            any_group, self, k_path, ok.SRW
        )

    def do(self, v, d, is_change):
        """
        Check, modify, and produce layer output.

        v: View
        d: dict
            Frame Over Preset
            {Option key: value}

        is_change: bool
            Is the state of the super Maya's matter and/or mask.

        Return: bool
            If True, then Shadow changed the background.
        """
        self.value_d = d
        is_back = v.is_back
        self.is_matter |= is_change

        self.realize(v)
        self.sub_maya[ok.BUMP].do(v, d[ok.SRW][ok.BUMP], self.is_matter)
        self.sub_maya[OVERLAY].do(
            v, d[ok.WRW][ok.OVERLAY_FO], is_change, self.is_matter
        )

        m = self.sub_maya[ok.SHADOW].do(
            v, d[ok.SRW][ok.SHADOW], self.is_matter, is_change
        )

        self.sub_maya[LIGHT].do(v, self.is_matter)
        self.sub_maya[ok.BLUR_BEHIND].do(
            v, d[ok.SRW][ok.BLUR_BEHIND], m or is_back, self.is_matter
        )
        self.reset_issue()
        return m


ROUTE_MULTI = {
    ff.GRADIENT: apply_gradient,
    ff.IMAGE: apply_image,
}
ROUTE = {
    ff.CLOUDS: apply_clouds,
    ff.COLOR: apply_color,
    ff.GRADIENT: apply_gradient,
    ff.IMAGE: apply_image,
    ff.PATTERN: apply_pattern,
    ff.PLASMA: apply_plasma
}
