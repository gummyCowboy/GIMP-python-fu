#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Caption as pt, Plan as fy, Signal as si
from roller_constant_key import (
    Item as ie, Node as ny, Option as ok, Plan as ak
)
from roller_deco_caption import (
    do_main_cell,
    do_main_face,
    do_main_facing,
    do_canvas,
    do_cell,
    do_face,
    do_facing,
    make_main_face_stripe,
    make_main_facing_stripe,
    make_main_stripe,
    make_canvas_stripe,
    make_cell_face_stripe,
    make_cell_facing_stripe,
    make_cell_stripe
)
from roller_maya import (
    MAIN,
    PER,
    CanvasRoute,
    CellRoute,
    FaceRoute,
    ImageRoll,
    check_matter,
    check_mix_basic
)
from roller_maya_shadow import Shadow
from roller_maya_stripe import Stripe
from roller_one_the import The
from roller_option_group import DecoGroup
from roller_view_real import make_canvas_group, make_cast_group
from roller_view_step import get_planner, make_model_key


def assign_image(v, maya, q):
    """
    Find assigned image for the "Image Name" Caption Type.

    v: View
    maya: Maya
    q: list
        a Model's grid item list
        [(r, c) or (r, c, x), ...]
    """
    d = maya.value_d
    per = d[ok.PER]
    per_d = maya.per_d
    image_maya = get_image_maya(v, maya)
    image_d = image_maya.per_d if image_maya else None
    if d[ok.SWITCH] or per:
        for k in q:
            if k in per_d:
                # Per
                this_maya = per_d[k]
                e = per[k]

            else:
                # main
                this_maya = maya
                e = d

            if e[ok.TYPE] == pt.IMAGE_NAME:
                if image_maya:
                    maya_j = image_d[k] if k in image_d else image_maya
                    image = maya_j.get_image(k)

                    if image != this_maya.get_image(k):
                        this_maya.is_matter = True
                    this_maya.set_image(k, image)
            else:
                if this_maya.get_image(k):
                    # Switched type.
                    this_maya.is_matter = True
                this_maya.set_image(k, None)


def get_image_maya(v, maya):
    """
    Get the Image Maya for a Caption Cell.

    v: View
    maya: Maya
    Return: Maya or None
        an Image type relative
    """
    # Canvas, Cell, Face Node position, '1'
    nav_k = make_model_key(maya.nav_k, (maya.nav_k[1], ie.IMAGE))

    any_group = The.helm.get_group(nav_k)
    if any_group:
        return (any_group.plan, any_group.work)[v.x]


class Caption(DecoGroup):
    """
    Create Widget group. Assign View run processor.
    Connect responsible signal handler.
    """

    def __init__(self, **d):
        DecoGroup.__init__(self, **d)

        node_k = self.nav_k[-2]
        self.plan = {
            ny.CANVAS: PlanCanvas,
            ny.CELL: PlanCell,
            ny.FACE: PlanFace,
            ny.FACING: PlanFacing
        }[node_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas,
            ny.CELL: WorkCell,
            ny.FACE: WorkFace,
            ny.FACING: WorkFacing
        }[node_k](self)
        baby = self.item.model.baby
        if node_k in (ny.FACE, ny.FACING):
            self.handle_d[
                baby.connect(si.CELL_SHIFT_CALC, self.on_cell_calc)
            ] = baby


class Chi(ImageRoll):
    """Factor from Plan and Work."""

    def __init__(self, any_group, view_x, p, q):
        """
        any_group: AnyGroup
            owner

        view_x: int
            0 or 1; Plan or Work index

        p: function
            Call to make Stripe material.

        q: iterable
            of function for producing View output
        """
        ImageRoll.__init__(
            self,
            any_group,
            view_x,
            q,
            k_path=[
                (),
                (ok.FCR, ok.FONT),
                (ok.LTR,),
                (ok.OCR,),
                (ok.MSS, ok.MARGIN)
            ]
        )
        self.set_issue()
        self.sub_maya[ok.STRIPE] = Stripe(
            any_group, self, view_x, p, (ok.MSS, ok.STRIPE)
        )


class Plan(Chi):
    """Manage Plan layer output."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group, p):
        """
        any_group: AnyGroup
            owner

        p: function
            Call to make Stripe material.
        """
        Chi.__init__(self, any_group, 0, p, self.put)

        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.CAPTION)
        self.handle_d[
            planner.connect(
                fy.SIGNAL_D[ak.CAPTION], self.on_plan_option_change
            )
        ] = planner

    def bore(self, v):
        """
        Manage layer output during a View run.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH] and self.is_planned

        if self.go:
            self.is_matter |= self.is_switched

        self.realize(v)
        if self.go:
            self.go = bool(self.matter)
            self.sub_maya[ok.STRIPE].do(v, d)

    def on_plan_option_change(self, _, arg):
        """Respond to change in PlanOption."""
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage Work layer output."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, p):
        """
        any_group: AnyGroup
            owner

        p: function
            Call to make Stripe material.
        """
        Chi.__init__(self, any_group, 1, p, self.put)
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, (ok.MSS, ok.SHADOW), (self,), is_wrap=False
        )

    def bore(self, v):
        """
        Manage layer output during a View run.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH]

        self.realize(v)
        if self.go:
            self.go = bool(self.matter)

            self.sub_maya[ok.STRIPE].do(v, d)
            v.is_back |= self.sub_maya[ok.SHADOW].do(
                v, d[ok.MSS][ok.SHADOW], self.is_matter, self.is_matter
            )


class Main:
    """Identify the Maya as the main option settings."""
    vote_type = MAIN

    def __init__(self):
        return


# Canvas_______________________________________________________________________
class Cloth:
    """Factor Plan and Work Canvas Maya."""

    def __init__(self):
        self.do_matter = do_canvas

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        if self.value_d[ok.TYPE] == pt.IMAGE_NAME:
            j = get_image_maya(v, self).get_image(None)

            if j != self.get_image(None):
                self.is_matter = True
            self.set_image(None, j)
        else:
            self.set_image(None, None)


class PlanCanvas(Main, Plan, CanvasRoute, Cloth):
    """Manage Plan's Canvas Caption layer output."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            owner
        """
        self.do_matter = do_canvas

        Main.__init__(self)
        Plan.__init__(self, any_group, make_canvas_stripe)
        CanvasRoute.__init__(self)
        Cloth.__init__(self)


class WorkCanvas(Main, Work, CanvasRoute, Cloth):
    """Manage Work's Canvas Caption layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'shade'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            owner
        """
        self.do_matter = do_canvas

        Main.__init__(self)
        Work.__init__(self, any_group, make_canvas_stripe)
        CanvasRoute.__init__(self)
        Cloth.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class Cellular:
    """Factor Plan and Work Cell Maya."""

    def __init__(self):
        self.do_matter = do_main_cell

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_image(v, self, self.model.cell_q)


class PlanCell(Main, Plan, CellRoute, Cellular):
    """Manage Plan/Cell layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        self.do_matter = do_main_cell

        Main.__init__(self)
        Plan.__init__(self, any_group, make_main_stripe)
        CellRoute.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(Main, Work, CellRoute, Cellular):
    """Manage Work/Cell layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per', 'shade'

    def __init__(self, any_group):
        self.do_matter = do_main_cell

        Main.__init__(self)
        Work.__init__(self, any_group, make_main_stripe)
        CellRoute.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per__________________________________________________________________________
class Per:
    """Factor Plan and Work Per Maya."""
    vote_type = PER

    def __init__(self, do_matter, k):
        self.do_matter = do_matter
        self.k = k
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per Cell_____________________________________________________________________
class PlanCellPer(Plan, Per):
    """Manage Plan Cell/Per output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
        k: tuple
            (row, column); Goo key
        """
        Plan.__init__(self, any_group, make_cell_stripe)
        Per.__init__(self, do_cell, k)


class WorkCellPer(Work, Per):
    """Manage Work Per Cell output."""
    issue_q = 'matter', 'mode', 'opacity', 'shade'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
        k: tuple
            (row, column)
        """
        Work.__init__(self, any_group, make_cell_stripe)
        Per.__init__(self, do_cell, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face_________________________________________________________________________
class Face:
    """Factor Plan and Work Face Maya."""

    def __init__(self):
        self.do_matter = do_main_face

    def prep(self, v):
        """
        Assign image for Face/Cell. Caption needs
        to check the image assigned by Image Maya.

        v: View
        """
        assign_image(v, self, self.model.face_q)


class PlanFace(Face, Main, Plan, FaceRoute):
    """Manage Plan/Face output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, make_main_face_stripe)
        FaceRoute.__init__(self, PlanFacePer)


class WorkFace(Face, Main, Work, FaceRoute):
    """Manage Work/Face layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per', 'shade'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            with Face options
        """
        Face.__init__(self)
        Main.__init__(self)
        Work.__init__(self, any_group, make_main_face_stripe)
        FaceRoute.__init__(self, WorkFacePer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face Per Cell________________________________________________________________
class PlanFacePer(Plan, Per):
    """Manage Plan/Face/Per layer output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            owner

        k: tuple
            (row, column); cell index
        """
        Plan.__init__(self, any_group, make_cell_face_stripe)
        Per.__init__(self, do_face, k)


class WorkFacePer(Work, Per):
    """Manage Work/Face/Per output."""
    issue_q = 'matter', 'mode', 'opacity', 'shade'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            owner

        k: tuple
            (row, column); cell index
        """
        Work.__init__(self, any_group, make_cell_face_stripe)
        Per.__init__(self, do_face, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing_______________________________________________________________________
class Facing:
    """Factor from Plan and Work Facing."""

    def __init__(self):
        self.do_matter = do_main_facing

    def prep(self, v):
        """
        Assign image for Face/Cell. Caption needs
        to check the image assigned by Image Maya.

        v: View
        """
        assign_image(v, self, self.model.face_q)


class PlanFacing(Facing, Main, Plan, FaceRoute):
    """Manage Plan Facing/Caption layer output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Facing.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, make_main_facing_stripe)
        FaceRoute.__init__(self, PlanFacingPer)


class WorkFacing(Facing, Main, Work, FaceRoute):
    """Manage Work Facing/Caption layer output."""
    issue_q = 'matter', 'mode', 'opacity', 'per', 'shade'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            the enclosing Preset's
        """
        Facing.__init__(self)
        Main.__init__(self)
        Work.__init__(self, any_group, make_main_facing_stripe)
        FaceRoute.__init__(self, WorkFacingPer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing Per Cell______________________________________________________________
class FacingPer(Per):
    """Factor Plan and Work Facing/Per Maya."""

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacingPer(Plan, FacingPer):
    """Manage Plan Facing/Caption/Per."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: AnyGroup
            the enclosing Preset's

        k: tuple
            (r, c); cell index; of int; Goo key
        """
        Plan.__init__(self, any_group, make_cell_facing_stripe)
        FacingPer.__init__(self, do_facing, k)


class WorkFacingPer(Work, FacingPer):
    """Manage Work Facing/Caption/Per."""
    issue_q = 'matter', 'mode', 'opacity', 'shade'

    def __init__(self, any_group, k):
        """
        Create a Maya for Per Cell.

        k: tuple
            (r, c); cell index; of int; Goo key
        """
        Work.__init__(self, any_group, make_cell_facing_stripe)
        FacingPer.__init__(self, do_facing, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
