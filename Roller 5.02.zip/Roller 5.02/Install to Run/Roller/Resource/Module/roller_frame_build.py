#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_maya import Maya


class Build(Maya):
    """Factor option-list sourced Maya."""

    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        any_group: AnyGroup
            option owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)

        do_matter: function
            Call to make primary layer.
        """
        self.super_maya = super_maya
        self.cause = super_maya.super_maya
        self.vote_type = super_maya.vote_type
        self.do_matter = do_matter

        Maya.__init__(self, any_group, 1, self.put, k_path)
        self.set_issue()


class SubBuild(Maya):
    """Factor sub-option-list sourced Maya."""
    def __init__(self, any_group, super_maya, k_path, do_matter):
        """
        any_group: AnyGroup
            option owner

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
            (Option key, ...)

        do_matter: function
            Call to make primary layer.
        """
        self.super_maya = super_maya
        self.cause = super_maya.cause if hasattr(super_maya, 'cause') else None
        self.vote_type = super_maya.vote_type
        self.do_matter = do_matter

        Maya.__init__(self, any_group, 1, self.put, k_path)
        self.set_issue()
