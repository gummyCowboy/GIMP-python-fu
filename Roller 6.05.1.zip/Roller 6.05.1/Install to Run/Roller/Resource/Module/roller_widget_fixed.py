#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk
from roller_widget import Widget
import gtk  # type: ignore


class Fixed(Widget):
    """Is a GTK SpinButton."""
    change_signal = 'value-changed'

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        self._precision = 0
        self._limit = map(float, d[wk.LIMIT])
        self._greater_g = d[wk.GREATER_G]
        adjustment = self._adjustment = gtk.Adjustment(
            value=0.,
            lower=self._limit[0],
            upper=self._limit[1],
            step_incr=1,
        )

        d[wk.ALIGN] = 0, 0, 1, 0
        g = self.spin_button = gtk.SpinButton(
            adjustment=adjustment, climb_rate=1.1, digits=0
        )

        g.set_update_policy(gtk.UPDATE_DISCONTINUOUS)
        g.set_numeric(1)
        g.set_increments(1, 10)
        Widget.__init__(self, g, **d)
        self.add(g)
        self._adjustment.emit('value-changed')

    def get_a(self):
        """
        Get the value of the greater Widget.

        Return: value
            from the greater Widget
        """
        return self._greater_g.get_a()

    def get_lesser_a(self):
        """
        Get the value of the 'gtk.Alignment'.
        Call from the greater Widget.

        Return: numeric
            value of Fixed
        """
        return self.spin_button.get_value_as_int()

    def set_lesser_a(self, a):
        """
        Set the 'gtk.Alignment' value.
        Call from the greater Widget.

        a: numeric
            int or float
        """
        self._adjustment.set_value(a)
