#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import LAYER_MODE_GRAIN_EXTRACT   # type: ignore
from roller_a_gegl import cubism, median_blur, neon, pixelize
from roller_constant_key import Option as ok
from roller_fu import clone_layer, merge_layer_group
from roller_maya_style import Style, make_background
from roller_one_wip import Wip, get_factor_w, get_factor_h
from roller_view_hub import do_mod
from roller_view_real import add_sub_base_group


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: PaperWaste
    Return: layer
        Backdrop Style material
    """
    d = maya.value_d
    parent = add_sub_base_group(maya)
    z = make_background(parent)
    w = max(1, int(get_factor_w(d[ok.BLOCK_W])))
    h = max(1, int(get_factor_h(d[ok.BLOCK_H])))
    z1 = clone_layer(z, n="Curvy")

    # background color, 'z'
    pixelize(z, *Wip.get_size())

    # shredded curvy edge with alpha holes, 'z1'
    pixelize(z1, w, h)
    median_blur(z1, (w + h) / 4, 50.)
    cubism(z1, 9., 3.)
    cubism(z1, 6., 3.)
    cubism(z1, 3., 3.)

    # bumpy paper stack, 'z2'
    z2 = clone_layer(z1, n="Bumpy")

    neon(z2, 5., .0)

    z2.mode = LAYER_MODE_GRAIN_EXTRACT
    z2.opacity = 50.
    z = merge_layer_group(parent)

    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class PaperWaste(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
