#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb   # type: ignore
from random import uniform, randint, seed
from roller_a_contain import Globe, Run
from roller_a_gegl import waterpixels
from roller_constant_for import Frame as ff
from roller_constant_key import Material as ma, Option as ok
from roller_frame_alt import AltWrapFiller
from roller_frame import do_alt_frame
from roller_fu import add_layer, blur_selection
from roller_view_hub import do_mod
from roller_view_real import get_light

'''
Define 'frame_ceramic' as a Maya-subtype
for managing a variation of Frame type.
'''

COLOR_BALANCE = (
    (-100., 100., 100.),
    (-100., -100., 100.),
    (-100., 100., -100.),
    (100., -100., -100.),
    (100., -100., 100.),
    (100., 100., -100.)
)


def do_matter(maya):
    """
    Make Wrap.

    maya: Ceramic
    Return: layer
        Wrap frame
    """
    return do_alt_frame(maya)


def do_filler(maya):
    """
    Draw Filler material.

    maya: AltFiller
    Return: layer
        Ceramic Filler material
    """
    j = Run.j
    d = maya.value_d
    seed_ = int(Globe.seed + d[ok.SEED])
    z = add_layer(j, "Material", maya.group, get_light(maya))

    pdb.gimp_selection_none(j)
    seed(seed_)

    # random turbulence
    pdb.plug_in_plasma(j, z, seed_, uniform(1., 7.))

    # mid-tones, '1'; yes, preserve luminosity,  '1'
    pdb.gimp_color_balance(z, 1, 1, *COLOR_BALANCE[randint(0, 5)])

    waterpixels(z, size=min(256, int(d[ok.MESH_SIZE])))
    pdb.gimp_selection_all(j)
    pdb.plug_in_mosaic(
        j, z,
        d[ok.MESH_SIZE],
        1.,                                     # tile height
        .1,                                     # minimum spacing
        .5,                                     # medium neatness
        0,                                      # no split
        Globe.azimuth,
        .0,                                     # minimum color variation
        1,                                      # yes, antialias
        1,                                      # yes, average color
        ff.MESH_TYPE.index(d[ok.MESH_TYPE]),
        0,                                      # smooth surface
        0                                       # black and white grout
    )
    blur_selection(z, 1.5)
    do_mod(z, d[ok.BRW][ok.MOD])
    return z


class Ceramic(AltWrapFiller):
    filler_k = ok.FILLER_CE
    kind = material = ma.CERAMIC
    shade_row = ok.BRW
    wrap_k = ok.WRAP_FI

    def __init__(self, any_group, super_maya, k_path):
        AltWrapFiller.__init__(
            self, any_group, super_maya, k_path, do_matter, do_filler
        )
