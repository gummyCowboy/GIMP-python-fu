#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (      # type: ignore
    CHANNEL_OP_ADD, CLIP_TO_IMAGE, LAYER_MODE_DIFFERENCE, pdb
)
from roller_a_contain import Run
from roller_constant_key import Option as ok
from roller_fu import (
    add_layer_above,
    blur_selection,
    get_item_size,
    get_layer_offsets,
    make_layer_group,
    merge_layer_group,
    remove_z,
    select_color,
    select_rect,
    set_layer_mode
)
from roller_fu_mode import translate_mode
from roller_maya_style import Style, make_background
from roller_one import make_rect_table
from roller_view_hub import (
    color_layer,
    color_selection,
    do_mod,
    do_rotated_layer,
    prep_replace_color_default
)
from roller_view_real import add_wip_layer

'''
Define 'backdrop/color_grid' as a Maya-subtype
for managing a variation of backdrop style layer.
'''


def do_color_grid(d, group):
    """
    Draw a Color Grid.

    d: dict
        Color Grid Preset

    group: layer
        Parent the output.

    Return: layer
        Color Grid material
    """
    return do_rotated_layer(d, draw_color_grid, group, 0)


def draw_color_grid(z, d):
    """
    Draw a black and white checkerboard.

    z: layer
        Replace with the checkerboard layer.

    d: dict
        Color Grid Preset

    Return: layer
        Has the checkerboard pattern.
    """
    j = z.image
    x, y = get_layer_offsets(z)
    w, h = get_item_size(z)
    row, column = int(d[ok.ROW]), int(d[ok.COLUMN])
    grid = make_rect_table((x, y, w, h), row, column)
    z1 = add_layer_above(z, "V")

    # Prep layers for selections.
    for i in (z, z1):
        color_layer(i, (255, 255, 255))

    pdb.gimp_selection_none(j)

    # Draw horizontal stripes.
    for r in range(0, row, 2):
        select_rect(
            j, .0, grid[r][0].y, w, grid[r][0].h, option=CHANNEL_OP_ADD
        )

    color_selection(z, (0, 0, 0))
    pdb.gimp_selection_none(j)

    # Draw vertical stripes.
    z1.mode = LAYER_MODE_DIFFERENCE

    # row, 'a'
    a = grid[0]

    for c in range(0, column, 2):
        select_rect(j, a[c].x, .0, a[c].w, h, option=CHANNEL_OP_ADD)

    color_selection(z1, (0, 0, 0))
    return pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)


def make_style(maya):
    """
    Do the Backdrop Style.

    maya: Style
    Return: layer
        Color Grid material
    """
    j = Run.j
    d = maya.value_d
    group = make_layer_group(j, "WIP", maya.group, 0)
    back_z = make_background(group)

    prep_replace_color_default()

    # black and white checkerboard layer, 'z'
    z = do_color_grid(d, maya.group)

    # Begin making two color grid layers each with its own layer mode.
    # layer to receive color grid material, 'z1'
    z1 = add_wip_layer("Color 1", group)

    # Select by color and then fill.
    select_color(z, (255, 255, 255))

    q = d[ok.COLOR_2A][0]

    set_layer_mode(z1, translate_mode(d[ok.COLOR_1_MODE]))
    color_selection(z1, q)

    a = d[ok.BELOW_COLOR_1]

    if a:
        blur_selection(back_z, a)

    # layer to receive color grid material, 'z1'
    z2 = add_wip_layer("Color 2", group)

    select_color(z, (0, 0, 0))

    q = d[ok.COLOR_2A][1]

    set_layer_mode(z2, translate_mode(d[ok.COLOR_2_MODE]))
    color_selection(z2, q)

    a = d[ok.BELOW_COLOR_2]

    if a:
        blur_selection(back_z, a)

    remove_z(z)

    z = merge_layer_group(group)

    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class ColorGrid(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
