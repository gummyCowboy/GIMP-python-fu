#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_ADD, pdb   # type: ignore
from roller_a_contain import Deco, Mold, Place, Pot, Run, Source
from roller_constant_for import Justification as ju, Resize as fz
from roller_constant_key import Option as ok
from roller_deco import (
    attach_mask_sel,
    create_face_main_mask,
    create_facing_main_mask,
    create_face_per_mask,
    make_facing_per_mask,
    make_mask_sel,
    ready_canvas_rect,
    ready_shape
)
from roller_fu import (
    clear_inverse_selection,
    copy_all_image,
    get_item_size,
    load_selection,
    paste_image,
    paste_layer,
    select_item,
    select_rect,
    select_shape,
    verify_layer,
    verify_layer_group
)
from roller_image_grind import ref_get_image
from roller_one import seal
from roller_polygon import (
    get_bounds, calc_circumradius, get_extreme, rotate_points, shift_center
)
from roller_view_hub import do_mod
from roller_view_real import clip_to_view, get_light, make_matter_group

'''Define 'deco_image' as having Model/Branch/Image output function.'''


def apply_shape_mask(z, shape):
    """
    Select a shape and clear pixel outside of it.

    z: layer
        target of the clear op

    shape: tuple
        Is a polygon shape's x, y series.
    """
    select_shape(z.image, shape)
    clear_inverse_selection(z)


def calc_lock(w, h, w1, h1):
    """
    Return the size of an image that will fit into a cell.

    w, h: float
        image size
        (width, height)

    w1, h1: float
        cell size
        (width, height)
        Conform the image size to this size.
    """
    if w and h:
        w_r = w1 / w
        h_r = h1 / h

        if w_r > h_r:
            w, h = w * h_r, h1
        else:
            w, h = w1, h * w_r

    else:
        # underflow
        return 1., 1.
    return max(round(w), 1.), max(round(h), 1.)


def calc_mold_angle(d):
    """
    If an image is rotated, calculate the rotated rectangle's
    corner points. The image is first rotated, and then the
    rotated image rectangle is fitted to the Place rectangle.

    maya: Maya
    """
    f = d[ok.ANGLE]
    if f:
        q = shift_center(Mold.foam(), *Mold.center())
        q = rotate_points(
            q, Place.center(), calc_circumradius(Source.w, Source.h), f
        )
        Pot.foam = fit_coord_in_rect(q)
        Mold.set_rect(*get_bounds(Pot.foam))


def create_cell(maya, d, group, is_main=False):
    """
    Place an image in a cell.

    maya: Maya
    d: dict
        Image Preset

    group: layer
        Is the parent layer for image output.

    is_main: bool
        Is True when the caller is the main cell Maya version.

    Return: layer or None
        image
    """
    j = ref_get_image(maya.any_group, maya.k, 0)
    if j:
        ready_shape(maya, d, option=None)
        Place.set_rect(*maya.rect)
        return verify_layer(place_image(maya, d, group, j, is_main))


def create_main(maya, d, p):
    """
    Place image for main.

    maya: Maya
    d: dict
        Image Preset

    p: function
        Place image.

    Return: layer or None
        image material
    """
    group = make_matter_group(maya)

    for k in maya.main_q:
        maya.k = k
        p(maya, d, group, is_main=True)
    return verify_layer_group(group)


def create_face(maya, d, group, is_main=False):
    """
    Place Face image.

    maya: Maya
    d: dict
        Image Preset

    group: layer
        Is the parent of Face output.

    is_main: bool
        Main Maya image output is placed on the same layer.
    """
    k = maya.k
    model = maya.model
    j = ref_get_image(maya.any_group, k, 0)
    if j:
        Place.set_rect(*model.get_facing_merged(k))
        maya.rect = model.get_facing_rect(k)
        Deco.shape = model.get_facing_shape(k)
        place_image(maya, d, group, j, is_main)


def create_facial_per(maya, d, p):
    """
    Place image for Face or Facing Per.

    maya: Maya
    d: dict
        Image Preset

    p: function
        Place Face or Facing Per image.

    Return: layer or None
        image
    """
    group = make_matter_group(maya)

    p(maya, d, group)
    return verify_layer_group(group)


def create_facing(maya, d, group, is_main=False):
    """
    Create Facing image layer.

    maya: Maya
    d: dict
        Image Preset

    group: layer
        Is the parent of Facing output.

    is_main: bool
        Main Maya image output is placed on the same layer.
    """
    k = maya.k
    model = maya.model
    j = ref_get_image(maya.any_group, k, 0)
    if j:
        Place.set_rect(*model.get_facing_merged(k))
        place_image(maya, d, group, j, is_main)


def do(maya, make):
    """
    Prepare and route image placement.

    maya: Maya
    make: function
        Call to make image layer.

    Return: layer or None
        image material
    """
    d = maya.value_d

    if not Run.x:
        # Preserve.
        mode = d[ok.MODE]

        # Plan override.
        d[ok.MODE] = "Normal"

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.BRW][ok.MOD])

    if not Run.x:
        # Restore.
        d[ok.MODE] = mode
        if z:
            z.opacity = 66.
    return z


def do_canvas(maya):
    """
    Place image for the Canvas/Image.

    maya: Maya
    Return: layer or None
        image
    """
    return do(maya, make_canvas)


def do_cell_main(maya):
    """
    Place image for Cell main option.

    maya: Maya
    Return: layer or None
        image material
    """
    return do(maya, make_cell_main)


def do_cell_per(maya):
    """
    Place image for Cell/Per.

    maya: Maya
    Return: layer or None
        image
    """
    return do(maya, make_cell_per)


def do_face_main(maya):
    """
    Place image for the Face main.

    maya: Maya
    Return: layer or None
        image material
    """
    return do(maya, make_face_main)


def do_face_per(maya):
    """
    Place image for Face/Per.

    maya: Maya
    Return: layer or None
        image
    """
    return do(maya, make_face_per)


def do_facing_main(maya):
    """
    Place image for the Facing main.

    maya: Maya
    Return: layer or None
        image material
    """
    return do(maya, make_facing_main)


def do_facing_per(maya):
    """
    Place image for Facing/Per.

    maya: Maya
    Return: layer or None
        image
    """
    return do(maya, make_facing_per)


def fit_coord_in_rect(q):
    """
    Given a rectangle polygon of points, calculate
    their position inside the Place rectangle.

    q: list
        x, y series
        8 total
        rectangle points

    Return: list
        [rectangle coordinate, ...]
    """
    # list of coordinate, point ordered, inside target rectangle, 'q1'
    q1 = []

    left, top, right, bottom = get_extreme(q)
    input_w = right - left
    input_h = bottom - top
    is_fit = Place.w >= input_w and Place.h >= input_h

    if not is_fit:
        center_x, center_y = Place.center()
        lock_w, lock_h = calc_lock(input_w, input_h, Place.w, Place.h)
        lock_x = center_x - lock_w / 2.
        lock_y = center_y - lock_h / 2.

        for i in range(0, 8, 2):
            # Transform size, one coordinate per side.
            x, y = q[i], q[i + 1]

            ratio_x = (x - left) / input_w
            ratio_y = (y - top) / input_h
            x = lock_w * ratio_x + lock_x
            y = lock_h * ratio_y + lock_y
            q1 += [x, y]
        return q1
    return q


def justify_mold(n):
    """
    Adjust the mold position with the image justification.

    n: string
        justification type
    """
    x, y, w, h = Mold.get_rect()
    cast_x, cast_y, cast_w, cast_h = Place.get_rect()

    if w != cast_w:
        # x position
        if n in ju.CENTER_X:
            x1 = cast_w / 2. - w / 2. + cast_x

        elif n in ju.LEFT:
            x1 = cast_x
        else:
            # right
            x1 = cast_x + cast_w - w

    else:
        x1 = cast_x

    if h != cast_h:
        # y position
        if n in ju.CENTER_Y:
            y1 = cast_h / 2. - h / 2. + cast_y

        elif n in ju.TOP:
            y1 = cast_y
        else:
            # bottom
            y1 = cast_y + cast_h - h

    else:
        y1 = cast_y

    Mold.set_pos(round(x1), round(y1))
    if Pot.foam and (x != x1 or y != y1):
        # Adjust foam to justification.
        w1 = x1 - x
        h1 = y1 - y
        q = Pot.foam

        # adjusted foam, 'q1'
        q1 = []

        for i in range(0, len(q), 2):
            x, y = q[i], q[i + 1]
            q1 += [x + w1, y + h1]
        Pot.foam = q1


def make_canvas(maya, d):
    """
    Place a Canvas Image.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        image
    """
    j = ref_get_image(maya.any_group, None, 0)
    if j:
        ready_canvas_rect(maya, d, option=None)
        Place.set_rect(*maya.rect)
        return verify_layer(
            place_image(maya, d, maya.group, j, False)
        )


def make_cell_main(maya, d):
    """
    Place image for Cell main.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        image material
    """
    return create_main(maya, d, create_cell)


def make_cell_per(maya, d):
    """
    Is needed for its argument signature.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        image
    """
    return verify_layer(create_cell(maya, d, maya.group))


def make_face_main(maya, d):
    """
    Place image for Face main.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        image material
    """
    return create_main(maya, d, create_face)


def make_face_per(maya, d):
    """
    Place image for Face/Per.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        image
    """
    return create_facial_per(maya, d, create_face)


def make_facing_main(maya, d):
    """
    Place image for Face main.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        image material
    """
    return create_main(maya, d, create_facing)


def make_facing_per(maya, d):
    """
    Place image for Facing/Per.

    maya: Maya
    d: dict
        Image Preset

    Return: layer or None
        image
    """
    return create_facial_per(maya, d, create_facing)


def mask_cell_main(maya, d):
    """
    Mask Cell/Image main layer.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer or None
        mask material
    """
    j = Run.j
    z = maya.matter
    sel = None
    model = maya.model

    pdb.gimp_selection_none(j)

    for k in maya.main_q:
        maya.k = k
        image_sel = model.get_image_sel(k)
        if image_sel:
            load_selection(j, image_sel)

            if not pdb.gimp_selection_is_empty(j):
                make_mask_sel(maya, d)

            if sel:
                load_selection(j, sel, option=CHANNEL_OP_ADD)
                pdb.gimp_image_remove_channel(j, sel)
            if not pdb.gimp_selection_is_empty(j):
                sel = pdb.gimp_selection_save(j)

    if sel:
        pdb.gimp_image_remove_channel(j, sel)
    return attach_mask_sel(z)


def mask_face_main(maya, d):
    """
    Mask image on Face/Image main layer.

    maya: Mask
    d: dict
        Mask Preset

    Return: layer or None
        mask material
    """
    return create_face_main_mask(maya, d)


def mask_face_per(maya, d):
    """
    Mask image on Face/Per layer.

    maya: Mask
    d: dict
        Mask Preset

    Return: layer or None
        mask
    """
    return create_face_per_mask(maya, d)


def mask_facing_main(maya, d):
    """
    Mask image on main Facing layer.

    maya: Mask
    d: dict
        Mask Preset

    Return: layer or None
        mask material
    """
    return create_facing_main_mask(maya, d)


def mask_facing_per(maya, d):
    """
    Mask image on Facing/Per layer.

    maya: Mask
    d: dict
        Mask Preset

    Return: layer or None
        mask
    """
    return make_facing_per_mask(maya, d)


def mold_cover(maya, d, j):
    """
    Resize an image using the Cover Resize Method.

    d: dict
        Image Preset

    j: GIMP image
        WIP

    Return: GIMP image
        WIP
    """
    x, y, w, h = Place.get_rect()
    w1, h1 = get_item_size(j)

    # Is small and not a Face image, 'is_small'.
    is_small = w1 <= w and h1 <= h and not maya.is_face

    trim(d, w1, h1, is_trim=not is_small)

    if is_small:
        x1 = x + w
        y1 = y + h

        # Transform uses foam.
        Pot.foam = x, y, x1, y, x, y1, x1, y1

        # Rotation uses rectangle.
        Mold.set_rect(x, y, w, h)
    return j


def mold_crop(_, d, j):
    """
    Set the Mold and Source rectangle for a Crop Resize Method.

    _: Maya
    d: dict
        Image Preset

    j: GIMP image
        WIP

    Return: GIMP image
        WIP
    """
    w, h = get_item_size(j)
    e = d[ok.RW1][ok.RESIZE]

    # Limit the crop rectangle size to the image size.
    x = seal(e[ok.CROP_X], 1., w - 1.)
    y = seal(e[ok.CROP_Y], 1., h - 1.)
    Source.rect = (
        x, y,
        seal(e[ok.CROP_W], 1., w - x),
        seal(e[ok.CROP_H], 1., h - y)
    )

    trim_oversize(d[ok.JUSTIFICATION], Place.w, Place.h)
    Mold.set_rect(.0, .0, Source.w, Source.h)

    # Source pixel is copied without resizing.
    Pot.is_small = True

    return j


def mold_factor(_, d, j):
    """
    Resize an image by multiplying its size by a factor.

    maya: Maya
    d: dict
        Image Preset

    j: GIMP image
        WIP

    Return: GIMP image
        source
    """
    e = d[ok.RW1][ok.RESIZE]
    w, h = e[ok.WIDTH], e[ok.HEIGHT]

    # Check to see if the Source image is resized.
    if w != 1. or h != 1.:
        # Create a resized Source image to replace the original.
        copy_all_image(j)

        j1 = paste_image()
        if j1:
            # Remove 'temp_image' in 'place_image'.
            j = Pot.temp_image = j1

            w = j.width * w
            h = j.height * h

            pdb.gimp_item_transform_perspective(
                j.layers[0], .0, .0, w, .0, .0, h, w, h
            )
            pdb.gimp_image_resize_to_layers(j)

    Source.set_rect(.0, .0, *get_item_size(j))
    trim_oversize(d[ok.JUSTIFICATION], Place.w, Place.h)
    Mold.set_rect(.0, .0, Source.w, Source.h)

    # Source pixel is copied without resizing.
    Pot.is_small = True

    return j


def mold_fill(maya, _, j):
    """
    Set the mold and Source rectangle for a Fill Resize Method.

    maya: Maya
        not used

    _: dict
        Image Preset

    j: GIMP image
        WIP

    Return: GIMP image
        source
    """
    x, y, w, h = Place.get_rect()

    Source.set_rect(.0, .0, *get_item_size(j))

    Pot.is_small = Source.w == w and Source.h == h

    Mold.set_rect(x, y, w, h)
    return j


def mold_fixed(_, d, j):
    """
    Resize an image with Fixed Resize Method.

    _: Maya
    d: dict
        Image Preset

    j: GIMP image
        source

    Return: GIMP image
        source
    """
    e = d[ok.RW1][ok.RESIZE]
    w, h = e[ok.FIXED_W], e[ok.FIXED_H]

    # Check to see if a new image is needed.
    w1, h1 = get_item_size(j)

    if (w, h) != (w1, h1):
        # Create a resized Source image to replace the original.
        copy_all_image(j)

        j1 = paste_image()
        if j1:
            # Remove 'temp_image' in 'place_image'.
            j = Pot.temp_image = j1

            pdb.gimp_item_transform_perspective(
                j.layers[0], .0, .0, w, .0, .0, h, w, h
            )
            pdb.gimp_image_resize_to_layers(j)

    Source.set_rect(.0, .0, *get_item_size(j))
    trim_oversize(d[ok.JUSTIFICATION], Place.w, Place.h)
    Mold.set_rect(.0, .0, Source.w, Source.h)

    # Source pixel is copied without resizing.
    Pot.is_small = True

    return j


def mold_lock(maya, _, j):
    """
    Determine the size of a mold rectangle given a Place rectangle,
    and a Locked Aspect Ratio Resize Method. Set the Source
    rectangle to the image size. Determine if the input image
    is smaller than the Place rectangle.

    maya: Maya
        not used

    _: dict
        Image Preset

    j: GIMP image
        source pixel

    Return: GIMP image
        source
    """
    w, h = get_item_size(j)
    w1, h1 = Place.w, Place.h
    Source.set_rect(.0, .0, w, h)
    Pot.is_small = Source.w <= w1 and Source.h <= h1

    if not Pot.is_small:
        # down-size
        w, h = calc_lock(w, h, w1, h1)

    Mold.set_rect(.0, .0, w, h)
    return j


def mold_trim(_, d, j):
    """
    Resize an image using the Trimmed Side Resize Method.

    _: Maya

    d: dict
        Image Preset

    j: GIMP image
        source

    Return: GIMP image
        source
    """
    w1, h1 = get_item_size(j)
    Pot.is_small = w1 <= Place.w and h1 <= Place.h

    if not Pot.is_small:
        trim(d, w1, h1)

    else:
        Mold.set_rect(Place.x, Place.y, w1, h1)
        Source.set_rect(.0, .0, w1, h1)
    return j


def paste_image_layer(maya, group):
    """
    Paste the clipboard and move the new layer to the top of a layer group.

    group:
        Receive image.

    Return: layer
        the newly pasted layer
    """
    # Paste on top of the Backing layer.
    z = paste_layer(Run.j.layers[-1].layers[-1], group.name + " Material")

    pdb.gimp_image_reorder_item(Run.j, z, group, get_light(maya))
    return z


def place_image(maya, d, group, j, is_main):
    """
    Copy and paste an image after molding it to a cell. Take an input image
    and produce a transformed image that fits inside a Place rectangle.

    maya: Maya
    d: dict
        Image Preset

    group: layer
        Is the parent of layer output.

    j: GIMP image
        pixel source

    is_main: bool
        Is true when the Maya is the main version.

    Return: image layer or None
        image
    """
    Pot.foam = []
    k = maya.k
    model = maya.model
    resize_type = d[ok.RW1][ok.RESIZE][ok.TYPE]
    j = ROUTE_MOLD[resize_type](maya, d, j)

    calc_mold_angle(d)

    if resize_type not in (ok.COVER, ok.FILLED):
        justify_mold(d[ok.JUSTIFICATION])

    if maya.is_face:
        if resize_type in (ok.COVER, ok.FILLED):
            Pot.foam = model.get_facing_foam(k)
        else:
            Pot.foam = model.get_facing_transform(k)(maya)

    select_rect(j, *Source.get_rect())
    pdb.gimp_edit_copy_visible(j)

    z = paste_image_layer(maya, group)
    z = transform_source(z)

    clip_to_view(z)

    if Pot.temp_image:
        pdb.gimp_image_delete(Pot.temp_image)
        Pot.temp_image = None

    if z:
        if maya.is_face:
            model.clip_facing(z, k)
        else:
            if not model.is_rectangle:
                apply_shape_mask(z, Deco.shape)
            if is_main:
                select_item(z)
                model.set_image_sel(Run.j, k)
    return z


def transform_source(z):
    """
    Transform an image into its destination mold rectangle.

    z: layer
        source pixel

    Return: layer
        transformed source
    """
    q = Pot.foam

    pdb.gimp_selection_none(Run.j)

    if q:
        # Coordinate is a float.
        # point order: topleft, top-right, bottom-left, bottom-right
        z = pdb.gimp_item_transform_perspective(z, *map(round, q))

    elif Pot.is_small:
        x, y = Mold.x, Mold.y
        pdb.gimp_layer_set_offsets(z, int(x), int(y))

    else:
        # I tried 'pdb.gimp_item_transform_perspective', but it fails
        # as it interpolates outside the layer boundary producing a soft
        # edged image for a rectangular image.
        pdb.gimp_context_set_antialias(0)

        # local origin, 'True'
        # Rectangle is integer.
        pdb.gimp_layer_scale(
            z, max(1, int(Mold.w)), max(1, int(Mold.h)), True
        )
        pdb.gimp_layer_set_offsets(z, int(Mold.x), int(Mold.y))
    return z


def trim(d, w1, h1, is_trim=True):
    """
    Trim side(s) of an oversized image.

    d: dict
        Image Preset

    w1, h1: numeric
        width, height of image

    is_trim: bool
        If True, then calculate the mold rectangle.
    """
    x, y, w, h = Place.get_rect()
    ratio_w = w / w1
    ratio_h = h / h1

    # the mold scale factor, 'f'.
    # the Place scale factor, 'f1'
    if ratio_w < ratio_h:
        # The image height is closer to the Place height.
        f = ratio_h
        f1 = h1 / h

    else:
        # The image width is closer to the Place width.
        f = ratio_w
        f1 = w1 / w

    Source.set_rect(.0, .0, w1, h1)
    trim_oversize(d[ok.JUSTIFICATION], w * f1, h * f1)

    if is_trim:
        # The mold rectangle is derived from the image rectangle.
        Mold.set_rect(x, y, round(Source.w * f), round(Source.h * f))


def trim_oversize(n, w, h):
    """
    Set the Source rectangle given a target scale. The justification
    determines the side(s) where clipping is applied.

    n: string
        image justification

    w, h: float
        Is the target's size.
    """
    x1, y1, w1, h1 = Source.get_rect()

    # x-vector
    # Check for oversized vector.
    if w < w1:
        # oversized
        w2 = w

        if n in ju.CENTER_X:
            x2 = (w1 / 2. + x1) - w / 2.

        elif n in ju.LEFT:
            x2 = x1

        else:
            # right
            x2 = x1 + w1 - w

    else:
        # no change
        x2 = x1
        w2 = w1

    # y-vector
    if h < h1:
        # oversized
        h2 = h

        if n in ju.CENTER_Y:
            y2 = (h1 / 2. + y1) - h / 2.

        elif n in ju.TOP:
            y2 = y1
        else:
            # bottom
            y2 = y1 + h1 - h

    else:
        # no change
        y2 = y1
        h2 = h1
    Source.set_rect(*map(round, (x2, y2, w2, h2)))


ROUTE_MOLD = {
    ok.COVER: mold_cover,
    fz.CROP: mold_crop,
    fz.FACTOR: mold_factor,
    ok.FILLED: mold_fill,
    fz.FIXED: mold_fixed,
    ok.LOCKED: mold_lock,
    ok.TRIM: mold_trim
}
