#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb  # type: ignore
from roller_a_contain import Run
from roller_constant_for import Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import ready_canvas_rect, ready_shape
from roller_fu import add_layer, select_shape, verify_layer
from roller_fu_comm import show_err
from roller_view_hub import do_mod, set_gimp_brush
from roller_view_real import get_light

'''Define 'deco_line' as having Model/Branch/Line output function.'''


def add_line_layer(j, maya):
    """
    Add a layer named after "Material" to the top of the Maya's group.

    j: GIMP image
        Is render.

    maya: Maya
    Return: layer
        newly added
    """
    return add_layer(j, "Material", maya.group, get_light(maya))


def do(maya, make):
    """
    Create Line for a navigation branch.

    maya: Maya
    Return: layer or None
        Line material
    """
    # Line Preset, 'd'
    d = maya.value_d

    if not Run.x:
        # Preserve.
        mode = d[ok.MODE]
        color = d[ok.RW1][ok.COLOR_1]

        # Plan override.
        d[ok.MODE] = "Normal"
        d[ok.RW1][ok.COLOR_1] = {
            ny.CANVAS: fy.CANVAS_LINE_COLOR,
            ny.CELL: fy.CELL_LINE_COLOR,
            ny.FACE: fy.FACE_LINE_COLOR,
            ny.FACING: fy.FACE_LINE_COLOR
        }[maya.any_group.render_key[-2]]

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.BRW][ok.MOD])

    if not Run.x:
        # Restore.
        d[ok.MODE] = mode
        d[ok.RW1][ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_canvas(maya):
    """
    Draw Canvas/Line.

    maya: Maya
    Return: layer or None
        Line material
    """
    return do(maya, make_canvas)


def do_cell_main(maya):
    """
    Draw Cell/Line/Per.

    maya: Maya
    Return: layer or None
        Line material
    """
    return do(maya, make_cell_main)


def do_cell_per(maya):
    """
    Draw Cell/Line/Per.

    maya: Maya
    Return: layer or None
        Line material
    """
    return do(maya, make_cell_per)


def do_facial_main(maya):
    """
    Draw Face or Facing Line/Per.

    maya: Maya
    Return: layer or None
        Line material
    """
    return do(maya, make_facial_main)


def do_facial_per(maya):
    """
    Draw Line for Face or Facing/Line/Per.

    maya: Maya
    Return: layer or None
        Line material
    """
    return do(maya, make_facial_per)


def make_canvas(maya, d):
    """
    Draw Canvas/Line material.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        Line material
    """
    j = Run.j
    z = add_line_layer(j, maya)

    ready_canvas_rect(maya, d)

    if not pdb.gimp_selection_is_empty(j):
        prep_line(d)
        pdb.gimp_drawable_edit_stroke_selection(z)
    return verify_layer(z)


def make_cell_main(maya, d):
    """
    Create material Cell/Line main.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        Line material
    """
    j = Run.j
    z = add_line_layer(j, maya)

    prep_line(d)

    # cell key, 'k'
    for k in maya.main_q:
        maya.k = k
        ready_shape(maya, d)
        if not pdb.gimp_selection_is_empty(j):
            pdb.gimp_drawable_edit_stroke_selection(z)
    return verify_layer(z)


def make_cell_per(maya, d):
    """
    Make output for Cell/Line/Per.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        Line material
    """
    j = Run.j
    z = add_line_layer(j, maya)

    ready_shape(maya, d)

    if not pdb.gimp_selection_is_empty(j):
        prep_line(d)
        pdb.gimp_drawable_edit_stroke_selection(z)
    return verify_layer(z)


def make_facial_main(maya, d):
    """
    Make output for Face or Facing Line/Per.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        Line material
    """
    j = Run.j
    z = add_line_layer(j, maya)

    prep_line(d)

    for k in maya.main_q:
        select_shape(j, maya.model.get_facing_shape(k))
        if not pdb.gimp_selection_is_empty(j):
            # Can throw an error if the image size is too small.
            try:
                pdb.gimp_drawable_edit_stroke_selection(z)
            except Exception as ex:
                show_err(ex)
    return verify_layer(z)


def make_facial_per(maya, d):
    """
    Make output for Face or Facing Line/Per.

    maya: Maya
    d: dict
        Line Preset

    Return: layer or None
        Line material
    """
    j = Run.j
    z = add_line_layer(j, maya)

    select_shape(j, maya.model.get_facing_shape(maya.k))

    if not pdb.gimp_selection_is_empty(j):
        prep_line(d)
        pdb.gimp_drawable_edit_stroke_selection(z)
    return verify_layer(z)


def prep_line(d):
    """
    Prepare to draw Line.

    d: dict
        Line Preset
    """
    set_gimp_brush(d[ok.RW1][ok.BRUSH])
    pdb.gimp_context_set_antialias(1)
    pdb.gimp_context_set_brush_angle(.0)
    pdb.gimp_context_set_brush_hardness(d[ok.HARDNESS])
    pdb.gimp_context_set_brush_size(d[ok.LINE_W])
    pdb.gimp_context_set_foreground(d[ok.RW1][ok.COLOR_1])
    pdb.gimp_context_set_opacity(100.)
