#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant_for import Signal as si
from roller_constant_key import Widget as wk
from roller_widget import Widget
import gtk  # type: ignore

'''Define sub-GTK Radio Widget and a Radio Button manager, RadioGroup.'''


class RadioGroup:
    """Use to manage a group of RadioButtons."""

    def __init__(self, q, k):
        """
        Receive the RadioButtons. The RadioButtons
        are assumed to be part of the same group.

        q: iterable
            group of related RadioButtons

        k: string
            group key
        """
        self.widget_q = q[:]
        self.key = k

    def get_a(self):
        """
        Find the active RadioButton. There's
        always one RadioButton that is active.

        Return: int
            index into group
            in 0 to n
        """
        for x, g in enumerate(self.widget_q):
            if g.get_a():
                return x

        # fail-safe
        return 0

    def set_a(self, x):
        """
        Set a RadioButton in the group as active. Only
        one RadioButton in a group can be active.

        x: integer
            index into group
        """
        # Repair.
        x = x if isinstance(x, int) else 0

        self.widget_q[x].set_a(1)

    def hide(self):
        """Hide the RadioButtons in this group."""
        for i in self.widget_q:
            i.hide()

    def show(self):
        """Show the RadioButtons in this group."""
        for i in self.widget_q:
            i.show()


class RadioButton(Widget):
    """
    Is a GTK RadioButton attached to an GTK Alignment.
    RadioButtons are grouped together and identify
    their group by referencing their first member.
    """
    change_signal = 'toggled'

    def __init__(self, **d):
        """
        d: dict
            Initialize the Widget.
        """
        g = gtk.RadioButton(d[wk.RADIO_GROUP], d[wk.TEXT][d[wk.LABEL_X]])

        Widget.__init__(self, g, **d)
        self.add(g)

    def get_a(self):
        """
        Get the value of the RadioButton.

        Return: int
            0 or 1
        """
        return self.widget.get_active()

    def set_a(self, a):
        """
        Set the value of the RadioButton.

        a: int
            0 or 1
        """
        self.widget.set_active(int(a))


class Radio(Widget):
    """Is a super class for the Radio-type classes."""
    change_signal = 'toggled'
    has_table_label = False

    def __init__(self, **d):
        """
        Create the Widgets.

        d: dict
            Has Init values.
        """
        # Is set by the Table container.
        group = self.label = None

        q = self.widget_q = []

        for x in range(len(d[wk.TEXT])):
            q += [RadioButton(**dict(d, label_x=x, radio_group=group))]
            group = q[0].widget

        Widget.__init__(self, q[0].widget, **d)

        # GTK container for the radio buttons
        self.box = d[wk.BOX]

        for i in q:
            self.box.pack_start(i, expand=True)

        self.add(self.box)

        self.radio_group = RadioGroup(q, self.key)
        if wk.TIPS in d:
            for x, i in enumerate(q):
                i.widget.set_tooltip_text(d[wk.TIPS][x])

    def get_a(self):
        """
        Get the value of the RadioGroup.

        Return: int
            index to the active RadioButton
        """
        return self.radio_group.get_a()

    def hide(self):
        """Hide the Buttons and their Label."""
        if self.box:
            if self.box.get_visible():
                self.box.hide()
        self.label_box.hide()

    def set_a(self, x):
        """
        Set the value in the RadioGroup.

        x: int
            index to a RadioButton
        """
        self.radio_group.set_a(int(x))
        self.on_voter_change(self.widget)

    def show(self):
        """Hide the Buttons and their Label."""
        if self.box:
            if not self.box.get_visible():
                self.box.show()
        self.label_box.show()


class RadioRandom(Radio):
    """Randomize select state."""

    def __init__(self, **d):
        Radio.__init__(self, **d)
        self.any_group.connect(si.RANDOMIZE, self.randomize)

    def randomize(self, *_):
        """Randomize the Widget value."""
        self.set_a(randint(0, len(self.widget_q) - 1))


class RadioRandomColumn(RadioRandom):
    """Create a VBox with RadioButtons."""

    def __init__(self, **d):
        """
        d: dict
            Initialize thw Widget.
        """
        d[wk.BOX] = gtk.VBox()
        RadioRandom.__init__(self, **d)


class RadioRandomRow(RadioRandom):
    """Create a HBox with RadioButtons."""

    def __init__(self, **d):
        """
        d: dict
            Initialize thw Widget.
        """
        d[wk.BOX] = gtk.HBox()
        RadioRandom.__init__(self, **d)


class RadioRow(Radio):
    """Is a Table suited Row Widget that does not randomize."""

    def __init__(self, **d):

        """
        d: dict
            Initialize thw Widget.
        """
        d[wk.BOX] = gtk.HBox()
        Radio.__init__(self, **d)


class SwitchRadio(Radio):
    """Randomize switch state."""

    def __init__(self, **d):

        """
        d: dict
            Initialize thw Widget.
        """
        d[wk.BOX] = gtk.HBox()
        Radio.__init__(self, **d)
        self.any_group.connect(si.RANDOMIZE, self.randomize)

    def randomize(self, *_):
        """Turn on the Switch."""
        self.set_a(1)
