#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CHANNEL_OP_INTERSECT, pdb   # type: ignore
from roller_a_contain import Deco, Run
from roller_constant_for import Deco as dc, Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import (
    add_group_type,
    make_deco_material,
    prep_below_type,
    create_facial_per,
    create_facial_main,
    ready_canvas_rect,
    ready_shape,
    test_image,
    transform_foam
)
from roller_deco_paint import paint
from roller_fu import (
    add_layer,
    clear_inverse_selection,
    load_selection,
    remove_z,
    select_item,
    select_polygon,
    select_rect,
    select_shape,
    verify_layer,
    verify_layer_group
)
from roller_view_hub import do_mod
from roller_view_real import get_light

'''Define 'deco_fringe' as having Model/Branch/Fringe output function.'''


def add_fringe_layer(maya, j, group, n):
    """
    Produce a view-sized layer for Fringe's select polygon.

    Return: layer
        newly added
    """
    return add_layer(j, n, group, get_light(maya))


def apply_deco_material(maya, z, d):
    """
    Apply deco material to a selection.

    z: layer
        Has raw Fringe material.

    d: dict
        Fringe Preset
    """
    # As Is and Multi-Color are no ready-to-go.
    if d[ok.TYPE] not in (dc.AS_IS, dc.MULTI_COLOR):
        n = z.name
        group = z.parent

        select_item(z)
        pdb.gimp_image_remove_layer(z.image, z)

        z = make_deco_material(maya, d, group)
        if z:
            z.name = n
    return z


def create_face(maya, d, group):
    """
    Create Face material.

    maya: Maya
    d: dict
        Fringe Preset

    group: layer
        Is the parent layer of Face output.
    """
    k = maya.k
    model = maya.model
    if test_image(maya, d):
        maya.rect = model.get_facing_rect(k)
        Deco.shape = model.get_facing_form(k)
        z = paint_shape(maya, d, group)
        if z:
            transform_foam(maya.rect, z, model.get_facing_foam(k))


def create_facing(maya, d, group):
    """
    Create Facing material.

    maya: Maya
    d: dict
        Fringe Preset

    group: layer or None
        Is the parent layer of Facing output.
    """
    j = Run.j
    k = maya.k
    model = maya.model
    if test_image(maya, d):
        maya.rect = model.get_facing_rect(k)
        n = d[ok.TYPE]

        if n in (dc.MEAN_COLOR, dc.COLOR):
            is_color = True
            Deco.shape = model.get_facing_shape(k)
            select_polygon(j, Deco.shape)

        else:
            Deco.shape = model.get_facing_form(k)
            is_color = False
            select_rect(Run.j, *maya.rect)

        # The As Is Fringe Type doesn't create a layer.
        z = make_deco_material(maya, d, group)

        if z and not is_color:
            z = transform_foam(maya.rect, z, model.get_facing_foam(k))

        z1 = add_fringe_layer(maya, j, group, n)

        select_shape(j, model.get_facing_shape(k))
        paint_sel(z1, d)

        if n in (dc.AS_IS, dc.MULTI_COLOR):
            remove_z(z)
        else:
            if z:
                select_item(z1)
                clear_inverse_selection(z)
            remove_z(z1)


def do(maya, make):
    """
    Make Fringe material. If the view run is a Plan-type,
    adjust the option settings to produce Plan output.

    maya: Maya
    make: function
        Create Fringe layer.

    Return: layer or None
        matter
    """
    d = maya.value_d

    if not Run.x:
        # Preserve.
        type_ = d[ok.TYPE]
        mode = d[ok.MODE]
        color = d[ok.COLOR_1]

        # Plan override.
        d[ok.TYPE] = dc.COLOR
        d[ok.MODE] = "Normal"
        d[ok.COLOR_1] = {
            ny.CELL: fy.CELL_FRINGE_COLOR,
            ny.CANVAS: fy.CANVAS_FRINGE_COLOR,
            ny.FACE: fy.FACE_FRINGE_COLOR,
            ny.FACING: fy.FACE_FRINGE_COLOR
        }[maya.any_group.render_key[-2]]

    z = make(maya, d)

    if z:
        do_mod(z, d[ok.BRW][ok.MOD])

    if not Run.x:
        # Restore.
        d[ok.TYPE] = type_
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_canvas(maya):
    """
    Make Canvas/Fringe output.

    maya: Maya
    Return: layer or None
        Fringe material
    """
    return do(maya, make_canvas)


def do_cell_main(maya):
    """
    Make Fringe/Cell for main.

    maya: Maya
    Return: layer or None
        Fringe material
    """
    return do(maya, make_cell_main)


def do_cell_per(maya):
    """
    Make Fringe for Cell/Per.

    maya: Maya
    Return: layer or None
        Fringe material
    """
    return do(maya, make_cell_per)


def do_face_main(maya):
    """
    Draw Fringe/Face for main.

    maya: Maya
    Return: layer or None
        Fringe material
    """
    return do(maya, make_face_main)


def do_face_per(maya):
    """
    Draw Face/Per Fringe.

    maya: Maya
    Return: layer or None
        Fringe material
    """
    return do(maya, make_face_per)


def do_facing_main(maya):
    """
    Draw Face/Fringe for main.

    maya: Maya
    Return: layer or None
        Fringe material
    """
    return do(maya, make_facing_main)


def do_facing_per(maya):
    """
    Draw Facing/Fringe for Per.

    maya: Maya
    Return: layer or None
        Fringe material
    """
    return do(maya, make_facing_per)


def make_canvas(maya, d):
    """
    Draw Canvas/Fringe material.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        Fringe material
    """
    if test_image(maya, d):
        prep_below_type(d, maya.group)
        ready_canvas_rect(maya, d, option=None)
        return verify_layer(paint_shape(maya, d, maya.group))


def make_cell_main(maya, d):
    """
    Create Cell/Fringe for main.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        Fringe material
    """
    def _do_many_material():
        """
        The cells have the same Fringe material, but
        the material has to be applied cell-by-cell.
        """
        prep_below_type(d, parent)

        for _k in maya.main_q:
            maya.k = _k
            if test_image(maya, d):
                ready_shape(maya, d)
                paint_shape(maya, d, group)
        return verify_layer_group(group)

    def _do_one_material():
        """
        The cells have the same Fringe material,
        so the output is combined on one layer.
        """
        for _k in maya.main_q:
            _z = add_fringe_layer(maya, j, group, "Material")
            maya.k = _k

            ready_shape(maya, d)
            paint_sel(_z, d)

        _z = verify_layer_group(group)
        if _z:
            return apply_deco_material(maya, _z, d)

    j = Run.j
    parent = maya.group
    group = add_group_type(maya, d)
    n = d[ok.TYPE]

    if n in dc.FRINGE_PER_TYPE:
        return _do_many_material()
    else:
        # All the Fringe is the same
        # material and is applied one time.
        return _do_one_material()


def make_cell_per(maya, d):
    """
    Make Cell/Fringe for Per.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        Fringe material
    """
    if test_image(maya, d):
        prep_below_type(d, maya.group)
        ready_shape(maya, d)
        return verify_layer(paint_shape(maya, d, maya.group))


def make_face_main(maya, d):
    """
    Create Face/Fringe for main.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        Fringe material
    """
    return create_facial_main(maya, d, create_face)


def make_face_per(maya, d):
    """
    Make Face/Fringe for Per.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        fringe
    """
    return create_facial_per(maya, d, create_face)


def make_facing_main(maya, d):
    """
    Create Facing/Fringe for main.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        Fringe material
    """
    return create_facial_main(maya, d, create_facing)


def make_facing_per(maya, d):
    """
    Make Facing/Fringe for Per.

    maya: Maya
    d: dict
        Fringe Preset

    Return: layer or None
        Fringe material
    """
    return create_facial_per(maya, d, create_facing)


def paint_shape(maya, d, group):
    """
    Paint Fringe and apply material.

    maya: Maya
    d: dict
        Fringe Preset

    group: layer
        Is the parent of Fringe output.

    Return: layer or None
        Fringe material
    """
    j = Run.j
    z = add_fringe_layer(maya, j, group, d[ok.TYPE])

    select_shape(j, Deco.shape)
    paint_sel(z, d)
    return apply_deco_material(maya, z, d)


def paint_sel(z, d):
    """
    Paint Fringe inside a selection. The selection may contract
    by 'paint', but material is clipped outside of the original selection.

    z: layer
        Receive Fringe.

    d: dict
        Fringe dict
    """
    j = Run.j
    if not pdb.gimp_selection_is_empty(j):
        sel = pdb.gimp_selection_save(j)

        paint(z, d)
        select_item(z)
        load_selection(j, sel, option=CHANNEL_OP_INTERSECT)
        clear_inverse_selection(z)
        pdb.gimp_image_remove_channel(j, sel)
