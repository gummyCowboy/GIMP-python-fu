#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    CHANNEL_OP_ADD, CHANNEL_OP_INTERSECT, CHANNEL_OP_SUBTRACT, pdb
)
from roller_a_contain import Globe, Run
from roller_constant_key import Material as ma, Option as ok
from roller_frame import (
    make_canvas_frame_sel, do_emboss_sel, select_wrap
)
from roller_frame_alt import FrameBasic
from roller_fu import (
    add_layer,
    dilate,
    load_selection,
    select_item,
    select_opaque,
    select_rect,
    verify_layer
)
from roller_view_real import get_light

'''
Define 'frame_circuit' as a Maya-subtype
for managing a variation of Frame type.
'''


def do_matter(maya):
    """
    Make the frame.

    maya: Circuit/Wrap
    Return: layer
        Wrap 'matter'
    """
    j = Run.j
    d = maya.value_d
    e = maya.super_maya.value_d[ok.BRW][ok.FILLER_CI]
    x, y, w, h = maya.model.canvas_rect

    select_wrap(j, maya.cast.matter, d[ok.WIDTH], d[ok.TYPE])

    sel = pdb.gimp_selection_save(j)

    # Canvas frame
    pdb.gimp_selection_none(j)
    make_canvas_frame_sel(maya, e)

    sel1 = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)

    # layer for the maze, 'z'
    z = add_layer(j, "Material", None, 0)

    pdb.gimp_context_set_foreground((0, 0, 0))
    pdb.gimp_context_set_background((255, 255, 255))
    pdb.plug_in_maze(
        j, z,
        int(max(1, w // e[ok.COLUMN])),     # passage scale
        int(max(1, h // e[ok.ROW])),        # passage scale
        1,                                      # yes, tileable
        0,                                      # depth first algorithm
        int(e[ok.SEED] + Globe.seed),
        0,                                      # multiple, not clearly defined
        0                                       # offset, not clearly defined
    )

    # amount, '1.'; no wrap, '0'; Sobel, '0'
    pdb.plug_in_edge(j, z, 1., 0, 0)

    w1 = max(1., e[ok.LINE_W] // 2. - 1.)

    for _ in range(int(w1)):
        dilate(z)

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    select_item(z)
    pdb.gimp_image_remove_layer(j, z)

    # layer for the combined frame, 'z'
    z = add_layer(j, "Material", maya.group, get_light(maya))

    for i in (sel, sel1):
        load_selection(j, i, option=CHANNEL_OP_ADD)
        pdb.gimp_image_remove_channel(j, i)

    select_opaque(maya.cast.matter, option=CHANNEL_OP_SUBTRACT)
    select_rect(Run.j, x, y, w, h, option=CHANNEL_OP_INTERSECT)
    return verify_layer(do_emboss_sel(z, d))


class Circuit(FrameBasic):
    filler_k = ok.FILLER_CI
    kind = material = ma.CIRCUIT
    wrap_k = ok.WRAP

    def __init__(self, any_group, super_maya, k_path):
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
        self.add_filler_k_path(k_path)
