#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    HISTOGRAM_BLUE,
    HISTOGRAM_GREEN,
    HISTOGRAM_RED,
    LAYER_MODE_ADDITION,
    LAYER_MODE_BURN,
    LAYER_MODE_OVERLAY,
    LAYER_MODE_SCREEN,
    LAYER_MODE_VIVID_LIGHT,
    pdb
)
from roller_a_contain import Globe, Run
from roller_constant_key import Material as ma, Option as ok
from roller_frame import do_selection
from roller_frame_alt import FrameBasic
from roller_fu import (
    clone_layer,
    get_layer_position,
    make_layer_group,
    merge_layer_group,
    saturate
)
from roller_view_hub import brush_stroke, do_curves, prep_brush, set_gimp_brush

'''
Define 'frame_joint' as a Maya-subtype
for managing a variation of Frame type.
'''


def do_matter(maya):
    """
    Add a frame to the image material on a layer.

    maya: Wrap
    Return: layer
        Wrap 'matter'
    """
    # Wrap Preset, 'd'
    d = maya.value_d
    init_brush(d)
    return do_selection(
        maya, do_sel, embellish, "Material", is_clear=d[ok.CLIP]
    )


def do_sel(maya, z):
    """
    Make a frame from a selection.

    maya: Joint
    z: layer
        Receive the frame.

    Return: layer
        Wrap material
    """
    j = Run.j
    d = maya.value_d

    pdb.plug_in_sel2path(j, z)
    pdb.gimp_context_set_opacity(100.)

    if j.active_vectors:
        for stroke in j.active_vectors.strokes:
            brush_stroke(
                z,
                'dots',
                d[ok.BRUSH_SIZE],
                stroke,
                d[ok.BRUSH_SIZE] / 15.,
                .0
            )
        pdb.gimp_image_remove_vectors(j, j.active_vectors)
    return z


def embellish(maya, z):
    """
    Add color and depth to frame material.

    maya: Maya
        not used

    z: layer
        Has frame.

    Return: layer
        Wrap material
    """
    j = Run.j
    group = make_layer_group(j, "Wrap", z.parent, get_layer_position(z), z=z)
    z1 = clone_layer(z)
    z1.mode = LAYER_MODE_OVERLAY
    z1.opacity = 25.
    z1 = clone_layer(z1)
    z1.mode = LAYER_MODE_BURN
    z1.opacity = 25.

    pdb.plug_in_emboss(
        j, z,
        Globe.azimuth,
        Globe.elevation,
        3,                              # depth
        1                               # emboss
    )
    do_curves(z, (.0, .2, 8., .6, 1., 1.))

    z1 = clone_layer(z)
    z2 = clone_layer(z1)
    z3 = clone_layer(z2)
    z1.mode = LAYER_MODE_VIVID_LIGHT
    z1.opacity = 80.
    z2.mode = LAYER_MODE_SCREEN
    z3.mode = LAYER_MODE_ADDITION
    z = merge_layer_group(group)

    pdb.gimp_drawable_curves_spline(
        z,
        HISTOGRAM_RED,
        6,                              # coordinate count
        (.0, .0, .5, .8, 1., 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        HISTOGRAM_GREEN,
        6,                              # coordinate count
        (.0, .0, .5, .3, 1., 1.)
    )
    pdb.gimp_drawable_curves_spline(
        z,
        HISTOGRAM_BLUE,
        8,                              # coordinate count
        (.0, .0, .2, .06, .7, .5, 1., 1.)
    )
    saturate(z, -33.)
    return z


def init_brush(d):
    """Initialize the brush before stroking the frame."""
    prep_brush()
    set_gimp_brush("dots")
    pdb.gimp_context_set_brush_size(d[ok.BRUSH_SIZE])


class Joint(FrameBasic):
    is_embossed = True
    kind = material = ma.JOINT
    wrap_k = ok.WRAP_JO

    def __init__(self, any_group, super_maya, k_path):
        """
        any_group: AnyGroup
            Owns the option.

        super_maya: Maya
            super type
            Is from the AnyGroup where the Frame Widget resides.

        k_path: tuple
            Key path of the Frame Button in its vote dict.
        """
        FrameBasic.__init__(self, any_group, super_maya, k_path, do_matter)
