#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import FILL_PATTERN, pdb  # type: ignore
from roller_constant_key import Option as ok
from roller_fu import merge_layer_group
from roller_maya_style import Style, make_background
from roller_view_hub import do_mod, set_fill_context, set_gimp_pattern
from roller_view_real import add_sub_base_group

'''
Define 'backdrop/pattern_fill' as a Maya-subtype
for managing a variation of backdrop style layer.
'''


def make_style(maya):
    """
    Make the Backdrop Style.

    maya: PatternFill
    Return: layer
        Backdrop Style output
    """
    d = maya.value_d
    parent = add_sub_base_group(maya)
    z = make_background(parent)

    set_fill_context(d)
    set_gimp_pattern(d[ok.RW1][ok.PATTERN])
    pdb.gimp_drawable_edit_bucket_fill(z, FILL_PATTERN, .0, .0)

    z = merge_layer_group(parent)

    do_mod(z, d[ok.RW1][ok.MOD])
    return maya.rename_layer(z)


class PatternFill(Style):
    """Create Backdrop Style output."""

    def __init__(self, *q):
        self.init_background(*q + (make_style,))
