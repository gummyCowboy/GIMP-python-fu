#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import (   # type: ignore
    ADD_MASK_SELECTION,
    CHANNEL_OP_ADD,
    CHANNEL_OP_REPLACE,
    CHANNEL_OP_SUBTRACT,
    CLIP_TO_IMAGE,
    FILL_PATTERN,
    GRADIENT_BLEND_RGB_PERCEPTUAL,
    pdb
)
from roller_a_contain import Deco, Globe, One, Run
from roller_constant_for import Deco as dc, Gradient as fg
from roller_constant_key import Option as ok
from roller_deco_mask import ROUTE_MASK
from roller_fu import (
    add_layer,
    clear_inverse_selection,
    copy_all_image,
    get_select_bounds,
    get_select_coord,
    isolate_selection,
    load_selection,
    make_clouds,
    make_layer_group,
    merge_layer_group,
    paste_layer,
    remove_layers,
    remove_z,
    select_item,
    select_rect,
    select_shape,
    shape_clipboard,
    verify_layer,
    verify_layer_group
)
from roller_image_grind import ref_get_image
from roller_many_rect import Rect
from roller_view_hub import (
    color_selection_default,
    get_mean_color,
    get_gradient_points,
    set_fill_context_default,
    set_gimp_gradient,
    set_gimp_pattern
)
from roller_view_real import clip_to_view, get_light, insert_copy
import math

'''Define 'deco' as having Model/Branch/Leaf output function.'''


def add_group_mask(j, z):
    """
    Make a mask group for merging mask output.

    j: GIMP image
        Receive layer group.

    z: layer
        Its parent is the group's parent.

    Return: layer
        the new group
    """
    return make_layer_group(j, "Mask Group", z.parent, 0)


def add_group_type(maya, d):
    """
    Make a deco's Type group. A Type group is eventually merged.
    Depends on 'maya.group'.

    d: dict
        deco type Preset

    Return: layer
        the new group
    """
    return make_layer_group(
        Run.j, d[ok.TYPE], maya.group, get_light(maya)
    )


def attach_mask_sel(z):
    """
    Attach a mask layer, made from a selection, to another layer.
    Depends upon a mask selection and an actual layer.

    z: layer
        Receive mask.

    Return: mask or None
        newly created
    """
    if z:
        if not pdb.gimp_selection_is_empty(z.image):
            mask = pdb.gimp_layer_create_mask(z, ADD_MASK_SELECTION)

            pdb.gimp_layer_add_mask(z, mask)
            return mask


def create_face_main_mask(maya, d):
    """
    Apply Box Face Mask for main.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer
        mask material
    """
    j = Run.j
    z = maya.matter
    group = add_group_mask(j, z)

    for k in maya.main_q:
        create_facial_mask(maya, group, d, k)
    return finish_facing_mask(z, group)


def create_facial_main(maya, d, p):
    """
    Create Face output for main.

    maya: Maya
    d: dict
        deco type Preset

    p: function
        Produce output.

    Return: layer or None
        facial material
    """
    group = add_group_type(maya, d)

    prep_below_type(d, group)

    for k in maya.main_q:
        maya.k = k
        p(maya, d, group)
    return verify_layer_group(group)


def create_facial_per(maya, d, p):
    """
    Make deco for Face or Facing Per.

    maya: Maya
    d: dict
        deco type Preset

    p: function
        Produce output.

    Return: layer or None
        facial material
    """
    group = add_group_type(maya, d)

    prep_below_type(d, group)
    p(maya, d, group)
    return verify_layer_group(group)


def create_facing_main_mask(maya, d):
    """
    Apply Facing mask for main.

    maya: Maya
    d: dict
        Mask Preset

    p: function
        Make cell Facing Mask.

    Return: layer
        mask
    """
    j = Run.j
    z = maya.matter
    model = maya.model
    group = add_group_mask(j, z)

    for k in maya.main_q:
        z1 = create_facial_mask(maya, group, d, k)
        model.clip_facing(z1, k)
    return finish_facing_mask(z, group)


def do_clouds(maya, z):
    """
    Fill a selection with solid noise.

    maya: Maya
    z: layer
        Receive clouds.

    Return: layer
        clouds
    """
    make_clouds(z, int(maya.value_d[ok.SEED] + Globe.seed))
    return z


def do_color(maya, z):
    """
    Fill a selection with a color. Is context sensitive.

    maya: Maya
    z: layer
        Receive color.

    Return: layer
        color
    """
    color = maya.value_d[ok.COLOR_1]

    color_selection_default(z, color)
    return z


def do_gradient(maya, z):
    """
    Fill a selection with a gradient.

    maya: Maya
    z: layer
        Receive gradient.

    Return: layer
        gradient
    """
    def _draw():
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(d[ok.GRADIENT_TYPE]),
            0,                 # gradient offset
            1,                 # Super sample is true.
            3,                 # super sample max depth
            .0,                # super sample threshold all
            1,                 # Dither is true.
            start_x, start_y,
            end_x, end_y
        )

    j = Run.j
    d = maya.value_d
    sel = pdb.gimp_selection_save(j)

    # Begin rectangle calculation.
    # The gradient draws in a rectangle space which
    # is made by the greater bounds of the intersection
    # of the canvas rectangle and the current selection.
    x, y, w, h = maya.rect
    x1, y1, x2, y2 = get_select_coord(j)
    x = min(max(.0, x), x1)
    y = min(max(.0, y), y1)
    w = max(w, x2 - x1)
    h = max(h, y2 - y1)
    # End rectangle calculation.

    set_fill_context_default()
    set_gimp_gradient(d)
    pdb.gimp_context_set_gradient_blend_color_space(
        GRADIENT_BLEND_RGB_PERCEPTUAL
    )
    pdb.gimp_context_set_gradient_reverse(0)

    start_x, end_x, start_y, end_y = get_gradient_points(d, x, y, w, h)

    select_rect(j, x, y, w, h)
    _draw()
    load_selection(j, sel)
    clear_inverse_selection(z)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def do_image(maya, z):
    """
    Fill a selection with an image.

    maya: Maya
    z: layer
        Receive image.

    Return: layer or None
        image
    """
    j = Run.j
    j1 = ref_get_image(maya.any_group, maya.k, 0)
    sel = pdb.gimp_selection_save(j)
    x, y, x1, y1 = pdb.gimp_selection_bounds(j)[1:]
    w, h = x1 - x, y1 - y

    if j1:
        pdb.gimp_selection_none(j)
        copy_all_image(j1)
        shape_clipboard(w, h)

        z1 = paste_layer(z)

        pdb.gimp_layer_set_offsets(z1, x, y)

        # Resize the pasted layer.
        z = pdb.gimp_image_merge_down(z.image, z1, CLIP_TO_IMAGE)

        if sel:
            load_selection(j, sel)
            clear_inverse_selection(z)

    else:
        remove_z(z)
        z = None

    if sel:
        pdb.gimp_image_remove_channel(j, sel)
    return z


def do_mean_color(maya, z):
    """
    Make a Mean Color layer. The Mean
    Color is calculated from a selection.

    maya: Maya
        not used

    z: layer
        Receive mean color.

    Return: layer
        mean color
    """
    color = get_mean_color(Deco.bg_z)

    color_selection_default(z, color)
    return z


def do_netting(maya, z):
    """
    Fill a selection with netting material.

    maya: Maya
    z: layer
        Receive netting.

    Return: layer
        netting
    """
    j = Run.j
    d = maya.value_d
    w = int(d[ok.NLS])
    color = d[ok.COLOR_1]
    w1 = int(d[ok.NET_LINE_W])
    x, y = get_select_bounds(j)[1:3]
    x, y = map(int, (x, y))
    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    pdb.plug_in_grid(
        j, z,
        w1, w, y,
        color,
        255,           # opacity
        w1, w, x,
        color,
        255,           # opacity
        0, 0, 0,
        color,
        255
    )
    isolate_selection(z, sel)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def do_pattern(maya, z):
    """
    Fill a selection with a pattern.

    maya: Maya
    z: layer
        Receive pattern.

    Return: layer
        pattern
    """
    d = maya.value_d

    set_fill_context_default()
    set_gimp_pattern(d[ok.PATTERN])
    pdb.gimp_drawable_edit_bucket_fill(z, FILL_PATTERN, .0, .0)
    return z


def do_plasma(maya, z):
    """
    Fill a selection with plasma.

    maya: Maya
    z: layer
        Receive plasma.

    Return: layer
        plasma
    """
    j = Run.j
    d = maya.value_d
    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z, int(d[ok.SEED] + Globe.seed), 3.)
    isolate_selection(z, sel)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def feather_mask(j, d):
    """
    Feather a Mask selection.

    j: GIMP image
        Is the render.

    d: dict
        Mask Preset

    Return: state of selection
    """
    if not pdb.gimp_selection_is_empty(j) and d[ok.FEATHER]:
        z = add_layer(j, "Feather", None, 0)

        color_selection_default(z, (255, 255, 255))

        a = d[ok.FEATHER]
        f = a / d[ok.STEPS]
        b = f

        while a > b:
            select_item(z)
            pdb.gimp_selection_feather(j, b)

            b += f
            if not pdb.gimp_selection_is_empty(j):
                clear_inverse_selection(z)

        select_item(z)
        remove_z(z)


def finish_backed():
    """
    If a copied background was made in deco production, then remove this copy.
    """
    if Deco.bg_z:
        pdb.gimp_image_remove_layer(Run.j, Deco.bg_z)
        Deco.bg_z = None


def finish_facing_mask(z, group):
    """
    Mask a merged layer group.

    z: layer
        Receive mask.

    group: layer
        Merge to create the mask's selection source.

    Return: drawable
        mask
    """
    z1 = merge_layer_group(group)

    select_item(z1)

    mask = attach_mask_sel(z)

    remove_z(z1)
    return mask


def create_face_per_mask(maya, d):
    """
    Apply Box/Face/Per Mask.

    maya: Mask
    d: dict
        Mask Preset

    Return: layer or None
        mask
    """
    z = maya.matter
    j = Run.j
    group = add_group_mask(j, z)

    create_facial_mask(maya, group, d, maya.k)
    return finish_facing_mask(z, group)


def make_facing_per_mask(maya, d):
    """
    Apply a Box/Facing Mask for Per.

    maya: Mask
    d: dict
        Mask Preset

    Return: layer or None
        mask
    """
    j = Run.j
    z = maya.matter
    group = add_group_mask(j, z)

    create_facial_mask(maya, group, d, maya.k)
    return finish_facing_mask(z, group)


def make_deco_material(maya, d, group):
    """
    Produce deco layer. Require a selection for deco-processing.

    maya: Maya
    d: dict
        deco type Preset

    group: layer
        Is the parent group of the deco output.

    Return: layer or None
        material
    """
    n = d[ok.TYPE]
    if n in ROUTE_DECO:
        if not pdb.gimp_selection_is_empty(Run.j):
            return verify_layer(
                ROUTE_DECO[n](
                    maya, add_layer(Run.j, n, group, get_light(maya))
                )
            )


def make_mask_sel(maya, d):
    """
    Form a mask selection from another selection. The
    selection is the rectangular bounds of the mask.

    maya: Maya
    d: dict
        Mask Preset

    Return: state of selection
        The selection is ready to become a mask.
    """
    j = Run.j
    mask_type = d[ok.TYPE]
    p = ROUTE_MASK.get(mask_type)
    is_sel, x, y, x1, y1 = get_select_bounds(j)

    if is_sel:
        if p:
            w, h = x1 - x, y1 - y
            w1, h1 = w * d[ok.HORZ_SCALE], h * d[ok.VERT_SCALE]

            # Create a mask-selection from the existing selection.
            p(
                j,
                One(
                    d=d,
                    maya=maya,

                    # Is the size of the mask influence, 'scale'.
                    scale=Rect(x + (w - w1) // 2., y + (h - h1) // 2., w1, h1),

                    # Is the size of the cast's alpha, 'sel'.
                    sel=Rect(x, y, w, h),
                )
            )
            if d[ok.CUT_OUT]:
                sel = pdb.gimp_selection_save(j)

                select_rect(j, x, y, w, h)
                load_selection(j, sel, option=CHANNEL_OP_SUBTRACT)
                pdb.gimp_image_remove_channel(j, sel)

        feather_mask(j, d)
        rotate_mask(j, d)
    else:
        pdb.gimp_selection_none(j)


def mask_cell_main(maya, d):
    """
    Mask a main deco layer.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer or None
        mask material
    """
    j = Run.j
    z = maya.matter

    # selection channel, 'sel'
    sel = None

    pdb.gimp_selection_none(j)

    # Create a selection from the main cells.
    for k in maya.main_q:
        maya.k = k
        ready_shape(maya, d)

        if not pdb.gimp_selection_is_empty(j):
            make_mask_sel(maya, d)

        if sel:
            load_selection(j, sel, option=CHANNEL_OP_ADD)
            pdb.gimp_image_remove_channel(j, sel)
        if not pdb.gimp_selection_is_empty(j):
            sel = pdb.gimp_selection_save(j)

    if sel:
        pdb.gimp_image_remove_channel(j, sel)
    return attach_mask_sel(z)


def mask_cell_per(maya, d):
    """
    Mask a cell.

    maya: Maya
    d: dict
        Mask Preset

    Return: mask or None
    """
    z = maya.matter

    select_item(z)
    make_mask_sel(maya, d)
    return attach_mask_sel(z)


def mask_face_main(maya, d):
    """
    Mask Face/Plaque for main.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer
        mask material or None
    """
    return create_face_main_mask(maya, d)


def mask_face_per(maya, d):
    """
    Mask Face/Per output.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer
        mask
    """
    return create_face_per_mask(maya, d)


def mask_facing_main(maya, d):
    """
    Mask Facing for main.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer
        mask material
    """
    return create_facing_main_mask(maya, d)


def mask_facing_per(maya, d):
    """
    Mask Facing/Per output.

    maya: Maya
    d: dict
        Mask Preset

    Return: layer
        mask
    """
    return make_facing_per_mask(maya, d)


def prep_below_type(d, z):
    """
    If the deco type depends on the visible background,
    then create a copy of the background. Both main or
    Per deco, expect the background copy to be set
    when their output function is called.

    d: dict
        deco type Preset

    z: layer
        parent group to place copy
    """
    if z and d.get(ok.TYPE) == dc.MEAN_COLOR:
        Deco.bg_z = insert_copy(None, z.parent, is_hide=True)


def create_facial_mask(maya, group, d, arg):
    """
    Create a mask for transformed Face or Facing.
    Prep GIMP context prior to calling.

    maya: Maya
    group: layer
        destination of output

    d: dict
        Mask Preset

    arg: tuple
        Face or Facing map key

    Return: layer
        mask
    """
    j = Run.j
    z = add_layer(j, "Mask", group, 0)
    maya.rect = maya.model.get_facing_rect(arg)
    w, h = maya.rect[2:]

    select_rect(j, .0, .0, w, h)
    make_mask_sel(maya, d)
    color_selection_default(z, (255, 255, 255))
    return transform_foam(
        (.0, .0, w, h), z, maya.model.get_facing_foam(arg)
    )


def ready_canvas_rect(maya, d, option=CHANNEL_OP_REPLACE):
    """
    Prepare a Canvas rectangle and shape. Select the rectangle
    when 'option' is not None.

    maya: Maya
    d: dict
        deco type Preset

    option: gimpfu enum or None
        If not None, the canvas' rectangle is selected.
    """
    if d.get(ok.OBEY_MARGIN):
        x, y, w, h = maya.rect = maya.model.canvas_pocket.rect

    else:
        x, y, w, h = maya.rect = maya.model.canvas_rect

    x1, y1 = x + w, y + h
    Deco.shape = x, y, x1, y, x1, y1, x, y1
    if option:
        select_shape(Run.j, Deco.shape, option=option)


def ready_shape(maya, d, option=CHANNEL_OP_REPLACE):
    """
    Set 'Deco.shape' and 'maya.rect'. Select
    the shape when 'option' is not None.

    maya: Maya
    d: dict
        deco type Preset

    option: gimpfu enum or None
        If not None, then the shape is selected.
    """
    a = maya.model
    k = maya.k

    # Mask doesn't have the OBEY_MARGIN option.
    if d.get(ok.OBEY_MARGIN, True):
        # the pocket shape
        maya.rect = a.get_pocket_rect(k)
        Deco.shape = a.get_shape(k)

    else:
        maya.rect = a.get_shift_rect(k)
        Deco.shape = a.get_plaque(k)
    if option is not None:
        select_shape(Run.j, Deco.shape, option=option)


def rotate_mask(j, d):
    """
    Rotate a Mask selection.

    j: GIMP image
        Is the render.

    d: dict
        Mask Preset

    Return: state of selection
    """
    if not pdb.gimp_selection_is_empty(j) and d[ok.ANGLE]:
        z = add_layer(j, "Rotate", None, 0)

        color_selection_default(z, (0, 0, 0))

        # auto-center, 'True'; x and y, '0'
        z1 = pdb.gimp_item_transform_rotate(
            z, math.radians(d[ok.ANGLE]), True, .0, .0
        )

        select_item(z1)
        remove_layers((z, z1))


def test_image(maya, d):
    """
    If the deco type is an image, determine if an
    image has been assigned.

    maya: Maya
    d: dict
        deco-type Preset

    Return: bool
        Is True if a valid image is assigned
    """
    if d[ok.TYPE] == dc.IMAGE:
        return bool(ref_get_image(maya.any_group, maya.k, 0))
    return True


def transform_foam(rect, z, q):
    """
    Shape rectangular material into a polygon.

    rect: tuple
        (x, y, w, h)
        input material to transform

    z: layer
        Is disposable input.

    q: tuple
        x, y float series
        (topleft, top-right, bottom-left, bottom-right)

    Return: layer
        the transformed material
    """
    select_rect(Run.j, *rect)

    # Transform the selected material into a floating selection layer.
    z1 = pdb.gimp_item_transform_perspective(z, *q)

    if pdb.gimp_layer_is_floating_sel(z1):
        pdb.gimp_floating_sel_to_layer(z1)
        clip_to_view(z1)

    remove_z(z)
    return z1


# {deco type: function}
ROUTE_DECO = {
    dc.MEAN_COLOR: do_mean_color,
    dc.CLOUDS: do_clouds,
    dc.COLOR: do_color,
    dc.GRADIENT: do_gradient,
    dc.IMAGE: do_image,
    dc.NETTING: do_netting,
    dc.PATTERN: do_pattern,
    dc.PLASMA: do_plasma
}
