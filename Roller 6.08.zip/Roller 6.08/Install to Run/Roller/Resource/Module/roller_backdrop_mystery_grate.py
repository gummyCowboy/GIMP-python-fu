#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import CLIP_TO_IMAGE, pdb  # type: ignore
from roller_a_contain import Run
from roller_backdrop_color_grid import do_color_grid
from roller_constant_for import Gradient as fg
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def_access import get_default_value
from roller_fu import (
    clone_layer,
    create_mask,
    flip_layer,
    merge_layer_group,
    transfer_mask
)
from roller_maya_style import Style
from roller_view_hub import do_gradient_for_layer, do_mod
from roller_view_real import add_sub_base_group, clip_to_wip
from roller_view_shadow import do_stylish_shadow

'''
Define 'backdrop/mystery_grate' as a Maya-subtype
for managing a variation of backdrop style layer.
'''


def do_1st_layer(j, d, e, d1, group):
    """
    Create a diamond-slat layer and a shadow.

    j: GIMP image
        Is the render.

    d: dict
        Color Grid Preset

    e: dict
        Gradient Fill Preset

    d1: dict
        Mystery Grate Preset

    group: layer group
        parent of output
    """
    d[ok.ROW] = 2
    d[ok.COLUMN] = d1[ok.COLUMN_1]
    d[ok.MODE] = "Normal"
    d[ok.ANGLE] = 45.
    z = do_color_grid(d, group)

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    do_stylish_shadow(z)
    create_mask(z)

    e[ok.START_X] = e[ok.START_Y] = 0, 0.
    e[ok.END_X] = e[ok.END_Y] = 0, 1.
    do_gradient(e, z)


def do_2nd_layer(j, d, e, d1, group):
    """
    Process the second layer.

    j: GIMP image
        Is the render.

    d: dict
        Color Grid Preset dict

    e: dict
        Gradient Fill Preset

    d1: dict
        Mystery Grate Preset

    group: layer group
        parent of output
    """
    d[ok.COLUMN] = d1[ok.COLUMN_2]
    z = do_color_grid(d, group)

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    do_stylish_shadow(z)
    create_mask(z)

    e[ok.END_X] = e[ok.END_Y] = 0, 0.
    e[ok.START_X] = e[ok.START_Y] = 0, 1.
    return do_gradient(e, z)


def do_3rd_layer(z):
    """
    Process the third layer.

    z: layer
        Modify.
    """
    z = clone_layer(z)

    flip_layer(z, is_h=True)
    do_stylish_shadow(z)
    create_mask(z)


def do_gradient(d, z):
    """
    Draw a gradient.

    d: dict
        Gradient Fill Preset

    z: layer
        Receive the gradient.

    Return: layer
        gradient
    """
    j = z.image
    z1 = do_gradient_for_layer(d, z.parent, 0)

    transfer_mask(z1, z)
    return pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: MysteryGrate
    Return: layer
        Backdrop Style material
    """
    j = Run.j
    d = maya.value_d
    e = get_default_value(by.GRADIENT_FILL)
    e[ok.GRADIENT] = d[ok.RW1][ok.GRADIENT]
    e[ok.GRADIENT_TYPE] = fg.LINEAR

    e.update(d)

    d1 = get_default_value(by.COLOR_GRID)
    d1[ok.ANGLE] = 45.
    group = add_sub_base_group(maya)
    z = do_gradient_for_layer(e, group, 0)
    z.name = "Base"

    do_1st_layer(j, d1, e, d, group)

    z1 = do_2nd_layer(j, d1, e, d, group)

    do_3rd_layer(z1)

    e[ok.START_X] = e[ok.END_Y] = 0, 1.
    e[ok.END_X] = e[ok.START_Y] = 0, .0
    z = merge_layer_group(group)

    clip_to_wip(z)
    do_mod(z, d[ok.RW1][ok.MOD])
    return maya.rename_layer(z)


class MysteryGrate(Style):
    """Create Backdrop Style output."""
    is_dependent = False

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.RW1,),
                k_path + (ok.RW1, ok.MOD),
                k_path + (ok.RW1, ok.MOD, ok.BLUR_D)
            ],
            make_style
        )
