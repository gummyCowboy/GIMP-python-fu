#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from gimpfu import (  # type: ignore
    CHANNEL_OP_REPLACE,
    CLIP_TO_IMAGE,
    DESATURATE_LUMINANCE,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_HSV_VALUE,
    pdb
)
from roller_a_contain import Globe, Run
from roller_a_gegl import unsharp_mask
from roller_backdrop_color_grid import do_color_grid
from roller_constant_key import Option as ok
from roller_fu import (
    blur_selection,
    clear_selection,
    clone_layer,
    flip_layer,
    load_selection,
    merge_layer_group,
    select_color
)
from roller_maya_style import Style
from roller_view_hub import do_mod
from roller_view_real import add_sub_base_group

'''
Define 'backdrop/dark_fort' as a Maya-subtype
for managing a variation of backdrop style layer.
'''


def make_style(maya):
    """
    Make a Dark Fort Backdrop Style layer.

    maya: Style
    Return: layer or None
        Dark Fort material
    """
    def _noise():
        """Add noise by color."""
        # Create a selection from black pixel.
        pdb.gimp_by_color_select(
            z,
            (0, 0, 0),
            0,                      # threshold
            CHANNEL_OP_REPLACE,
            1,                      # yes, antialias
            0,                      # no feather
            .0,                     # feather radius
            0                       # no sample merged
        )

        # Clear the black grid.
        clear_selection(z)

        pdb.plug_in_rgb_noise(
            j, z,
            1,                      # yes, independent
            0,                      # no correlated
            .1,                     # R noise
            .1,                     # G noise
            .1,                     # B noise
            .0                      # A noise
        )
        pdb.plug_in_emboss(
            j, z,
            azimuth,
            elevation,
            3,                      # depth
            0                       # bump
        )
        pdb.plug_in_despeckle(
            j, z,
            15,                     # radius
            1,                      # adaptive
            0,                      # black cut-off
            255                     # white cut-off
        )
        pdb.plug_in_despeckle(
            j, z,
            15,                     # radius
            1,                      # adaptive
            0,                      # black cut-off
            255                     # white cut-off
        )

    j = Run.j
    d = maya.value_d
    group = add_sub_base_group(maya)
    azimuth = Globe.azimuth
    elevation = Globe.elevation
    e = deepcopy(d)
    e[ok.ANGLE] = .0
    grid = do_color_grid(e, group)
    z = clone_layer(grid, n="Noise")

    select_color(z, (0, 0, 0))

    sel = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)
    _noise()

    z1 = clone_layer(z, n="HSV Value")
    z1.mode = LAYER_MODE_HSV_VALUE

    flip_layer(z1, is_h=True)
    pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

    z = pdb.gimp_image_merge_down(j, z1, CLIP_TO_IMAGE)
    z1 = clone_layer(z, n="Difference")
    z1.mode = LAYER_MODE_DIFFERENCE

    # lowest turbulence, '1.'
    pdb.plug_in_plasma(j, z, int(d[ok.SEED] + Globe.seed), 1.)

    z = clone_layer(z, n="Unsharp Mask")

    load_selection(j, sel)
    blur_selection(z, 1)
    unsharp_mask(z, 2., .5, 0.)
    pdb.gimp_selection_none(j)

    z = pdb.gimp_image_merge_down(j, z, CLIP_TO_IMAGE)

    pdb.gimp_drawable_desaturate(z, DESATURATE_LUMINANCE)
    pdb.plug_in_emboss(
        j, z,
        azimuth,
        elevation,
        3,                  # depth
        0                   # bump
    )
    pdb.gimp_image_remove_channel(j, sel)

    z = merge_layer_group(group)

    do_mod(z, d[ok.BRW][ok.MOD])
    return maya.rename_layer(z)


class DarkFort(Style):
    """Create Backdrop Style output."""
    is_dependent = False
    is_seeded = True

    def __init__(self, any_group, super_maya, k_path):
        Style.__init__(
            self,
            any_group,
            super_maya,
            [
                k_path,
                k_path + (ok.BRW, ok.MOD),
                k_path + (ok.BRW, ok.MOD, ok.BLUR_D)
            ],
            make_style
        )
