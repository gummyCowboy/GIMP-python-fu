#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import BackdropStyle as by, Model as md

'''Define Widget tooltip.'''

_ACCEPT = " Accept and show cell to the "
_REQUIRE = " Requires the Cell/Margin step. "
_DEPENDENT_STYLE = " Uses the Backing layer. "
_INDEPENDENT_STYLE = " Doesn't use the Backing layer. "


class Tip:
    """Has tooltip text string."""
    ADD_SHIFT_XY = \
        " After the first cell, each cell's position \n" \
        " is offset by this amount from the prior \n" \
        " cell in the cell sequence. "
    AMP = " A higher value to increases the roughness. "
    AUTOCROP = " Crop empty space around an image. "
    AZIMUTH = " The light angle is used by emboss. "
    BLEND = " A higher value to reduces textural variation. "
    CELL_SIZE = \
        " The canvas space is divided by this \n" \
        " to derive the row and column count. "
    CLIP = " Clip the output. "
    COLOR = " Red\t{} \n Green\t{} \n Blue\t{} "
    COLOR_COUNT = " Is the number of potential colors. "
    COLOR_INDENT = " \tRed \t{} \n \tGreen\t{} \n \tBlue\t{} "
    COLOR_RGBA = COLOR + "\n Alpha\t{}"
    COLOR_RGBA_INDENT = COLOR_INDENT + "\t\n Alpha\t{}"
    CONTRACT = " Move the brush stroke inward toward the center. "
    CROP_X = \
        " Crop the image with a rectangle \n" \
        " defined by X, Y, Width, and Height. "
    CUT_OUT = \
        " Invert the mask making it cut-out instead of cut-around. "
    DELETE_MODEL = " Delete the selected model. "
    DELETE_PLAN = " Remove the Plan output after rendering. "
    DISTRESS = " Stress the frame more with a higher value. "
    DRAFT_BUTTON = " Plan steps up to the visible option group. "
    ELEVATION = " Increase value to lighten emboss output. "
    END_X = " Add to the x-axis end coordinate. "
    END_Y = " Add to the y-axis end coordinate. "
    FACTOR_H = " Multiply by the render height and add to the result. "
    FACTOR_W = " Multiply by the render width and add to the result. "
    FCI = " Make the grid's first cell position be row 1, column 2. "
    FEATHER = \
        " The initial feather is this number divided \n" \
        " by steps. Subsequent steps add the initial \n" \
        " value to the feather. This value becomes the \n" \
        " feather amount applied on the last step. "
    FILL_MODE = "Is the paint mode used by the bucket fill. "
    FIXED_W = " Resize the image to these dimensions. "
    FONT_SIZE = " Is for Draft/Plan text output. "
    FRINGE_MASK = " Paint brush strokes around the edge masking the material. "
    HEIGHT_MOD = " Modify the image height by this amount. "
    HIDE_LAYER = " Hide Layers in the dock for faster processing. "
    LAYERED = \
        " The image's layers are iterated as a tree, \n" \
        " where each layer becomes an image reference. "
    IMAGE_NAME = \
        " The order of image name list is \n" \
        " from GIMP's open image order. "
    LAYER_ORDER = \
        " Is the direction of the layer-tree iteration. \n" \
        " With top-down, the first layer is the \n" \
        " layer at the top of the layer tree. \n" \
        " If top-down is off, then the order is \n" \
        " bottom-up, and the first layer is \n" \
        " the bottom layer in the tree. "
    INTENSITY = " Modify the shadow opacity. "
    INWARD = " Make Facing output face toward the center. "
    KEEP = " Have GIMP save a new gradient. "
    LEAD = " Prefix the output. "
    LENGTH_SHIFT = " Randomize the length of a tape strip. "
    LOOP_MINUS = \
        " Assign an image using a circular-type index variable. \n" \
        " Loop Minus decrements after assigning an image. \n" \
        " It's index rolls-over to the last open image after \n" \
        " the first open image. Both Loop Plus and Loop \n" \
        " Minus use the same index variable. If the Minus \n" \
        " option is used before the Plus option, then the \n" \
        " last open image is the first image reference. "
    LOOP_PLUS = \
        " Assign an image using a circular-type index variable. \n" \
        " Loop Plus increments after assigning an image. \n" \
        " The index rolls-over to the first open image after \n" \
        " the last open image. Both Loop versions use the same \n" \
        " index variable. If the Plus index is used before the \n" \
        " Minus index, then the first open image is the first \n" \
        " image reference. "
    MERGE_CELL = " X:\t\t{} \n Y:\t\t{} \n Width:\t{} \n Height:\t{} "
    MODEL_LIST_NEW = " Make a new model. "
    MODEL_LIST_TREE = " active model in inverted layer order "
    MODEL_LIST_TYPE = {
        md.BOX:
            " Arrange double-spaced box-shaped \n"
            " cell by row and column. ",
        md.CELL: " Define a cell. ",
        md.PYRAMID: " Define cell in a triangular-shaped stack. ",
        md.STACK: " Layer cell in a stack. ",
        md.TABLE: " Arrange cell by row and column. "
    }
    MODEL_STEP = " Add and remove available step from the navigation tree. "
    MOVE_UP = MOVE_DOWN = " Change the order a Model output. "
    MOVE_LEFT = " Remove the selected item from the interface. "
    MOVE_RIGHT = " Move the selected item to the interface. "
    NAVIGATION = (
        _ACCEPT + "north (ctrl ↑) ",
        _ACCEPT + "south (ctrl ↓) ",
        _ACCEPT + "west (ctrl ←) ",
        _ACCEPT + "east (ctrl →) "
    )
    OBEY_MARGIN = " Constrict output with branch margin. "
    OPAQUE = " Make the blur's mask source opaque. "
    OPTION_LIST = {
        # Backdrop Style
        by.ACRYLIC_SKY: _DEPENDENT_STYLE,
        by.BACK_GAME: _DEPENDENT_STYLE,
        by.CLAY_CHEMISTRY: _DEPENDENT_STYLE,
        by.COLOR_FILL: _DEPENDENT_STYLE,
        by.COLOR_GRID: _DEPENDENT_STYLE,
        by.CORE_DESIGN: _INDEPENDENT_STYLE,
        by.CUBE_PATTERN: _INDEPENDENT_STYLE,
        by.CUBISM_COVER: _DEPENDENT_STYLE,
        by.CRYSTAL_CAVE: _INDEPENDENT_STYLE,
        by.DARK_FORT: _INDEPENDENT_STYLE,
        by.FADING_MAZE: _INDEPENDENT_STYLE,
        by.DENSITY_GRADIENT: _INDEPENDENT_STYLE,
        by.DROP_ZONE: _INDEPENDENT_STYLE,
        by.ETCH_SKETCH: _DEPENDENT_STYLE,
        by.FLOOR_SAMPLE: _INDEPENDENT_STYLE,
        by.GALACTIC_FIELD: _DEPENDENT_STYLE,
        by.GLASS_GAW: _INDEPENDENT_STYLE,
        by.GRADIENT_FILL: _INDEPENDENT_STYLE,
        by.HISTORIC_TRIP: _DEPENDENT_STYLE,
        by.IMAGE_GRADIENT: _DEPENDENT_STYLE,
        by.LINE_STONE: _DEPENDENT_STYLE,
        by.LOST_MAZE: _INDEPENDENT_STYLE,
        by.MAZE_BLEND: _DEPENDENT_STYLE,
        by.MEAN_COLOR: _DEPENDENT_STYLE,
        by.MYSTERY_GRATE: _INDEPENDENT_STYLE,
        by.NOISE_RIFT: _INDEPENDENT_STYLE,
        by.PAPER_WASTE: _DEPENDENT_STYLE,
        by.PATTERN_FILL: _DEPENDENT_STYLE,
        by.RAINBOW_VALLEY: _DEPENDENT_STYLE,
        by.RECT_PATTERN: _INDEPENDENT_STYLE,
        by.ROCKY_LANDING: _INDEPENDENT_STYLE,
        by.ROOF_TOP: _INDEPENDENT_STYLE,
        by.SOFT_TOUCH: _DEPENDENT_STYLE,
        by.SPECIMEN_SPECKLE: _DEPENDENT_STYLE,
        by.SPIRAL_CHANNEL: _INDEPENDENT_STYLE,
        by.SQUARE_CLOUD: _DEPENDENT_STYLE,
        by.STONE_AGE: _DEPENDENT_STYLE,
        by.TRAILING_VINE: _INDEPENDENT_STYLE,
        by.TRIANGLE_REVERB: _INDEPENDENT_STYLE,
        by.WAVE_FILL: _INDEPENDENT_STYLE
    }
    PER_CHECK_BUTTON = " Define option as either main or per. "
    PER_BUTTON = " Open a per option table. "
    PEEK_BUTTON = " Preview steps up to the visible option group. "
    PERCENTILE = "darker < 50% < lighter"
    PLAN_BORDER = " Show Border material in Draft/Plan output. "
    PLAN_BUTTON = " Draw a plan graph using the Planner options. "
    PLAN_CELL_SHAPE = " Draw cell shape outline. \n" + _REQUIRE
    PLAN_CORNER = \
        " Display the bottom-left and top-right \n" \
        " coordinate of a cell's position. \n" + _REQUIRE
    PLAN_POSITION = \
        " Display the topleft coordinate of a cell's position. \n" \
        + _REQUIRE
    PLAN_DIMENSION = " Display the size of a cell. " + _REQUIRE
    PLAN_GRID = " Draw the model's grid. "
    PLAN_IMAGE_NAME = " Show the name of image assigned to a cell. "
    PLAN_RATIO = " Display the cell's position ratio. \n" + _REQUIRE
    POWER = " Increase cloud material with a higher value. "
    PREVIEW_BUTTON = " Make a render using the navigation tree (ctrl-p). "
    SEED = " Randomized output uses this an init value. "
    RENAME_MODEL = " Rename the selected model. "
    REVISE_MODEL = " Revise the available steps for the selected model. "
    REVERSE = " Reverse the order of the gradient colors. "
    SAMPLE_COUNT = " Sample points are evenly distributed between the edges. "
    SCATTER_COUNT = " Is the number of mazes to draw. "
    SEED_GLOBAL = " Add to any random seed. "
    SHIFT_H = " Randomize the image's height (+/-). "
    SHIFT_W = " Randomize the image's width (+/-). "
    SHIFT_X = " Randomize the image's x position (+/-). "
    SHIFT_Y = " Randomize the image's y position (+/-). "
    SLICE = " Cut an image into rectangles using row and column values. "
    SLIDER_INT_PART = " Add to the result with the factored calculation. "
    SPIRAL_DISTANCE = " Lower the value to increase the spiral count. "
    SPREAD = " Increase scattering. "
    START_NUMBER = " Set the first number of the sequence. "
    STEPS = " Repeat feather. "
    STEPS_DROP_ZONE = " Is the number of colors in the resulting gradient. "
    STRIP_H = " Factor the caption's text height. "
    TAB = \
        " The order of the numeric list is \n" \
        " from GIMP's open image order. "
    THRESHOLD = \
        " A threshold of 1.0 is a match all \n" \
        " and a threshold of 0.0 is to match none. "
    TRAIL = " Suffix the output. "
    WH_FACTOR = " Scale of the image by a factor. "
    WHIRL = " Spin the material around the center of the image. "
    WIDTH_MOD = " Modify the image width by this amount. "
    WIP = " Scale the image size. Improve the render's edge-case output. "
