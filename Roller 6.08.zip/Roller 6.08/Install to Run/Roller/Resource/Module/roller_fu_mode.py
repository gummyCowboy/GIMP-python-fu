#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from gimpfu import (  # type: ignore
    LAYER_MODE_ADDITION,
    LAYER_MODE_BURN,
    LAYER_MODE_COLOR_ERASE,
    LAYER_MODE_DARKEN_ONLY,
    LAYER_MODE_DIFFERENCE,
    LAYER_MODE_DISSOLVE,
    LAYER_MODE_DIVIDE,
    LAYER_MODE_DODGE,
    LAYER_MODE_EXCLUSION,
    LAYER_MODE_ERASE,
    LAYER_MODE_GRAIN_EXTRACT,
    LAYER_MODE_GRAIN_MERGE,
    LAYER_MODE_HARDLIGHT,
    LAYER_MODE_HARD_MIX,
    LAYER_MODE_HSL_COLOR,
    LAYER_MODE_HSV_HUE,
    LAYER_MODE_HSV_SATURATION,
    LAYER_MODE_HSV_VALUE,
    LAYER_MODE_LCH_CHROMA,
    LAYER_MODE_LCH_COLOR,
    LAYER_MODE_LCH_HUE,
    LAYER_MODE_LCH_LIGHTNESS,
    LAYER_MODE_LIGHTEN_ONLY,
    LAYER_MODE_LINEAR_BURN,
    LAYER_MODE_LINEAR_LIGHT,
    LAYER_MODE_LUMA_LIGHTEN_ONLY,
    LAYER_MODE_LUMA_DARKEN_ONLY,
    LAYER_MODE_LUMINANCE,
    LAYER_MODE_MERGE,
    LAYER_MODE_MULTIPLY,
    LAYER_MODE_NORMAL,
    LAYER_MODE_OVERLAY,
    LAYER_MODE_PIN_LIGHT,
    LAYER_MODE_SCREEN,
    LAYER_MODE_SPLIT,
    LAYER_MODE_SOFTLIGHT,
    LAYER_MODE_SUBTRACT,
    LAYER_MODE_VIVID_LIGHT
)
from roller_constant_for import Widget as fw
from roller_constant_key import Option as ok

'''
Define a dictionary and the methodology for
translating layer mode string into GIMP enum.
'''


class Mode:
    # Translate.
    # d -> {mode identifier: gimpfu enum}
    d = OrderedDict([
        ("Normal", LAYER_MODE_NORMAL),
        ("Dissolve", LAYER_MODE_DISSOLVE),
        ("Color Erase", LAYER_MODE_COLOR_ERASE),
        ("Erase", LAYER_MODE_ERASE),
        ("Merge", LAYER_MODE_MERGE),
        ("Split", LAYER_MODE_SPLIT),
        (fw.LIST_SEPARATOR, None),
        ("Lighten Only", LAYER_MODE_LIGHTEN_ONLY),
        ("Luma Lighten Only", LAYER_MODE_LUMA_LIGHTEN_ONLY),
        ("Screen", LAYER_MODE_SCREEN),
        ("Dodge", LAYER_MODE_DODGE),
        ("Addition", LAYER_MODE_ADDITION),
        (fw.LIST_SEPARATOR * 2, None),
        ("Darken Only", LAYER_MODE_DARKEN_ONLY),
        ("Luma Darken Only", LAYER_MODE_LUMA_DARKEN_ONLY),
        ("Multiply", LAYER_MODE_MULTIPLY),
        ("Burn", LAYER_MODE_BURN),
        ("Linear Burn", LAYER_MODE_LINEAR_BURN),
        (fw.LIST_SEPARATOR * 3, None),
        ("Overlay", LAYER_MODE_OVERLAY),
        ("Soft Light", LAYER_MODE_SOFTLIGHT),
        ("Hard Light", LAYER_MODE_HARDLIGHT),
        ("Vivid Light", LAYER_MODE_VIVID_LIGHT),
        ("Pin Light", LAYER_MODE_PIN_LIGHT),
        ("Linear Light", LAYER_MODE_LINEAR_LIGHT),
        ("Hard Mix", LAYER_MODE_HARD_MIX),
        (fw.LIST_SEPARATOR * 4, None),
        ("Difference", LAYER_MODE_DIFFERENCE),
        ("Exclusion", LAYER_MODE_EXCLUSION),
        ("Subtract", LAYER_MODE_SUBTRACT),
        ("Grain Extract", LAYER_MODE_GRAIN_EXTRACT),
        ("Grain Merge", LAYER_MODE_GRAIN_MERGE),
        ("Divide", LAYER_MODE_DIVIDE),
        (fw.LIST_SEPARATOR * 5, None),
        ("HSV Hue", LAYER_MODE_HSV_HUE),
        ("HSV Saturation", LAYER_MODE_HSV_SATURATION),
        ("HSL Color", LAYER_MODE_HSL_COLOR),
        ("HSV Value", LAYER_MODE_HSV_VALUE),
        (fw.LIST_SEPARATOR * 6, None),
        ("LCH Hue", LAYER_MODE_LCH_HUE),
        ("LCH Chroma", LAYER_MODE_LCH_CHROMA),
        ("LCH Color", LAYER_MODE_LCH_COLOR),
        ("LCH Lightness", LAYER_MODE_LCH_LIGHTNESS),
        ("Luminance", LAYER_MODE_LUMINANCE)
    ])

    # ComboBox value, 'q'
    MODE_Q = (
        "Normal",
        "Dissolve",
        "Color Erase",
        "Erase",
        "Merge",
        "Split",
        fw.LIST_SEPARATOR,
        "Lighten Only",
        "Luma Lighten Only",
        "Screen",
        "Dodge",
        "Addition",
        fw.LIST_SEPARATOR,
        "Darken Only",
        "Luma Darken Only",
        "Multiply",
        "Burn",
        "Linear Burn",
        fw.LIST_SEPARATOR,
        "Overlay",
        "Soft Light",
        "Hard Light",
        "Vivid Light",
        "Pin Light",
        "Linear Light",
        "Hard Mix",
        fw.LIST_SEPARATOR,
        "Difference",
        "Exclusion",
        "Subtract",
        "Grain Extract",
        "Grain Merge",
        "Divide",
        fw.LIST_SEPARATOR,
        "HSV Hue",
        "HSV Saturation",
        "HSL Color",
        "HSV Value",
        fw.LIST_SEPARATOR,
        "LCH Hue",
        "LCH Chroma",
        "LCH Color",
        "LCH Lightness",
        "Luminance",
    )

    # Use with Decay.
    EDGE_MODE = (
        "Normal",
        "Lighten Only",
        "Screen",
        "Overlay",
        "Soft Light",
        "Hard Light",
        "Difference",
        "Subtract",
        "Grain Extract",
        "Grain Merge",
        "Divide",
        "HSV Value",
        "HSV Saturation",
        "HSL Color",
        "LCH Lightness",
        "Luminance"
    )


def get_fill_mode(d):
    """
    Get the enum mode from a English translation.

    d: dict
        Has a FILL_MODE option.

    Return: enum
        layer mode
    """
    return Mode.d[d[ok.FILL_MODE]]


def get_gradient_mode(d):
    """
    Get the enum mode from a English translation. Use with gradient.

    d: dict
        Has a GRADIENT_MODE option.

    Return: enum
        layer mode
    """
    return Mode.d[d[ok.GRADIENT_MODE]]


def get_mode(d, k=ok.MODE):
    """
    Get the enum mode from a English translation.

    d: dict
        Has a MODE option.

    k: string
        mode key

    Return: enum
        layer mode
    """
    return Mode.d[d[k]]


def translate_mode(n):
    """
    Translate an English Paint Mode descriptor into GIMP layer mode enum.

    n: string
        paint mode descriptor

    Return: enum
        layer mode
    """
    return Mode.d[n]
