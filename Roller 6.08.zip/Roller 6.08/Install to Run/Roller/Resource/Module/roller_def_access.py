#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_key import Widget as wk
from roller_def_act import scour


def get_default_value(k):
    """
    Fetch a Widget group's default option value.

    k: string
        Group key

    Return: dict
        {option key: value}
        Use to load a default Preset.
    """
    return deepcopy(Def.default_d.get(k, {}))


def get_group_keys(k):
    """
    Fetch a Widget group's option key list.
    Typically Widget groups are organized as a Preset or a Row.

    k: string
        Group key

    Return: list or None
        [option key]
    """
    if k in Def.group_def:
        return Def.group_def[k].keys()
    if k in Def.sub_group_def:
        return Def.sub_group_def[k][wk.SUB].keys()


def get_init(k):
    """
    Fetch Widget init argument for a Widget group.

    k: string
        Preset key

    Return: tuple
        (dict, list)
        ({option key: Widget init dict}, [option key])
    """
    if k in Def.group_def:
        d = deepcopy(Def.group_def[k])
        return d, Def.group_def[k].keys()

    if k in Def.sub_group_def:
        d = deepcopy(Def.sub_group_def[k])
        return d[wk.SUB], d[wk.SUB].keys()
    return None, None


def get_init_d(k):
    """
    Fetch Widget init argument for a Widget group.

    k: string
        Preset key

    Return: tuple
        (dict, list)
        ({option key: Widget init dict}, [option key])
    """
    return get_init(k)[0]


def get_vote_d(k):
    """
    Fetch the prefab vote dict for a Preset.

    k: string
        Option key

    Return: dict
        Is the default vote dict for the Preset.
    """
    return Def.vote_d.get(k, {})


class Def:
    """Access Preset definition and vote dict."""
    default_d = {}
    group_def = {}
    sub_group_def = {}
    vote_d = {}

    def __init__(self, group_def, sub_group_def):
        """
        group_def: dict
            {Preset key: Preset definition dict}

        sub_group_def: dict
            {sub-Preset key: sub-Preset definition dict}
        """
        d = Def.group_def = group_def
        e = Def.sub_group_def = sub_group_def

        # Load the vote dict.
        for i in d:
            Def.vote_d[i] = scour({}, d[i], wk.ISSUE)

        for i in e:
            Def.vote_d[i] = scour({}, e[i], wk.ISSUE)

        # Load the default Preset value dict.
        for i in d:
            Def.default_d[i] = scour({}, d[i], wk.VAL)
        for i in e:
            Def.default_d[i] = scour({}, e[i], wk.VAL)
