#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gimpfu import pdb    # type: ignore
from copy import deepcopy
from math import radians
from roller_a_contain import Cat, Run, The
from roller_constant_for import Backdrop as bs, Signal as si
from roller_constant_key import Option as ok, SubMaya as sm
from roller_fu import (
    clear_selection,
    layer_has_pixel,
    make_layer_group,
    merge_layer_group,
    remove_z,
    select_ellipse
)
from roller_maya_layer import check_matter, check_mix
from roller_maya_style import Style, check_style_group
from roller_one import enumerate_name
from roller_one_wip import Wip, get_factor_h, get_factor_w
from roller_view_hub import (
    color_selection,
    create_gradient,
    delete_gradient,
    do_gradient_for_layer,
    prep_brush,
    set_draw_line_brush,
    set_fill_context_default
)
from roller_view_real import (
    add_sub_base_group, add_wip_layer, get_point_on_edge, insert_copy
)
import colorsys

'''
Define 'backdrop/image_gradient' as a Maya-subtype
for managing a background layer variety.
'''


def _check_mix(maya):
    """
    Determine the matter layer's mode or opacity change.

    maya: Maya
    """
    d = maya.value_d
    q = ("Normal", 100.) if maya.is_sample else (d[ok.MODE], d[ok.OPACITY])
    check_mix(maya, 'matter', *q)


def do_diagonal(d, z, color, a):
    """
    Sample color and return a gradient's start and end points.

    d: dict
        Image Gradient Preset

    z: layer
        Backing

    color: list
        [sampled color, ...]

    a: int
        sample count

    Return: tuple
        ((start relative coordinate, end relative coordinate), ...)
    """
    q = get_diagonal_points(d, a)

    for i in range(a):
        x, y = q[i]
        color[i] = pick_color(d, z, x, y)

    w, h = Wip.get_size()
    return (
        (0, q[0][0] / w),
        (0, q[0][1] / h),
        (0, q[-1][0] / w),
        (0, q[-1][1] / h)
    )


def do_horizontal(d, z, color, a):
    """
    Sample color and return a gradient's start and end points.

    d: dict
        Image Gradient Preset

    z: layer
        Backing

    color: list
        [sampled color, ...]

    a: int
        sample count

    Return: tuple
        ((start relative coordinate, end relative coordinate), ...)
        Are in gradient factor.
    """
    q = get_horizontal_points(d, a)

    for i in range(a):
        x, y = q[i]
        color[i] = pick_color(d, z, x, y)
    return (0, .0), (0, .5), (0, 1.), (0, .5)


def do_vertical(d, z, color, a):
    """
    Sample color and return a gradient's start and end points.

    d: dict
        Image Gradient Preset

    z: layer
        Backing

    color: list
        Store sampled color.
        [sampled color, ...]

    a: int
        sample count

    Return: tuple
        ((start relative coordinate, end relative coordinate), ...)
        Factor with WIP.
    """
    q = get_vertical_points(d, a)

    for i in range(a):
        x, y = q[i]
        color[i] = pick_color(d, z, x, y)
    return (0, .5), (0, .0), (0, .5), (0, 1.)


def get_diagonal_points(d, a):
    """
    Get the sample points for a topleft vector.

    d: dict
        Image Gradient Preset

    a: int
        sample point count

    Return: list
        [sample point, ...]
        [(x, y), ...]
        Are WIP relative image coordinate.
    """
    f = radians(d[ok.DIAGONAL])
    x, y = get_point_on_edge(f)

    # pi, '3.14'
    x1, y1 = get_point_on_edge(f + 3.14159265)

    x, y = x - Wip.x, y - Wip.y
    x1, y1 = x1 - Wip.x, y1 - Wip.y
    q = []
    b = a + 1
    right_x, bottom_y = Wip.w - 1., Wip.h - 1.

    # run and rise of line, 'w1 and h1'
    w1 = (x1 - x) / b
    h1 = (y1 - y) / b

    for i in range(a):
        x = min(x + w1, right_x)
        y = min(y + h1, bottom_y)
        q.append((x, y))
    return q


def get_horizontal_points(d, a):
    """
    Get the sample points for a horizontal vector.

    d: dict
        Image Gradient Preset

    a: int
        sample point count

    Return: list
        of sample point
        [(x, y), ...]
        Are WIP relative image coordinate.
    """
    x = 0
    y = get_factor_h(d[ok.START_Y])
    q = []
    w = Wip.w / (a + 1.)
    right_x = Wip.w - 1.

    for i in range(a):
        x = min(x + w, right_x)
        q.append((x, y))
    return q


def get_vertical_points(d, a):
    """
    Get the sample points for a vertical vector.

    d: dict
        Image Gradient Preset

    a: int
        sample point count

    Return: list
        of sample point
        [(x, y), ...]
        Are WIP relative image coordinate.
    """
    x = get_factor_w(d[ok.START_X])
    y = 0
    q = []
    h = Wip.h / (a + 1.)
    bottom_y = Wip.h - 1.

    for i in range(a):
        y = min(y + h, bottom_y)
        q.append((x, y))
    return q


def pick_color(d, z, x, y):
    """
    Pick a color from the canvas.

    d: dict
        Image Gradient Preset

    z: layer
        Backing

    x, y: float
        canvas coordinate to pick from

    Return: color
        the picked color
        RGBA
    """
    # Prevent sample overflow.
    sample_w = min(Wip.w / 2., Wip.h / 2., d[ok.SAMPLE_RADIUS])

    # Prevent x, y overflow.
    x += Wip.x
    y += Wip.y
    w = Wip.x + Wip.w
    h = Wip.y + Wip.h

    if x >= w:
        x = w - 1.

    if y >= h:
        y = h - 1.
    return pdb.gimp_image_pick_color(
        z.image, z,
        x, y,
        0,                              # no sample merged
        1,                              # yes, sample radius
        sample_w
    )


GET_POINTS = do_vertical, do_horizontal, do_diagonal


def make_style(maya):
    """
    Make a Backdrop Style layer.

    maya: ImageGradient
    Return: layer
        Backdrop Style material
    """
    d = maya.value_d
    parent = add_sub_base_group(maya)
    bg_z = insert_copy(parent, parent)
    sample_cnt = int(d[ok.SAMPLE_COUNT])

    # ImageGradient Preset dict, 'e'
    e = deepcopy(d)

    e[ok.OFFSET] = 0
    color = [0] * sample_cnt
    x = bs.VECTOR.index(d[ok.SAMPLE_VECTOR])

    if d[ok.PREVIEW_MODE] == bs.SHOW_SAMPLE and Run.is_preview:
        show_sample(parent, bg_z, d, sample_cnt, x, color)
        maya.is_sample = True

    else:
        show_gradient(parent, bg_z, d, e, sample_cnt, x, color)
        maya.is_sample = False

    remove_z(bg_z)

    z = merge_layer_group(parent)

    if Run.is_preview:
        z.name = "Image Gradient Sample"
        return z
    else:
        return maya.rename_layer(z)


def prep_line():
    """Prepare to draw line."""
    set_draw_line_brush()
    pdb.gimp_context_set_brush_size(1.)
    pdb.gimp_context_set_foreground((0, 0, 0))


def show_gradient(parent, z, d, e, a, x, color):
    """
    Draw an Image Gradient.

    parent: layer
        destination group

    z: layer
        Backing

    d: dict
        ImageGradient Preset

    e: dict
        modified options for drawing gradient

    a: int
        sample count

    x: int
        sample vector index
    """
    set_fill_context_default()

    gradients = Cat.gradient_list

    # gradient name, 'n'
    n = d[ok.NAME]

    is_keep = d[ok.KEEP]

    if not n:
        n = "Sampled Gradient"

    # The option name is needed in the gradient list so that
    # 'set_gimp_gradient' will pass the gradient-exists test.
    if n in gradients:
        n = enumerate_name(n, gradients)

    gradients += [n]
    grad = e[ok.GRADIENT] = create_gradient(n, is_keep)

    if a > 2:
        pdb.gimp_gradient_segment_range_split_uniform(grad, 0, 0, a - 1)

    # Set 'color'.
    e[ok.START_X], e[ok.START_Y], e[ok.END_X], e[ok.END_Y] = \
        GET_POINTS[x](e, z, color, a)

    for x in range(a - 1):
        opacity = color[x].alpha * 100.

        pdb.gimp_gradient_segment_set_left_color(grad, x, color[x], opacity)

        opacity = color[x + 1].alpha * 100.
        pdb.gimp_gradient_segment_set_right_color(
            grad, x, color[x + 1], opacity
        )

    # gradient layer, 'z'
    z = do_gradient_for_layer(e, parent, 0)
    z.name = "Image Gradient"

    if is_keep:
        The.grad = grad

    else:
        delete_gradient(grad)
    gradients.pop(-1)


def show_sample(parent, z, d, a, x, color):
    """
    Show a preview with the sample area filled with sampled color.

    z: layer
        Backing

    d: dict
        ImageGradient Preset

    a: int
        sample point count

    x: int
        vector index

    color: list
        of sampled color
    """
    j = z.image
    group = make_layer_group(j, "Image Gradient Sample", parent, 0)

    pdb.gimp_selection_none(j)

    q = (
        get_vertical_points, get_horizontal_points, get_diagonal_points
    )[x](d, a)

    # Set 'color'.
    GET_POINTS[x](d, z, color, a)

    w = min(Wip.w, Wip.h, d[ok.SAMPLE_RADIUS])
    w1 = w + w
    w2 = w + 1
    w3 = w2 * 2

    # Draw a line.
    line = q[0][0], q[0][1], q[-1][0], q[-1][1]
    line_layer = add_wip_layer("Line", group)
    sample_layer = add_wip_layer("Sample", group)
    color1 = color

    prep_line()
    prep_brush()
    pdb.gimp_selection_none(j)
    pdb.gimp_paintbrush_default(line_layer, len(line), line)

    for x1, u in enumerate(q):
        x, y = u
        r, g, b, alpha = [(i / 255.) for i in color1[x1]]
        hsv = colorsys.rgb_to_hsv(r, g, b)
        color = (0, 0, 0) if hsv[2] > .5 else (255, 255, 255)

        if alpha < 1.:
            z = add_wip_layer("Alpha", group)
            z1 = add_wip_layer("Alpha 2", group)
            z1.opacity = 100. * alpha

        else:
            z = z1 = sample_layer

        x, y = x + Wip.x, y + Wip.y
        select_ellipse(j, x - w2, y - w2, w3, w3)
        color_selection(z, color)
        select_ellipse(j, x - w, y - w, w1, w1)

        if z1.opacity:
            color_selection(z1, (r, g, b))
        if z1.opacity < 100.:
            # Remove the material as it is visible when semi-opaque.
            clear_selection(line_layer, is_keep=True)
            clear_selection(z)
    merge_layer_group(group)


class ImageGradient(Style):
    """Create Backdrop Style output."""
    is_dependent = True

    # Override Style's version.
    put = (
        (check_style_group, 'group'),
        (check_matter, 'matter'),
        (_check_mix, None)
    )

    def __init__(self, any_group, super_maya, k_path):
        self.is_sample = False

        Style.__init__(self, any_group, super_maya, k_path, make_style)
        self.latch(any_group, (si.AFTER_VIEW, self.on_after_view))

    def do(self, z, d, is_change):
        """
        Override Style's function. If a sample is shown and this
        is the last run, then set the 'is_matter' flag.

        z: layer
            Backing layer

        d: dict
            Backdrop Style Preset

        is_change: bool
            Is the state of Backing matter change.
        """
        self.value_d = d

        if self.is_sample and not Run.is_preview:
            self.is_matter = True

        if not self.is_matter and self.is_dependent and is_change:
            self.is_matter = True

        self.go = layer_has_pixel(z)

        self.realize()

        if self.matter:
            a = self.sub_maya[sm.ADD]

            if self.is_sample:
                a.die()
            else:
                a.do(
                    d[ok.BRW][ok.ADD_ALT],
                    self.is_matter,
                    self.is_matter,
                    is_change
                )

        else:
            self.die()

        self.reset_issue()
        self.any_group.emit(si.AFTER_VIEW, None)

    def on_after_view(self, any_group, _):
        """
        Respond to an AFTER_VIEW Signal.

        any_group: Backdrop
        _: None
        """
        any_group.changed(x=1)
