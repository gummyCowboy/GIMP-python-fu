#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from random import randint
from roller_widget import set_widget_attr
from roller_constant_for import Widget as fw
from roller_constant_key import Button as bk, Widget as wk
from roller_one import random_rgb
from roller_widget_button import RainbowColorButton
from roller_widget_button import Button
import gtk  # type: ignore


class Row(gtk.Alignment):
    """
    Is a GTK HBox container for multiple widgets that share a Table Widget row.
    """
    change_signal = None

    def __init__(self, **d):
        """
        Create an HBox.

        d: dict
            Initialize the Row.
        """
        super(gtk.Alignment, self).__init__()

        # The 'label' reference is a Label Widget displayed
        # in the Table container and is created by the Table.
        self.box = self.label = self.label_box = None

        self.any_group = None
        self.widget_q = ()

        if wk.KEY not in d:
            d[wk.KEY] = None

        set_widget_attr(self, d)

        self.row_key = d[wk.KEY]
        self.hbox = gtk.HBox()
        self.add(self.hbox)

    def hide(self):
        """Hide its Widget and Label."""
        self.box.hide()
        self.label_box.hide()

    def show(self):
        """Show its Widget and Label."""
        self.box.show()
        self.label_box.show()


class WidgetRow(Row):
    """
    Is a Row with an array of Widget. Access
    Widget through a 'widget_q' attribute.
    """
    has_table_label = False

    def __init__(self, **d):
        """
        Create an HBox occupied by an array of Widget.

        d: dict
            Has init values.
        """
        Row.__init__(self, **d)

        self.keys = []
        self.key_d = {}
        w = fw.MARGIN // 2
        w1 = w // 2
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)
        padding = d[wk.PADDING] if wk.PADDING in d else None
        d[wk.ALIGN] = 0, 0, 1, 0
        d[wk.ROW_KEY] = self.row_key
        d[wk.ANY_GROUP] = self.any_group
        relay = d[wk.RELAY][:]
        x = 0

        # iterable of option def, 'key_d'
        key_d = d[wk.SUB]

        # circular or cross-over
        for i in (wk.SUB, wk.TEXT, wk.WIDGET):
            if i in d:
                d.pop(i)

        for key, arg_d in key_d.items():
            arg_d.update(d)

            arg_d[wk.KEY] = key

            if key != bk.RANDOM:
                self.keys += [key]

            if x == 0:
                # Widget is on the left.
                arg_d[wk.PADDING] = w, w, 0, w1

            elif x == len(key_d) - 1:
                # Widget is on the right.
                arg_d[wk.PADDING] = w, w, w1, 0

            else:
                # Widget is in the middle.
                arg_d[wk.PADDING] = w, w, w1, w1

            arg_d[wk.RELAY] = relay[:]
            self.widget_q += (arg_d[wk.WIDGET](**arg_d),)
            self.key_d[key] = self.widget_q[-1]
            x += 1

        if padding:
            self.set_padding(*padding)
        for i in self.widget_q:
            self.hbox.pack_start(i, expand=True)
            same_size.add_widget(i.widget)

    def get_a(self):
        """
        Assemble the values of the Widget along the Row in a dict.

        Return: dict
            {Option key: Widget value}
        """
        d = {}

        for i in self.widget_q:
            k = i.key
            if k in self.keys:
                d[k] = i.get_a()
        return d

    def get_g(self, k):
        """
        Return the value of a of a Row owned Widget by its key.

        k: string
            Widget option key

        Return: Widget or None
        """
        for i in self.widget_q:
            if i.key == k:
                return i

    def hide_button(self, k):
        """
        Hide a Button in the Row.

        k: string
            Button key
        """
        for i in self.widget_q:
            if i.key == k:
                i.hide()
                break

    def set_a(self, d):
        """
        Set the value of Row Widget.

        d: dict
            Button Row Preset
        """
        for i in self.widget_q:
            k = i.key
            if k in d:
                i.set_a(d[k])

    def set_view_value(self, x, d):
        """
        The view run value is used by Widget to determine
        change and is set during a view run.

        x: int
            Plan or Work index
        """
        for i in self.widget_q:
            if i.key != bk.RANDOM:
                i.set_view_value(x, d[i.key])

    def show_button(self, k):
        """
        Show a Button in the Row.

        k: string
            Button key
        """
        for i in self.widget_q:
            if i.key == k:
                i.show()
                break

    def update_visibility(self, hide_q):
        """
        Hide or show each Widget in the Row.

        hide_q: tuple
            (Option key, ...)
            to hide
        """
        for i in self.widget_q:
            i.hide() if i.key in hide_q else i.show()


class Rainbow(Row):
    """Is an GTK HBox with two or more ColorButtons."""
    has_table_label = True

    def __init__(self, **d):
        """
        d: dict
            Initialize the Rainbow.
        """
        Row.__init__(self, **d)

        w = fw.MARGIN // 2
        w1 = w // 2
        self._has_alpha = d[wk.HAS_ALPHA] if wk.HAS_ALPHA in d else False
        d[wk.ALIGN] = 0, 0, 1, 0
        d[wk.GREATER_G] = self
        padding = d[wk.PADDING] if wk.PADDING in d else None
        count = d[wk.BUTTON_COUNT]
        self.issue = d[wk.ISSUE]
        d[wk.KEY] = None

        d.pop(wk.ISSUE)

        for i in range(count):
            if i == 0:
                d[wk.PADDING] = w, w, 0, w1

            elif i == count - 1:
                d[wk.PADDING] = w, w, w1, 0

            else:
                # Button in the middle
                d[wk.PADDING] = w, w, w1, w1
            self.widget_q += (RainbowColorButton(**d),)

        if padding:
            self.set_padding(*padding)
        for i in self.widget_q:
            self.hbox.pack_start(i, expand=True)

    def get_a(self):
        """
        Collect the values of the ColorButtons.

        Return: list
            [color values, ...]
        """
        q = []

        for i in self.widget_q:
            q += [i.get_a()]
        return q

    def randomize(self):
        """Randomize the values of the ColorButtons."""
        for i in self.widget_q:
            # RGB, 'q'
            q = random_rgb()

            if self._has_alpha:
                # RGBA, 'q'
                q += (randint(0, 255),)
            i.set_a(q)

    def set_a(self, q):
        """
        Set the colors of the ColorButtons.

        q: iterable
            Has color values.
        """
        for x, i in enumerate(q):
            self.widget_q[x].set_a(i)

        for x in range(2):
            view_value = [i.view_value[x] for i in self.widget_q]
            self.any_group.cast_vote(x, self.key, self.issue, q != view_value)
        self.any_group.update_option_a(self.key, q)

    def set_view_value(self, x, q):
        """
        The view run value is used by Widget to determine change.

        x: int
            Plan or Work index

        q: list
            [color, ...]
        """
        for x1, i in enumerate(self.widget_q):
            i.set_view_value(x, q[x1])

    def update_a(self):
        """One of the RainbowColorButtons has changed. Update its AnyGroup."""
        q = self.get_a()

        for x in range(2):
            view_value = [i.view_value[x] for i in self.widget_q]
            self.any_group.cast_vote(x, self.key, self.issue, q != view_value)
        self.any_group.update_option_a(self.key, q)

    def update_visibility(self, color_count):
        """
        The number of visible ColorButtons is dependent on the color count.

        color_count: int
            the number of ColorButtons to show
        """
        for x, i in enumerate(self.widget_q):
            i.show() if x < color_count else i.hide()
        self.label.hide() if not color_count else self.label.show()


class SelectRow(WidgetRow):
    """
    Has two Buttons, Select All and Select
    None. Manipulate a list of CheckButton.
    """

    def __init__(self, widget_q, **d):
        self._widget_q = widget_q
        w = fw.MARGIN
        d[wk.PADDING] = 0, 0, w, w
        d[wk.RELAY] = d[wk.RELAY][:]

        d[wk.RELAY].insert(0, self.on_select_button)

        d[wk.SUB] = OrderedDict([
            (bk.SELECT_ALL, {
                wk.STILL: True,
                wk.KEY: None,
                wk.TEXT: "Select All",
                wk.WIDGET: Button
            }),
            (bk.SELECT_NONE, {
                wk.STILL: True,
                wk.KEY: None,
                wk.TEXT: "Select None",
                wk.WIDGET: Button
            })
        ])
        WidgetRow.__init__(self, **d)

    def on_select_button(self, g):
        """
        Respond to Button action.

        g: Button
            Is responsible.
        """
        a = int(g.key == bk.SELECT_ALL)
        for i in self._widget_q:
            i.set_a(a)
