#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_a_contain import Run
from roller_constant_for import Signal as si
from roller_constant_key import ModelList as ml, Option as ok, Step as sk
from roller_one_extract import find_visible_preset
from roller_one_helm import Helm
from roller_view_plan import do_plan_step
from roller_view_step import get_step_d, translate_to_id
from roller_view_work import do_work_step

'''
Define 'view' as factored Draft, Peek, Plan
and Preview's responsible function.
'''


def clean_up():
    """Clean up after a view run."""
    Run.is_back = False


def do_draft():
    """Is a Plan-type view run that stops on the active Preset AnyGroup."""
    step_q, q = get_peek_lists()

    do_planner(step_q)
    update_after_view(q, 0)
    clean_up()


def do_final_render():
    """Make a render and return the session's Steps SuperPreset."""
    Run.is_preview = False
    return do_work()


def do_peek():
    """Is a work view run that stops on the active Preset AnyGroup."""
    step_q, q = get_peek_lists()
    Run.is_preview = True

    do_worker(step_q, get_step_d(step_q), None)
    update_after_view(q, 1)
    clean_up()


def do_plan():
    """Call to do a Plan run."""
    d = get_step_d(sk.DEFAULT_STEP)
    step_d = deepcopy(d)

    step_d.update(
        translate_to_id(d[sk.MODEL][ok.MODEL_LIST][ml.ACTIVE])
    )
    do_planner(Helm.get_step_q())
    clean_up()


def do_planner(step_q):
    """
    Make a render using Plan.

    step_q: list
        Are navigation step key for Plan.
    """
    Run.is_preview = False

    # Plan index, '0'
    Run.x = 0
    do_plan_step(prep(step_q, 0))


def do_preview():
    """Make a render but keep the main window open."""
    Run.is_preview = True

    do_work()
    clean_up()


def do_work():
    """
    Make a render using work.

    Return: tuple
        (
            the default navigation step key dict,
            the navigation tree value dict
        )
    """
    d = get_step_d(sk.DEFAULT_STEP)
    step_d = deepcopy(d)

    step_d.update(
        translate_to_id(d[sk.MODEL][ok.MODEL_LIST][ml.ACTIVE])
    )
    return do_worker(Helm.get_step_q(), step_d, d)


def do_worker(step_q, step_d, d):
    """
    Make a render using work.

    step_q: list
        Are navigation step key for work.

    step_d: dict
        {navigation step key: Preset value dict}

    d: dict or None
        Steps Preset, a session type
        Is returned with a final view run for saving the session.

    Return: tuple
        (the default step value dict, the navigation tree value dict)
    """
    # work index, '1'
    Run.x = 1

    do_work_step(prep(step_q, 1))
    return d, step_d


def get_peek_lists():
    """
    Make two lists for a Draft or Peek function. The first list is composed of
    steps to be processed by a view run, and the second list are steps that
    didn't get processed due to Peek's limitation.

    Return: tuple
        ([step key], [step key])
    """
    nav_k = find_visible_preset()
    q = Helm.get_preset_step_q()
    x = q.index(nav_k) + 1
    return q[:x], q[x:]


def make_run_q(step_q, view_x):
    """
    From the navigation tree step key list, filter out non-run-able step key.
    The list starts from the first altered option group.

    step_q: list
        Are navigation step key visible in the user interface.
        [navigation step key, ...]

    Return: tuple
        (list, int or None)
        list: [(step key, AnyGroup), ...]
        int: index to the first altered group in the provided step key list.
        AnyGroup is strictly preset type.
    """
    q = []
    altered_x = None
    get_group = Helm.get_group

    # Preset-type only
    for x, k in enumerate(step_q):
        a = get_group(k)
        if a and a.item.group_type == 'preset':
            if altered_x is None:
                if a.altered[view_x]:
                    altered_x = x
                    q += [(k, a)]
            else:
                q += [(k, a)]
    return q, altered_x


def prep(step_q, view_x):
    """
    Prepare view run variable.

    step_q: list
        [navigation step key, ...]
        Initialize the image dict.

    view_x: int
        0 or 1; Plan or work

    Return: list
        [(navigation step key, AnyGroup), ...]
    """
    q, step_x = make_run_q(step_q, view_x)
    return q


def update_after_view(non_view_q, x):
    """
    Update AnyGroup that is not part of the
    last view run but has potential change.

    non_view_q: list
        [navigation step key, ...]
        Each item was not viewed.

    x: int
        0 or 1; Plan or work
    """
    p = Helm.get_group
    for k in non_view_q:
        a = p(k)

        if Run.is_back:
            a.emit(si.BACK_CHANGE, x)
        a.changed(x)
