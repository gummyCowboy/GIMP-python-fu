#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk, Window as wi
from roller_port_stripe import PortStripe
from roller_window import Window


class RWStripe(Window):
    """Is a GTK dialog for defining a caption background stripe."""
    def __init__(self, g):
        """
        Create a window.

        g: OptionButton
            Has values.
        """
        self.safe = g
        d = {
            wk.WIN: g.win.win,
            wk.WINDOW_KEY: wi.STRIPE,
            wk.WINDOW_TITLE: "Define Caption Background Stripe"
        }

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self
            }
        )

        self.port = PortStripe(d, g)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()
