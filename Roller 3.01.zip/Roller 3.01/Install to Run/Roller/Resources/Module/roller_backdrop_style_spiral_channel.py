#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import BackdropStyle as bs, Gradient as fg
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_backdrop_style_gradient_fill import GradientFill
from roller_one import Hat
from roller_one_fu import Lay
from roller_option_preset import Preset
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class SpiralChannel:
    """Create a spiral which changes form with various flip mods."""

    @staticmethod
    def do(one):
        """
        Do the backdrop-style.

        The main process is to draw a spiral gradient
        at the center of the image. The current
        is split by a potential tile function.

        one: One
            Has variables.

        Return: layer or None
            with Spiral Channel
        """
        cat = Hat.cat
        j = j1 = cat.render.image
        d = one.d
        if d[ok.OPACITY]:
            group = Lay.group(j, one.k)
            z = Lay.clone(one.z)

            pdb.gimp_image_reorder_item(j, z, group, 0)

            e = Preset.get_default(by.GRADIENT_FILL)
            e[ok.GRADIENT] = "FG to BG (RGB)"

            if d[ok.GRADIENT_DIRECTION] == bs.COUNTER_CLOCKWISE:
                e[ok.GRADIENT_TYPE] = fg.SPIRAL_COUNTER_CW

            else:
                e[ok.GRADIENT_TYPE] = fg.SPIRAL_CLOCKWISE

            e[ok.BUMP] = Preset.get_default(ok.BUMP)
            e[ok.START_X] = e[ok.START_Y] = e[ok.END_Y] = .5
            e[ok.END_X] = .5 + d[ok.SPIRAL_DISTANCE]
            color = d[ok.COLOR]

            # The color inverts when using the difference mode.
            # This reverses that effect:
            if d[ok.SPIRAL_MOD] != "None":
                color = tuple([255 - i for i in d[ok.COLOR]])

            # Preserve:
            q = pdb.gimp_context_get_foreground()
            q1 = pdb.gimp_context_get_background()

            pdb.gimp_context_set_foreground(color)
            pdb.gimp_context_set_background((255, 255, 255))

            is_tile = False
            s = w, h = cat.render.size
            row, column = d[ok.ROW], d[ok.COLUMN]

            if row > 1 or column > 1:
                is_tile = True
                w = s[0] // column
                h = s[1] // row
                j1 = pdb.gimp_image_new(w, h, fu.RGB)
                z = Lay.add(j1, "Tile")
                pdb.gimp_image_set_active_layer(j1, z)

            if is_tile:
                x, y, x1, y1 = RenderHub.get_layer_points(e, w, h)

            else:
                x, y, x1, y1 = RenderHub.get_layer_points(e, s[0], s[1])

            z = GradientFill.do_gradient(z, e, x, y, x1, y1)

            if d[ok.SPIRAL_MOD] != "None":
                z = Lay.clone(z)
                z.mode = fu.LAYER_MODE_DIFFERENCE

                if d[ok.SPIRAL_MOD] in (bs.HORIZONTAL_FLIP, bs.FLIP_BOTH):
                    Lay.flip(z, horizontal=1)
                if d[ok.SPIRAL_MOD] in (bs.VERTICAL_FLIP, bs.FLIP_BOTH):
                    Lay.flip(z)

            if is_tile:
                pdb.gimp_edit_copy_visible(j1)
                pdb.gimp_image_delete(j1)

                tiles = Lay.group(j, "Tiles", parent=group)
                x = y = 0

                for c in range(column):
                    if not c:
                        z = first = Lay.paste(one.z)
                        pdb.gimp_image_reorder_item(j, z, tiles, 0)

                    else:
                        z = Lay.clone(first)
                        x = c * w

                    if c % 2:
                        Lay.flip(z, horizontal=1)
                    pdb.gimp_layer_set_offsets(z, x, y)

                z = first = Lay.merge_group(tiles)

                if row > 1:
                    tiles = Lay.group(j, "Tiles", parent=group)
                    x = 0

                    pdb.gimp_image_reorder_item(j, z, tiles, 0)

                    for r in range(row - 1):
                        z = Lay.clone(first)
                        flip_offset = 0

                        if not r % 2:
                            Lay.flip(z)
                            flip_offset = s[1] - h

                        y = (r + 1) * h - flip_offset
                        pdb.gimp_layer_set_offsets(z, x, y)
                    z = Lay.merge_group(tiles)

                x = s[0] % column // 2 if s[0] % column > 1 else 0
                y = s[1] % row // 2 if s[1] % row > 1 else 0
                if x or y:
                    pdb.gimp_layer_set_offsets(z, x, y)

            z = Lay.merge_group(group)
            z = RenderHub.bump(z, d[ok.BUMP])
            z.opacity = d[ok.OPACITY]

            # Restore:
            pdb.gimp_context_set_foreground(q)
            pdb.gimp_context_set_background(q1)

            return z
