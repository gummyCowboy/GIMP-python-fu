#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class PatternFill:
    """Fill the backdrop with a pattern."""

    @staticmethod
    def do(one):
        """
        Create a Pattern Fill backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            with Pattern Fill
        """
        d = one.d
        if d[ok.OPACITY]:
            z = Lay.clone(one.z)
            s = Hat.cat.render.size
            x, y = RenderHub.get_layer_points(d, s[0], s[1])[:2]

            RenderHub.set_fill_context(d)
            pdb.gimp_context_set_pattern(d[ok.PATTERN])
            pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, x, y)

            if d[ok.INVERT]:
                pdb.gimp_drawable_invert(z, Fu.DrawableInvert.NO_LINEAR)
            return RenderHub.bump(z, d[ok.BUMP])
