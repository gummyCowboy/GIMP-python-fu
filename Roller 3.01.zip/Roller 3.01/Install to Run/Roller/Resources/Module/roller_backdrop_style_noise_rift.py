#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import seed
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
sn = Fu.SolidNoise


class NoiseRift:
    """Create soft lines."""

    @staticmethod
    def do(one):
        """
        Do the backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            with Noise Rift
        """
        j = Hat.cat.render.image
        d = one.d
        if d[ok.OPACITY]:
            z = one.z
            group = Lay.group(j, one.k)

            seed(d[ok.RANDOM_SEED])

            if d[ok.USE_PLASMA]:
                z = Lay.add(j, one.k, parent=group)

                pdb.plug_in_plasma(
                    j, z,
                    d[ok.RANDOM_SEED],
                    Fu.Plasma.LOWEST_TURBULENCE
                )
                Lay.blur(z, 500)
                z = Lay.clone(z)

            else:
                z = Lay.clone(z)

                pdb.gimp_image_reorder_item(j, z, group, 0)
                RenderHub.adjust_mean_value(z)

            RenderHub.add_noise(z, d)

            if d[ok.INVERT_NOISE]:
                pdb.gimp_drawable_invert(z, 0)

            z = Lay.merge_group(group)
            z = RenderHub.bump(z, d[ok.BUMP])
            z.mode, z.opacity = RenderHub.get_mode(d)

            Lay.clone(one.z)
            return pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
