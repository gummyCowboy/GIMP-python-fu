#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_one import Comm
import gimpfu as fu
import math

di = Fu.Dilate
pdb = fu.pdb
ro = Fu.Rotate
sc = Fu.LayerScale
ta = Fu.ThresholdAlpha
LOHALO = fu.INTERPOLATION_LOHALO
NOHALO = fu.INTERPOLATION_NOHALO
NO_LAYER_FOUND = "The layer offset of, {}, was not found"
OPACITY_100 = 100.
SAMPLE_MERGED_NO = 0
THRESHOLD_ALL = .0
X_IS_0 = Y_IS_0 = 0.


class Lay:
    """These are functions used to manage image layers."""

    @staticmethod
    def add(j, n, parent=None, offset=0):
        """
        Add a layer to an image.

        j: GIMP image
            to receive layer

        n: string
            new layer name

        parent: layer
            parent
            group layer

        offset: int
            offset from top
            from parent

        Return: layer
            the new layer
        """
        z = Lay.new(j, n)

        pdb.gimp_image_insert_layer(j, z, parent, offset)
        return z

    @staticmethod
    def adjust_opacity(z):
        """
        For a given layer, adjust its material-only, alpha channel
        mean intensity value, to be above a threshold.

        z: layer
            with material to adjust

        Return: layer, Selection state
            with material
        """
        j = z.image

        # the mean intensity value, 'f':
        f = 0

        while f < 225.:
            # Create a selection-mask:
            Sel.item(z)

            if Sel.is_sel(j):
                # Get the mean intensity value of the material's alpha:
                f = pdb.gimp_drawable_histogram(
                    z, fu.HISTOGRAM_ALPHA, .0, 1.
                )[0]
                if f < 225.:
                    # double-down:
                    z = Lay.clone(z)
                    z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            else:
                break
        return z

    @staticmethod
    def apply_mask(z):
        """
        Apply a layer's mask with itself.

        z: layer
            with mask
        """
        if z and z.mask:
            pdb.gimp_layer_remove_mask(z, fu.MASK_APPLY)

    @staticmethod
    def blur(z, a):
        """
        Blur a layer.

        z: layer
            to receive blur

        a: float or int
            blur amount
        """
        a = min(a, 500.)
        pdb.plug_in_gauss_rle2(z.image, z, a, a)

    @staticmethod
    def clear_image_sel(z, z1):
        """
        From an image selection, remove material from a layer.

        z: layer
            with image

        z1: layer
            to clear
        """
        Sel.make_layer_sel(z)
        Lay.clear_sel(z1)

    @staticmethod
    def clear_sel(z, keep_sel=False):
        """
        Clear a layer's selection.

        If there's no selection, do nothing.
        GIMP will clear the layer otherwise.

        z: layer
            to clear material

        keep_sel: flag
            If it's true, then the selection is removed.
        """
        j = z.image

        if Sel.is_sel(j):
            pdb.gimp_edit_clear(z)
        if not keep_sel:
            pdb.gimp_selection_none(j)

    @staticmethod
    def clone(z):
        """
        Duplicate a layer.

        z: layer
            to duplicate

        Return: layer
            the duplicate
        """
        j = z.image

        pdb.gimp_selection_all(j)

        z1 = pdb.gimp_layer_copy(z, 0)
        a = Lay.offset(z)

        pdb.gimp_image_insert_layer(j, z1, z.parent, a)
        pdb.gimp_selection_none(j)
        return z1

    @staticmethod
    def clone_background(z):
        """
        Make a copy of the background below a layer.
        Insert the copy to be behind the layer.

        z: layer
            work-in-progress

        Return: layer
            the copy of the background
        """
        j = z.image

        Lay.hide_layers_above(z)
        Mage.copy_all(j)
        Lay.show_layer_on_top(z)
        pdb.gimp_selection_none(j)

        z1 = Lay.paste(z)

        pdb.gimp_layer_set_offsets(z1, 0, 0)
        pdb.gimp_image_reorder_item(
            j, z1,
            z.parent,
            Lay.offset(z)
        )
        return z1

    @staticmethod
    def clone_opaque(z, is_opaque):
        """
        Return a duplicate layer with an optional
        transform of no semi-transparent pixels.

        z: layer
            with material

        is_opaque: flag
            When true, the clone is made 100% opaque.
        """
        j = z.image
        z = Lay.clone(z)

        # no semi-transparency:
        if is_opaque:
            pdb.plug_in_threshold_alpha(j, z, ta.THRESHOLD_ALL)
            pdb.plug_in_antialias(j, z)
        return z

    @staticmethod
    def color_fill(z, q):
        """
        Fill a layer with a color.

        z: layer
            to fill

        q: tuple
            RGB color
        """
        # Preserve:
        q1 = pdb.gimp_context_get_background()

        pdb.gimp_context_set_background(q)
        z.fill(fu.BACKGROUND_FILL)
        # Restore:
        pdb.gimp_context_set_background(q1)

    @staticmethod
    def copy_visible(z):
        """
        Copy the visible image material after hiding
        any layers above a given layer within its layer group.

        z: layer
            Layers above this layer are hidden before the image is copied.

        Return: Selection
            in the edit memory buffer
        """
        for z1 in z.parent.layers:
            if z1 == z:
                Mage.copy_all(z.image)
                break
            else:
                Lay.hide(z1)
        for z1 in z.parent.layers:
            if z1 == z:
                break
            else:
                Lay.show(z1)

    @staticmethod
    def create_mask(z, option=fu.ADD_MASK_ALPHA):
        """
        A layer gets an alpha mask.

        z: layer
            to mask

        option: gimpfu enum
            mask type
        """
        mask = pdb.gimp_layer_create_mask(z, option)
        z.add_mask(mask)

    @staticmethod
    def dilate(z):
        """
        Dilate the material on a layer.

        z: layer
            to receive dilation
        """
        pdb.plug_in_dilate(
            z.image,
            z,
            di.OPAQUE,
            di.CHANNEL_0,
            di.FULL_RATE,
            di.DIRECTION_MASK_0,
            di.LOW_LIMIT_0,
            di.UPPER_LIMIT_255
        )

    @staticmethod
    def discard_mask(z):
        """
        Delete a layer's mask.

        z: layer or None
            Has mask.
        """
        if z and z.mask:
            pdb.gimp_layer_remove_mask(z, fu.MASK_DISCARD)

    @staticmethod
    def flip(z, horizontal=0):
        """
        Flip a layer horizontally or vertically.

        z: layer
            to flip

        horizontal: flag
            If it's true, flip layer horizontally.

        Return: layer
            the modified layer
        """
        a = fu.ORIENTATION_HORIZONTAL if horizontal \
            else fu.ORIENTATION_VERTICAL
        return pdb.gimp_item_transform_flip_simple(z, a, True, 0)

    @staticmethod
    def make_name(z, n):
        """
        Name a layer given its name and parent layer.

        z: layer
            parent
            Has name.

        n: string
            layer name
        """
        return "{}: {}".format(z.name, n)

    @staticmethod
    def group(j, n, parent=None, offset=0):
        """
        Create a group layer.

        j: GIMP image
            to receive group

        n: string
            name of group

        parent: layer
            parent layer of group

        offset: int
            offset from the top

        Return: layer
            the group
        """
        z = pdb.gimp_layer_group_new(j)

        pdb.gimp_image_insert_layer(j, z, parent, offset)

        z.name = n
        z.mode = fu.LAYER_MODE_PASS_THROUGH
        return z

    @staticmethod
    def hide(z):
        """
        Make a layer invisible.

        z: layer
            to hide
        """
        if z.visible:
            pdb.gimp_item_set_visible(z, 0)

    @staticmethod
    def has_pixel(z):
        """
        Return the pixel count of a layer.

        Color count will return zero if the layer is completely transparent.

        z: layer
            to check

        Return: int
            the number of colors in the layer
        """
        if z:
            return pdb.plug_in_ccanalyze(z.image, z)

    @staticmethod
    def hide_layers_above(z):
        """
        Hide a layer and any layers above in a layer stack.

        z: layer
            first layer to hide
            child of parent
        """
        for z1 in z.parent.layers:
            Lay.hide(z1)
            if z1 == z:
                break

    @staticmethod
    def merge(z):
        """
        Merge a layer down, then rename it.

        z: layer
            to merge down

        Return: layer
            after the merge
        """
        n = z.name
        z = pdb.gimp_image_merge_down(z.image, z, fu.CLIP_TO_IMAGE)
        z.name = n
        return z

    @staticmethod
    def merge_group(z):
        """
        Merge layer group. Resize merge group to image size.

        z: layer
            group

        Return: layer
            the merged group
        """
        z = pdb.gimp_image_merge_layer_group(z.image, z)

        pdb.gimp_layer_resize_to_image_size(z)
        return z

    @staticmethod
    def new(j, n):
        """
        Create a layer.

        j: GIMP image
            to receive layer

        n: string
            layer name

        Return: layer
            newly created
        """
        return pdb.gimp_layer_new(
            j,
            j.width,
            j.height,
            fu.RGBA_IMAGE,
            n,
            OPACITY_100,
            fu.LAYER_MODE_NORMAL
        )

    @staticmethod
    def offset(z):
        """
        Get a layer's offset from its parent.

        z: layer
            with an unknown offset

        Return: int
            offset
        """
        if z:
            return pdb.gimp_image_get_item_position(z.image, z)
        return -1

    @staticmethod
    def paste(z):
        """
        Paste the content of the buffer.

        j: GIMP image
            to receive the new layer

        z: layer
            paste above this layer

        Return: layer
            newly created
        """
        j = z.image

        # Without a selection, GIMP pastes the
        # buffer material at the topleft.
        # With a selection, GIMP pastes the buffer
        # material centered around the selection:
        pdb.gimp_selection_none(j)

        a = pdb.gimp_edit_paste(z, 0)

        pdb.gimp_floating_sel_to_layer(a)
        return j.active_layer

    @staticmethod
    def remove(z):
        """
        Remove a layer if it exists.

        z: layer
            to remove
        """
        if z and pdb.gimp_item_is_valid(z):
            pdb.gimp_image_remove_layer(z.image, z)

    @staticmethod
    def rotate(j, a):
        """
        Rotate the top layer.

        j: GIMP image
            to rotate

        a: float or int
            rotation amount in degrees

        Return: layer
            the transformed layer
        """
        pdb.gimp_context_set_transform_direction(fu.TRANSFORM_FORWARD)
        pdb.gimp_context_set_transform_resize(fu.TRANSFORM_RESIZE_ADJUST)

        z = pdb.gimp_item_transform_rotate(
            j.layers[0],
            math.radians(a),
            ro.AUTO_CENTER_YES,
            ro.CENTER_X_0,
            ro.CENTER_Y_0
        )

        pdb.gimp_image_resize_to_layers(j)
        return z

    @staticmethod
    def show(z):
        """
        Makes a layer visible.

        z: layer
            to show
        """
        if not z.visible:
            pdb.gimp_item_set_visible(z, 1)

    @staticmethod
    def show_layer_on_top(z):
        """
        Show layers in a group from the top layer
        and stop after the given layer.

        z: layer
            last layer to show
        """
        for z1 in z.parent.layers:
            Lay.show(z1)
            if z1 == z:
                break

    @staticmethod
    def sync_empty(z, z1):
        """
        Synchronize empty (fully transparent) pixels from one layer to
        another. The layer with the transparency may have a layer mask.

        z: layer
            Has the transparency.

        z1: layer
            to clear
        """
        z2 = Lay.clone_opaque(z, True)

        Sel.make_layer_sel(z2)
        Lay.clear_sel(z1)
        Lay.remove(z2)

    @staticmethod
    def transfer_mask(z, z1, option=fu.ADD_MASK_ALPHA):
        """
        Transfer a mask from one layer to another.

        z: layer
            to receive mask

        z1: layer
            with the mask

        option: gimpfu enum
            mask-type
        """
        if not z1.mask:
            Lay.create_mask(z1, option=option)
        if not z.mask:
            z.add_mask(pdb.gimp_layer_create_mask(z1, option))


class Sel:
    """Organize selection functions."""

    @staticmethod
    def color(z, q):
        """
        Create a selection based on color.

        z: layer
            to color

        q: tuple
            RGB color
        """
        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_sample_merged(0)

        # composite:
        pdb.gimp_context_set_sample_criterion(0)
        pdb.gimp_context_set_sample_threshold(.059)
        pdb.gimp_context_set_sample_transparent(1)
        pdb.gimp_image_select_color(z.image, fu.CHANNEL_OP_REPLACE, z, q)

    @staticmethod
    def ellipse(j, x, y, w, h, option=fu.CHANNEL_OP_ADD):
        """
        Make an ellipse selection.

        j: GIMP image
            to receive selection

        x, y: int
            top-left point of ellipse

        w: int
            radius width

        h: int
            radius height

        option: GIMP enum
            add, replace, subtract, or intersect
        """
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_context_set_feather(1)
        pdb.gimp_context_set_feather_radius(2., 2.)
        pdb.gimp_image_select_ellipse(
            j,
            option,
            x, y,
            w, h,
        )

    @staticmethod
    def fill(z, q):
        """
        Fill a selection on a layer.

        z: layer
            to apply fill

        q: tuple
            RGB color
        """
        # Preserve:
        q1 = pdb.gimp_context_get_background()

        pdb.gimp_context_set_background(q)
        pdb.gimp_edit_bucket_fill(
            z,
            fu.BACKGROUND_FILL,
            fu.LAYER_MODE_NORMAL,
            OPACITY_100,
            THRESHOLD_ALL,
            SAMPLE_MERGED_NO,
            X_IS_0, Y_IS_0
        )
        # Restore:
        pdb.gimp_context_set_background(q1)

    @staticmethod
    def grow(j, w, m, feather=0):
        """
        Expand a selection.

        When a selection is grown incrementally,
        the selection appears to be angular.

        j: GIMP image
            with selection

        w: int
            expansion amount

        m: flag
            expansion type
            '0' is rounded.
            '1' is angular.

        feather: bool
            If true the selection is softened with a feather.
        """
        pdb.gimp_context_set_feather(feather)
        if m:
            pdb.gimp_context_set_antialias(0)
            for _ in range(w):
                pdb.gimp_selection_grow(j, 1)
        else:
            pdb.gimp_context_set_antialias(1)
            pdb.gimp_selection_grow(j, w)

    @staticmethod
    def invert(j):
        """
        Invert a selection.

        j: GIMP image
            with selection
        """
        if Sel.is_sel(j):
            pdb.gimp_selection_invert(j)

    @staticmethod
    def invert_clear(z, keep_sel=False):
        """
        Invert and clear a selection.

        z: layer
            Is cleared.

        keep_sel: flag
            If it's true, then the selection is the same on exit.
        """
        j = z.image

        if keep_sel:
            sel = pdb.gimp_selection_save(j)

        Sel.invert(j)
        Lay.clear_sel(z)
        if keep_sel:
            Sel.load(j, sel)
            pdb.gimp_image_remove_channel(j, sel)

    @staticmethod
    def is_sel(j):
        """
        Determine if there is a selection.

        j: GIMP image
            with selection

        Return: bool
            If it's true, then there is a selection.
        """
        return not pdb.gimp_selection_is_empty(j)

    @staticmethod
    def isolate(z, sel, keep_sel=False):
        """
        Clear out material not in a selection.

        z: layer
            with material to clear

        sel: selection
            The selection part is preserved.
            The other part is removed.

        keep_sel: flag
            If true, the selection remains.
        """
        Sel.load(z.image, sel)
        Sel.invert_clear(z, keep_sel=keep_sel)

    @staticmethod
    def item(z, option=fu.CHANNEL_OP_REPLACE):
        """
        Select an item.

        z: layer
            to select

        option: GIMP enum
            selection operation
            replace, add, subtract
        """
        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_antialias(1)
        pdb.gimp_image_select_item(z.image, option, z)

    @staticmethod
    def load(j, sel, option=fu.CHANNEL_OP_REPLACE):
        """
        Load a previously saved selection.

        j: GIMP image
            to receive selection

        sel: selection
            a selection channel of image

        option: selection operation
            add, replace, subtract
        """
        if sel:
            pdb.gimp_context_set_feather(0)
            pdb.gimp_context_set_antialias(0)
            pdb.gimp_image_select_item(j, option, sel)

    @staticmethod
    def make_layer_sel(z):
        """
        Intersect a layer's selection with its mask selection.

        z: layer
            with or without a mask
        """
        Sel.item(z)
        if z.mask:
            Sel.item(z.mask, option=fu.CHANNEL_OP_INTERSECT)

    @staticmethod
    def polygon(j, q, option=fu.CHANNEL_OP_REPLACE):
        """
        Add a polygon selection to the current selection.

        j: GIMP image
            to receive selection

        q: list
            of points

        option: GIMP enum
            add, subtract, or replace the selection mode
        """
        if q:
            pdb.gimp_context_set_antialias(1)
            pdb.gimp_context_set_feather(0)
            pdb.gimp_image_select_polygon(j, option, len(q), q)
        else:
            Comm.info_msg("Sorry. Roller failed to draw a polygon.")

    @staticmethod
    def rect(j, x, y, w, h, option=fu.CHANNEL_OP_ADD):
        """
        Draw a selection rectangle.

        j: GIMP image
            to receive selection
        """
        pdb.gimp_context_set_feather(0)
        pdb.gimp_context_set_antialias(0)
        pdb.gimp_image_select_rectangle(j, option, x, y, w, h)

    @staticmethod
    def select_shape(j, shape, option=fu.CHANNEL_OP_REPLACE):
        """
        Make a selection based on a layer's cell
        shape, and an image's cell rectangle.

        j: GIMP image
            Has render.

        shape: tuple or dict
            If it is a dict, then the shape is a ellipse.
            Otherwise, it is an polygon.

        option: enum
            selection operation
            add, subtract, intersect, or replace
        """
        if isinstance(shape, dict):
            Sel.ellipse(
                j,
                shape['x'], shape['y'],
                shape['w'], shape['h'],
                option=option
            )
        else:
            Sel.polygon(j, shape, option=option)


class Mage:
    """Organize GIMP image-related functions."""

    @staticmethod
    def shape(j, w, h):
        """
        Resize, copy, and close an image.

        j: GIMP image
            with one layer

        w: int
            width to shape

        h: int
            height to shape

        Return: buffered data
            with image
        """
        z = j.layers[0]

        # as recommended by Davies Media Design:
        a = LOHALO if w * h <= j.width * j.height else NOHALO

        pdb.gimp_context_set_interpolation(a)
        pdb.gimp_layer_scale(z, w, h, sc.IMAGE_ORIGIN)
        pdb.gimp_image_resize_to_layers(j)
        pdb.gimp_edit_copy_visible(j)
        pdb.gimp_image_delete(j)

    @staticmethod
    def copy_all(j):
        """
        Copy a visible image while ensuring that it's the whole image.

        j: GIMP
            image
        """
        pdb.gimp_selection_none(j)
        pdb.gimp_edit_copy_visible(j)
