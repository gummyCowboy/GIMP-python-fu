#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Grid as gr, Shape as sh
from roller_one import Rect
from roller_one_extract import Form, Shape


class GridDiamond:
    """
    Calculate the coordinates and the size of cells.

    The cells are diamond shaped.
    """

    def __init__(self, one):
        """
        Calculate cell size and diamond shape.

        one: One
            Has init values.
        """
        grid = self.grid = one.grid
        row, column = self.row, self.column = one.r, one.c
        table = grid.table
        s = one.layer_space
        x, y = one.offset
        self.is_not_shift = grid.double_type == sh.NOT_SHIFT

        # intersect points:
        q_x = self.q_x = []
        q_y = self.q_y = []

        if one.grid_type == gr.CELL_SIZE:
            # cell size:
            w, h = one.column_width / 1., one.row_height / 1.

            # table size:
            w1, h1 = w / 2., h / 2.
            s1 = w + (column - 1) * w1, h + (row - 1) * h1
            x, y = Shape.calc_pin_offset(
                one.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        elif one.grid_type == gr.SHAPE_COUNT:
            # cell size:
            w = s[0] / (.5 + column * .5)
            h = s[1] / (.5 + row * .5)
            w = min(w, h) / 1.
            w, h = w, w

            # table size:
            h1 = h / 2.
            s1 = column * h1 + h1, row * h1 + h1
            x, y = Shape.calc_pin_offset(
                one.pin_corner,
                s,
                s1[0], s1[1],
                x, y
            )

        else:
            w = s[0] / (.5 + column * .5)
            h = s[1] / (.5 + row * .5)

        offset = x, y

        # intersects:
        w1 = w / 2
        h1 = h / 2
        for c in range(column + 2):
            q_x.append(int(round(x)))
            x += w1

        for r in range(row + 2):
            q_y.append(int(round(y)))
            y += h1

        # Compose points:
        for r in range(row):
            for c in range(column):
                if Shape.is_allocated_cell(self.grid, r, c):
                    y, y1, y2 = q_y[r], q_y[r + 1], q_y[r + 2]
                    x, x1, x2 = q_x[c], q_x[c + 1], q_x[c + 2]
                    position = x, y
                    size = x2 - x, y2 - y

                    if (
                        x + size[0] > s[0] + offset[0] or
                        y + size[1] > s[1] + offset[1]
                    ):
                        position = size = 0, 0

                    # 'cell' is the cell rectangle before margins:
                    table[r][c].cell = Rect(position, size)
                    if size[0]:
                        table[r][c].plaque = x, y1, x1, y, x2, y1, x1, y2

    def _do_per_cell(self, r, c, q):
        """
        Get and calculate the points to make a diamond.

        Vertical triangles face up or down.

        r, c: int
            cell index

        q: tuple
            top, bottom, left, right

        is_inverted: flag
            If it's true, the triangle is inverted.

        Return: tuple
            of lists
            x-intersect list, x-pocket list, and
            y-intersect list, y-pocket list
            Each list has strict synchronized points.
        """
        top, bottom, left, right = q
        x_list = [-1] * 4
        y_list = [-1] * 4
        x_list_1 = [0] * 4
        y_list_1 = [0] * 4

        # Get points from intersects:
        # of y:
        if not top:
            y_list[1] = self.q_y[r]

        if not bottom:
            y_list[3] = self.q_y[r + 2]

        if not top and not bottom:
            y_list[0] = y_list[2] = self.q_y[r + 1]

        # of x:
        if not left:
            x_list[0] = self.q_x[c]

        if not right:
            x_list[2] = self.q_x[c + 2]

        if not left and not right:
            x_list[1] = x_list[3] = self.q_x[c + 1]

        # Calc shape from pocket:
        rect = self.grid.table[r][c].pocket

        # of y:
        y_list_1[1] = rect.y
        y_list_1[3] = rect.y + rect.h
        y_list_1[0] = y_list_1[2] = rect.y + rect.h // 2

        # of x:
        x_list_1[0] = rect.x
        x_list_1[2] = rect.x + rect.w
        x_list_1[1] = x_list_1[3] = rect.x + rect.w // 2

        # Return the intersect and pocket-bound points:
        return x_list, x_list_1, y_list, y_list_1

    def calc_shape_per_cell(self, cell_table):
        """
        Calculate the shape of the diamond from
        the pocket size on a per cell basis.

        Is part of the Grid template.

        cell_table: list
            of cell margin
        """
        for r in range(self.row):
            for c in range(self.column):
                if Shape.is_allocated_cell(self.grid, r, c):
                    rect = self.grid.table[r][c].cell
                    if rect.w:
                        q = Form.combine_margin(
                            cell_table[r][c],
                            rect.w, rect.h
                        )
                        x_list, x_list_1, y_list, y_list_1 = \
                            self._do_per_cell(r, c, q)

                        q = zip(x_list, x_list_1)
                        q_x = map(Shape.get_point, q)
                        q = zip(y_list, y_list_1)
                        q_y = map(Shape.get_point, q)
                        q = zip(q_x, q_y)
                        self.grid.table[r][c].shape = [j for i in q for j in i]

    def calc_shape_with_pocket(self):
        """
        Calculate the shape of the diamond from
        the pocket size using intersects.

        Is part of the Grid template.
        """
        q = self.grid.table

        # intersect points:
        q_x = self.q_x = []
        q_y = self.q_y = []

        for c in range(self.column):
            if self.row == 1:
                r = 0
                if Shape.is_allocated_cell(self.grid, 0, c):
                    rect = q[r][c].pocket
                else:
                    rect = Rect((0, 0), (0, 0))

            else:
                r = c % 2 if self.is_not_shift else not c % 2
                rect = q[r][c].pocket

            x = rect.x

            q_x.append(x)
            q_x.append(x + rect.w // 2)
            q_x.append(x + rect.w)

        for r in range(self.row):
            if self.column == 1:
                c = 0
                if Shape.is_allocated_cell(self.grid, r, 0):
                    rect = q[r][c].pocket
                else:
                    rect = Rect((0, 0), (0, 0))

            else:
                c = r % 2 if self.is_not_shift else not r % 2
                rect = q[r][c].pocket

            y = rect.y

            q_y.append(y)
            q_y.append(y + rect.h // 2)
            q_y.append(y + rect.h)
        for r in range(self.row):
            for c in range(self.column):
                if Shape.is_allocated_cell(self.grid, r, c):
                    if q[r][c].pocket.w:
                        x = q_x[c * 3]
                        x1 = q_x[c * 3 + 1]
                        x2 = q_x[c * 3 + 2]
                        y = q_y[r * 3]
                        y1 = q_y[r * 3 + 1]
                        y2 = q_y[r * 3 + 2]
                        q[r][c].shape = x, y1, x1, y, x2, y1, x1, y2
