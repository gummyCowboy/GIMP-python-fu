#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Widget as fw
from roller_constant_key import Button as bk, Widget as wk
from roller_widget_button import Button, PreviewButton
import gtk


class ButtonPair(gtk.Alignment):
    """Is an GTK HBox with two Buttons."""

    def __init__(self, **d):
        """
        Create an HBox with some buttons.

        d: dict
            Has init values.
        """
        super(gtk.Alignment, self).__init__()

        if wk.RENDER_PAD in d:
            self.set_padding(*d[wk.RENDER_PAD])

        w = fw.MARGIN
        w1 = w // 2
        self.key = d[wk.KEY] if wk.KEY in d else None
        same_size = gtk.SizeGroup(mode=gtk.SIZE_GROUP_BOTH)
        hbox = gtk.HBox()
        q = d[wk.TEXT]
        d[wk.KEY] = d[wk.TEXT] = q[0]
        d[wk.PADDING] = w1, w1, 0, w1
        d[wk.ALIGN] = 0, 0, 1, 0
        g = self.left_button = Button(**d)
        n = d[wk.KEY] = d[wk.TEXT] = q[1]
        d[wk.PADDING] = w1, w1, w1, 0
        g1 = self.right_button = PreviewButton(**d) \
            if n == bk.PREVIEW else Button(**d)

        for i in (g, g1):
            hbox.pack_start(i, expand=1)
            same_size.add_widget(i.widget)
        self.add(hbox)
