#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import (
    Format as ff,
    Gradient as fg,
    Plan as fy,
    Plaque as aq,
    Shape as sh
)
from roller_constant_key import Layer as nk, Option as ok
from roller_constant_fu import Fu
from roller_effect_feather_steps import FeatherSteps
from roller_model_image import Image
from roller_one import Base, Comm, Hat, Mode, One
from roller_one_extract import dispatch, Form, Path, Shape
from roller_one_fu import Lay, Mage, Sel
from roller_render_gradient_light import GradientLight
from roller_render_hub import RenderHub
from roller_render_shadow import Shadow
import gimpfu as fu

gf = Fu.GradientFill
pdb = fu.pdb
GRID = "Grid Broken"
OPACITY_100 = 255
PER_CELL_TYPE = aq.AVERAGE_COLOR, aq.GRADIENT, aq.IMAGE, aq.SHADOW


def blur_behind(z, d):
    """
    Blur behind plaque material.

    z: layer
        with material

    d: dict
        Has the blur behind option.

    Return: layer
        with material
    """
    z1 = RenderHub.blur_behind(z, d, has_mode=True)
    if z1:
        z = z1
    return z


def do_average_color(j, z, one):
    """
    Make an average color plaque.

    Exit with a selection to save.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has cell data.

    opacity: float
        for plaque layer

    Return: state of image, layer
        selection, with material
    """
    d = one.d

    if one.is_layer:
        pdb.gimp_selection_none(j)
        j1 = None

    else:
        # Disconnect the dict so it doesn't change:
        one.image_index = deepcopy(one.image_index)

        grid_d = one.grid.grid_d if one.grid else None
        j1 = Image.get_image_for_cell(
            Path.get_cell_place_chunk(one.path),
            grid_d,
            one.image_index,
            one.r, one.c,
            one.is_merge_cell
        )

        if j1 and j1.j:
            Mage.copy_all(j1.j)
            Image.close_image(j1)
        else:
            j1 = None

    if j1:
        j1 = pdb.gimp_edit_paste_as_new_image()

        pdb.plug_in_pixelize2(
            j1, j1.layers[0],
            j1.width,
            j1.height,
        )
        Mage.shape(j1, one.w, one.h)

    else:
        # There's no image, so use background.
        # Copy selection:
        Sel.rect(
            j,
            one.x, one.y,
            one.w, one.h,
            option=fu.CHANNEL_OP_REPLACE
        )
        pdb.gimp_edit_copy_visible(j)

        j1 = pdb.gimp_edit_paste_as_new_image()

        pdb.plug_in_pixelize2(
            j1, j1.layers[0],
            j1.width, j1.height
        )
        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

    z = Lay.paste(z)

    pdb.gimp_layer_set_offsets(z, one.x, one.y)
    Sel.item(z)
    Sel.select_shape(j, one.plaque)
    Sel.invert_clear(z, keep_sel=True)
    feather(z, d)

    z = RenderHub.bump(z, d[ok.BUMP])

    Sel.item(z)
    return z


def do_cell(one):
    """
    The cell has a plaque.

    one: One
        Has cell data.
    """
    cat = Hat.cat
    j = cat.render.image
    d = one.d
    _type = d[ok.PLAQUE_TYPE]
    if _type in plaque_process:
        z = Lay.add(j, "Plaque", parent=one.group)

        if one.is_one_sel:
            Sel.select_shape(j, one.plaque)

        else:
            if one.is_plan:
                z = do_color(j, z, one)
            else:
                z = plaque_process[_type](j, z, one)
                if z:
                    z.opacity = d[ok.OPACITY]

        cat.save_plaque_sel(one.model_name, one.r, one.c)
        if not one.is_one_sel and not one.is_plan:
            if is_blur_behind(d):
                blur_behind(z, d)
            else:
                do_mode(z, d)


def do_color(j, z, one):
    """
    Make a image plaque.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has options.

    Return: state of image, layer
        selection, with material
    """
    if not one.is_one_sel:
        Sel.select_shape(j, one.plaque)

    Sel.fill(z, get_color(one))

    if not one.is_plan:
        feather(z, one.d)
        z = RenderHub.bump(z, one.d[ok.BUMP])

    Sel.item(z)
    return z


def do_gradient(j, z, one):
    """
    Make a gradient plaque.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    def draw_gradient():
        pdb.gimp_drawable_edit_gradient_fill(
            z,
            fg.GRADIENT_TYPE_LIST.index(gradient_type),
            gf.OFFSET_0,
            gf.YES_SUPERSAMPLE,
            gf.SUPERSAMPLE_MAX_DEPTH_2,
            gf.SUPERSAMPLE_THRESHOLD_0,
            gf.YES_DITHER,
            start_x, start_y,
            end_x, end_y
        )

    d = one.d
    gradient = d[ok.GRADIENT]

    if gradient not in Hat.cat.gradient_list:
        Comm.info_msg(
            ff.MISSING_ITEM.format("Plaque", "gradient", gradient)
        )
    else:
        x, y, w, h = one.x, one.y, one.w, one.h
        gradient_type = d[ok.GRADIENT_TYPE]

        RenderHub.set_fill_context(fg.FILL_DICT)
        pdb.gimp_context_set_gradient(gradient)
        pdb.gimp_context_set_gradient_blend_color_space(
            fu.GRADIENT_BLEND_RGB_PERCEPTUAL
        )
        pdb.gimp_context_set_gradient_reverse(0)

        start_x, end_x, start_y, end_y =\
            RenderHub.get_gradient_points(
                d[ok.GRADIENT_ANGLE],
                x, y,
                w, h
            )

        Sel.rect(j, x, y, w, h, option=fu.CHANNEL_OP_REPLACE)
        draw_gradient()
        Sel.select_shape(j, one.plaque)
        Sel.invert_clear(z, keep_sel=True)
        feather(z, d)

        z = RenderHub.bump(z, d[ok.BUMP])

        Sel.item(z)
        return z


def do_image(j, z, one):
    """
    Make a image plaque.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has cell image.

    opacity: float
        for plaque layer

    Return: state of image, layer or None
        selection, with material
    """
    d = one.d
    j1 = Image.get_image(d[ok.IMAGE], one.image_index)

    if j1:
        j2 = j1.j

        pdb.gimp_selection_none(j)
        Mage.copy_all(j2)
        Image.close_image(j1)

        j2 = pdb.gimp_edit_paste_as_new_image()

        Mage.shape(j2, one.w, one.h)

        z = Lay.paste(z)

        pdb.gimp_layer_set_offsets(z, one.x, one.y)
        Sel.item(z)

        if d[ok.BLUR]:
            Lay.blur(z, d[ok.BLUR])

        Sel.select_shape(j, one.plaque)
        Sel.invert_clear(z, keep_sel=True)
        feather(z, d)

        z = RenderHub.bump(z, d[ok.BUMP])

        Sel.item(z)
        return z
    else:
        # There is no plaque:
        pdb.gimp_selection_none(j)


def do_mode(z, d):
    """
    If the plaque paint mode is not Normal, then
    set the layer's mode. Merge the plaque
    layer with a copy of the background in order
    to normalize the influence.

    z: layer
        Has plaque material.

    d: dict
        Has mode.

    Return: layer
        with plaque material
    """
    n = d[ok.MODE]

    if z and n != "Normal":
        z1 = Lay.clone_background(z)

        Sel.item(z)
        Sel.invert_clear(z1)

        z.mode = Mode.get_(d)
        z = Lay.merge(z)
    return z


def do_netting(j, z, one):
    """
    Make a netting plaque.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    d = one.d
    w = d[ok.NET_LINE_SPACING]
    color = d[ok.COLOR]
    w1 = d[ok.NET_LINE_WIDTH]

    if not one.is_one_sel:
        Sel.select_shape(j, one.plaque)

    pdb.plug_in_grid(
        j, z,
        w1,
        w,
        w,
        color,
        OPACITY_100,
        w1,
        w,
        w,
        color,
        OPACITY_100,
        0,
        0,
        0,
        (0, 0, 0),
        0
    )

    if d[ok.FEATHER]:
        Sel.select_shape(j, one.plaque)
        FeatherSteps.feather_layer_sel(z, d)

    sel = pdb.gimp_selection_save(j)
    z = RenderHub.bump(z, one.d[ok.BUMP])

    Sel.load(j, sel)
    pdb.gimp_image_remove_channel(j, sel)
    return z


def do_pattern(j, z, one):
    """
    Make a pattern plaque.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    d = one.d
    pattern = d[ok.PATTERN]

    if pattern in Hat.cat.pattern_list:
        if not one.is_one_sel:
            Sel.select_shape(j, one.plaque)

        RenderHub.set_fill_context(fg.FILL_DICT)
        pdb.gimp_context_set_pattern(pattern)

        # Try and fill the selection by keeping the
        # fill point within the visible canvas:
        x = Base.seal(one.x, 0, j.width - 1)
        y = Base.seal(one.y, 0, j.height - 1)

        pdb.gimp_drawable_edit_bucket_fill(
            z,
            fu.FILL_PATTERN,
            Base.seal(x, 0, j.width),
            Base.seal(y, 0, j.height)
        )

        if d[ok.BLUR]:
            Lay.blur(z, d[ok.BLUR])

        feather(z, d)

        z = RenderHub.bump(z, d[ok.BUMP])
        Sel.item(z)

    else:
        Comm.info_msg(ff.MISSING_ITEM.format("Plaque", "pattern", pattern))
    return z


def do_plasma(j, z, one):
    """
    Make a plasma plaque.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    d = one.d

    if one.is_one_sel:
        # Is a work-around for a plasma bug not filling a selection correctly:
        sel = Hat.cat.save_short_term_sel()

    pdb.gimp_selection_none(j)
    pdb.plug_in_plasma(j, z, d[ok.RANDOM_SEED], 3)

    if d[ok.BLUR]:
        Lay.blur(z, d[ok.BLUR])

    if one.is_one_sel:
        Sel.load(j, sel)

    else:
        Sel.select_shape(j, one.plaque)

    Sel.invert_clear(z)
    feather(z, d)

    z = RenderHub.bump(z, d[ok.BUMP])

    Sel.item(z)
    return z


def do_shadow(j, z, one):
    """
    Make a shadow plaque.

    j: GIMP image
        Is render.

    z: layer
        work-in-progress

    one: One
        Has cell data.

    Return: state of image, layer
        selection, with material
    """
    d = one.d

    Sel.select_shape(j, one.plaque)
    Sel.fill(z, (0, 0, 0))

    z1 = Shadow.do(
        One(
            cast=(z,),
            d=d,
            is_inner=True,
            model_name=one.model_name,
            parent=one.group
        )
    )

    pdb.gimp_image_remove_layer(j, z)

    z = z1

    if z1:
        feather(z1, d)

        z = RenderHub.bump(z1, d[ok.BUMP])
        Sel.item(z)
    return z


def feather(z, d):
    """
    Feather the plaque selection.

    z: layer
        Has material.

    d: dict
        Has feather option.
    """
    if d[ok.FEATHER]:
        FeatherSteps.feather(z, d)
        Sel.item(z)


def get_color(one):
    """
    Get the color for the border material.

    d: dict
        of border

    Return: tuple
        RGB
    """
    if one.is_plan:
        return one.color
    return one.d[ok.COLOR]


def is_blur_behind(d):
    """
    Determine if blur behind is in effect.

    Return: bool
        Is true when the blur behind is to be done.
    """
    return d[ok.BLUR_BEHIND] and d[ok.OPACITY]


class Plaque:
    """
    Manage Plaque operation.

    Require a backdrop image for Plaque's average color function.
    """
    @staticmethod
    def do_custom_cell(one, is_plan):
        """
        Do the plaque for a custom cell.

        one: One
            Has variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with plaque
        """
        cat = Hat.cat
        j = cat.render.image
        parent = one.parent
        d = one.d
        r = fy.CUSTOM_CELL
        z = group = None
        opacity = d[ok.OPACITY]
        _type = d[ok.PLAQUE_TYPE]
        shape = one.cell.shape

        if opacity and _type != "None":
            a = one.cell.rect
            one.is_one_sel = one.is_layer = False
            one.r = one.c = r
            one.is_merge_cell = one.is_per_cell = False
            one.plaque = dispatch[shape](a)
            one.shape = shape
            one.is_plan = is_plan
            one.x, one.y = a.position
            one.w, one.h = a.size
            group = one.group = Lay.group(
                j,
                Lay.make_name(parent, nk.CELL_PLAQUE),
                parent=parent
            )
            do_cell(one)

        if group:
            z = Lay.merge_group(group)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.DECO)
        return z

    @staticmethod
    def do_grid(one, is_plan):
        """
        Do the plaque for the grid cells.

        one: One
            Has init values.

        is_plan: bool
            Is true when the caller is Plan.

        Return: layer or None
            with plaque material
        """
        def act():
            """Use to lower indentation."""
            one.r, one.c = r, c
            e = one.d = Form.get_form(d, r, c) if is_per_cell else d
            m = e[ok.OPACITY] and e[ok.PLAQUE_TYPE] != "None"

            if m:
                m = Shape.is_allocated_cell(one.grid, r, c)

            if m:
                if is_merge_cell:
                    if grid_d[ok.PER_CELL][r][c] == (-1, -1):
                        m = False
            if m:
                rect = one.grid.get_merge_cell_rect(r, c)
                one.x, one.y = rect.position
                one.w, one.h = rect.size

                if is_merge_cell:
                    one.plaque = dispatch[sh.RECTANGLE](rect)

                else:
                    one.plaque = one.grid.get_plaque(r, c)

                if not one.group:
                    one.group = Lay.group(
                        j,
                        Lay.make_name(parent, nk.CELL_PLAQUE),
                        parent
                    )
                do_cell(one)

        cat = Hat.cat
        j = cat.render.image
        z = one.group = None
        parent = one.parent
        row, column = one.grid.division
        is_merge_cell = one.is_merge_cell = one.grid.is_merge_cell
        d = one.d
        grid_d = one.grid.grid_d
        is_per_cell = one.is_per_cell = d[ok.PER_CELL]
        one.is_one_sel = one.is_layer = False
        one.shape = one.grid.cell_shape
        one.is_plan = is_plan
        go = True
        f, n = d[ok.OPACITY], d[ok.PLAQUE_TYPE]

        if not is_per_cell:
            go = f and n != "None"

        if go:
            if not is_per_cell and n not in PER_CELL_TYPE:
                one.is_one_sel = True
            for r in range(row):
                for c in range(column):
                    act()

        if one.is_one_sel:
            pdb.gimp_selection_none(j)

            z = Lay.add(j, "Fill", parent=one.group)
            z.opacity = d[ok.OPACITY]
            q = [
                cat.get_plaque_sel(one.model_name, r, c)
                for r in range(row) for c in range(column)
            ]

            [Sel.load(j, i, option=fu.CHANNEL_OP_ADD) for i in q if i]
            if Sel.is_sel(j):
                if is_plan:
                    z = do_color(j, z, one)
                else:
                    z = plaque_process[n](j, z, one)
                    if not is_plan:
                        if is_blur_behind:
                            z = blur_behind(z, d)
                        else:
                            z = do_mode(z, d)

        if one.group:
            z = Lay.merge_group(one.group)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.DECO)
        return z

    @staticmethod
    def do_layer(one, is_plan):
        """
        Add plaque layer.

        Is one per grid.

        one: One
            Has init variables.

        is_plan: bool
            Is true when the caller is Plan.

        Return: list
            with plaque layer
        """
        d = one.d
        z = None
        opacity = d[ok.OPACITY]
        _type = d[ok.PLAQUE_TYPE]
        go = opacity and _type != "None"
        if go:
            cat = Hat.cat
            parent = one.parent
            j = cat.render.image
            one.is_layer = True
            one.is_plan = is_plan
            one.is_one_sel = False
            size = cat.render.size

            if d[ok.OBEY_MARGINS]:
                one.y, bottom, one.x, right = one.layer_margin
                one.w = size[0] - one.x - right
                one.h = size[1] - one.y - bottom

            else:
                one.x = one.y = 0
                one.w, one.h = size

            w, h = one.x + one.w, one.y + one.h
            one.plaque = one.x, one.y, w, one.y, w, h, one.x, h
            one.group = Lay.group(
                j,
                Lay.make_name(parent, nk.LAYER_PLAQUE),
                parent,
                len(parent.layers)
            )
            if _type in plaque_process:
                z = Lay.add(j, "Layer Plaque", parent=one.group)
                z = plaque_process[_type](j, z, one)

                if z:
                    z.opacity = d[ok.OPACITY]

                z = Lay.merge_group(one.group)

                cat.save_plaque_sel(one.model_name, fy.LAYER, fy.LAYER)
                if not is_plan:
                    if is_blur_behind(d):
                        z = blur_behind(z, d)
                    else:
                        z = do_mode(z, d)

        if not is_plan:
            z = GradientLight.apply_light(z, ok.DECO)
        return z


plaque_process = {
    aq.AVERAGE_COLOR: do_average_color,
    aq.COLOR: do_color,
    aq.IMAGE: do_image,
    aq.GRADIENT: do_gradient,
    aq.NETTING: do_netting,
    aq.PATTERN: do_pattern,
    aq.PLASMA: do_plasma,
    aq.SHADOW: do_shadow
}
