#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import randint
from roller_constant_for import Widget as fw
from roller_constant_key import Widget as wk
from roller_one import Hat
from roller_option_preset import NonPreset
from roller_option_group import OptionGroup
from roller_port_preview import PortPreview
from roller_widget_box import Box
from roller_widget_button import Button, PreviewButton
from roller_widget_tree import ChoiceList
import gtk
from roller_widget_box import Eventful
from roller_widget_label import Label


class PortChoice(PortPreview):
    """Is a port with a Treeview list and process Buttons."""

    def __init__(self, d, g, k):
        """
        Create choice widgets.

        d: dict
            Has initial widget values.

        g: OptionButton
            Has widget value.

        k: string
            name of choice
        """
        self._key = k
        self.group = OptionGroup(
            **{
                wk.CONTAINER: None,
                wk.GROUP_KEY: k,
                wk.GROUP_TYPE: NonPreset,
                wk.PATH: (k,)
            }
        )
        PortPreview.__init__(self, d, g)

    def _draw_list_group(self, g):
        """
        Draw the list group.

        g: GTK container
            for list group
        """
        key = self._key

        # without the case-sensitive:
        for i in ('radient', 'rush', 'ont', 'attern'):
            if i in key:
                break

        q = self._list = {
            'rush': Hat.cat.brush_list,
            'ont': Hat.cat.font_list,
            'radient': Hat.cat.gradient_list,
            'attern': Hat.cat.pattern_list
        }[i]
        choice = self.safe.get_value()
        self.choice_list = ChoiceList(
            **{
                wk.CONTAINER: g,
                wk.LIST: q,
                wk.CHOICE: choice,
                wk.ON_KEY_PRESS: self.on_key_press,
                wk.ON_WIDGET_CHANGE: self.on_widget_change
            }
        )
        self.treeview = self.choice_list.treeview

    def draw_process_group(self, g):
        """
        Draw a process group with cancel and accept options.

        g: GTK container
            to receive group
        """
        w = fw.MARGIN
        w1 = w // 2
        hbox = Box(box=gtk.HBox, align=(0, 0, 1, 1))
        q = (
            Button(
                align=(0, 0, 1, 0),
                on_widget_change=self._cancel,
                padding=(w, w, w, w1),
                text="Cancel"
            ),
            Button(
                align=(0, 0, 1, 0),
                on_widget_change=self.randomize,
                padding=(w, w, w1, w1),
                text="Randomize"
            ),
            PreviewButton(
                align=(0, 0, 1, 0),
                group=self.group,
                on_preview_button=self.task_preview,
                padding=(w, w, w1, w1),
            ),
            Button(
                align=(0, 0, 1, 0),
                on_widget_change=self.accept_preview,
                padding=(w, w, w1, w),
                text="Accept"
            )
        )

        for i in q:
            hbox.add(i)

        self._preview_button = q[2]

        g.add(hbox)
        self.keep(q)

    def draw_port(self, g):
        """
        Draw the port's widgets.

        Is part of the Port template.

        g: VBox
            container for the widgets
        """
        q = self._draw_list_group, self.draw_process_group
        name = "Available {}".format(self._key), ""

        for x, p in enumerate(q):
            box = Eventful(self.color)
            vbox = gtk.VBox()

            box.add(vbox)

            if name[x]:
                vbox.pack_start(
                    Label(
                        padding=(4, 4, 4, 4),
                        text=name[x] + ":"
                    ),
                    expand=False
                )

            p(vbox)
            self.reduce_color()
            g.pack_start(box, expand=(True, False)[x])
        self.roller_window.win.vbox.set_size_request(350, 390)

    def get_group_value(self):
        """
        Use to get the value of the list selection.
        Call from PortPreview.

        Return: string
            Is choice from choice list.
        """
        x = self.treeview.get_selection().get_selected_rows()[1][0][0]
        return self._list[x]

    def randomize(self, _):
        """
        Randomize a choice for the list.

        _: Button
            Is responsible.
            no use
        """
        if len(self._list):
            self.choice_list.select_item(randint(0, len(self._list) - 1))
