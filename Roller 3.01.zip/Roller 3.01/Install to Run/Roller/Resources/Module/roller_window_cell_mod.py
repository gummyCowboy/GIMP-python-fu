#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk, Window as wi
from roller_port_cell_mod import PortCellMod
from roller_window import Window


class WindowCellMod(Window):
    """Draw a cell data modification window."""

    def __init__(self, d, g, r, c):
        """
        Create window.

        d: dict
            Has init values.
            of PortCell

        g: widget
            Has cell table.

        r, c: int
            cell position
        """
        d[wk.WINDOW_KEY] = wi.CELL_MOD
        self._accept_window = d[wk.ON_ACCEPT]

        Window.__init__(self, d)
        d.update(
            {
                wk.ON_ACCEPT: self.accept,
                wk.ON_CANCEL: self.cancel,
                wk.WIN: self,
                wk.WINDOW_TITLE: d[wk.WINDOW_TITLE]
            }
        )

        self.port = PortCellMod(d, g, r, c)

        self.win.vbox.add(self.port.pane)
        self.win.show_all()
        self.win.run()
        self.win.destroy()

    def accept(self, cell_table):
        """
        Close the window.

        Return: true
            The key-press is handled.
        """
        self._accept_window(cell_table)
        return self.close()
