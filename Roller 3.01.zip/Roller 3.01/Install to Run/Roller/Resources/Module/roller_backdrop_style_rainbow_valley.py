#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
import gimpfu as fu

pdb = fu.pdb
sn = Fu.SolidNoise


def noise(z, d):
    """
    Adds noise to a layer.

    z: layer
        layer that receives noise

    d: dict
        Has options.
    """
    if d[ok.POWER]:
        cat = Hat.cat

        pdb.plug_in_solid_noise(
            cat.render.image,
            z,
            sn.NO_TILEABLE,
            sn.YES_TURBULENT,
            d[ok.RANDOM_SEED],
            sn.MEDIUM_DETAIL,
            sn.HORIZONTAL_SIZE_2,
            sn.VERTICAL_SIZE_2
        )
        pdb.plug_in_hsv_noise(
            cat.render.image,
            z,
            Fu.HSVNoise.MEDIUM_HOLDNESS,
            d[ok.POWER],
            d[ok.POWER],
            d[ok.POWER]
        )


class RainbowValley:
    """Fill the backdrop with a colorful abstract."""

    @staticmethod
    def do(one):
        """
        Create the Rainbow Valley backdrop-style.

        one: One
            Has variables.

        Return: layer
            Has material.
        """
        e = deepcopy(one.d)
        j = Hat.cat.render.image
        z = Lay.clone(one.z)
        group = Lay.group(j, one.k)

        pdb.plug_in_plasma(j, z, e[ok.RANDOM_SEED], 3)
        pdb.gimp_image_reorder_item(j, z, group, 0)

        for i in range(10):
            z = Lay.clone(z)
            z.name = "Layer #{} of 10".format(i + 1)
            z.mode = fu.LAYER_MODE_DIFFERENCE

            pdb.plug_in_despeckle(j, z, i, 0, 0, 255)

            if i % 2:
                z = Lay.clone(z)
                z.mode = fu.LAYER_MODE_LIGHTEN_ONLY

                noise(z, e)

                e[ok.RANDOM_SEED] += 1

                pdb.plug_in_despeckle(j, z, i, 0, 0, 255)
                z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

            do_engrave = 0

            if e[ok.TEXTURE]:
                if i < 7 or i == 9:
                    do_engrave = 1

            elif i < 7:
                do_engrave = 1

            if do_engrave:
                z = Lay.clone(z)

                pdb.plug_in_engrave(j, z, max(i, 2), 1)

                z.mode = fu.LAYER_MODE_BURN
                z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
                pdb.plug_in_wind(
                    j,
                    z,
                    Fu.Wind.THRESHOLD_0,
                    Fu.Wind.FROM_TOP,
                    Fu.Wind.STRENGTH_50,
                    Fu.Wind.BLAST,
                    Fu.Wind.LEADING_EDGE
                )

        z = Lay.merge_group(group)

        if e[ok.EMBOSS]:
            z = Lay.clone(z)
            z.mode = fu.LAYER_MODE_OVERLAY

            pdb.plug_in_emboss(j, z, Hat.cat.light_angle, 30., 1, 1)
            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
        return z
