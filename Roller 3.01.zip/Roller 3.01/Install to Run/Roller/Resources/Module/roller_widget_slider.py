#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Widget as wk
from roller_widget import Widget
import gtk

# For GTK, let it know that the function handled an event:
DONE = 1


class Slider(Widget):
    """
    Combine a HScale, arrow buttons, and a
    spin button to make a unified slider.
    """
    change_signal = 'value-changed'

    def __init__(self, **d):
        """
        Create a slider group of widgets.

        d: dict
            Has init values.
        """
        self._precision = d[wk.PRECISION] if wk.PRECISION in d else 0
        self._limit = d[wk.LIMIT]
        hbox = gtk.HBox()

        if self._precision == 0:
            self._page_increment = 1.

        elif self._precision == 1 and self._limit[1] > 10:
            self._page_increment = 1.

        else:
            self._page_increment = .1

        # step:
        a = 2
        b = self._limit[1]

        if b > 50:
            a = 5
            if b > 100:
                a = 10

        if self._precision == 0:
            climb_rate = 1.25
            step = (1, a)

        else:
            climb_rate = .05

            if self._precision == 1:
                if self._limit[1] < 5:
                    step = (.1, .5)
                else:
                    step = (1., a)
            else:
                step = (.01, .1)

        adjustment = self._adjustment = gtk.Adjustment(
            value=0.,
            lower=self._limit[0] / 1.,
            upper=self._limit[1] / 1.,
            step_incr=step[0],
            page_incr=self._page_increment,
            page_size=0.
        )

        # an horizontal scale
        g = gtk.HScale(adjustment=adjustment)

        g.set_digits(self._precision)

        d[wk.ALIGN] = 0, 0, 1, 0

        g.set_size_request(150, 1)
        Widget.__init__(self, g, **d)

        left_button = self.left_button = gtk.Button()
        right_button = self.right_button = gtk.Button()
        left_arrow = gtk.Arrow(gtk.ARROW_LEFT, gtk.SHADOW_NONE)
        right_arrow = gtk.Arrow(gtk.ARROW_RIGHT, gtk.SHADOW_NONE)
        spin_button = self.spin_button = gtk.SpinButton(
            adjustment=adjustment,
            digits=self._precision,
            climb_rate=climb_rate
        )

        spin_button.set_increments(*step)
        left_button.add(left_arrow)
        right_button.add(right_arrow)
        hbox.pack_start(left_button, expand=False)
        hbox.pack_start(g, expand=True)
        hbox.pack_start(right_button, expand=False)
        hbox.pack_start(spin_button, expand=False)
        self.add(hbox)
        g.set_value_pos(gtk.POS_LEFT)

        # Do connections last:
        left_button.connect('clicked', self.on_left_arrow_button)
        right_button.connect('clicked', self.on_right_arrow_button)
        g.connect('value-changed', self.on_value_changed)

        for i in (left_button, right_button):
            i.connect('key_press_event', self.on_key_press)

        spin_button.connect('key_press_event', self.on_key_press)
        self._adjustment.emit('value-changed')

    def _on_key_press(self, g, event):
        """
        Process an arrow button key-press.

        g: gtk.Button
            active

        event: gtk.Event
            of key-press

        Return: None or true
            Is true if the key-press is processed.
        """
        n = gtk.gdk.keyval_name(event.keyval)
        if n in ('space', 'Return'):
            if g == self.left_button:
                self.on_left_arrow_button()

            else:
                self.on_right_arrow_button()
            return DONE

    def get_value(self):
        """
        Get the value of the Alignment.

        Is part of the Widget template.

        Return: numeric
            value of slider
        """
        a = self._adjustment.get_value()
        return int(a) if self._precision == 0 else round(a, self._precision)

    def set_value(self, value):
        """
        Set the Alignment value.

        Is part of the Widget template.

        value: numeric
            int or float
        """
        self._adjustment.set_value(value)

    def on_left_arrow_button(self, *_):
        """Respond to the left arrow button click."""
        a = self._adjustment.get_value()
        if a > self._limit[0]:
            a -= self._page_increment
            self._adjustment.set_value(a)

    def on_right_arrow_button(self, *_):
        """Respond to the right arrow button click."""
        a = self._adjustment.get_value()
        if a < self._limit[1]:
            a += self._page_increment
            self._adjustment.set_value(a)

    def on_value_changed(self, *_):
        """
        The alignment value changed.

        Enable or disable the arrow buttons accordingly.
        """
        a = self._adjustment.get_value()
        b = 1 if a > self._limit[0] else 0
        c = 1 if a < self._limit[1] else 0

        self.left_button.set_sensitive(b)
        self.right_button.set_sensitive(c)
        self.on_widget_change(self)
        return DONE
