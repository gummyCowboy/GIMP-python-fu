#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_a_contain import Gradient, Run
from roller_constant_for import Issue as vo, Signal as si
from roller_constant_key import Option as ok, Step as sk
from roller_fu import copy_all_image, paste_layer_into, set_layer_attr
from roller_fu_mode import translate_mode
from roller_maya_build import SubBuild
from roller_maya_layer import check_matter
from roller_one_helm import Helm
from roller_one_ring import Ring
from roller_view_real import mask_sub_maya


def do_matter(maya):
    """
    Make a Gradient Light layer at the top of a super Maya layer group.

    maya: Light
    Return: layer
        Has Gradient Light material.
    """
    return insert_gradient(maya.super_maya.group)


def insert_gradient(group):
    """
    Paste a Gradient Light layer at the top of a layer group.

    group: layer group or None for a GIMP image
        output destination

    Return: layer
        the original or its alter
    """
    copy_all_image(Gradient.image)
    return paste_layer_into(group, group.name + " Gradient Light")


class Light(SubBuild):
    """Manage Gradient Light layer output."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (check_matter, 'matter'),

    def __init__(self, any_group, super_maya, material):
        """
        any_group: AnyGroup
            Own Gradient Light.

        super_maya: Maya
            Has control over the Light output.

        material: string
            Material key
        """
        self._material = material
        self._view_mode = self.view_value = self._view_opacity = None

        SubBuild.__init__(self, any_group, super_maya, vo.NO_VOTE, do_matter)
        self.latch(Ring.gob, (si.LIGHT_CHANGE, self.on_light_change))
        self.value_d = Helm.get_group(sk.GRADIENT_LIGHT).value_d

    def do(self, is_change):
        """
        Manage layer output during a view run.

        is_change: bool
            Is True when the super Maya has either matter or mask change.
        """
        d = self.value_d
        self.go = self.super_maya.go and d[ok.SWITCH]
        e = d[ok.RW2][ok.HEAT].get(self._material)

        if e:
            mode, opacity = e[ok.MODE], e[ok.OPACITY]
        else:
            self.go = False
            mode = opacity = None

        if self.go:
            if not self.matter:
                if opacity == .0:
                    self.is_mode = self.is_opacity = self.is_matter = False
                else:
                    # Matter is valid because the layer had been suppressed.
                    self.is_matter = True

            self.realize()
            if self.matter:
                if self.is_mode or self.is_opacity or self.is_matter:
                    m = set_layer_attr(
                        self.matter, translate_mode(mode), opacity
                    )
                    Run.is_back += m
                if self.is_matter or is_change:
                    self.mask_light_layer()

        else:
            self.die()

        self.reset_issue()

        self.view_value = deepcopy(self.value_d)
        self._view_mode = mode
        self._view_opacity = opacity

    def mask_light_layer(self):
        """
        Mask the Gradient Light layer from a super
        Maya 'matter' layer's alpha selection.
        """
        mask_sub_maya(self.super_maya.matter, self.matter)

    def on_light_change(self, *_):
        """Respond to Gradient Light change."""
        mode = opacity = None
        d = self.value_d

        if d and d[ok.RW2][ok.HEAT]:
            e = d[ok.RW2][ok.HEAT].get(self._material)
            if e:
                mode, opacity = e[ok.MODE], e[ok.OPACITY]

        e = self.view_value

        if e:
            self.is_mode = self.is_opacity = self.is_matter = False

            for k in d:
                if k != ok.RW2:
                    if d[k] != e[k]:
                        self.is_matter = True
                        break

            if opacity != self._view_opacity:
                self.is_opacity = True
            if mode != self._view_mode:
                self.is_mode = True
        else:
            self.is_mode = self.is_opacity = self.is_matter = True

    def reset(self):
        """
        Call when the view image closes as during an image resize event.
        """
        self.view_value = None
        self.is_mode = self.is_opacity = self.is_matter = True
