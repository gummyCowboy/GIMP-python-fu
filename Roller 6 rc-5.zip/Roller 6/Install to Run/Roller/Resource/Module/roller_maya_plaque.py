#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_a_contain import Run
from roller_constant_for import Deco as dc, Plan as fy, Signal as si
from roller_constant_key import (
    Material as ma, Node as ny, Option as ok, Plan as ak, SubMaya as sm
)
from roller_deco import (
    finish_backed,
    mask_cell_main,
    mask_cell_per,
    mask_face_main,
    mask_face_per,
    mask_facing_main,
    mask_facing_per
)
from roller_deco_plaque import (
    do_canvas,
    do_cell_main,
    do_cell_per,
    do_face_main,
    do_face_per,
    do_facing_main,
    do_facing_per
)
from roller_maya import (
    CanvasRoute,
    CellRoute,
    FaceRoute,
    Main,
    Per,
    Plasma,
    take_background_vote
)
from roller_maya_layer import check_matter, check_mix_basic
from roller_maya_light import Light
from roller_maya_mask import Mask
from roller_maya_add import Add
from roller_option_group import DecoImageGroup
from roller_view_option_list import Frame
from roller_view_real import make_canvas_group, make_cast_group
from roller_view_step import get_planner


class Plaque(DecoImageGroup):
    """Assign Plan and Work delegates for view run processing."""
    frame_row_k = ok.BRW

    def __init__(self, **d):
        DecoImageGroup.__init__(self, **d)

        self.plan = {
            ny.CANVAS: PlanCanvas,
            ny.CELL: PlanCell,
            ny.FACE: PlanFace,
            ny.FACING: PlanFacing
        }[self.branch_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas,
            ny.CELL: WorkCell,
            ny.FACE: WorkFace,
            ny.FACING: WorkFacing
        }[self.branch_k](self)
        if self.branch_k in (ny.FACE, ny.FACING):
            # Face has no Margin to receive update from Shift. Thus
            # Plaque receive update directly from Shift instead of Margin.
            self.latch(
                self.item.model.baby, (si.CELL_SHIFT_CALC, self.on_cell_calc)
            )

    @staticmethod
    def get_image_d(d):
        """
        Return the Image Choice Preset if its use.

        d: dict
            Plaque Preset

        Return: dict or None
            Image Choice Preset
        """
        if d[ok.SWITCH]:
            if d[ok.TYPE] == dc.IMAGE:
                e = d[ok.RW1][ok.IMAGE_CHOICE]
                if e[ok.SWITCH]:
                    return e


class Chi(Plasma):
    """Factor Plan and Work layer output."""

    def __init__(self, any_group, view_x, q, make_mask, get_mask_d):
        """
        any_group: Plaque
        view_x: int
            0 or 1; Plan or Work

        q: iterable
            of function for producing view output

        make_mask: function
            Mask Plaque layer.

        get_mask_d: function
            Retrieve the Mask Preset.
        """
        Plasma.__init__(
            self,
            any_group,
            view_x,
            q,
            [(), (ok.RW1, ok.IMAGE_CHOICE), (ok.BRW, ok.MOD)]
        )

        self.sub_maya[sm.MASK] = Mask(
            any_group, self, view_x, make_mask, get_mask_d, (ok.RW1, ok.MASK)
        )
        self.set_issue()


class Plan(Chi):
    """Manage Plan Plaque output."""
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group, make_mask, get_mask_d):
        """
        any_group: Plaque
        make_mask: function
            Mask the Plaque matter layer.

        get_mask_d: function
            Retrieve the Mask Preset.
        """
        Chi.__init__(self, any_group, 0, self.put, make_mask, get_mask_d)

        planner = get_planner(any_group.nav_k)
        self.is_planned = planner.get_option_a(ak.PLAQUE)
        self.latch(
            planner, (fy.SIGNAL_D[ak.PLAQUE], self.on_plan_option_change)
        )

    def bore(self):
        """Manage layer output for a view run."""
        d = self.value_d
        self.go = d[ok.SWITCH] and self.is_planned
        self.is_matter |= self.is_switched

        self.realize()
        if self.go:
            if self.matter:
                self.sub_maya[sm.MASK].do(d[ok.RW1][ok.MASK], self.is_matter)

    def on_plan_option_change(self, _, arg):
        """
        Respond to change from Planner's Plaque option.

        arg: tuple
            (bool, bool)
            (
                Is True if the Plaque option is checked in Planner.,
                Is True if the Plaque option in Planner changed.
            )
        """
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Manage Plaque for Peek, Preview and final output."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group, make_mask, get_mask_d):
        """
        any_group: Plaque
        make_mask: function
            Mask Plaque material.

        get_mask_d: function
            Retrieve the Mask Preset.
        """
        Chi.__init__(self, any_group, 1, self.put, make_mask, get_mask_d)

        self.sub_maya[sm.ADD] = Add(any_group, self, (ok.BRW, ok.ADD))
        self.sub_maya[sm.FRAME] = Frame(any_group, self, (ok.BRW, ok.FRAME))
        self.sub_maya[sm.LIGHT] = Light(any_group, self, ma.PLAQUE)
        self.latch(any_group, (si.BACK_CHANGE, self.on_back_change))

    def bore(self):
        """Produce layer output during a view run."""
        d = self.value_d
        self.go = d[ok.SWITCH]
        is_back = Run.is_back

        if self.go:
            self.is_matter |= take_background_vote(d)

        self.realize()
        if self.go:
            if self.matter:
                is_mask = self.sub_maya[sm.MASK].do(
                    d[ok.RW1][ok.MASK], self.is_matter
                )

                self.sub_maya[sm.ADD].do(
                    d[ok.BRW][ok.ADD],
                    self.is_matter,
                    is_mask,
                    is_back,
                    self.group
                )
                finish_backed()

                m = self.is_matter or is_mask

                self.sub_maya[sm.FRAME].do(d[ok.BRW][ok.FRAME], m)
                self.sub_maya[sm.LIGHT].do(m)
            else:
                self.die()


class WorkMain(Main, Work):
    """Manage Work output for main."""
    def __init__(self, *arg):
        """
        arg: tuple
            Work spec
        """
        Main.__init__(self)
        Work.__init__(self, *arg + (self.get_mask_d,))


# Canvas_______________________________________________________________________
class Cloth:
    """Factor Plan and Work Canvas."""

    def __init__(self):
        self.do_matter = do_canvas


class PlanCanvas(Cloth, Main, Plan, CanvasRoute):
    """Manage Plan Canvas/Plaque output for main."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        Cloth.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, mask_cell_per, self.get_mask_d)
        CanvasRoute.__init__(self)


class WorkCanvas(Cloth, WorkMain, CanvasRoute):
    """Manage Work Canvas/Plaque."""
    issue_q = 'matter', 'mode', 'opacity'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_mix_basic, None)
    )

    def __init__(self, any_group):
        """
        any_group: Plaque
        """
        Cloth.__init__(self)
        WorkMain.__init__(self, any_group, mask_cell_per)
        CanvasRoute.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class Cellular:
    """Factor from Plan and Work Cell."""
    is_face = False

    def __init__(self):
        self.do_matter = do_cell_main


class PlanCell(Main, Plan, CellRoute, Cellular):
    """Manage Plan Cell/Plaque for main."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Main.__init__(self)
        Plan.__init__(self, any_group, mask_cell_main, self.get_mask_d)
        CellRoute.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(WorkMain, CellRoute, Cellular):
    """Manage Work Cell/Plaque for main."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: Plaque
        """
        WorkMain.__init__(self, any_group, mask_cell_main)
        CellRoute.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per Cell_____________________________________________________________________
class PlanCellPer(Plan, Per):
    """Manage Plan Cell/Plaque/Per output."""
    is_face = False
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(self, any_group, mask_cell_per, self.get_mask_d)
        Per.__init__(self, do_cell_per, k)


class WorkCellPer(Work, Per):
    """Manage Work Cell/Plaque/Per output."""
    is_face = False
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int
        """
        Work.__init__(self, any_group, mask_cell_per, self.get_mask_d)
        Per.__init__(self, do_cell_per, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face_________________________________________________________________________
class Face:
    """Factor Plan and Work Face."""
    is_face = True

    def __init__(self):
        self.do_matter = do_face_main


class PlanFace(Face, Main, Plan, FaceRoute):
    """Manage Plan Face/Plaque output."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, mask_face_main, self.get_mask_d)
        FaceRoute.__init__(self, PlanFacePer)


class WorkFace(Face, WorkMain, FaceRoute):
    """Manage Work Face/Plaque output for main."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: Plaque
        """
        Face.__init__(self)
        WorkMain.__init__(self, any_group, mask_face_main)
        FaceRoute.__init__(self, WorkFacePer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face Per_____________________________________________________________________
class FacePer(Per):
    """Factor Plan and Work Face/Plaque for Per."""
    is_face = True

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacePer(Plan, FacePer):
    """Manage Plan Face/Plaque/Per output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: Plaque
        k: tuple
            (r, c, x);
            of int; Goo key
        """
        Plan.__init__(self, any_group, mask_face_per, self.get_mask_d)
        FacePer.__init__(self, do_face_per, k)


class WorkFacePer(Work, FacePer):
    """Manage Work Face/Plaque/Per output."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            (r, c); cell index; of int; Goo key
        """
        Work.__init__(self, any_group, mask_face_per, self.get_mask_d)
        FacePer.__init__(self, do_face_per, k)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing_______________________________________________________________________
class Facing:
    """Factor Plan and Work Facing."""
    is_face = False

    def __init__(self):
        self.do_matter = do_facing_main


class PlanFacing(Facing, Main, Plan, FaceRoute):
    """Manage Plan Facing/Plaque output for main."""
    issue_q = 'matter', 'per', 'switched'

    def __init__(self, any_group):
        Facing.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, mask_facing_main, self.get_mask_d)
        FaceRoute.__init__(self, PlanFacingPer)


class WorkFacing(Facing, WorkMain, FaceRoute):
    """Manage Work Facing/Plaque output for main."""
    issue_q = 'matter', 'mode', 'opacity', 'per'

    def __init__(self, any_group):
        """
        any_group: Plaque
        """
        Facing.__init__(self)
        WorkMain.__init__(self, any_group, mask_facing_main)
        FaceRoute.__init__(self, WorkFacingPer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Facing Per Cell______________________________________________________________
class FacingPer(Per):
    """Factor Plan and Work Facing/Per."""
    is_face = False

    def __init__(self, *q):
        Per.__init__(self, *q)


class PlanFacingPer(Plan, FacingPer):
    """Manage Plan Facing/Plaque/Per output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, k):
        """
        any_group: Plaque
        k: tuple
            (r, c); cell index; of int
        """
        Plan.__init__(self, any_group, mask_facing_per, self.get_mask_d)
        FacingPer.__init__(self, do_facing_per, k)


class WorkFacingPer(Work, FacingPer):
    """Manage Work Facing/Plaque/Per output."""
    issue_q = 'matter', 'mode', 'opacity'

    def __init__(self, any_group, k):
        """
        k: tuple
            Goo key
        """
        Work.__init__(self, any_group, mask_facing_per, self.get_mask_d)
        FacingPer.__init__(self, do_facing_per, k)
