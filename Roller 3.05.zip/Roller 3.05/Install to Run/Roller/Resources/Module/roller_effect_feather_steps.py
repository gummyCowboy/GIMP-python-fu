#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Effect as ek, Option as ok
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
FEATHER = ek.FEATHER_STEPS


class FeatherSteps:
    """Feather the edges of the combined images on the image layer."""

    @staticmethod
    def do(one):
        """
        Do the Feather Reduction effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer
            with Feather Steps
        """
        z = Lay.clone(one.image_layer)
        z.name = Lay.name(z.parent, FEATHER)

        Lay.hide(one.image_layer)
        Lay.show(z)
        FeatherSteps.feather(z, one.d)
        return z

    @staticmethod
    def feather(z, d):
        """
        Feather image material with linear growth repeating steps.

        z: layer
            Has image material to feather.
            Could possibly have a layer mask.

        d: dict
            Has feather options.
        """
        if z:
            j = z.image
            a = d[ok.FEATHER]
            f = float(a) / d[ok.STEPS]
            b = f

            RenderHub.expand_image(j)

            while a > b:
                Sel.make_layer_sel(z)
                pdb.gimp_selection_feather(j, b)

                if Sel.is_sel(j):
                    Sel.invert_clear(z)

                else:
                    break
                b = min(b + f, a)
            RenderHub.contract_image(j)

    @staticmethod
    def feather_layer_sel(z, d):
        """
        Feather material with linear growth
        repeating steps using an existing layer.

        z: layer
            Has material to feather.

        d: dict
            Has feather options.
        """
        if z:
            j = z.image
            a = d[ok.FEATHER]
            f = float(a) / d[ok.STEPS]
            b = f

            RenderHub.expand_image(j)

            while a > b:
                Sel.item(z)
                pdb.gimp_selection_feather(j, b)

                if Sel.is_sel(j):
                    Sel.invert_clear(z)

                else:
                    break
                b = min(b + f, a)
            RenderHub.contract_image(j)

    @staticmethod
    def feather_sel(j, d):
        """
        Feather a selection with linear growth
        repeating steps using an existing selection.

        j: GIMP image
            Has selection.

        d: dict
            Has feather options.
        """
        a = d[ok.FEATHER]
        f = float(a) / d[ok.STEPS]
        b = f
        if a:
            RenderHub.expand_image(j)

            while a > b:
                pdb.gimp_selection_feather(j, b)
                b = min(b + f, a)
            RenderHub.contract_image(j)
