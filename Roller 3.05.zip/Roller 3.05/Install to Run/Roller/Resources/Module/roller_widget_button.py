#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Color as co,
    Image as fi,
    Resize as fz,
    Tooltip as ft
)
from roller_constant_key import Button as bk, Option as ok, Widget as wk
from roller_one import Comm, Hat
from roller_one_tip import Tip
from roller_widget_entry import Entry
from roller_widget_box import Box, Eventful
from roller_widget import Widget
import gtk
import os

CROP = "X: {} , Y: {}, Width: {}, Height: {}"
FILE_ONLY = \
    "The selected item is a folder, " \
    "and the entry is for an image file only."

FIXED = "Width: {}, Height: {}"
FOLDER_ONLY = \
    "The selected item is a not folder, " \
    "and the entry is for folders only. "

FACTOR = "Width x {}, Height x {}"
tip_dict = {
    ft.BRUSH_TIP_TYPE: Tip.make_brush_tooltip,
    ft.BUMP_TIP_TYPE: Tip.make_bump_tooltip,
    ft.INFLUENCE_TYPE: Tip.make_influence_tooltip,
    ft.IMAGE_TIP_TYPE: Tip.make_image_tooltip,
    ft.MARGIN_TIP_TYPE: Tip.make_margin_tooltip,
    ft.MASK_PLAQUE_TIP_TYPE: Tip.mask_plaque_tooltip,
    ft.RESIZE_TIP_TYPE: Tip.make_resize_tooltip,
    ft.SHADOW_TIP_TYPE: Tip.make_shadow_tooltip,
    ft.STRIPE_TIP_TYPE: Tip.make_stripe_tooltip
}
tip_text_dict = {
    ft.BRUSH_TIP_TYPE: "Configure Brush",
    ft.BUMP_TIP_TYPE: "Configure Bump",
    ft.INFLUENCE_TYPE: "Configure Influence",
    ft.MARGIN_TIP_TYPE: "Configure Margins",
    ft.MASK_PLAQUE_TIP_TYPE: "Configure Mask",
    ft.SHADOW_TIP_TYPE: "Configure Shadow",
    ft.STRIPE_TIP_TYPE: "Configure Stripe"
}


class Button(Widget):
    """This is a custom GTK Button."""
    change_signal = 'clicked'

    def __init__(self, **d):
        """
        Create a gtk.Button that is attached to an gtk.Alignment.

        d: dict
            Has keyword arguments for Widget.
        """
        # There is no basestring in Python 3:
        if isinstance(d[wk.TEXT], basestring):
            g = gtk.Button(d[wk.TEXT])

        else:
            # for arrow:
            g = gtk.Button()
            g.add(d[wk.TEXT])

        self.value = None

        Widget.__init__(self, g, **d)
        self.add(g)

        # Do connections last:
        g.connect('clicked', self.callback)

    def get_value(self):
        """
        Is part of the Widget template.

        Return: value
            from 'self.value'
        """
        return self.value

    def set_value(self, a):
        """
        Set 'self.value'.

        Is part of the Widget template.

        a: value
            Give to 'self.value'.
        """
        self.value = a


class ColorButton(Widget):
    """Open a color-chooser dialog on action."""
    change_signal = 'clicked'

    def __init__(self, **d):
        """
        Create button.

        d: dict
            Has keyword arguments for Widget.
        """
        g = gtk.ColorButton(color=gtk.gdk.Color(0, 0, 0))

        Widget.__init__(self, g, **d)
        self.add(g)

        # Do connections last:
        g.connect('clicked', self.callback)
        g.connect('color_set', self.update_tooltip)

    @staticmethod
    def convert_to_rgb(color):
        """
        Convert gtk.gdk.Color to RGB.
        """
        if isinstance(color.red, int):
            return tuple(
                [i // 257 for i in (color.red, color.green, color.blue)]
            )

    def get_value(self):
        """
        Get the value of the button.

        Is part of the Widget template.

        Return: tuple
            color
            RGB
            in 0 to 255
        """
        color = self.widget.get_color()
        return ColorButton.convert_to_rgb(color)

    def set_value(self, color):
        """
        Set the color of the button.

        Is part of the Widget template.

        color: gtk.gdk.Color
            of button
        """
        if not isinstance(color, gtk.gdk.Color):
            if isinstance(color, tuple):
                color = tuple([i * 257 for i in color])
            # 'color' is in the range of 0 to 65535.
            # 257 in gdk color is 1 RGBA:
            color = gtk.gdk.Color(*color)

        self.widget.set_color(color)

        q = ColorButton.convert_to_rgb(color)
        n = co.COLOR_TOOLTIP.format(q[0], q[1], q[2])
        self.set_tooltip_text(n)

    def update_tooltip(self, *_):
        """
        Update the widget after the user closes the color-chooser dialog.
        """
        self.set_value(self.get_value())


class ColorfulButton(Eventful):
    """This Button changes color."""

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        super(ColorfulButton, self).__init__(None)

        self.value = None
        self._accept = d[wk.ON_ACCEPT]
        self._update_window = d[wk.ON_WIDGET_CHANGE]
        self.background_color = d[wk.COLOR]
        self.group = d[wk.GROUP] if wk.GROUP in d else None
        self.on_preview_button = d[wk.ON_PREVIEW_BUTTON] \
            if wk.ON_PREVIEW_BUTTON in d else None

        # Embed the widget inside a VBox and an HBox:
        g = self.label = gtk.Label(d[wk.TEXT])
        g1 = self.hbox = gtk.HBox()

        self.add(g1)
        g1.add(g)

        # events to react to:
        a = gtk.gdk
        p = self.connect

        for i in (
            a.BUTTON_PRESS_MASK,
            a.FOCUS_CHANGE_MASK,
            a.KEY_PRESS_MASK
        ):
            self.add_events(i)

        self.set_can_focus(1)
        self.set_color(self.background_color)

        # Avoid the 'button_press_event' as it fails the widget:
        p('button_release_event', self.on_click)
        p('key_press_event', self.on_key_press)
        p('focus_in_event', self.focus_in)
        p('focus_out_event', self.focus_out)

    def set_color(self, color):
        """
        Set the button-face color.

        color: gtk.gdk.Color
            button color
        """
        self.modify_bg(gtk.STATE_NORMAL, color)

    def on_click(self, *_):
        """Pass the click event to the button owner."""
        self.grab_focus()
        self._update_window(self)

    def on_key_press(self, g, a):
        """
        Process a 'space' key-press.

        g: self
        a: event
            key-press event

        Return: None or true
            Is true when key-press is processed.
        """
        n = gtk.gdk.keyval_name(a.keyval)

        if n == 'space':
            return self._update_window(g)
        elif n == 'Return':
            return self._accept()

    def focus_in(self, *_):
        """Change the color of the button to show focus."""
        self.set_color(co.FOCUS_COLOR)

    def focus_out(self, *_):
        """Change the color of the button to normal."""
        self.set_color(self.background_color)

    def set_label(self, n):
        """
        Change button's text.

        n: string
            for label
        """
        self.label.set_text(n)

    def set_size(self, w=10, h=10):
        """
        Try to set the size of the button.

        w: int
            width of widget

        h: int
            height of widget
        """
        self.set_size_request(width=w, height=h)

    def set_text_color(self, color):
        """
        Set the color of the button's text.

        color: gtk.gdk.Color
        state: normal or disabled
        """
        self.label.modify_fg(gtk.STATE_NORMAL, color)

    def show(self):
        """Display the custom button."""
        super(ColorfulButton, self).show()
        for g in (self.hbox, self.vbox, self.label):
            g.show()


class OptionButton(Button):
    """Has a label that reflects its data."""

    MAX_SIZE = 48
    WITH_VALUE = "{}…"

    def __init__(self, **d):
        """
        Create a GTK Button that is attached to a GTK Alignment.

        d: dict
            Has button variables.
        """
        # Relay on change:
        self._update_window = d[wk.ON_WIDGET_CHANGE]
        d[wk.ON_WIDGET_CHANGE] = self.do_choice

        self.tip_type = None
        d[wk.TEXT] = "…"

        Button.__init__(self, **d)
        self.widget.set_use_underline(False)
        for k in (
            wk.CHOICE_WINDOW,
            wk.COLOR,
            wk.PREVIEW,
            wk.TIP_TYPE,
        ):
            if k in d:
                setattr(self, k, d[k])

    def _update_tooltip(self, a):
        """
        Set the button's tool-tip to 'value'.

        a: value
            give to 'self.value'
        """
        if a is not None:
            # There is no basestring in Python 3:
            if isinstance(a, basestring):
                self.set_tooltip_text(" {} ".format(a))

            else:
                if self.tip_type in tip_dict:
                    self.set_tooltip_text(tip_dict[self.tip_type](a))

    def do_choice(self, _):
        """
        Open a choice window.

        Alter a button's value.

        _: Button
            activated
            to receive choice
            not used
        """
        self.choice_window(self)
        self._update_window(self)

    def set_value(self, a):
        """
        Override the super class, so that the
        button's label can be modified.

        Is part of the Widget template.

        a: string or dict
            the value to apply to 'self.value'
        """
        self.value = a
        n = ""

        self._update_tooltip(a)

        if a is not None:
            # There is no basestring in Python 3:
            if isinstance(a, basestring):
                # Choice-type buttons have a text value:
                n = " {} ".format(a)

            else:
                if self.tip_type in tip_text_dict:
                    n = tip_text_dict[self.tip_type]

                elif self.tip_type == ft.RESIZE_TIP_TYPE:
                    n = a[ok.RESIZE_TYPE]
                    if n not in fz.TEXT_TYPE:
                        if n == fz.CROP:
                            n = CROP.format(
                                a[ok.CROP_X],
                                a[ok.CROP_Y],
                                a[ok.CROP_W],
                                a[ok.CROP_H]
                            )

                        elif n == fz.FIXED:
                            n = FIXED.format(
                                a[ok.FIXED_IMAGE_SIZE_W],
                                a[ok.FIXED_IMAGE_SIZE_H]
                            )
                        elif n == fz.FACTOR:
                            n = FACTOR.format(
                                a[ok.FACTOR_IMAGE_SIZE_W],
                                a[ok.FACTOR_IMAGE_SIZE_H]
                            )
                elif self.tip_type == ft.IMAGE_TIP_TYPE:
                    n = a[ok.IMAGE_SOURCE]
                    if n != "None":
                        if n in fi.INDICES:
                            x = fi.INDICES.index(n)
                            b = a[n]
                            n = fi.TOOLTIPS[x][b]
                        else:
                            n = a[n]

        x = min(OptionButton.MAX_SIZE, len(n))

        self.widget.set_label(
            OptionButton.WITH_VALUE.format(n[-x:].rstrip()))
        self._update_window(self)


class SwitchButton(ColorfulButton):
    """Use to process cell connection events."""

    def __init__(self, r, c, **d):
        """
        Create the button.

        d: dict
            Has init values.
            text
        """
        self.r = r // 2
        self.c = c // 2
        self.grid = d[wk.CELL_TABLE]
        self.action = d[wk.ON_WIDGET_CHANGE]
        d[wk.ON_WIDGET_CHANGE] = self.on_switch_action
        self.pad = d[wk.CONTAINER]
        self.gate = 0
        ColorfulButton.__init__(self, **d)

    def on_switch_action(self, _):
        """
        Reverse the switch setting.

        Call the connection operator.
        """
        x = self.gate = int(not self.gate)

        self.set_label(("+", "-")[x])
        self.action[x](self.grid[self.r][self.c])


class OSButton(Widget):
    """Use a super for FileButton and FolderButton."""
    change_signal = 'changed'

    def __init__(self, **d):
        """
        d: dict
            Has init values.
        """
        box = Box()
        d[wk.CHARS] = 90
        g = self.os_entry = Entry(**d)
        d[wk.ON_WIDGET_CHANGE] = d[wk.OS_BUTTON_CLICK]
        g1 = self.os_button = Button(**d)

        Widget.__init__(self, g.widget, **d)
        box.add(g)
        box.add(g1)
        self.add(box)

    def get_value(self):
        """
        Set the value of the Entry.

        Is part of the Widget template.

        Return: string
            a file or folder reference
        """
        return self.os_entry.get_value()

    def set_value(self, n):
        """
        Get the value of the Entry.

        Is part of the Widget template.

        n: string
            a file or folder reference
        """
        return self.os_entry.set_value(n)


class FileButton(OSButton):
    """
    Has an Entry and a Button that opens a dialog to choose an image file.
    """

    def __init__(self, **d):
        """
        Draw the Entry and Button.

        d: dict
            Has init values.

        """
        d[wk.TEXT] = "Select a File…"
        d[wk.OS_BUTTON_CLICK] = self._get_file_entry_item
        OSButton.__init__(self, **d)

    def _get_file_entry_item(self, *_):
        """Open a file chooser dialog."""
        dialog = gtk.FileChooserDialog(
            title="Choose Image File",
            parent=self.win.win,
            action=gtk.FILE_CHOOSER_ACTION_OPEN,
            buttons=(
                "Cancel",
                gtk.RESPONSE_CANCEL,
                "Accept",
                gtk.RESPONSE_ACCEPT
            )
        )
        file_filter = gtk.FileFilter()

        n = self.os_entry.get_value()

        if not n:
            n = Hat.cat.image_file_path

        # from 'en.wikipedia.org/wiki/File_URI_scheme':
        n = "file://localhost/" + os.path.dirname(n)

        dialog.set_current_folder_uri(n)
        file_filter.set_name("Images")

        for i in fi.EXTENSION:
            file_filter.add_pattern("*" + i)

        dialog.add_filter(file_filter)

        response = dialog.run()

        # "-3" is the enum for accept:
        n = dialog.get_filename() if response == -3 else ""

        dialog.destroy()
        if n:
            Hat.cat.image_file_path = n

            if not os.path.isfile(n):
                Comm.pop_up(
                    self.win.win,
                    1,
                    FILE_ONLY.format(n),
                    "Wrong Item Type"
                )
                n = ""
            if n:
                self.os_entry.set_value(n)


class FolderButton(OSButton):
    """Has an Entry and a Button that opens a dialog to choose a folder."""

    def __init__(self, **d):
        """
        Draw the Entry and Button.

        d: dict
            Has init values.
        """
        d[wk.TEXT] = "Select a Folder…"
        d[wk.OS_BUTTON_CLICK] = self._get_folder_entry_item
        OSButton.__init__(self, **d)

    def _get_folder_entry_item(self, *_):
        """Open a folder chooser dialog."""
        action = gtk.FILE_CHOOSER_ACTION_SELECT_FOLDER
        dialog = gtk.FileChooserDialog(
            title="Choose Image Folder",
            parent=self.win.win,
            action=action,
            buttons=(
                "Cancel",
                gtk.RESPONSE_CANCEL,
                "Accept",
                gtk.RESPONSE_ACCEPT
            )
        )
        n = self.os_entry.get_value()

        if not n:
            n = Hat.cat.image_folder_path

        if os.path.isdir(n):
            # from 'en.wikipedia.org/wiki/File_URI_scheme':
            n = "file://localhost/" + n

            # Set the initial folder:
            dialog.set_current_folder_uri(n)

        response = dialog.run()

        # "-3" is the enum for accept:
        n = dialog.get_filename() if response == -3 else ""

        dialog.destroy()
        if n:
            Hat.cat.image_folder_path = n
            if not os.path.isdir(n):
                Comm.pop_up(
                    self.win.win,
                    1,
                    FOLDER_ONLY.format(n),
                    "Wrong Item Type"
                )
                n = ""
            if n:
                self.os_entry.set_value(n)


class PreviewButton(Button):
    """
    Use to initiate render previews.
    """
    def __init__(self, **d):
        """
        Create a GTK Button that is attached to a GTK Alignment.

        d: dict
            Has button variables.
        """
        d[wk.ON_WIDGET_CHANGE] = self._on_button_action
        d[wk.TEXT] = d[wk.KEY] = bk.PREVIEW

        Button.__init__(self, **d)
        self.group.preview_button = self

    def _on_button_action(self, g):
        """
        Let the owner know that the button has been activated.

        g: Button
            self
        """
        self.on_preview_button(self, g.group)
