#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_constant_fu import Fu
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Sel
import gimpfu as fu

cs = Fu.ColorSelect
ed = Fu.Edge
pdb = fu.pdb


def make_sel(one, frame_sel, _):
    """
    Modify the current selection with the selected lines.

    Add the line selection to the border selection
    within the bounds of the filler selection.

    one: One
        Has options.

    frame_sel: Selection
        of image frame

    _: Selection
        not used

    Return: state of selection
    """
    sel = None
    cat = Hat.cat
    j = cat.render.image
    d = one.d
    z = Lay.add(j, one.k, parent=one.parent)
    s = cat.render.size
    w = s[0] // d[ok.COLUMN_MAZE]
    h = s[1] // d[ok.ROW_MAZE]

    if d[ok.COMPOSITION_FRAME_WIDTH]:
        pdb.gimp_selection_all(j)
        pdb.gimp_selection_shrink(j, d[ok.COMPOSITION_FRAME_WIDTH])
        Sel.invert(j)
        sel = cat.save_short_term_sel()

    pdb.gimp_selection_none(j)
    pdb.gimp_context_set_foreground((0, 0, 0))
    pdb.gimp_context_set_background((255, 255, 255))
    pdb.plug_in_maze(j, z, w, h, 1, 0, d[ok.RANDOM_SEED], 0, 0)
    pdb.plug_in_edge(j, z, ed.AMOUNT_1, ed.NO_WRAP, ed.SOBEL)

    w = max(d[ok.LINE_WIDTH] // 2 - 1, 1)

    for _ in range(w):
        Lay.dilate(z)

    # Create a selection from the white pixels:
    pdb.gimp_by_color_select(
        z,
        (255, 255, 255),
        cs.THRESHOLD_0,
        fu.CHANNEL_OP_REPLACE,
        cs.YES_ANTIALIAS,
        cs.NO_FEATHER,
        cs.FEATHER_RADIUS_0,
        cs.NO_SAMPLE_MERGED
    )
    Sel.load(j, frame_sel, option=fu.CHANNEL_OP_ADD)
    Sel.load(j, sel, option=fu.CHANNEL_OP_ADD)
    pdb.gimp_image_remove_layer(j, z)


class RaisedMaze:
    """Add a framework to BorderLine."""

    @staticmethod
    def do(one):
        """
        Do the Line Fashion image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer
            with Raised Maze
        """
        # Preserve:
        q = pdb.gimp_context_get_foreground()
        q1 = pdb.gimp_context_get_background()

        z = BorderLine.do(one, framer=make_sel)

        # Restore:
        pdb.gimp_context_set_foreground(q)
        pdb.gimp_context_set_background(q1)

        return z
