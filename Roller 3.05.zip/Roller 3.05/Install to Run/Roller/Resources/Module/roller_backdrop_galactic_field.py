#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_gradient_fill import GradientFill
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_one import Hat, One
from roller_one_fu import Lay, Mage
from roller_one_gegl import Gegl
from roller_option_preset import Preset
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb


class GalacticField:
    """Create a starry backdrop."""

    @staticmethod
    def do(one):
        """
        Do the backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            with Trailing Vine
        """
        z = None

        if Lay.has_pixel(one.z):
            d = one.d
            cat = Hat.cat
            j = cat.render.image
            z = Lay.clone(one.z)
            group = Lay.group(j, one.k, layer=z)
            n = "Dotify"
            z1 = Lay.clone(z)
            z1.name = n
            z1.mode = fu.LAYER_MODE_DIFFERENCE

            pdb.plug_in_gimpressionist(j, z1, n)
            Mage.copy_all(z.image)

            z2 = Lay.paste(z1)
            z2.mode = fu.LAYER_MODE_HARD_MIX
            Gegl.emboss(z2, cat.light_angle, 12, 3)

            n = "Embroidery"
            z3 = Lay.clone(z)
            z3.name = n
            z3.mode = fu.LAYER_MODE_COLOR_ERASE

            pdb.plug_in_gimpressionist(j, z3, n)
            Mage.copy_all(z.image)

            z4 = Lay.paste(z)

            Lay.hide(z3)
            Gegl.blur(z, 500)

            Mage.copy_all(z.image)

            z5 = Lay.paste(z4)
            z5.mode = fu.LAYER_MODE_SOFTLIGHT

            Lay.hide(z1)
            Lay.hide(z2)

            z = Lay.merge_group(group)
            group = Lay.group(j, one.k, layer=z)
            z1 = Lay.clone(z)
            z1.mode = fu.LAYER_MODE_DIFFERENCE
            Gegl.unsharp_mask(z1, 3., .5, .0)

            Mage.copy_all(j)

            z = Lay.paste(z1)
            z.mode = fu.LAYER_MODE_SOFTLIGHT

            Lay.hide(z1)

            z = Lay.merge_group(group)
            group = Lay.group(j, one.k, layer=z)
            z = Lay.clone(z)
            z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
            z.opacity = 50.

            Gegl.waterpixels(z)

            z = Lay.clone(z)
            z.mode = fu.LAYER_MODE_DIFFERENCE
            z.opacity = 100.
            z = Lay.merge_group(group)
            if d[ok.OPACITY]:
                e = Preset.get_default(by.GRADIENT_FILL)
                e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
                    RenderHub.get_gradient_factors(d[ok.GRADIENT_ANGLE])

                e.update(d)

                z = GradientFill.do_layer(z.image, One(d=e, k="Gradient"))
                z.mode, z.opacity = RenderHub.get_mode(d)
                z = Lay.merge(z)
        return z
