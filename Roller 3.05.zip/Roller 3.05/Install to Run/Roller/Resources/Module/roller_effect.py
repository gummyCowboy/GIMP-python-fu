#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Effect as ek


class ImageEffect:
    """Has objects used by image-effects."""
    EFFECT_STEPS = 'effect_steps'

    # Use for effects that make a copy of the image layer:
    IS_HIDE = 'is_hide'

    SHADE = ek.SHADOW_1, ek.SHADOW_2, ek.INNER_SHADOW
    SHADED = {EFFECT_STEPS: SHADE, IS_HIDE: 0}
    NO_SHADE = {EFFECT_STEPS: (), IS_HIDE: 0}
    PROPERTY = {
        ek.BALL_JOINT: SHADED,
        ek.BORDER_LINE: SHADED,
        ek.BRUSH_PUNCH: SHADED,
        ek.CAMO_PLANET: SHADED,
        ek.CERAMIC_CHIP: SHADED,
        ek.CIRCLE_PUNCH: SHADED,
        ek.CLEAR_FRAME: SHADED,
        ek.COLOR_BOARD: SHADED,
        ek.COLOR_PIPE: SHADED,
        ek.CORNER_TAPE: NO_SHADE,
        ek.CUTOUT_PLATE: SHADED,
        ek.FEATHER_STEPS: {EFFECT_STEPS: (), IS_HIDE: 1},
        ek.FRAME_OVER: SHADED,
        ek.GLASS_REVEAL: SHADED,
        ek.GRADIENT_LEVEL: SHADED,
        ek.IMAGE_EFFECT: NO_SHADE,
        ek.INNER_SHADOW: SHADED,
        ek.JAGGED_EDGE: {EFFECT_STEPS: SHADE, IS_HIDE: 1},
        ek.LINE_FASHION: SHADED,
        ek.METALLIC_PROFILE: SHADED,
        ek.MAZE_MIRROR: SHADED,
        ek.NO_EFFECT: NO_SHADE,
        ek.PAINT_RUSH: SHADED,
        ek.RAD_WAVE: SHADED,
        ek.RAISED_MAZE: SHADED,
        ek.SHADOW_1: NO_SHADE,
        ek.SHADOW_2: NO_SHADE,
        ek.SHAPE_BURST: SHADED,
        ek.SQUARE_CUT: SHADED,
        ek.SQUARE_PUNCH: SHADED,
        ek.STAINED_GLASS: SHADED,
        ek.STRETCH_TRAY: SHADED,
        ek.TRI_SHADOW: SHADED,
        ek.WIRE_FENCE: SHADED
    }

    # effect categories:
    MAIN = (
        ek.BALL_JOINT,
        ek.BORDER_LINE,
        ek.BRUSH_PUNCH,
        ek.CAMO_PLANET,
        ek.CERAMIC_CHIP,
        ek.CIRCLE_PUNCH,
        ek.CLEAR_FRAME,
        ek.COLOR_BOARD,
        ek.COLOR_PIPE,
        ek.CORNER_TAPE,
        ek.CUTOUT_PLATE,
        ek.FEATHER_STEPS,
        ek.FRAME_OVER,
        ek.GLASS_REVEAL,
        ek.GRADIENT_LEVEL,
        ek.INNER_SHADOW,
        ek.JAGGED_EDGE,
        ek.LINE_FASHION,
        ek.MAZE_MIRROR,
        ek.METALLIC_PROFILE,
        ek.NO_EFFECT,
        ek.PAINT_RUSH,
        ek.RAD_WAVE,
        ek.RAISED_MAZE,
        ek.SHAPE_BURST,
        ek.SQUARE_CUT,
        ek.SQUARE_PUNCH,
        ek.STAINED_GLASS,
        ek.STRETCH_TRAY,
        ek.TRI_SHADOW,
        ek.WIRE_FENCE
    )

    # These image effects duplicate the image layer as part of their
    # function. The duplicate image layer is to be deleted after a render:
    IMAGE_DUPLICATOR = ek.JAGGED_EDGE, ek.FEATHER_STEPS
