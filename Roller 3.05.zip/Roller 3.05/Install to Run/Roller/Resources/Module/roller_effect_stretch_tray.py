#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_render_gradient_light import GradientLight
import gimpfu as fu

pdb = fu.pdb
em = Fu.Emboss
ta = Fu.ThresholdAlpha
FOUR_COORDINATES = 4


def do_job(_, one, sel):
    """
    Draw the ceramic chip.

    _: layer
        not used

    one: One
        with options

    sel: Selection
        for filler material

    Return: layer
        with filler material
    """
    cat = Hat.cat
    j = cat.render.image
    image_layer = one.image_layer
    z = Lay.clone(image_layer)
    group = Lay.group(j, one.k, parent=z.parent, layer=z)

    z1 = Lay.clone(z)

    pdb.plug_in_wind(
        j, z1,
        Fu.Wind.THRESHOLD_0,
        Fu.Wind.FROM_TOP,
        Fu.Wind.STRENGTH_100,
        Fu.Wind.WIND,
        Fu.Wind.TRAILING_EDGE
    )
    pdb.plug_in_threshold_alpha(j, z1, ta.THRESHOLD_ALL)

    z1 = Lay.clone(z)

    pdb.plug_in_wind(
        j, z1,
        Fu.Wind.THRESHOLD_0,
        Fu.Wind.FROM_BOTTOM,
        Fu.Wind.STRENGTH_100,
        Fu.Wind.WIND,
        Fu.Wind.TRAILING_EDGE
    )
    pdb.plug_in_threshold_alpha(j, z1, ta.THRESHOLD_ALL)

    z1 = Lay.clone(z)

    pdb.plug_in_wind(
        j, z1,
        Fu.Wind.THRESHOLD_0,
        Fu.Wind.FROM_LEFT,
        Fu.Wind.STRENGTH_100,
        Fu.Wind.WIND,
        Fu.Wind.TRAILING_EDGE
    )
    pdb.plug_in_threshold_alpha(j, z1, ta.THRESHOLD_ALL)

    z1 = Lay.clone(z)

    pdb.plug_in_wind(
        j, z1,
        Fu.Wind.THRESHOLD_0,
        Fu.Wind.FROM_RIGHT,
        Fu.Wind.STRENGTH_100,
        Fu.Wind.WIND,
        Fu.Wind.TRAILING_EDGE
    )
    pdb.plug_in_threshold_alpha(j, z1, ta.THRESHOLD_ALL)

    z = Lay.merge_group(group)

    Sel.load(j, sel)
    Sel.isolate(z, sel)
    pdb.gimp_curves_spline(z, fu.HISTOGRAM_VALUE, 4, [0, 64, 255, 187])
    Gegl.saturation(z, 10.)

    z = GradientLight.apply_light(z, ok.OTHER_FRAME)
    z1 = Lay.clone(z)
    z1.mode = fu.LAYER_MODE_HARDLIGHT
    z1.opacity = 80.

    pdb.gimp_curves_spline(
        z,
        fu.HISTOGRAM_VALUE,
        FOUR_COORDINATES,
        [0, 117, 255, 137]
    )
    pdb.plug_in_emboss(
        j, z,
        cat.light_angle,
        cat.elevation,
        em.DEPTH_3,
        em.EMBOSS
    )

    z = Lay.merge(z1)

    pdb.gimp_image_reorder_item(j, z, z.parent, 0)
    return z


class StretchTray:
    """Stretch the image in horizontal and vertical directions."""

    @staticmethod
    def do(one):
        """
        Do the image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer or None
            Is border.
        """
        return BorderLine.do(one, filler=do_job)
