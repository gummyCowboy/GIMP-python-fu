#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_backdrop_color_grid import ColorGrid
from roller_constant_key import Option as ok
from roller_effect_border_line import BorderLine
from roller_one import Hat
from roller_one_fu import Lay, Sel
import gimpfu as fu

pdb = fu.pdb


def make_sel(one, frame_sel, filler_sel):
    """
    Draw the ceramic chip.

    one: One
        Has options.

    frame_sel: Selection
        the frame

    filler_sel: Selection
        for squares

    Return: layer
        the ceramic chip layer
    """
    d = one.d

    # A random sequence is reproducible given the same seed:
    cat = Hat.cat
    j = cat.render.image
    z = Lay.add(j, one.k, parent=one.parent)

    pdb.gimp_selection_none(j)

    d[ok.COLOR_1] = 0, 0, 0
    d[ok.COLOR_2] = 255, 255, 255
    d[ok.BUMP] = {ok.BUMP_TYPE: "None"}
    d[ok.ROTATE] = .0
    d[ok.INVERT] = False
    z = ColorGrid.draw_color_grid(z, d)

    Sel.isolate(z, filler_sel)
    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    Sel.item(z)
    Sel.grow(j, 1, 1)
    Sel.load(j, frame_sel, option=fu.CHANNEL_OP_ADD)
    pdb.gimp_image_remove_layer(j, z)


class SquareCut:
    """Create a frame with a square grid."""

    @staticmethod
    def do(one):
        """
        Do the image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer
            with Ceramic Chip
        """
        return BorderLine.do(one, framer=make_sel, filler=lambda *q, **k: None)
