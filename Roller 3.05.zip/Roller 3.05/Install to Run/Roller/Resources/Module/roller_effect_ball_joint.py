#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Plan as fy
from roller_constant_fu import Fu
from roller_constant_key import Model as md, Option as ok
from roller_one import Comm, Hat
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
from roller_render_gradient_light import GradientLight
import gimpfu as fu

em = Fu.Emboss
hs = Fu.HueSaturation
pdb = fu.pdb
ELEVATION_30 = 30
CUSTOM = fy.CUSTOM_CELL


def embellish(j, z):
    """
    Add color and depth to the frame.

    j: GIMP image
        Is render.

    z: layer
        Has frame.

    Return: layer
        with new features
    """
    pdb.gimp_drawable_hue_saturation(
        z,
        fu.HUE_RANGE_ALL,
        hs.HUE_OFFSET_0,
        hs.LIGHTNESS_0,
        hs.SATURATION_MINUS_100,
        hs.OVERLAP_0
    )

    z1 = Lay.clone(z)
    z1.mode = fu.LAYER_MODE_OVERLAY

    pdb.plug_in_emboss(
        j, z1,
        Hat.cat.light_angle,
        ELEVATION_30,
        em.DEPTH_3,
        em.EMBOSS
    )
    pdb.gimp_selection_none(j)
    return pdb.gimp_image_merge_down(j, z1, fu.CLIP_TO_IMAGE)


def process_grid(z, one):
    """
    Do effect for each image in the cell grid.

    z: layer
        to receive effect

    one: One
        Has variables.
    """
    cat = Hat.cat
    j = cat.render.image
    d = one.grid.grid_d
    is_merge_cell = one.grid.is_merge_cell

    if not is_merge_cell:
        s = 1
    for r in range(one.r):
        for c in range(one.c):
            if is_merge_cell:
                s = d[ok.PER_CELL][r][c]

            # '(-1, -1)' is a dependent cell in a merge cell table:
            if s != (-1, -1):
                cat.join_selection(one.model_name, r, c)
                if Sel.is_sel(j):
                    process_image(z, one)


def process_image(z, one):
    """
    Do the effect for an image.

    z: layer
        to receive effect

    one: One
        Has variables.
    """
    j = z.image
    d = one.d

    pdb.plug_in_sel2path(j, z)

    stroke = j.active_vectors.strokes[0]

    pdb.gimp_selection_none(j)
    RenderHub.brush_stroke_on_stroke(
        z,
        'dots',
        d[ok.BRUSH_SIZE],
        stroke,
        d[ok.BRUSH_SIZE] / 15.,
        .0
    )


class BallJoint:
    """
    Create a metallic image frame_name from a brush with overlapping circles.
    """

    @staticmethod
    def do(one):
        """
        Do the Ball Joint image-effect.
        Is an image-effect template function.

        one: One
            Has variables.

        Return: layer or None
            with frame
        """
        cat = Hat.cat
        j = cat.render.image
        parent = one.parent

        try:
            pdb.gimp_context_set_brush('dots')

        except RuntimeError:
            # Exit with an error message:
            Comm.info_msg(
                "Roller requires the 'dots' brush for the Ball Joint effect. "
                "Please check Roller's included files for the file."
            )
            return

        z = Lay.add(j, Lay.name(parent, one.k), parent=parent)

        if one.context == md.TABLE:
            process_grid(z, one)
            z = embellish(j, z)

        else:
            # custom cell:
            r = CUSTOM
            cat.join_selection(one.model_name, r, r)
            if Sel.is_sel(j):
                process_image(z, one)
                z = embellish(j, z)

        Lay.clear_image_sel(one.image_layer, z)

        z = GradientLight.apply_light(z, ok.METAL_FRAME)

        if z:
            one.shadow_layer += [one.image_layer, z]
        return z
