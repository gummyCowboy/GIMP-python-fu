#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_render_hub import RenderHub
import gimpfu as fu

pdb = fu.pdb
de = Fu.Despeckle


class HistoricTrip:
    """
    Fill the backdrop-image with a stony texture
    with lines derived from the backdrop-image.
    """

    @staticmethod
    def do(one):
        """
        Do the backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            with backdrop-style
        """
        def merge(z_):
            """
            Merge a group and set its resulting layer mode.

            z_: layer group
                to merge

            return: layer
                Is the result of the merge.
            """
            z_ = Lay.merge_group(z_)
            z_.mode = fu.LAYER_MODE_GRAIN_MERGE
            pdb.plug_in_colortoalpha(j, z_, (0, 0, 0))
            return z_

        d = one.d
        if d[ok.OPACITY]:
            cat = Hat.cat
            j = cat.render.image
            z = Lay.clone(one.z)
            parent = Lay.group(j, one.k, layer=z)
            z1 = Lay.clone(one.z)
            group = Lay.group(j, one.k, parent=parent, layer=z1)
            z2 = Lay.clone(z1)
            z2.mode = fu.LAYER_MODE_DIFFERENCE
            color = RenderHub.get_average_color(z)

            for i in range(d[ok.ITERATIONS]):
                Gegl.spread(z2, 0, amount_x=d[ok.SPREAD], amount_y=min(6, d[ok.SPREAD]))

            z1 = Lay.clone(one.z)
            group1 = Lay.group(j, one.k, parent=parent, layer=z1)
            z2 = Lay.clone(z1)
            z2.mode = fu.LAYER_MODE_DIFFERENCE

            for i in range(d[ok.ITERATIONS]):
                Gegl.spread(z2, 0, amount_x=min(6, d[ok.SPREAD]), amount_y=d[ok.SPREAD])

            Lay.color_fill(z, color)

            z1 = merge(group)
            z2 = merge(group1)

            pdb.gimp_edit_copy_visible(j)

            z = Lay.paste(z2)
            z.mode = fu.LAYER_MODE_HSV_VALUE

            Gegl.emboss(z1, cat.light_angle, 12, 1)
            Gegl.emboss(z2, cat.light_angle, 12, 1)
            Gegl.waterpixels(z, size=d[ok.SUPERPIXEL_SIZE])

            z = Lay.paste(z)
            z.mode = fu.LAYER_MODE_DISSOLVE
            z.opacity = 50.

            Gegl.blur(z, 5.)
            pdb.gimp_edit_copy_visible(j)

            z = Lay.paste(z)

            Gegl.saturation(z, d[ok.SATURATION])

            z = Lay.merge_group(parent)
            z = RenderHub.bump(z, d[ok.BUMP])
            z.mode, z.opacity = RenderHub.get_mode(d)

            Lay.clone(one.z)

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

            pdb.plug_in_despeckle(
                j, z,
                de.RADIUS_1,
                0,
                de.BLACK_MINUS_ONE,
                de.WHITE_256
            )
            return z
