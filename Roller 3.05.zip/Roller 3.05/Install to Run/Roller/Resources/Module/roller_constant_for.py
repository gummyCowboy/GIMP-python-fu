#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import (
    Button as bk,
    Effect as ek,
    Group as gk,
    Option as ok,
    Path as pa,
    Step as sk
)
import gimpfu as fu
import gtk

# Often times keys will change with version changes by enumeration.

BACKDROP = "Backdrop"
BACKDROP_IMAGE = "Backdrop Image"
COLOR = "Color"
GRADIENT = "Gradient"
GRADIENT_ANGLE = "Gradient Angle"
GRADIENT_TYPE = "Gradient Type"
HEXAGON_HORIZONTAL = "Hexagon, Aligned Horizontally"
HEXAGON_VERTICAL = "Hexagon, Aligned Vertically"
IMAGE = "Image"
LIST_SEPARATOR = "★"
PATTERN = "Pattern"
RECTANGLE = "Rectangle"
SHADOW = "Shadow"
TEXT = "Text"
TRIANGLE_DOWN = "Triangle, Facing Down"
TRIANGLE_LEFT = "Triangle, Facing Left"
TRIANGLE_RIGHT = "Triangle, Facing Right"
TRIANGLE_UP = "Triangle, Facing Up"


class BackdropStyle:
    """Has values used by backdrop styles."""
    BACKDROP_IMAGE = BACKDROP_IMAGE
    CARTOONY = "Cartoony"
    CLOCKWISE, COUNTER_CLOCKWISE = 0, 1
    COMPONENT = "Red", "Green", "Blue"
    COMPOSITION_FRAME = "Frame"
    DIAGONAL = "Diagonal"
    DIRECTION = "Clockwise", "Counter-Clockwise"
    EVENLY_DISTRIBUTED = "Evenly Distributed"
    FILLED = "Filled"
    FLIP_BOTH = "Flip Both Axis"
    GRADIENT = "Gradient"
    HORIZONTAL = "Horizontal"
    HORIZONTAL_FLIP = "Horizontal Flip"
    MESH_TYPE = "Square", "Hexagon", "Octagon", "Triangle"
    NEWS_TYPE = "Dot", "Line", "Diamond", "Euclidean Dot", "PS-Diamond"
    NOISE_LAYER_MODE = (
        None,
        fu.LAYER_MODE_MULTIPLY,
        fu.LAYER_MODE_HARD_MIX,
        fu.LAYER_MODE_GRAIN_EXTRACT,
        fu.LAYER_MODE_HSL_COLOR
    )
    PLASMA = "Plasma"
    POINT_KEY = {"Start X", "Start Y", "End X", "End Y"}
    PRISMATIC = "Prismatic"
    RANDOM = "Random"
    SCATTERED_CONNECTORS = "Scattered Connectors"
    SCATTERED_MAZES = "Scattered Mazes"
    SHOW_GRADIENT, SHOW_SAMPLE = 0, 1
    SYRUPY = "Syrupy"
    VERTICAL = "Vertical"
    VERTICAL_FLIP = "Vertical Flip"

    # dependent:
    BACKDROP_TYPE = BACKDROP_IMAGE, GRADIENT, PLASMA
    GAP_TYPE = RANDOM, EVENLY_DISTRIBUTED
    MAZE_TYPE = (
        SCATTERED_CONNECTORS,
        SCATTERED_MAZES,
        COMPOSITION_FRAME,
        FILLED
    )
    NOISE_MODE_LIST = "None", "Dark", CARTOONY, SYRUPY, PRISMATIC
    SPIRAL_MOD_LIST = "None", HORIZONTAL_FLIP, VERTICAL_FLIP, FLIP_BOTH
    VECTOR = VERTICAL, HORIZONTAL, DIAGONAL

    class PaintRush:
        WHITE_HARD = "Hard Edge on White"
        WHITE_MIXED = "Mixed Edge on White"
        WHITE_SOFT = "Soft Edge on White"
        GREY_HARD = "Hard Edge on Grey"
        GREY_MIXED = "Mixed Edge on Grey"
        GREY_SOFT = "Soft Edge on Grey"
        TYPE = (
            WHITE_SOFT,
            WHITE_MIXED,
            WHITE_HARD,
            GREY_SOFT,
            GREY_MIXED,
            GREY_HARD
        )


class Bump:
    """Has values used by the bump preset."""
    CLOTH = "Cloth"
    CROSSHATCH = "Crosshatch"
    NOISE = "Noise"
    HAS_BUMP = NOISE, CLOTH, CROSSHATCH
    TYPE = "None", NOISE, CLOTH, CROSSHATCH


class Caption:
    """Has values used by Caption option."""
    IMAGE_NAME = "Image Name"
    SEQUENCE_NUMBER = "Sequence Number"
    TEXT = "Text"
    CELL_TYPE_LIST = (
        "None",
        LIST_SEPARATOR,
        TEXT,
        SEQUENCE_NUMBER,
        IMAGE_NAME
    )
    CUSTOM_CELL_TYPE_LIST = "None", IMAGE_NAME, TEXT
    LAYER_TYPE_LIST = "None", TEXT
    NO_SEQUENCE_LIST = "None", LIST_SEPARATOR, TEXT, IMAGE_NAME


class Color:
    """Has values used by color processing."""
    MAX_COLOR = 65535

    # colored button:
    ACTIVE_COLOR = gtk.gdk.Color(55000, 55000, 0)
    CELL_COLOR = gtk.gdk.Color(55000, 55000, MAX_COLOR)
    CONNECTOR_COLOR = gtk.gdk.Color(52000, 52000, MAX_COLOR)
    CONNECTED_COLOR = gtk.gdk.Color(MAX_COLOR, 0, 0)
    FOCUS_COLOR = gtk.gdk.Color(50000, 44000, MAX_COLOR)

    COLOR_TOOLTIP = " Red:\t{} \n Green:\t{} \n Blue:\t{} "
    HEADER_COLOR = 44000, 44000, MAX_COLOR
    LIST_CELL_COLOR = gtk.gdk.Color(50000, 60000, 47000)
    WHITE = gtk.gdk.Color(MAX_COLOR, MAX_COLOR, MAX_COLOR)
    MISSING_FILE = gtk.gdk.Color(MAX_COLOR, MAX_COLOR, MAX_COLOR // 2)


class Fill:
    """
    Has values used by a fill process.

    Color Fill and Pattern Fill use criteria.
    """
    CRITERION_LIST = (
        "Composite",
        "Red",
        "Green",
        "Blue",
        "Hue",
        "Saturation",
        "Value",
        "Alpha",
        "LCH-Lightness",
        "LCH-Chroma",
        "LCH Hue"
    )


class Frame:
    """Has values used by frame makers."""
    BAND = "Band"
    BEVEL = "Bevel"
    COLOR = "Color"
    EDGE = "Edge"
    FLAT = "Flat"
    FLAT_TOP = "Flat Top"
    GRADIENT = "Gradient"
    IMAGE = "Image"
    M_SHAPE = "M-Shape"
    PLASMA = "Plasma"
    RAISE = "Raise"
    RING = "Ring"
    ROUND = "Round"
    RIPPLE = "Ripple"
    SINK = "Sink"
    AS_IS = "As Is"
    U_SHAPE = "U-Shape"
    PROFILE = BAND, BEVEL, FLAT, RAISE, ROUND, SINK
    CURVE = "None", EDGE, FLAT_TOP, M_SHAPE, RING, RIPPLE, U_SHAPE
    CURVE_DICT = {
        EDGE: [0, 0, 127, 0, 130, 0, 133, 133, 255, 255],
        FLAT_TOP: [0, 0, 200, 255, 255, 255],
        M_SHAPE: [0, 0, 84, 84, 127, 0, 168, 168, 255, 255],
        RING: [0, 0, 126, 126, 240, 255, 241, 60, 255, 30],
        RIPPLE: [0, 0, 50, 255, 100, 0, 150, 255, 200, 0, 255, 255],
        U_SHAPE: [0, 255, 127, 0, 255, 255]
    }
    FRAME_STYLE = AS_IS, COLOR, GRADIENT, IMAGE, PLASMA

    # Are image-effects with transparency and a blur-behind process:
    BLUR_BEHIND_EFFECT = (
        ek.CLEAR_FRAME,
        ek.COLOR_BOARD,
        ek.GLASS_REVEAL,
        ek.GRADIENT_LEVEL,
        ek.STAINED_GLASS
    )


class Fringe:
    """Has values used the Fringe option."""
    AS_IS = "As Is"
    BACKDROP = BACKDROP
    GRADIENT = "Gradient"
    IMAGE = "Image"
    MASK = "Mask"
    ONE_COLOR = "One Color"
    PATTERN = "Pattern"
    PLASMA = "Plasma"
    TWO_COLOR = "Two Color"
    TYPE = (
        "None",
        LIST_SEPARATOR,
        AS_IS,
        BACKDROP,
        GRADIENT,
        IMAGE,
        MASK,
        ONE_COLOR,
        PATTERN,
        PLASMA,
        TWO_COLOR
    )


class Gradient:
    """Has values used by gradients."""
    BOTTOM_CENTER_TO_TOP_CENTER = "Bottom-center to Top-center"
    BOTTOM_LEFT_TO_TOP_RIGHT = "Bottom-left to Top-right"
    BOTTOM_RIGHT_TO_TOP_LEFT = "Bottom-right to Top-left"
    CENTER = "Center"
    MIDDLE_LEFT_TO_MIDDLE_RIGHT = "Middle-left to Middle-right"
    MIDDLE_RIGHT_TO_MIDDLE_LEFT = "Middle-right to Middle-left"
    RADIAL = "Radial"
    SPIRAL_CLOCKWISE = "Spiral-Clockwise"
    SPIRAL_COUNTER_CW = "Spiral-Counter-Clockwise"
    SQUARE = "Square"
    TOP_CENTER_TO_BOTTOM_CENTER = "Top-center to Bottom-center"
    TOP_LEFT_TO_BOTTOM_RIGHT = "Top-left to Bottom-right"
    TOP_RIGHT_TO_BOTTOM_LEFT = "Top-right to Bottom-left"
    GRADIENT_ANGLE = (
        CENTER,
        TOP_LEFT_TO_BOTTOM_RIGHT,
        TOP_CENTER_TO_BOTTOM_CENTER,
        TOP_RIGHT_TO_BOTTOM_LEFT,
        BOTTOM_LEFT_TO_TOP_RIGHT,
        BOTTOM_CENTER_TO_TOP_CENTER,
        BOTTOM_RIGHT_TO_TOP_LEFT,
        MIDDLE_LEFT_TO_MIDDLE_RIGHT,
        MIDDLE_RIGHT_TO_MIDDLE_LEFT
    )
    CENTER_X = (
        CENTER,
        TOP_CENTER_TO_BOTTOM_CENTER,
        BOTTOM_CENTER_TO_TOP_CENTER
    )
    CENTER_Y = (
        CENTER,
        MIDDLE_LEFT_TO_MIDDLE_RIGHT,
        MIDDLE_RIGHT_TO_MIDDLE_LEFT
    )
    GRADIENT_TYPE_LIST = (
        "Linear",
        "Bilinear",
        RADIAL,
        SQUARE,
        "Conical Symmetric",
        "Conical ASymmetric",
        "Shape-burst-Angular",
        "Shape-burst-Spherical",
        "Shape-burst-Dimpled",
        SPIRAL_CLOCKWISE,
        SPIRAL_COUNTER_CW
    )
    LEFT_X = (
        BOTTOM_LEFT_TO_TOP_RIGHT,
        MIDDLE_LEFT_TO_MIDDLE_RIGHT,
        TOP_LEFT_TO_BOTTOM_RIGHT
    )
    SHAPE_BURST = (
        "Shape-burst-Angular",
        "Shape-burst-Spherical",
        "Shape-burst-Dimpled"
    )
    TOP_Y = (
        TOP_CENTER_TO_BOTTOM_CENTER,
        TOP_LEFT_TO_BOTTOM_RIGHT,
        TOP_RIGHT_TO_BOTTOM_LEFT
    )
    FILL_DICT = {
        ok.THRESHOLD: 1.,
        ok.CRITERION: "Composite",
        ok.MODE: "Normal",
        ok.OPACITY: 100.
    }


class Grid:
    """Has values used by the grid group."""
    CELL_COUNT = "Cell Count"
    CELL_SIZE = "Cell Size"
    SHAPE_COUNT = "Shape Count"
    TYPE_LIST = CELL_COUNT, CELL_SIZE, SHAPE_COUNT

    # pin:
    TOP_LEFT = "Top-Left"
    TOP_RIGHT = "Top-Right"
    BOTTOM_LEFT = "Bottom-Left"
    BOTTOM_RIGHT = "Bottom-Right"
    CENTER = "Center"
    PIN_LIST = CENTER, TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT

    # A fixed-sized table has a pin-point:
    PINS_WITH_X_OFFSET = CENTER, TOP_RIGHT, BOTTOM_RIGHT
    PINS_WITH_Y_OFFSET = CENTER, BOTTOM_LEFT, BOTTOM_RIGHT


class Group:
    """Has values used by option groups."""
    # Is an attribute added to a VBox that flags
    # it as having a PerCellGroup:
    PER_CELL_GROUP = 'per_cell_group'

    # Match a source option group with its per cell group:
    SOURCE_GROUP_KEY = {
        gk.PER_CELL_BORDER: gk.CELL_BORDER,
        gk.PER_CELL_CAPTION: gk.CELL_CAPTION,
        gk.PER_CELL_FRINGE: gk.CELL_FRINGE,
        gk.PER_CELL_GRID: gk.GRID,
        gk.PER_CELL_IMAGE_PLACE: gk.CELL_IMAGE_PLACE,
        gk.PER_CELL_IMAGE_MASK: gk.CELL_IMAGE_MASK,
        gk.PER_CELL_MARGIN: gk.CELL_MARGIN,
        gk.PER_CELL_PLAQUE: gk.CELL_PLAQUE
    }
    PER_CELL_DEPENDENT = {
        gk.PER_CELL_GRID: (pa.CELL, pa.GRID),
        gk.PER_CELL_BORDER: (pa.CELL, pa.BORDER),
        gk.PER_CELL_CAPTION: (pa.IMAGE, pa.CAPTION),
        gk.PER_CELL_FRINGE: (pa.CELL, pa.FRINGE),
        gk.PER_CELL_IMAGE_PLACE: (pa.IMAGE, pa.PLACE),
        gk.PER_CELL_IMAGE_MASK: (pa.IMAGE, pa.MASK),
        gk.PER_CELL_MARGIN: (pa.CELL, pa.MARGIN),
        gk.PER_CELL_PLAQUE: (pa.CELL, pa.PLAQUE)
    }


class Justification:
    """Has values used by options of justification."""
    TOP_LEFT = "Top-Left"
    TOP_CENTER = "Top-Center"
    TOP_RIGHT = "Top-Right"
    LEFT_CENTER = "Left-Center"
    CENTER = "Center"
    RIGHT_CENTER = "Right-Center"
    BOTTOM_LEFT = "Bottom-Left"
    BOTTOM_CENTER = "Bottom-Center"
    BOTTOM_RIGHT = "Bottom-Right"
    TYPE = (
        TOP_LEFT,
        TOP_CENTER,
        TOP_RIGHT,
        LEFT_CENTER,
        CENTER,
        RIGHT_CENTER,
        BOTTOM_LEFT,
        BOTTOM_CENTER,
        BOTTOM_RIGHT
    )
    BOTTOM = BOTTOM_CENTER, BOTTOM_LEFT, BOTTOM_RIGHT
    CENTER_X = BOTTOM_CENTER, CENTER, TOP_CENTER
    CENTER_Y = CENTER, LEFT_CENTER, RIGHT_CENTER
    LEFT = BOTTOM_LEFT, LEFT_CENTER, TOP_LEFT
    RIGHT = BOTTOM_RIGHT, RIGHT_CENTER, TOP_RIGHT
    TOP = TOP_CENTER, TOP_LEFT, TOP_RIGHT


class Image:
    """Has values used by the image group."""
    # Use with the file selector as a filter:
    EXTENSION = (
        ".xcf",
        ".jpg", ".jpeg", ".jpe", ".jif", ".jfif", ".jfi",
        ".png",
        ".gif", ".webp",
        ".tiff", ".tif",
        ".psd",
        ".raw", ".arw", ".cr2", ".nrw", ".k25",
        ".bmp", ".dib",
        ".jp2", ".j2k", ".jpx", ".jpm", ".mj2",
        ".ico",
        ".svg",
        ".pdf"
    )
    FIRST_IMAGE = "1st Image"
    IMAGE_SOURCE_LIST = (
        "None",
        ok.FILE,
        ok.FOLDER,
        ok.IMAGE_NAME,
        ok.LOOP_INDEX,
        ok.NEXT_INDEX,
        ok.NUMERIC_SEQUENCE,
        ok.PREVIOUS_INDEX
    )
    LOOP_MINUS = "Loop-Minus"
    LOOP_PLUS = "Loop-Plus"
    FOLDER_ORDER_LIST = "Ascending (A to Z)", "Descending (Z to A)"
    LAYER_ORDER_LIST = "Bottom-Up", "Top-Down"
    NEXT_CIRCULAR = "Next-Circular"
    NEXT_LINEAR = "Next-Linear"
    PREVIOUS_CIRCULAR = "Previous-Circular"
    PREVIOUS_LINEAR = "Previous-Linear"
    SLICE_ORDER_LIST = "Top-Left to Bottom-Right", "Bottom-Right to Top-Left"

    # 'opened_images' value indices:
    IMAGE_INDEX, LAYER_LIST_INDEX = 0, 1

    # file list indices for folder pile:
    FILE_INDEX, FILTER_INDEX = 0, 1

    # index-ordered:
    NEXT_TYPE = NEXT_LINEAR, NEXT_CIRCULAR
    PREVIOUS_TYPE = PREVIOUS_LINEAR, PREVIOUS_CIRCULAR
    LOOP_TYPE = LOOP_PLUS, LOOP_MINUS
    INDICES = ok.LOOP_INDEX, ok.NEXT_INDEX, ok.PREVIOUS_INDEX
    TOOLTIPS = LOOP_TYPE, NEXT_TYPE, PREVIOUS_TYPE


class Layer:
    """Has values used by GIMP layers."""
    LAYER_BULLET = "• "
    BACKDROP = "Backdrop"
    GRID = "Grid"
    BACKDROP_LIGHT_OPACITY = 6.


class Margin:
    """Has values used by margins."""
    # Combined margin indices:
    TOP, BOTTOM, LEFT, RIGHT = range(4)
    MARGIN_GROUP = gk.CELL_MARGIN, gk.CUSTOM_CELL_MARGIN, gk.LAYER_MARGIN
    MARGIN_KEY_H = (
        (ok.FIXED_LEFT, ok.FACTOR_LEFT),
        (ok.FIXED_RIGHT, ok.FACTOR_RIGHT)
    )
    MARGIN_KEY_V = (
        (ok.FIXED_TOP, ok.FACTOR_TOP),
        (ok.FIXED_BOTTOM, ok.FACTOR_BOTTOM)
    )
    MARGIN_KEY = (
        ok.FACTOR_BOTTOM,
        ok.FACTOR_LEFT,
        ok.FACTOR_RIGHT,
        ok.FACTOR_TOP,
        ok.FIXED_BOTTOM,
        ok.FIXED_LEFT,
        ok.FIXED_RIGHT,
        ok.FIXED_TOP
    )


class Mask:
    """Has values used by the image mask option."""
    CIRCLE = "Circle"
    CUT_CORNERS = "Cut Corners"
    DIAMOND = "Diamond"
    HEXAGON_HORIZONTAL = HEXAGON_HORIZONTAL
    IMAGE = "Image"
    OCTAGON = "Octagon"
    OCTAGON_ALIGNED = "Octagon, Aligned"
    OVAL = "Oval"
    RECTANGLE = RECTANGLE
    RHOMBUS = "Rhombus"
    ROUNDED_CORNERS = "Rounded Corners"
    SQUARE = "Square"
    TEXT = "Text"
    HEXAGON_VERTICAL = HEXAGON_VERTICAL
    TYPE = [
        "None",
        LIST_SEPARATOR,
        CIRCLE,
        CUT_CORNERS,
        DIAMOND,
        HEXAGON_HORIZONTAL,
        HEXAGON_VERTICAL,
        IMAGE,
        OCTAGON,
        OCTAGON_ALIGNED,
        OVAL,
        RECTANGLE,
        RHOMBUS,
        ROUNDED_CORNERS,
        SQUARE,
        TEXT,
        TRIANGLE_DOWN,
        TRIANGLE_LEFT,
        TRIANGLE_RIGHT,
        TRIANGLE_UP
    ]


class Model:
    """Has values used by one of the model groups."""
    MISSING_ITEM = "Roller {} can't find a {}, {}."

    # fringe layout enum:
    NO_LAYOUT, IS_BOTH_FRINGE, IS_CELL_FRINGE, IS_LAYER_FRINGE = 0, 1, 2, 3

    # Use to distinguish factored-preset option groups:
    # parent types:
    PARENT_TYPE = (
        gk.GRID_CELL,
        gk.CUSTOM_CELL_CELL,
        gk.GRID_LAYER,
        gk.PER_CELL
    )
    PARENT_CELL_INDEX = 0
    PARENT_LAYER_INDEX = 2

    # Use to convert a radio box choice to text:
    LOWER_SHADOWS = sk.SHADOW_1, sk.SHADOW_2

    AQUA = "Aqua"
    BLUE = "Blue"
    PURPLE = "Purple"
    COMPOSITE = "Composite"
    GREEN = "Green"
    YELLOW = "Yellow"
    RED = "Red"
    CAMO_TYPE = COMPOSITE, GREEN, RED, BLUE, AQUA, PURPLE, YELLOW


class Node:
    """Has values used by the Node widget."""
    BLUR_BEHIND = ", Blur Behind"

    # Is the length of the backdrop-style sub-steps when a
    # backdrop-style is chosen other than Backdrop Image:
    WITH_BACKDROP_STYLE = 3


class Plan:
    """Has values used by Plan."""
    BACKGROUND_COLOR = 0, 0, 0
    LAYER_MARGIN_COLOR = 40, 35, 35
    LAYER_PLAQUE_COLOR = 40, 45, 40
    LAYER_FRINGE_COLOR = 45, 45, 50
    LAYER_BORDER_COLOR = 55, 50, 50
    LAYER_CAPTION_COLOR = 55, 60, 55
    GRID_COLOR = 60, 60, 65
    CELL_MARGIN_COLOR = 70, 65, 65
    CELL_PLAQUE_COLOR = 70, 75, 70
    CELL_FRINGE_COLOR = 75, 75, 80
    CELL_BORDER_COLOR = 85, 80, 80
    CELL_STRIPE_COLOR = 85, 90, 85

    # Negative row and column numbers are invalid, but part
    # of a selection id and are used as an item identifier:
    CUSTOM_CELL = -1
    LAYER = -2


class Plaque:
    """Has values used by the Plaque effect."""
    AVERAGE_COLOR = "Average Color"
    BACKDROP = "Backdrop"
    COLOR = COLOR
    SHADOW = "Shadow"
    GRADIENT = "Gradient"
    GRADIENT_ANGLE = "Gradient Angle"
    GRADIENT_TYPE = GRADIENT_TYPE
    NETTING = "Netting"
    IMAGE = "Image"
    PATTERN = "Pattern"
    PLASMA = "Plasma"
    TYPE = (
        "None",
        LIST_SEPARATOR,
        AVERAGE_COLOR,
        BACKDROP,
        COLOR,
        GRADIENT,
        IMAGE,
        NETTING,
        PATTERN,
        PLASMA,
        SHADOW
    )


class Preset:
    """Has values used by a preset."""
    DEFAULT = u"Default"
    PRESET_SEPARATOR = "﹎"


class Render:
    """Has values used by the render process."""
    MAX_SIZE = 100000


class Resize:
    """Has values used by the resize method."""
    CROP = "Crop"
    FIXED = "Fixed Size"
    FACTOR = "Factor of Image Size"
    TEXT_TYPE = ok.COVER, ok.FILLED, ok.LOCKED, ok.TRIM
    RESIZE_TYPE_LIST = (
        ok.COVER,
        CROP,
        ok.FILLED,
        FIXED,
        FACTOR,
        ok.LOCKED,
        ok.TRIM
    )


class Shape:
    CIRCLE = "Circle"
    CIRCLE_HORIZONTAL = "Circle, Aligned Horizontally"
    CIRCLE_VERTICAL = "Circle, Aligned Vertically"
    DIAMOND = "Diamond"
    ELLIPSE = "Ellipse"
    ELLIPSE_HORIZONTAL = "Ellipsis, Aligned Horizontally"
    ELLIPSE_RATIO = .1345
    ELLIPSE_VERTICAL = "Ellipsis, Aligned Vertically"
    ELLIPSE_LIST = ELLIPSE_HORIZONTAL, ELLIPSE_VERTICAL
    HEXAGON_HORIZONTAL = HEXAGON_HORIZONTAL
    HEXAGON_VERTICAL = HEXAGON_VERTICAL
    HEXAGON = HEXAGON_HORIZONTAL, HEXAGON_VERTICAL
    OCTAGON = "Octagon"
    OCTAGON_ALIGNED = "Octagon, Aligned"
    OCTAGON_DOUBLE = "Octagon, Double-spaced"
    OCTAGONS = OCTAGON, OCTAGON_ALIGNED
    OCTAGON_RATIO = .2928932188
    RECTANGLE = RECTANGLE
    RHOMBUS = "Rhombus"
    SQUARE = "Square"
    DOUBLE = ELLIPSE_LIST + HEXAGON + (DIAMOND, RHOMBUS) + \
        (CIRCLE_VERTICAL, CIRCLE_HORIZONTAL, OCTAGON_DOUBLE)

    CUSTOM_SHAPE_LIST = (
        RECTANGLE,
        DIAMOND,
        ELLIPSE,
        HEXAGON_HORIZONTAL,
        HEXAGON_VERTICAL,
        OCTAGON,
        OCTAGON_ALIGNED,
        TRIANGLE_DOWN,
        TRIANGLE_LEFT,
        TRIANGLE_RIGHT,
        TRIANGLE_UP
    )
    NORMAL_LIST = (
        SQUARE,
        CIRCLE_HORIZONTAL,
        CIRCLE_VERTICAL,
        HEXAGON_HORIZONTAL,
        HEXAGON_VERTICAL,
        OCTAGON,
        OCTAGON_ALIGNED,
        OCTAGON_DOUBLE,
        RHOMBUS,
        TRIANGLE_DOWN,
        TRIANGLE_LEFT,
        TRIANGLE_RIGHT,
        TRIANGLE_UP
    )
    SHAPE_LIST = (
        RECTANGLE,
        DIAMOND,
        ELLIPSE_HORIZONTAL,
        ELLIPSE_VERTICAL,
        HEXAGON_HORIZONTAL,
        HEXAGON_VERTICAL,
        OCTAGON,
        OCTAGON_ALIGNED,
        OCTAGON_DOUBLE,
        TRIANGLE_DOWN,
        TRIANGLE_LEFT,
        TRIANGLE_RIGHT,
        TRIANGLE_UP
    )
    HORIZONTAL_ALIGNED = ELLIPSE_HORIZONTAL, HEXAGON_HORIZONTAL
    VERTICAL_ALIGNED = ELLIPSE_VERTICAL, HEXAGON_VERTICAL

    # width/height ratios of an equilateral triangle:
    TRIANGLE_SCALE_RATIO_UP = 1.1547005

    # Is also the sine of 60 degrees:
    TRIANGLE_SCALE_RATIO_DOWN = .8660254

    # flag and enum; A zero enum is excluded as not double-spaced.
    # Use to type a double-spaced grid:
    NOT_DOUBLE_SPACE, NOT_SHIFT, SHIFT = 0, 1, 2


class Step:
    """Has values used by the render steps."""
    # Is index of the SuperPreset model types in a step tuple:
    MODEL_INDEX = 2


class Tooltip:
    """Has values used by widgets with a tooltip."""
    # types:
    BRUSH_TIP_TYPE = 'brush'
    BUMP_TIP_TYPE = 'bump'
    INFLUENCE_TYPE = 'influence'
    IMAGE_TIP_TYPE = 'image'
    MARGIN_TIP_TYPE = 'margin'
    MASK_PLAQUE_TIP_TYPE = 'plaque_mask'
    RESIZE_TIP_TYPE = 'resize'
    SHADOW_TIP_TYPE = 'shadow'
    STRIPE_TIP_TYPE = 'stripe'


class Triangle:
    """Has values used to describe triangles."""
    TRIANGLE_DOWN = "Triangle, Facing Down"
    TRIANGLE_LEFT = "Triangle, Facing Left"
    TRIANGLE_RIGHT = "Triangle, Facing Right"
    TRIANGLE_UP = "Triangle, Facing Up"
    TRIANGLE = TRIANGLE_DOWN, TRIANGLE_LEFT, TRIANGLE_RIGHT, TRIANGLE_UP
    INVERTED = TRIANGLE_UP, TRIANGLE_RIGHT, TRIANGLE_LEFT, TRIANGLE_DOWN
    HORIZONTAL_TRIANGLE = TRIANGLE_LEFT, TRIANGLE_RIGHT
    VERTICAL_TRIANGLE = TRIANGLE_DOWN, TRIANGLE_UP


class Widget:
    """Has values used by widgets."""
    FILE = "Add file reference…"
    IMAGE_SYMBOL = "❑"
    LAST_USED = "Last Used"
    LIST_SEPARATOR = LIST_SEPARATOR
    MARGIN = 4
    NO_IMAGE = "…"
    SCROLL_SPAN = 22
    UNDEFINED = "〰 undefined 〰"

    # Are buttons that do not change the group change status:
    NO_CHANGE = bk.OPEN, bk.PREVIEW, bk.PLAN, bk.RANDOM
