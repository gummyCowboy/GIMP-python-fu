#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_backdrop_color_grid import ColorGrid
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat, One
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
import gimpfu as fu

pdb = fu.pdb


class SpacetimeFabric:
    """Use wind to shred lines and make a fabric texture."""

    @staticmethod
    def do(one):
        """
        Create the Spacetime Fabric backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            with Spacetime Fabric
        """
        cat = Hat.cat
        j = cat.render.image
        if Lay.has_pixel(one.z):
            # z = Lay.clone(one.z)
            d = deepcopy(one.d)
            d[ok.COLOR_1] = 255, 255, 255
            d[ok.COLOR_2] = 0, 0, 0
            d[ok.MODE] = "Normal"
            d[ok.OPACITY] = 100
            d[ok.ROTATE] = 0
            d[ok.THRESHOLD] = 1.
            d[ok.INVERT] = 0
            d[ok.BUMP] = {ok.BUMP_TYPE: "None"}

            ColorGrid.do(One(d=d, k=one.k, z=one.z))

            z = j.active_layer
            s = cat.render.size
            w = s[0] // d[ok.COLUMN]
            h = s[1] // d[ok.ROW]
            w = min(w, h)
            w = max(1, w // 4)

            pdb.plug_in_edge(j, z, 10, 1, 4)

            for _ in range(w):
                Lay.dilate(z)

            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))
            Sel.item(z)

            white_sel = cat.save_short_term_sel()

            pdb.gimp_selection_none(j)
            pdb.gimp_image_remove_layer(j, z)

            # Create three layers, one for each color:
            z = red = Lay.clone(one.z)
            z.name = "Red"
            group = Lay.group(j, one.k, layer=z)
            z = green = Lay.clone(z)
            z.name = "Green"
            z = blue = Lay.clone(z)
            z.name = "Blue"
            n = d[ok.COMPONENT]

            pdb.plug_in_colortoalpha(j, red, (0, 255, 255))
            pdb.plug_in_colortoalpha(j, green, (255, 0, 255))
            pdb.plug_in_colortoalpha(j, blue, (255, 255, 0))

            if n == "Red":
                z = red
                q = green, blue

            elif n == "Green":
                z = green
                q = red, blue

            else:
                z = blue
                q = red, green

            Sel.load(j, white_sel)
            Lay.clear_sel(z, keep_sel=True)
            pdb.gimp_selection_none(j)

            w1 = max(2, w // 2)

            # Shred the edges of the top layer:
            for i in range(10):
                for i1 in range(4):
                    z.name = n + str(i) + str(i1)
                    pdb.plug_in_wind(
                        j,
                        z,
                        Fu.Wind.THRESHOLD_0,
                        i1,
                        w1,
                        Fu.Wind.BLAST,
                        Fu.Wind.LEADING_EDGE
                    )
                    Gegl.blur(z, 12)

            pdb.gimp_image_reorder_item(j, z, group, 0)

            # Add texture to the bottom layers:
            for z in q:
                n = z.name
                for i in range(3):
                    for i1 in range(4):
                        pdb.plug_in_wind(j, z, 0, i1, (50, 25, 12)[i], 1, 1)
                        z.name = n + str(i) + str(i1)

                z = Lay.clone(z)

                pdb.plug_in_engrave(j, z, i + 2, 1)

                z.mode = fu.LAYER_MODE_BURN
                pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

            z = Lay.merge_group(group)

            if d[ok.EMBOSS]:
                group = Lay.group(j, one.k, layer=z)
                z1 = Lay.clone(z)

                pdb.plug_in_emboss(j, z1, cat.light_angle, 30., 1, 1)

                z1.mode = fu.LAYER_MODE_OVERLAY
                z = Lay.clone(z1)
                z.mode = fu.LAYER_MODE_GRAIN_MERGE
                z = Lay.clone(z1)
                z.mode = fu.LAYER_MODE_DIFFERENCE
                z.opacity = 50.
                z = Lay.merge_group(group)
                pdb.gimp_drawable_invert(z, 0)
            return z
