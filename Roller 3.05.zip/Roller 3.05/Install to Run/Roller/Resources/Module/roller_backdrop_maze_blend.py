#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_fu import Fu
from roller_constant_key import Option as ok
from roller_one import Hat
from roller_one_fu import Lay, Sel
from roller_render_hub import RenderHub
import gimpfu as fu

cs = Fu.ColorSelect
ed = Fu.Edge
em = Fu.Emboss
pdb = fu.pdb
ELEVATION_20 = 20.
STRENGTH_100 = 100
THRESHOLD_POINT_5 = 127


class MazeBlend:
    """
    Use a maze graph to produce softly blended backdrop.
    """

    @staticmethod
    def do(one):
        """
        Do the Maze Blend backdrop-style.

        one: One
            Has variables.

        Return: layer or None
            Has Maze Blend
        """
        cat = Hat.cat
        j = cat.render.image
        d = one.d
        if Lay.has_pixel(one.z) and d[ok.OPACITY]:
            s = cat.render.size
            group = Lay.group(j, one.k)
            z = Lay.add(j, one.k, parent=group)

            # Preserve:
            q = pdb.gimp_context_get_foreground()
            q1 = pdb.gimp_context_get_background()

            Lay.color_fill(z, (127, 127, 127))

            z = Lay.clone(one.z)

            pdb.gimp_image_reorder_item(j, z, group, 0)
            pdb.plug_in_pixelize2(j, z, s[0], s[1])

            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)
            z1 = Lay.clone(z)
            z1.mode = fu.LAYER_MODE_MULTIPLY
            z1.opacity = 25.
            w = s[0] // d[ok.COLUMN_MAZE]
            h = s[1] // d[ok.ROW_MAZE]
            w1 = int((w + h) / 1.5)

            pdb.gimp_selection_none(j)
            pdb.gimp_context_set_background((0, 0, 0))
            pdb.gimp_context_set_foreground((255, 255, 255))
            pdb.plug_in_maze(j, z1, w, h, 1, 0, d[ok.RANDOM_SEED], 0, 0)
            Sel.color(z1, (255, 255, 255))

            sel = cat.save_short_term_sel()
            z2 = Lay.clone(z1)
            z2.mode = fu.LAYER_MODE_OVERLAY

            pdb.plug_in_edge(j, z1, ed.AMOUNT_1, ed.NO_WRAP, ed.SOBEL)

            for _ in range(4):
                Lay.dilate(z1)

            pdb.gimp_drawable_invert(z2, 0)
            Lay.color_fill(z2, (127, 127, 127))
            Sel.load(j, sel)
            Sel.invert_clear(z2)
            pdb.plug_in_emboss(
                j,
                z2,
                cat.light_angle,
                ELEVATION_20,
                em.DEPTH_3,
                em.EMBOSS
            )
            pdb.gimp_drawable_invert(z1, 0)
            Lay.blur(z1, w1)
            Sel.load(j, sel)
            Sel.invert(j)
            Sel.invert_clear(z1)

            z = Lay.merge_group(group)
            z.mode, z.opacity = RenderHub.get_mode(d)

            Lay.clone(one.z)
            z = pdb.gimp_image_merge_down(j, z, fu.CLIP_TO_IMAGE)

            # Restore:
            pdb.gimp_context_set_foreground(q)
            pdb.gimp_context_set_background(q1)

            return z
