#!/usr/bin/env python
# -*- coding: utf-8 -*-
from collections import OrderedDict
from copy import deepcopy
from roller_constant_for import (
    BackdropStyle as bs,
    Bump as fb,
    Fill as fl,
    Frame as fo,
    Gradient as fg,
    Grid as gr,
    Group as og,
    Image as fi,
    Justification as ju,
    Model as mo,
    Node as fd,
    Preset as fp,
    Step as fs,
    Widget as fw,
    Shape as sh
)
from roller_constant_key import (
    BackdropStyle as by,
    Effect as ek,
    Group as gk,
    Model as md,
    Option as ok,
    Pickle as pc,
    Plan as ak,
    Preset as pk,
    Step as sk,
    Widget as wk
)
from roller_one import Comm, Hat, OZ
from roller_one_draw import Draw
from roller_one_extract import Path
from roller_widget import Widget
from roller_widget_box import Box
from roller_widget_button_pair import ButtonPair
from roller_widget_combo import ComboBoxEntry
from roller_widget_tree import Node, OptionList, ModelList
import glob
import gtk
import os

screen_width, screen_height = gtk.gdk.screen_width(), gtk.gdk.screen_height()

ERROR = "Roller was unable to load per cell table."
LOAD_ERR = "Roller is unable to load a file in its original state."
PC = ok.PER_CELL

# dictionaries
# 'A' is the first in the sort and has
# dependency in the 'B' group and the others:
A_SHADOW = OrderedDict([
    (ok.INTENSITY, 0),
    (ok.SHADOW_BLUR, 10),
    (ok.OFFSET_X, 0),
    (ok.OFFSET_Y, 0),
    (ok.SHADOW_COLOR, (0, 0, 0)),
    (ok.MAKE_OPAQUE, 0)
])
A_INNER_SHADOW = OrderedDict([
    (ok.INTENSITY, 0),
    (ok.INLAY_BLUR, 25),
    (ok.SHADOW_COLOR, (0, 0, 0))
])
A_MARGIN = OrderedDict([
    (ok.FIXED_TOP, 0),
    (ok.FIXED_BOTTOM, 0),
    (ok.FIXED_LEFT, 0),
    (ok.FIXED_RIGHT, 0),
    (ok.FACTOR_TOP, .0),
    (ok.FACTOR_BOTTOM, .0),
    (ok.FACTOR_LEFT, .0),
    (ok.FACTOR_RIGHT, .0),
    (ok.MARGIN_SIZE, "")
])
A_TRI_SHADOW = OrderedDict([
    (ok.SHADOW_TYPE, 0),
    (ek.SHADOW_1, A_SHADOW),
    (ek.SHADOW_2, A_SHADOW),
    (ek.INNER_SHADOW, A_INNER_SHADOW)
])
# 'B' is sorted with 'A' and has
# dependency from the others:
B_BUMP = OrderedDict([
    (ok.BUMP_TYPE, "None"),
    (ok.BLUR_X, 48),
    (ok.BLUR_Y, 6),
    (ok.NOISE, .12),
    (ok.BUMP_DEPTH, 2)
])
B_IMAGE = OrderedDict([
    (ok.IMAGE_SOURCE, "None"),
    (ok.NUMERIC_SEQUENCE, fi.FIRST_IMAGE),
    (ok.IMAGE_NAME, ""),
    (ok.NEXT_INDEX, 0),
    (ok.PREVIOUS_INDEX, 0),
    (ok.LOOP_INDEX, 0),
    (ok.FILE, ""),
    (ok.FOLDER, ""),
    (ok.FILTER, ""),
    (ok.FOLDER_ORDER, 0),
    (ok.AS_LAYERS, 0),
    (ok.AUTOCROP, 0),
    (ok.LAYER_ORDER, 0),
    (ok.SLICE, 0),
    (ok.ROW_SLICE, 1),
    (ok.COLUMN_SLICE, 1),
    (ok.SLICE_ORDER, 0)
])
B_INFLUENCE = OrderedDict([
    (ok.BACKDROP_INFLUENCE, 8.),
    (ok.BORDER_INFLUENCE, 10.),
    (ok.PLAQUE_INFLUENCE, 10.),
    (ok.FRINGE_INFLUENCE, 10.),
    (ok.IMAGE_INFLUENCE, .0),
    (ok.METAL_FRAME, 80.),
    (ok.OTHER_FRAME, 11.),
    (ok.TRANSLUCENT_FRAME, 11.)
])
B_RESIZE_METHOD = OrderedDict([
    (ok.RESIZE_TYPE, ok.LOCKED),
    (ok.LOCKED, ""),
    (ok.TRIM, ""),
    (ok.FILLED, ""),
    (ok.COVER, ""),
    (ok.FIXED_IMAGE_SIZE_W, 500),
    (ok.FIXED_IMAGE_SIZE_H, 500),
    (ok.FACTOR_IMAGE_SIZE_W, 1.),
    (ok.FACTOR_IMAGE_SIZE_H, 1.),
    (ok.CROP_X, 0),
    (ok.CROP_Y, 0),
    (ok.CROP_W, 250),
    (ok.CROP_H, 250)
])
B_SHADOW_DICT = {ok.TRI_SHADOW: A_TRI_SHADOW, ok.SHADOW_TYPE: "None"}
BACKDROP_IMAGE = OrderedDict([
    (ok.BACKDROP_IMAGE_BLUR, 0),
    (ok.FIT_IMAGE, 1),
    (ok.INVERT, 0),
    (ok.IMAGE, B_IMAGE),
    (ok.BUMP, B_BUMP)
])
BACKDROP_STYLE = {ok.BACKDROP_STYLE: by.BACKDROP_IMAGE}
BACKGROUND_STRIPE = OrderedDict([
    (ok.STRIPE_TYPE, 0),
    (ok.STRIPE_HEIGHT, 1.5),
    (ok.OPACITY, 100.),
    (ok.BLUR_BEHIND, .0),
    (ok.COLOR, (127, 127, 127))
])
BORDER = OrderedDict([
    (ok.MODE, "Normal"),
    (ok.BORDER_WIDTH, 0),
    (ok.OPACITY, 100.),
    (ok.BORDER_BLUR, 0),
    (ok.BLUR_BEHIND, .0),
    (ok.BUMP_DEPTH, 12),
    (ok.EMBOSS, 0),
    (ok.COMMON_BORDER, 1),
    (ok.OBEY_MARGINS, 0),
    (ok.COLOR, (127, 127, 127)),
    (ok.TRI_SHADOW, B_SHADOW_DICT)
])
BRUSH = OrderedDict([
    (ok.BRUSH_SIZE, 100.),
    (ok.BRUSH_SPACING, 100.),
    (ok.BRUSH_ANGLE, .0),
    (ok.ANGLE_JITTER, .0),
    (ok.BRUSH_HARDNESS, 1.),
    (ok.OPACITY, 100.),
    (ok.BRUSH, "1. Pixel")
])
CAPTION = OrderedDict([
    (ok.CELL_CAPTION_TYPE, "None"),
    (ok.CUSTOM_CELL_CAPTION_TYPE, "None"),
    (ok.LAYER_CAPTION_TYPE, "None"),
    (ok.JUSTIFICATION, ju.TOP_LEFT),
    (ok.TEXT, ""),
    (ok.LEADING_TEXT, ""),
    (ok.TRAILING_TEXT, ""),
    (ok.START_NUMBER, 1),
    (ok.OPACITY, 100.),
    (ok.FONT_SIZE, 24),
    (ok.OBEY_MARGINS, 1),
    (ok.CLIP_TO_CELL, 1),
    (ok.COLOR, (0, 0, 0)),
    (ok.FONT, "Tahoma"),
    (ok.CAPTION_MARGIN, A_MARGIN),
    (ok.TRI_SHADOW, B_SHADOW_DICT),
    (ok.BACKGROUND_STRIPE, BACKGROUND_STRIPE)
])
CELL_PLAN = OrderedDict([
    (ak.BORDER, 0),
    (ak.CAPTION, 0),
    (ak.CELL_FRINGE, 0),
    (ak.CELL_MARGINS, 1),
    (ak.CELL_PLAQUE, 0),
    (ak.COORDINATES, 0),
    (ak.CORNERS, 0),
    (ak.DIMENSIONS, 0),
    (ak.IMAGE, 1),
    (ak.IMAGE_MASK, 0),
    (ak.NAME, 1),
    (ak.RATIOS, 0),
    (ak.RECTANGLE, 1)
])
TABLE_PLAN = OrderedDict([
    (ak.BORDER, 0),
    (ak.CAPTION, 0),
    (ak.CELL_FRINGE, 0),
    (ak.CELL_MARGINS, 1),
    (ak.CELL_PLAQUE, 0),
    (ak.COORDINATES, 0),
    (ak.CORNERS, 0),
    (ak.DIMENSIONS, 0),
    (ak.GRID, 1),
    (ak.IMAGE, 1),
    (ak.IMAGE_MASK, 0),
    (ak.LAYER_FRINGE, 0),
    (ak.LAYER_PLAQUE, 0),
    (ak.LAYER_MARGINS, 1),
    (ak.NAME, 1),
    (ak.RATIOS, 0)
])
FRINGE = OrderedDict([
    (ok.FRINGE_TYPE, "None"),
    (ok.GRADIENT_TYPE, fg.GRADIENT_TYPE_LIST[0]),
    (ok.GRADIENT_ANGLE, fg.TOP_RIGHT_TO_BOTTOM_LEFT),
    (ok.MODE, "Normal"),
    (ok.CONTRACT, 0),
    (ok.RANDOM_SEED, 0),
    (ok.OBEY_MARGINS, 0),
    (ok.CLIP_TO_CELL, 1),
    (ok.BRUSH_DICT, BRUSH),
    (ok.BUMP, B_BUMP),
    (ok.COLOR, (0, 0, 0)),
    (ok.COLOR_1, (87, 87, 87)),
    (ok.COLOR_2, (174, 174, 174)),
    (ok.GRADIENT, fp.DEFAULT),
    (ok.IMAGE, B_IMAGE),
    (ok.PATTERN, "Pine"),
    (ok.TRI_SHADOW, B_SHADOW_DICT)
])
GLOBAL = OrderedDict([
    (ok.RENDER_WIDTH, screen_width),
    (ok.RENDER_HEIGHT, screen_height),
    (ok.LIGHT_ANGLE, 45.),
    (ok.ELEVATION, 30.),
    (ok.CLOSE_FILE, 0),
    (ok.DELETE_PLANS, 1)
])
GRADIENT_LIGHT = OrderedDict([
    (ok.GRADIENT_TYPE, "Bilinear"),
    (ok.OFFSET, 0),
    (ok.ROTATE, .0),
    (ok.START_X, .0),
    (ok.START_Y, 1.),
    (ok.END_X, 1.),
    (ok.END_Y, .0),
    (ok.INVERT, 0),
    (ok.REVERSE, 0),
    (ok.INFLUENCE, B_INFLUENCE),
    (ok.GRADIENT, fp.DEFAULT),
    (ok.GRADIENT_POSITION, "")
])
IMAGE_MASK = OrderedDict([
    (ok.MASK_TYPE, "None"),
    (ok.TEXT, "A"),
    (ok.HORZ_SCALE, 1.),
    (ok.VERT_SCALE, 1.),
    (ok.FEATHER, 0),
    (ok.STEPS, 1),
    (ok.FONT, "Tahoma"),
    (ok.IMAGE, B_IMAGE)
])
IMAGE_PLACE = OrderedDict([
    (ok.MODE, "Normal"),
    (ok.JUSTIFICATION, ju.CENTER),
    (ok.OPACITY, 100.),
    (ok.BLUR_BEHIND, .0),
    (ok.ROTATE, .0),
    (ok.FLIP_HORIZONTAL, 0),
    (ok.FLIP_VERTICAL, 0),
    (ok.IMAGE, B_IMAGE),
    (ok.RESIZE_METHOD, B_RESIZE_METHOD)
])
MODEL = {ok.MODEL_LIST: []}
PER_CELL = {ok.PER_CELL: []}
PLAQUE = OrderedDict([
    (ok.PLAQUE_TYPE, "None"),
    (ok.GRADIENT_TYPE, fg.GRADIENT_TYPE_LIST[0]),
    (ok.GRADIENT_ANGLE, fg.GRADIENT_ANGLE[0]),
    (ok.MODE, "Normal"),
    (ok.OPACITY, 100.),
    (ok.BLUR_BEHIND, .0),
    (ok.FEATHER, 0),
    (ok.STEPS, 1),
    (ok.BLUR, 0),
    (ok.INTENSITY, 200),
    (ok.INLAY_BLUR, 50),
    (ok.NET_LINE_SPACING, 6),
    (ok.NET_LINE_WIDTH, 2),
    (ok.RANDOM_SEED, 0),
    (ok.OBEY_MARGINS, 1),
    (ok.BUMP, B_BUMP),
    (ok.PLAQUE_MASK, IMAGE_MASK),
    (ok.TRI_SHADOW, B_SHADOW_DICT),
    (ok.COLOR, (127, 127, 127)),
    (ok.SHADOW_COLOR, (0, 0, 0)),
    (ok.GRADIENT, fp.DEFAULT),
    (ok.IMAGE, B_IMAGE),
    (ok.PATTERN, "Pine")
])
PRESET_STEPS = {
    sk.GLOBAL: GLOBAL,
    sk.BACKDROP_STYLE: BACKDROP_STYLE,
    sk.BACKDROP_IMAGE: BACKDROP_IMAGE,
    sk.GRADIENT_LIGHT: GRADIENT_LIGHT,
    sk.MODEL: MODEL
}
WITH_BUMP = OrderedDict([
    (ok.BUMP_TYPE, fb.NOISE),
    (ok.BLUR_X, 48),
    (ok.BLUR_Y, 6),
    (ok.BUMP_DEPTH, 2),
    (ok.NOISE, .055)
])

# Define the default structure of an option's Preset dictionary:
_default = {
    by.AVERAGE_COLOR: OrderedDict([
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.INVERT, 0),
        (ok.BUMP, WITH_BUMP)
    ]),
    by.BACKDROP_IMAGE: BACKDROP_IMAGE,
    by.CARBON_14:  OrderedDict([
        (ok.MESH_TYPE, "Hexagon"),
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.MESH_SIZE, 50),
        (ok.NEATNESS, 1.),
        (ok.RANDOM_SEED, 0),
        (ok.BUMP, WITH_BUMP)
    ]),
    by.CLAY_CHEMISTRY: OrderedDict([
        (ok.GRADIENT_TYPE, "Linear"),
        (ok.GRADIENT_ANGLE, fg.TOP_CENTER_TO_BOTTOM_CENTER),
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.GRADIENT, "Default"),
        (ok.BUMP, B_BUMP)
    ]),
    by.COLOR_FILL: OrderedDict([
        (ok.CRITERION, fl.CRITERION_LIST[0]),
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.THRESHOLD, 1.),
        (ok.START_X, .0),
        (ok.START_Y, .0),
        (ok.INVERT, 0),
        (ok.COLOR, (127, 127, 127)),
        (ok.BUMP, WITH_BUMP)
    ]),
    by.COLOR_GRID: OrderedDict([
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.ROW, 4),
        (ok.COLUMN, 4),
        (ok.ROTATE, .0),
        (ok.INVERT, 0),
        (ok.COLOR_1, (64, 64, 64)),
        (ok.COLOR_2, (181, 181, 181)),
        (ok.BUMP, WITH_BUMP)
    ]),
    by.CORE_DESIGN: OrderedDict([
        (ok.ROW, 12),
        (ok.COLUMN, 12),
        (ok.OFFSET, 0),
        (ok.OPACITY, 100.),
        (ok.INVERT, 0),
        (ok.REVERSE, 0),
        (ok.GRADIENT, "Default"),
        (ok.COLOR, (0, 0, 0))
    ]),
    by.CRYSTAL_CAVE: OrderedDict([
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.RANDOM_SEED, 0)
    ]),
    by.CUBISM_COVER: OrderedDict([
        (ok.BACKDROP_TYPE, bs.BACKDROP_IMAGE),
        (ok.GRADIENT_TYPE, fg.SPIRAL_CLOCKWISE),
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.BACKDROP_BLUR, 250),
        (ok.TILE_SIZE, 20.),
        (ok.SATURATION, 1.),
        (ok.RANDOM_SEED, 0),
        (ok.GRADIENT, "Default")
    ]),
    by.DARK_FORT: OrderedDict([
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.ROW, 8),
        (ok.COLUMN, 12),
        (ok.RANDOM_SEED, 0)
    ]),
    by.DENSITY_GRADIENT: OrderedDict([
        (ok.GRADIENT_ANGLE, fg.TOP_CENTER_TO_BOTTOM_CENTER),
        (ok.GRADIENT_MODE, "Luma Lighten Only"),
        (ok.RANDOM_SEED, 0),
        (ok.GRADIENT, "Desert Sunset")
    ]),
    by.ETCH_SKETCH: OrderedDict([
        (ok.SKETCH_TEXTURE, bs.NEWS_TYPE),
        (ok.CELL_SIZE, 9),
        (ok.OPACITY, 100.),
        (ok.EMBOSS, 0),
        (ok.INVERT, 0)
    ]),
    by.FLOOR_SAMPLE: OrderedDict([
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.NUMBER_OF_SLICES, 6),
        (ok.STARTING_ANGLE, 0),
        (ok.INTENSITY, 0),
        (ok.SHADOW_BLUR, 10),
        (ok.INVERT, 0),
        (ok.COLOR_1, (187, 187, 187)),
        (ok.COLOR_2, (64, 64, 64)),
        (ok.SHADOW_COLOR, (0, 0, 0)),
        (ok.BUMP, B_BUMP)
    ]),
    by.GALACTIC_FIELD: OrderedDict([
        (ok.GRADIENT_TYPE, "Linear"),
        (ok.GRADIENT_ANGLE, fg.TOP_CENTER_TO_BOTTOM_CENTER),
        (ok.MODE, "Subtract"),
        (ok.OPACITY, 30.),
        (ok.GRADIENT, "Galactic Field")
    ]),
    by.GLASS_GAW: OrderedDict([
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.RANDOM_SEED, 0),
        (ok.BUMP, B_BUMP)
    ]),
    by.GRADIENT_FILL: OrderedDict([
        (ok.GRADIENT_TYPE, "Linear"),
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.OFFSET, 0),
        (ok.ROTATE, .0),
        (ok.START_X, .0),
        (ok.START_Y, 1.),
        (ok.END_X, 1.),
        (ok.END_Y, .0),
        (ok.INVERT, 0),
        (ok.REVERSE, 0),
        (ok.GRADIENT, "Default"),
        (ok.BUMP, B_BUMP),
        (ok.GRADIENT_POSITION, "")
    ]),
    by.HISTORIC_TRIP: OrderedDict([
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.ITERATIONS, 12),
        (ok.SPREAD, 512),
        (ok.SUPERPIXEL_SIZE, 20),
        (ok.SATURATION, .3),
        (ok.BUMP, WITH_BUMP)
    ]),
    by.IMAGE_GRADIENT: OrderedDict([
        (ok.NAME, "Sampled Gradient"),
        (ok.GRADIENT_TYPE, "Linear"),
        (ok.SAMPLE_VECTOR, bs.VERTICAL),
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.SAMPLE_RADIUS, 15),
        (ok.SAMPLE_POINTS, 5),
        (ok.ROTATE, .0),
        (ok.START_X, .5),
        (ok.START_Y, .5),
        (ok.DIAGONAL_ROTATION, 45.),
        (ok.KEEP_GRADIENT, 0),
        (ok.INVERT, 0),
        (ok.REVERSE, 0),
        (ok.BUMP, B_BUMP),
        (ok.PREVIEW_MODE, bs.SHOW_GRADIENT)
    ]),
    by.LINE_STONE: OrderedDict([
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.RANDOM_SEED, 0)
    ]),
    by.LOST_MAZE: OrderedDict([
        (ok.GRADIENT_ANGLE, fg.GRADIENT_ANGLE[0]),
        (ok.ROW_MAZE, 10),
        (ok.COLUMN_MAZE, 10),
        (ok.OFFSET, 0),
        (ok.RANDOM_SEED, 0),
        (ok.INVERT, 0),
        (ok.REVERSE, 0),
        (ok.GRADIENT, "Default")
    ]),
    by.MAZE_BLEND: OrderedDict([
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.ROW_MAZE, 4),
        (ok.COLUMN_MAZE, 100),
        (ok.RANDOM_SEED, 0)
    ]),
    by.NANO_SUIT: OrderedDict([
        (ok.OPACITY, 99.),
        (ok.INVERT, 0),
        (ok.BUMP, WITH_BUMP)
    ]),
    by.MYSTERY_GRATE: OrderedDict([
        (ok.COLUMN_1, 8),
        (ok.COLUMN_2, 80),
        (ok.OFFSET, 0),
        (ok.INVERT, 0),
        (ok.REVERSE, 0),
        (ok.GRADIENT, "Default")
    ]),
    by.NOISE_RIFT: OrderedDict([
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.DETAIL_LEVEL, 1),
        (ok.SOFTNESS, 500),
        (ok.RANDOM_SEED, 0),
        (ok.USE_PLASMA, 1),
        (ok.INVERT_NOISE, 0),
        (ok.BUMP, B_BUMP)
    ]),
    by.PATTERN_FILL: OrderedDict([
        (ok.CRITERION, fl.CRITERION_LIST[0]),
        (ok.MODE, "Normal"),
        (ok.THRESHOLD, 1.),
        (ok.OPACITY, 100.),
        (ok.START_X, .0),
        (ok.START_Y, .0),
        (ok.INVERT, 0),
        (ok.PATTERN, "Paper"),
        (ok.BUMP, WITH_BUMP)
    ]),
    by.RAINBOW_VALLEY: OrderedDict([
        (ok.BACKDROP_TYPE, bs.BACKDROP_IMAGE),
        (ok.GRADIENT_TYPE, fg.SPIRAL_CLOCKWISE),
        (ok.POWER, 30),
        (ok.RANDOM_SEED, 0),
        (ok.TEXTURE, 0),
        (ok.EMBOSS, 0),
        (ok.GRADIENT, "Default")
    ]),
    by.ROCKY_LANDING:  OrderedDict([
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.BLEND, 12),
        (ok.RANDOM_SEED, 0)
    ]),
    by.SPACETIME_FABRIC: OrderedDict([
        (ok.COMPONENT, "Green"),
        (ok.ROW, 10),
        (ok.COLUMN, 10),
        (ok.EMBOSS, 0)
    ]),
    by.SPECIMEN_SPECKLE: OrderedDict([
        (ok.GRADIENT_TYPE, "Linear"),
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.OFFSET, 0),
        (ok.ROTATE, .0),
        (ok.INVERT, 0),
        (ok.REVERSE, 0),
        (ok.PATTERN_1, "Crack"),
        (ok.PATTERN_2, "Leopard"),
        (ok.PATTERN_3, "Paper"),
        (ok.COLOR, (176, 82, 0)),
        (ok.GRADIENT, "Default")
    ]),
    by.SPIRAL_CHANNEL: OrderedDict([
        (ok.SPIRAL_MOD, bs.HORIZONTAL_FLIP),
        (ok.SPIRAL_DISTANCE, .1),
        (ok.OPACITY, 100.),
        (ok.ROW, 1),
        (ok.COLUMN, 1),
        (ok.COLOR, (75, 75, 75)),
        (ok.BUMP, WITH_BUMP),
        (ok.GRADIENT_DIRECTION, bs.CLOCKWISE)
    ]),
    by.SQUARE_CLOUD: OrderedDict([
        (ok.MODE, "Normal"),
        (ok.OPACITY, 100.),
        (ok.RANDOM_SEED, 0),
        (ok.COLOR, (127, 255, 127))
    ]),
    by.TRAILING_VINE: OrderedDict([
        (ok.LAYER_COUNT, 7),
        (ok.WAVE_PER_LAYER, 5),
        (ok.RANDOM_SEED, 0),
        (ok.USE_PLASMA, 1)
    ]),
    by.WATERY_PAGE: OrderedDict([(ok.BUMP, B_BUMP)]),
    ek.STRETCH_TRAY: OrderedDict([
        (ok.WIDTH, 50),
        (ok.FRAME_WIDTH, 3),
        (ok.NOISE_OPACITY, 30.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.RANDOM_SEED, 0),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.BALL_JOINT: OrderedDict([(ok.BRUSH_SIZE, 30)]),
    ek.BORDER_LINE: OrderedDict([
        (ok.FRAME_WIDTH, 10),
        (ok.NOISE_OPACITY, 30.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.RANDOM_SEED, 0),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.BRUSH_PUNCH: OrderedDict([
        (ok.BRUSH_SIZE, 100),
        (ok.BRUSH_SPACING, 100.),
        (ok.ANGLE_JITTER, .0),
        (ok.FRAME_WIDTH, 6),
        (ok.NOISE_OPACITY, 30.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.RANDOM_SEED, 0),
        (ok.BRUSH, "1. Pixel"),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.CAMO_PLANET: OrderedDict([
        (ok.CAMO_TYPE, mo.COMPOSITE),
        (ok.FRAME_WIDTH, 40),
        (ok.SATURATION, 2.),
        (ok.RANDOM_SEED, 0),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.CERAMIC_CHIP: OrderedDict([
        (ok.MESH_TYPE, "Triangle"),
        (ok.WIDTH, 45),
        (ok.FRAME_WIDTH, 4),
        (ok.MESH_SIZE, 33),
        (ok.NOISE_OPACITY, 30.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.RANDOM_SEED, 0),
        (ok.COLOR, (0, 255, 0)),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.CIRCLE_PUNCH: OrderedDict([
        (ok.CIRCLE_DIAMETER, 50),
        (ok.WIDTH, 45),
        (ok.FRAME_WIDTH, 4),
        (ok.ROTATE, 45.),
        (ok.NOISE_OPACITY, 30.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.RANDOM_SEED, 0),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.CLEAR_FRAME: OrderedDict([
        (ok.FRAME_WIDTH, 45),
        (ok.INNER_FRAME_WIDTH, 5),
        (ok.OPACITY, 26.),
        (ok.COLOR, (255, 255, 255)),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.COLOR_BOARD: OrderedDict([
        (ok.FRAME_WIDTH, 1),
        (ok.OPACITY, 100.),
        (ok.COLOR, (255, 255, 255)),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.COLOR_PIPE: OrderedDict([
        (ok.PROFILE, fo.ROUND),
        (ok.NOISE_MODE, "None"),
        (ok.FRAME_WIDTH, 40),
        (ok.NOISE_OPACITY, 100.),
        (ok.RANDOM_SEED, 0),
        (ok.COLOR, (0, 127, 0))
    ]),
    ek.CORNER_TAPE: OrderedDict([
        (ok.TAPE_LENGTH, 150),
        (ok.TAPE_WIDTH, 50),
        (ok.OPACITY, 10.),
        (ok.INTENSITY, 70),
        (ok.SHADOW_BLUR, 6),
        (ok.ANGLE_SHIFT, 5),
        (ok.CORNER_SHIFT, 9),
        (ok.LENGTH_SHIFT, 10),
        (ok.BLUR_BEHIND, 8.),
        (ok.RANDOM_SEED, 0),
        (ok.COLOR, (230, 220, 210))
    ]),
    ek.CUTOUT_PLATE: OrderedDict([
        (ok.FRAME_WIDTH, 100),
        (ok.BEVEL_EDGE_WIDTH, 8),
        (ok.NOISE_OPACITY, 25.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.RANDOM_SEED, 0),
        (ok.PATTERN, "Paper")
    ]),
    ek.FEATHER_STEPS: OrderedDict([
        (ok.FEATHER, 200),
        (ok.STEPS, 6)
    ]),
    ek.FRAME_OVER: OrderedDict([
        (ok.FRAME, "None"),
        (ok.FRAME_STYLE, fo.PLASMA),
        (ok.MODE, "Normal"),
        (ok.GRADIENT_TYPE, fg.GRADIENT_TYPE_LIST[0]),
        (ok.GRADIENT_ANGLE, fg.GRADIENT_ANGLE[0]),
        (ok.OPACITY, 100.),
        (ok.BLUR_BEHIND, .0),
        (ok.BLUR, 20.),
        (ok.RANDOM_SEED, 0),
        (ok.BUMP, B_BUMP),
        (ok.GRADIENT, fp.DEFAULT),
        (ok.COLOR, (127, 127, 127)),
        (ok.IMAGE, B_IMAGE)
    ]),
    ek.GLASS_REVEAL: OrderedDict([
        (ok.PROFILE, fo.ROUND),
        (ok.CURVE, "None"),
        (ok.OPACITY, 47),
        (ok.FRAME_WIDTH, 50),
        (ok.EMBOSS, 0)
    ]),
    ek.GRADIENT_LEVEL: OrderedDict([
        (ok.NOISE_MODE, "None"),
        (ok.FRAME_WIDTH, 60),
        (ok.OPACITY, 100.),
        (ok.BLUR_BEHIND, .0),
        (ok.NOISE_OPACITY, 35.),
        (ok.RANDOM_SEED, 1430641197),
        (ok.COLOR_1, (177, 86, 29)),
        (ok.COLOR_2, (118, 73, 42))
    ]),
    ek.INNER_SHADOW: A_INNER_SHADOW,
    ek.JAGGED_EDGE: OrderedDict([
        (ok.AMPLITUDE, 3),
        (ok.SMOOTHNESS, 4),
        (ok.RANDOM_SEED, 0)
    ]),
    ek.LINE_FASHION: OrderedDict([
        (ok.WIDTH, 45),
        (ok.LINE_WIDTH, 12),
        (ok.GAP_WIDTH, 48),
        (ok.FRAME_WIDTH, 4),
        (ok.ROTATE, 45.),
        (ok.NOISE_OPACITY, 30.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.RANDOM_SEED, 0),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.MAZE_MIRROR: OrderedDict([
        (ok.MAZE_TYPE, bs.SCATTERED_CONNECTORS),
        (ok.GAP_TYPE, bs.RANDOM),
        (ok.ROW, 10),
        (ok.COLUMN, 10),
        (ok.CELL_GAP, 3),
        (ok.STOP_LENGTH, 25),
        (ok.SCATTER_COUNT, 4),
        (ok.FRAME_WIDTH, 12),
        (ok.COMPOSITION_FRAME_WIDTH, 12),
        (ok.LINE_WIDTH, 12),
        (ok.NOISE_OPACITY, 30.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.RANDOM_SEED, 0),
        (ok.MAZE_DIRECTION, bs.CLOCKWISE),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.METALLIC_PROFILE: OrderedDict([
        (ok.PROFILE, fo.BAND),
        (ok.FRAME_WIDTH, 10)
    ]),
    ek.NO_EFFECT: {},
    ek.PAINT_RUSH: OrderedDict([
        (ok.EDGE_TYPE, bs.PaintRush.WHITE_SOFT),
        (ok.EDGE_MODE, "Lighten Only"),
        (ok.FRAME_WIDTH, 100),
        (ok.POST_BLUR, 0),
        (ok.COLORIZE_OPACITY, 100.),
        (ok.COLOR, (175, 90, 10)),
        (ok.EMBOSS, 0),
        (ok.COLORIZE, 0)
    ]),
    ek.RAD_WAVE: OrderedDict([
        (ok.FRAME_WIDTH, 10),
        (ok.LINE_WIDTH, 8),
        (ok.COMPOSITION_FRAME_WIDTH, 8),
        (ok.ROW, 2),
        (ok.COLUMN, 2),
        (ok.WAVE_AMPLITUDE, 10),
        (ok.WAVELENGTH, 25.),
        (ok.WHIRL, 0),
        (ok.NOISE_OPACITY, 30.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.RANDOM_SEED, 0),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.RAISED_MAZE: OrderedDict([
        (ok.FRAME_WIDTH, 8),
        (ok.LINE_WIDTH, 8),
        (ok.COMPOSITION_FRAME_WIDTH, 8),
        (ok.ROW_MAZE, 10),
        (ok.COLUMN_MAZE, 10),
        (ok.NOISE_OPACITY, 30.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.RANDOM_SEED, 0),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.SHADOW_1: A_SHADOW,
    ek.SHADOW_2: A_SHADOW,
    ek.SHAPE_BURST: OrderedDict([
        (ok.SHAPE_BURST, fg.SHAPE_BURST[0]),
        (ok.FRAME_WIDTH, 50),
        (ok.UNSHARP_AMOUNT, 3.),
        (ok.UNSHARP_RADIUS, 3.),
        (ok.UNSHARP_THRESHOLD, .0),
        (ok.REVERSE, 0),
        (ok.INVERT, 0),
        (ok.GRADIENT, fp.DEFAULT)
    ]),
    ek.SQUARE_CUT: OrderedDict([
        (ok.WIDTH, 45),
        (ok.FRAME_WIDTH, 3),
        (ok.ROW, 20),
        (ok.COLUMN, 20),
        (ok.NOISE_OPACITY, 30.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.RANDOM_SEED, 0),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.SQUARE_PUNCH: OrderedDict([
        (ok.WIDTH, 50),
        (ok.LINE_WIDTH, 25),
        (ok.GAP_WIDTH, 50),
        (ok.FRAME_WIDTH, 4),
        (ok.NOISE_OPACITY, 30.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.ROTATE, 45.),
        (ok.RANDOM_SEED, 0),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.STAINED_GLASS: OrderedDict([
        (ok.WIDTH, 45),
        (ok.PANE_WIDTH, 100),
        (ok.PANE_HEIGHT, 100),
        (ok.FRAME_WIDTH, 5),
        (ok.NOISE_OPACITY, 30.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.ROTATE, 45.),
        (ok.RANDOM_SEED, 0),
        (ok.FRAME_TYPE, 1)
    ]),
    ek.WIRE_FENCE: OrderedDict([
        (ok.MESH_TYPE, "Hexagon"),
        (ok.MESH_SIZE, 30),
        (ok.WIDTH, 35),
        (ok.WIRE_THICKNESS, 3),
        (ok.NEATNESS, 1.),
        (ok.FRAME_WIDTH, 4),
        (ok.NOISE_OPACITY, 30.),
        (ok.SOFTNESS, 500),
        (ok.DETAIL_LEVEL, 2),
        (ok.RANDOM_SEED, 0),
        (ok.FRAME_TYPE, 1)
    ]),
    gk.BACKGROUND_STRIPE: BACKGROUND_STRIPE,
    gk.BRUSH: BRUSH,
    gk.CAPTION_MARGIN: A_MARGIN,
    gk.CELL_BORDER: BORDER,
    gk.CELL_CAPTION: CAPTION,
    gk.CELL_FRINGE: FRINGE,
    gk.CELL_IMAGE_MASK: IMAGE_MASK,
    gk.CELL_IMAGE_PLACE: IMAGE_PLACE,
    gk.CELL_MARGIN: A_MARGIN,
    gk.CELL_PLAQUE: PLAQUE,
    gk.CUSTOM_CELL_BORDER: BORDER,
    gk.CUSTOM_CELL_CAPTION: CAPTION,
    gk.CUSTOM_CELL_FRINGE: FRINGE,
    gk.CUSTOM_CELL_IMAGE_MASK: IMAGE_MASK,
    gk.CUSTOM_CELL_IMAGE_PLACE: IMAGE_PLACE,
    gk.CUSTOM_CELL_MARGIN: A_MARGIN,
    gk.CUSTOM_CELL_PLAQUE: PLAQUE,
    gk.EFFECT: {},
    gk.GRADIENT_LIGHT: GRADIENT_LIGHT,
    gk.GRID: OrderedDict([
        (ok.GRID_TYPE, gr.CELL_COUNT),
        (ok.CELL_SHAPE, sh.RECTANGLE),
        (ok.CELL_SHAPE_NORMAL, sh.SQUARE),
        (ok.PIN_CORNER, gr.TOP_LEFT),
        (ok.ROW_COUNT, 1),
        (ok.COLUMN_COUNT, 1),
        (ok.ROW_HEIGHT, 500),
        (ok.COLUMN_WIDTH, 500),
        (ok.VERT_COUNT, 1),
        (ok.HORZ_COUNT, 1),
        (ok.CELL_SHIFT, 0),
        (ok.GRID_SIZE, "")
    ]),
    gk.IMAGE_CHOICE: B_IMAGE,
    gk.INFLUENCE: B_INFLUENCE,
    gk.LAYER_BORDER: BORDER,
    gk.LAYER_CAPTION: CAPTION,
    gk.LAYER_FRINGE: FRINGE,
    gk.LAYER_MARGIN: A_MARGIN,
    gk.LAYER_PLAQUE: PLAQUE,
    gk.PER_CELL_BORDER: PER_CELL,
    gk.PER_CELL_CAPTION: PER_CELL,
    gk.PER_CELL_FRINGE: PER_CELL,
    gk.PER_CELL_GRID: PER_CELL,
    gk.PER_CELL_IMAGE_PLACE: PER_CELL,
    gk.PER_CELL_IMAGE_MASK: PER_CELL,
    gk.PER_CELL_MARGIN: PER_CELL,
    gk.PER_CELL_PLAQUE: PER_CELL,
    gk.PLAQUE_MASK: IMAGE_MASK,
    gk.PRESET_CUSTOM_CELL: {},
    gk.PRESET_TABLE: {},
    gk.PRESET_STEPS: {},
    gk.PRESET_TRI_SHADOW: {},
    gk.RECTANGLE: OrderedDict([
        (ok.FIXED_POSITION_X,  0),
        (ok.FIXED_POSITION_Y, 0),
        (ok.FIXED_WIDTH, 500),
        (ok.FIXED_HEIGHT, 500),
        (ok.FACTOR_POSITION_X, .0),
        (ok.FACTOR_POSITION_Y, .0),
        (ok.FACTOR_WIDTH, .0),
        (ok.FACTOR_HEIGHT, .0),
        (ok.RECTANGLE_SPECS, "")
    ]),
    gk.RESIZE_METHOD: B_RESIZE_METHOD,
    gk.STEPS: {sk.STEP_LIST: []},
    gk.TRI_SHADOW: {},
    ok.BRUSH_DICT: BRUSH,
    ok.BUMP: B_BUMP,
    ok.CELL_PLAN: CELL_PLAN,
    ok.SHADOW_DICT: B_SHADOW_DICT,
    ok.IMAGE: B_IMAGE,
    ok.TABLE_PLAN: TABLE_PLAN
}


def add_to_d(d, e):
    """
    Recursively add missing dict items
    to a loaded dict using a default
    dictionary as a source.

    d: dict
        receiver

    e: dict
        of default
    """
    for i, value in e.items():
        if i not in d:
            d[i] = value
        else:
            if e and i in e:
                a, b = isinstance(d[i], dict), isinstance(value, dict)

                if a and b:
                    add_to_d(d[i], value)
                elif a or b:
                    d[i] = value


def check_per_cell(g, q):
    """
    Check a per cell table's dictionaries with the default.

    g: Widget
        Has form group key.

    q: list
        per cell table
    """
    d = Preset.get_default(g.form_group_key)

    # dimension, row, 'i':
    for i in q:
        # dimension, column, 'j':
        for j in i:
            if isinstance(j, dict):
                add_to_d(j, d)
                remove_from_d(j, d)


def get_group(path):
    """
    Get the OptionGroup and Node of a path.

    path: tuple
        of steps

    Return: tuple
        OptionGroup, Node
    """
    group = Hat.cat.group_dict[path]
    return group, group.node


def remove_from_d(d, e):
    """
    Recursively remove invalid dict items
    from a loaded dict using a default
    dictionary as a comparison.

    d: dict
        to check

    e: dict
        of default
    """
    q = d.keys()

    # 'e' is empty for the Tri-Shadow SuperPreset:
    if e:
        for i in q:
            if i not in e:
                d.pop(i)
            else:
                a, b = isinstance(d[i], dict), isinstance(e[i], dict)

                if a and b:
                    remove_from_d(d[i], e[i])
                elif a or b:
                    d[i] = e[i]


def translate_model_to_id(d, model_list):
    """
    Exchange custom cell names with ids in a SuperPreset dict.

    d: dict
        of SuperPreset

    model_list: ModelList
        Has names to translate.

    Return: dict
        of SuperPreset
        with translated cell names
    """
    if model_list:
        for i in model_list.get_value():
            d = SuperPreset.translate_to_id(d, i, Hat.cat.group_id.get_id(i))
    return d


def update_version(g, a):
    """
    Check the keys in a loaded preset
    dict with the default dict keys.

    g: Widget
        Has key.

    a: dict or Widget
        Has keys to verify.
    """
    if isinstance(a, dict):
        e = Preset.get_default(g.key)

        add_to_d(a, e)
        remove_from_d(a, e)

    else:
        if g.key == ok.PER_CELL:
            # a per cell widget has a 2D list of dictionaries, 'a':
            check_per_cell(g, a)
    return a


class Preset(Widget):
    """Use to manage presets."""

    def __init__(self, **d):
        """
        Create a grid group preset.

        Use the Widget template 'get_value' and 'set_value'
        functions to manage widget option groups.

        d: dict
            Has keyword arguments.
        """
        # Is set in OptionGroup:
        self.update_view = None

        # There is no basestring in Python 3.
        # Backdrop-style and image-effect have a tuple for a key:
        k = self.group_key = d[wk.GROUP_KEY]
        self._default_dict = deepcopy(_default[k])
        self._save_window = d[wk.SAVE_WINDOW]

        # Has preset path.
        # The key is a preset name. The value is a path:
        self._external_preset = {}

        vbox = Box(align=(0, 0, 1, 0))
        self._update_window = d[wk.ON_WIDGET_CHANGE]
        d[wk.ON_WIDGET_CHANGE] = self._on_preset_change
        g = self.menu = ComboBoxEntry(**d)

        Widget.__init__(self, g, **d)

        g1 = self._pair = ButtonPair(
            on_widget_change=self._on_preset_button,
            text=(pk.SAVE, pk.DELETE),
            win=self.win
        )

        self.add(vbox)
        vbox.add(g)
        vbox.pack_start(g1, expand=1)

    def _collect_preset(self):
        """
        Create a list, 'self._option_list', of internal and external presets.

        Return: list
            of options
            to populate combobox
        """
        # menu options:
        q = self._option_list = []
        ext_files = []
        go = False
        self._external_preset = {}

        try:
            search_path = OZ.get_preset_path(
                self.group_key,
                u"*",
                Hat.cat.preset_folder
            )

            # Ignore sub-directories:
            ext_files = glob.glob(search_path)
            go = True

        except Exception as ex:
            Comm.show_err(ex)
            Comm.show_err("Roller was unable to load presets.")

        if go:
            # Load internal presets into a list:
            q.append(fp.DEFAULT)
            # Make an external preset file list:
            for n in ext_files:
                file_name = os.path.basename(n)
                split_name = file_name.split(fp.PRESET_SEPARATOR)
                combined_name = u""

                for n1 in range(1, len(split_name)):
                    combined_name = combined_name + split_name[n1]

                types = combined_name.split(u".")
                name = types[0]
                self._external_preset[name] = n
                q.append(name)
        return q

    @staticmethod
    def _expand_preset(d, e):
        """
        Expand dict from another dict.

        Is recursive.

        d: dict
            expanding dict

        e: dict
            source dict
        """
        # Remove old:
        for k in d.keys():
            if k not in e:
                d.pop(k)
        for i in e.keys():
            if i not in d:
                d[i] = deepcopy(e[i])
            if d[i] and isinstance(d[i], dict):
                if e[i] and isinstance(e[i], dict):
                    Preset._expand_preset(d[i], e[i])
                else:
                    # Change type:
                    d[i] = deepcopy(e[i])

    def _get_preset(self, n):
        """
        Find a preset dictionary from internal or external sources.

        n: string
            name of preset

        Return: dict
            of preset
        """
        if n in self._external_preset:
            d = OZ.pickle_load(
                {
                    pc.FILE: self._external_preset[n],
                    pc.SHOW_ERROR: True
                }
            )

        else:
            d = deepcopy(self._default_dict)
            n = fp.DEFAULT
        return d, n

    def _load(self, n, d):
        """
        Load a preset dictionary.

        n: string
            name of preset

        d: dict
            of preset
        """
        Draw.load_count += 1

        if n != fw.UNDEFINED:
            d, n = self._get_preset(n)

        self.set_value(d)
        self.menu.set_text(n)
        self._verify_del_button()
        Draw.load_count -= 1

    def _on_preset_change(self, g):
        """
        Call after loading a preset.

        g: ComboBox
            Has changed.
            not used
        """
        if not Draw.load_count:
            n = self.get_text()
            if n != fw.UNDEFINED:
                self._load(n, self._default_dict)

                self.group.unseen = self.group.changed = True

                # '-2' will skip this preset if it's a super:
                self.set_super_to_undefined(g.group.path[:-2])

                SuperPreset.update_view_buttons(self.group.path)
                self._update_window(self)
                if self.update_view:
                    self.update_view(self)

    def _on_preset_button(self, g):
        """
        Receive button Preset Button action.

        g: Button
            Is responsible.
        """
        def _delete():
            """Delete a preset file."""
            n = self.menu.get_text()
            is_external = False

            if n in self._external_preset:
                is_external = True
            if is_external:
                path = self._external_preset[n]
                if Comm.pop_up(
                    self.win.win,
                    0,
                    "Do you want to delete:\n{}?".format(path),
                    "Delete a File Confirmation"
                ):
                    try:
                        os.remove(path)
                        Comm.pop_up(
                            self.win.win,
                            1,
                            "The file:\n" + path + "\nwas removed.",
                            "File Deleted"
                        )

                        if n in self._external_preset:
                            self._external_preset.pop(n)
                        self.refresh(fw.UNDEFINED)
                    except Exception as ex:
                        Comm.show_err(ex)
                        Comm.show_err("Roller was unable to delete the file.")
        self.save(g) if g.key == pk.SAVE else _delete()

    def _verify_del_button(self):
        """The delete Button is valid for an external preset."""
        self._pair.right_button.disable() if self.get_text() in \
            (fp.DEFAULT, fw.UNDEFINED) else self._pair.right_button.enable()

    @staticmethod
    def get_default(k):
        """
        Get a preset dictionary.

        Is part of a Preset template.

        k: string
            of preset

        Return: dict
            default dict
        """
        if k in _default:
            return deepcopy(_default[k])
        return {}

    @staticmethod
    def get_keys(k):
        """
        Get the keys belonging to a preset.

        Is part of a Preset template.

        k: string
            of preset

        Return: list
            of preset keys
            of string
        """
        if k in _default:
            return _default[k].keys()
        return []

    def get_text(self):
        """
        Return the value displayed in the Entry.

        The text may or may not be a row in the drop-menu.

        Return: string
            from the Entry
        """
        g = self.menu.widget.child

        if g:
            return g.get_text()
        return ""

    def get_value(self):
        """
        Return the preset dictionary.

        Skip widget(s) without keys in the dictionary.
        ModelList widgets don't have preset dictionary values.
        """
        d = {}
        e = self.group.d

        for i in Preset.get_keys(self.group_key):
            d[i] = e[i].get_value()
        return d

    @staticmethod
    def is_preset(key):
        """
        Determine if a key is a preset key.

        Return: bool
            Is true if the key is a preset key.
        """
        return key in _default

    def load(self, n):
        """
        Load a preset.

        n: string
            name of preset

        Return: dict
            the loaded preset
        """
        Draw.load_count += 1

        self.menu.populate_list(self._collect_preset())

        d, n = self._get_preset(n)

        self.set_value(d)
        self.menu.set_text(n)
        self._verify_del_button()
        Draw.load_count -= 1
        return d

    def load_preset(self, d, n):
        """
        Load a preset dictionary.

        d: dict
            of preset

        n: string
            to display
        """
        Draw.load_count += 1

        self.menu.populate_list(self._collect_preset())
        self.set_value(d)
        self.menu.set_text(n)
        self._verify_del_button()
        Draw.load_count -= 1

    def refresh(self, n):
        """
        The state of the preset menu has changed.

        n: string or None
            the name to display on the menu
            Is none to repopulate the combobox.
        """
        Draw.load_count += 1

        self.menu.populate_list(self._collect_preset())

        if n:
            p = self.menu.set_value if n in self._option_list \
                else self.menu.set_text
            p(n)

        self._verify_del_button()
        Draw.load_count -= 1

    def save(self, *_):
        """Save a preset file."""
        d = {
            pk.GET_DATA: self.get_value,
            wk.KEY: self.group_key,
            wk.WIN: self.win.win
        }
        if self._save_window(d).is_write:
            # Get the result from the init dict:
            self.refresh(d[pk.FILE_NAME])

            # Update any other presets with the same preset-type.
            # 'q', list of steps:
            q = SuperPreset.get_steps(sk.STEPS, with_dict=False)[1]
            e = Hat.cat.group_dict

            # 'i', steps key:
            for i in q:
                if i in e:
                    # 'a', OptionGroup:
                    a = e[i]
                    if (
                        a.preset and
                        a.group_key == self.group.group_key and
                        a is not self.group
                    ):
                        a.preset.refresh(None)

    def set_text(self, n):
        """
        Set the text in the Entry which is a child of the ComboBox.

        The text does not have to be a row in the drop-menu.

        n: string
            to display in the Entry
        """
        g = self.menu.widget.child
        if g:
            g.set_text(n)
            self._verify_del_button()

    @staticmethod
    def set_super_to_undefined(q):
        """
        Set the SuperPresets to undefined.

        Find them using a Node label, "Preset".

        q: tuple
            path
            Identifies super's.
        """
        cat = Hat.cat
        if not Draw.load_count and q:
            # Set SuperPresets to undefined:
            path = list(q[:3]) if len(q) > 2 else [q[0]]
            d = cat.group_dict
            while path:
                q = tuple(path)
                if q in d:
                    group = d[q]
                    if group.node:
                        q1 = group.node.get_value()
                        if gk.PRESET in q1:
                            path1 = q + (gk.PRESET,)
                            if path1 in d:
                                # Is a SuperPreset, 'e':
                                e = d[path1].d
                                e[e.keys()[0]].set_to_undefined(
                                    has_super=False
                                )
                path.pop(-1)

    def set_to_undefined(self, has_super=True, ignore_load=False):
        """
        Set the preset ComboBox display to undefined.

        has_super: bool
            If it's true, then set SuperPreset as changed:
        """
        if not Draw.load_count or ignore_load:
            if self.get_text() != fw.UNDEFINED:
                Draw.load_count += 1

                self.set_text(fw.UNDEFINED)

                Draw.load_count -= 1
                self._verify_del_button()
            if has_super:
                Preset.set_super_to_undefined(self.group.path)

    def set_value(self, d):
        """
        Load the preset on a menu change.

        d: dict
            Preset dict or None
        """
        Draw.load_count += 1
        e = self.group.d

        if self.group.group_type == PerCell:
            for i, a in d.items():
                # Find the Per Cell key:
                if i in e:
                    check_per_cell(self.group.d[ok.PER_CELL], a)

        [e[i].set_value(d[i]) for i in d if i in e]
        Draw.load_count -= 1


class SuperPreset(Preset):
    """Has sub-presets."""

    def __init__(self, **d):
        """
        Initialize the Preset.

        d: dict
            Has keyword init values.
        """
        # Port is PortMain.
        # Remember values needed to load the tree:
        Preset.__init__(self, **d)

    def _expand_tree(self, d, a, g, k, z_list=None):
        """
        Use recursion to walk through the option groups
        setting the list values. So that grid
        and custom cell branches will form.

        d: dict
            of SuperPreset
            Has values to load into widgets.

        a: OptionGroup
            Has needed info.

        g: Node
            Has branches.

        k: tuple
            path
            Is key for the group dict.

        Return: tuple
            OptionGroup, Node
            for recursion
        """
        if g:
            for i in g.get_value():
                k1 = k + (i,)
                if k1 in Hat.cat.group_dict:
                    # OptionGroup, 'a':
                    a = Hat.cat.group_dict[k1]

                    if a.node:
                        g = a.node
                        d, a, g, k1, z_list = self._expand_tree(
                            d,
                            a,
                            g,
                            k1,
                            z_list=z_list
                        )
                    else:
                        # widget dict, 'e':
                        e = a.d
                        # SuperPresets are not in the save dict:
                        if k1 in d:
                            d1 = d[k1]
                            for j, g in e.items():
                                if j in d1:
                                    if isinstance(g, ModelList):
                                        g.set_value(
                                            d1[j],
                                            is_preset=True
                                        )
                                        z_list = g
                                    elif isinstance(g, OptionList):
                                        g.set_value(d1[j])
        return d, a, g, k, z_list

    def _load_steps(self, d):
        """
        There are two phases to loading a Steps SuperPreset:

        (1) Create the option groups.
        (2) Load the option group values.

        d: dict
            Is a relational-type database.
            key: path, value: group dict
        """
        # Walk-through the Nodes to get additional steps:
        path = sk.STEPS
        group, node = get_group(path)
        model_list = self._expand_tree(d, group, node, path)[4]

        # Translate the SuperPreset names into an id number:
        if model_list:
            for i in model_list.get_value():
                n = i[md.NAME_INDEX]
                _id = Hat.cat.group_id.get_id(n)
                d = SuperPreset.translate_to_id(d, n, _id)
                path = sk.EFFECT + (_id,)
                group, node = get_group(path)
                d = translate_model_to_id(
                    d,
                    self._expand_tree(d, group, node, path)[4]
                )
        SuperPreset._load_widgets(d)

    def _load_sub_steps(self, d, q):
        """
        Load widgets of a sub-SuperPreset.

        d: dict
            of Effect

        q: tuple
            of indices in path where the group id is inserted
        """
        path = self.group.path[:-1]
        group, node = get_group(path)

        # Get ids in the path:
        q1 = []

        for i in q:
            q1 += [path[i]]

        # Translate the name into its id:
        e = {}

        for i, a in d.items():
            # If 'i' is not a tuple, then the dict is the wrong version:
            if isinstance(i, tuple):
                q3 = list(i)

                for j in range(len(q)):
                    q3[q[j]] = q1[j]
                e[tuple(q3)] = a

        d = translate_model_to_id(
            e,
            self._expand_tree(e, group, node, path)[4]
        )
        SuperPreset._load_widgets(d)

    @staticmethod
    def _load_widgets(d):
        """
        Load the widgets from a translated SuperPreset dictionary.

        d: dict
            of SuperPreset
        """
        is_err = False
        e = Hat.cat.group_dict

        # Set the values of the options:
        for i, d1 in d.items():
            for j, a in d1.items():
                # option value, 'a':
                if j != sk.SELECTED_ROW:
                    if i in e and j in e[i].d:
                        # Don't set it twice:
                        if type(e[i].d[j]) not in (ModelList, OptionList):
                            g = e[i].d[j]
                            g.group.changed = g.group.unseen = True
                            a = update_version(g, a)
                            g.set_value(a)
                    else:
                        if not is_err:
                            # Report an error one time:
                            Comm.info_msg(LOAD_ERR)
                        is_err = True
                else:
                    if a is not None:
                        if i in e:
                            k = [k for k in e[i].d][0]
                            # Select Node item:
                            e[i].d[k].select_item(a)
            if i in e and wk.PRESET in e[i].d:
                e[i].d[wk.PRESET].set_text(fw.UNDEFINED)

    @staticmethod
    def _translate_step(q):
        """
        Replace a numeric id with its corresponding name.

        q: tuple
            a step key

        Return: tuple
            the translated step
        """
        q1 = []
        group_id = Hat.cat.group_id

        if len(q) > fs.MODEL_INDEX:
            if isinstance(q[fs.MODEL_INDEX], int):
                q1 += [fs.MODEL_INDEX]

        if q1:
            q2 = list(q)

            for x1 in q1:
                q2[x1] = group_id.get_name(q[x1])
            q = tuple(q2)
        return q

    @staticmethod
    def get_steps(path, with_list=True, with_dict=True, last_path=None):
        """
        Make a steps dict.

        The steps are reflected by the order of the option groups.

        The steps dict has a steps list where each step is resolved
        into a step-keyed dictionary.

        steps dict
            key: 'steps', value: list of step
            1 to n of step:
                key: path, value: preset-type dict

        path: tuple
            of SuperPreset

        with_list: bool
            If it's true, a step list is built into the resulting dict.

        with_dict: bool
            If it's true, the step option groups are added with their values.

        last_path: tuple or None
            If it is a tuple, then its the stop point for the walk.

        Return: tuple
            steps dict, steps list
            The dict has option values, and the list is ordered for rendering.
        """
        def walk(a, g, k, m):
            """
            Use recursion to walk through the option groups.
            Collect option values and Node selections.

            a: OptionGroup
                Has needed info.

            g: Node
                Has branches.

            k: tuple
                path
                Is key for the group dict.

            m: bool
                If true the walk is done.

            Return: tuple
                OptionGroup, Node
                for recursion
            """
            if g and not m:
                if with_dict:
                    # Collect option values in 'e' of 'get_steps':
                    e[a.path] = {sk.SELECTED_ROW: g.get_sel_x()}

                if with_list:
                    steps.append(a.path)
                for i in g.get_value():
                    # Expand path:
                    k1 = k + (i,)

                    # Replace numeric id of a SuperPreset:
                    if k1 not in d:
                        _id = group_id.get_id(i)
                        k1 = k + (_id,)
                    if k1 in d and not m:
                        a = d[k1]

                        if a.node:
                            # Continue with a new node:
                            g = a.node
                            a, g, k1, m = walk(a, g, k1, m)
                        else:
                            # Is a terminal point of this branch:
                            if a.group_type in (PerCell, Preset):
                                keys = Preset.get_keys(a.group_key)

                            elif a.group_type == NonPreset:
                                keys = NonPreset.get_keys(a.group_key)

                            else:
                                keys = None

                            if with_list:
                                # Add option's step to the sequence:
                                steps.append(a.path)
                            if keys:
                                # Collect values from widgets:
                                d1 = Path.get_dict_from_path(
                                    k1,
                                    add_per_cell=False
                                )

                                if with_dict:
                                    e[k1] = d1

                                # Is there a Per Cell table?
                                if hasattr(a.vbox, og.PER_CELL_GROUP):
                                    # Get the Per Cell's cell table:
                                    k2 = Path.make_per_cell_path(k1)

                                    # OptionGroup 'b':
                                    b = d[k2]

                                    if with_dict:
                                        e[k2] = {PC: b.d[PC].get_value()}
                                    if with_list:
                                        # Add the Per Cell step:
                                        steps.append(b.path)
                    if k1 == last_path:
                        m = True
            return a, g, k, m

        d = Hat.cat.group_dict
        group_id = Hat.cat.group_id
        e = {}
        steps = []
        group = d[path]
        node = group.node
        walk(group, node, path, False)
        return e, steps

    @staticmethod
    def get_render_steps(path=None):
        """
        Get the steps for a render or preview.

        path: tuple
            Is the last step needed.

        Return: list
            of filter steps
        """
        # Remove steps that are not needed for a render:
        q1 = []
        d = Hat.cat.group_dict
        q = SuperPreset.get_steps(sk.STEPS, with_dict=False, last_path=path)[1]

        # Filter out useless steps:
        for i in q:
            if d[i].group_type not in (Node, SuperPreset):
                q1 += [i]
        return q1

    def get_value(self):
        """
        Collect a SuperPreset dictionary.

        Use to save a SuperPreset.

        Return: dict
            of SuperPreset
            key: step; value: option group dict
        """
        k = sk.STEPS if self.group_key == gk.PRESET_STEPS else \
            self.group.path[:-1]

        d = SuperPreset.get_steps(k, with_list=False)[0]
        return SuperPreset.translate_to_name(d)

    @staticmethod
    def make_preview(g, group):
        """
        Create a preview render.

        g: OptionButton
            of preview
            Is responsible.
            Has path.

        group: OptionGroup
            Has group variables.
        """
        # Get the render-filtered steps that lead to the path:
        path = group.path

        Hat.cat.viewer.do(
            SuperPreset.get_render_steps(path=path),
            is_preview=True
        )
        g.set_sensitive(0)
        SuperPreset.update_preview_buttons(path)
        if hasattr(group, 'plan_button'):
            if group.plan_button:
                group.plan_button.set_sensitive(1)

    def set_value(self, d):
        """
        Override the 'set_value' function in the Preset class.

        d: dict
            of super preset
        """
        if not d:
            # Use default dict:
            if self.group_key == gk.PRESET_STEPS:
                d = PRESET_STEPS
            else:
                if not Draw.preset_load_count:
                    # Create a default dict:
                    path = self.group.path[:-1]
                    group_dict = Hat.cat.group_dict
                    q = SuperPreset.get_steps(path, with_dict=False)[1]

                # Set the name of the default SuperCell:
                if self.group_key == gk.PRESET_TABLE:
                    NonPreset.update_z_item_name(
                        gk.TABLE_PROPERTY,
                        ok.TABLE_NAME,
                        "Table 1"
                    )

                else:
                    NonPreset.update_z_item_name(
                        gk.CUSTOM_CELL_PROPERTY,
                        ok.CELL_NAME,
                        "Cell 1"
                    )

                # Remove useless paths:
                for x, i in enumerate([j for j in q]):
                    # Get OptionGroup, 'a':
                    a = group_dict[i]
                    if a.group_type not in (Node, SuperPreset):
                        d[i] = a.group_type.get_default(a.group_key)
        if d:
            Draw.preset_load_count += 1

            if self.group_key == gk.PRESET_STEPS:
                self._load_steps(d)

            else:
                # sub-SuperPreset:
                x = (
                    gk.PRESET_TABLE,
                    gk.PRESET_CUSTOM_CELL,
                    gk.PRESET_TRI_SHADOW
                ).index(self.group_key)
                q = ((fs.MODEL_INDEX,), (fs.MODEL_INDEX,), ())[x]
                self._load_sub_steps(d, q)
            Draw.preset_load_count -= 1

    @staticmethod
    def translate_to_id(d, n, _id):
        """
        Translate a name to an id.

        d: dict
            of SuperPreset

        n: string
            name

        Return: dict
            with translated names
        """
        e = {}
        x = fs.MODEL_INDEX

        for step in d:
            if len(step) > x and n == step[x]:
                q = list(step)
                q[x] = _id
                q = tuple(q)
                e[q] = d[step]
            else:
                e[step] = d[step]
        return e

    @staticmethod
    def translate_to_name(d):
        """
        Replace numeric ids with their corresponding names.

        d: dict
            of steps

        Return: dict
            'd' after translation
        """
        e = {}

        for i, a in d.items():
            # Replace ids with names:
            e[SuperPreset._translate_step(i)] = a
        return e

    @staticmethod
    def update_plan_buttons(path):
        """
        Update the plan and preview buttons after change.

        path: tuple
            a render step
        """
        # Change the Preview buttons along the tree branch:
        q = SuperPreset.get_steps(sk.STEPS, with_dict=False)[1]
        d = Hat.cat.group_dict
        for i in q:
            if i == path:
                continue

            a = d[i]
            if a.plan_button:
                a.plan_button.set_sensitive(1)

    @staticmethod
    def update_preview_buttons(path):
        """
        Update the plan and preview buttons after change.

        path: tuple
            a render step
        """
        # Change the Preview buttons along the tree branch:
        q = SuperPreset.get_steps(sk.STEPS, with_dict=False)[1]
        d = Hat.cat.group_dict
        for i in q:
            if i == path:
                continue

            a = d[i]
            if a.preview_button:
                a.preview_button.set_sensitive(1)

    @staticmethod
    def update_view_buttons(path):
        """
        Update the plan and preview buttons after change.

        path: tuple
            a render step
        """
        # Change the Preview buttons along the tree branch:
        q = SuperPreset.get_steps(sk.STEPS, with_dict=False)[1]
        d = Hat.cat.group_dict
        for i in q:
            if i == path:
                continue

            a = d[i]

            if a.preview_button:
                a.preview_button.set_sensitive(1)
            if a.plan_button:
                a.plan_button.set_sensitive(1)


class NonPreset:
    """
    Are dictionaries that do not have a preset,
    but still have options. Use when drawing groups.
    """
    n = fd.BLUR_BEHIND

    # Define option group content.
    # Is part of a Preset template:
    _default = {
        ek.NO_EFFECT: {},
        gk.BACKDROP_STYLE: BACKDROP_STYLE,
        gk.CAPTION_BEHIND: {},
        ok.CELL_PLAN: CELL_PLAN,
        gk.CLEAR_FRAME_BEHIND: {ok.BLUR_BEHIND: 16},
        gk.COLOR_BOARD_BEHIND: {ok.BLUR_BEHIND: 0},
        gk.CUSTOM_CELL_PROPERTY: OrderedDict([
            (ok.CELL_NAME, "Cell 1"),
            (ok.CUSTOM_CELL_SHAPE, sh.RECTANGLE),
            (ok.CELL_PLAN, CELL_PLAN)
        ]),
        gk.GLASS_REVEAL_BEHIND: {ok.BLUR_BEHIND: 12},
        gk.GRADIENT_LEVEL_BEHIND: {ok.BLUR_BEHIND: 12},
        gk.MODEL: MODEL,
        gk.TABLE_PROPERTY: OrderedDict([
            (ok.TABLE_NAME, "Table 1"),
            (ok.TABLE_PLAN, TABLE_PLAN)
        ]),
        gk.GLOBAL: GLOBAL,
        gk.IMAGE_BEHIND: {},
        gk.IMAGE_EFFECT: {ok.IMAGE_EFFECT: ek.NO_EFFECT},
        gk.SHADOW_TYPE: {ok.SHADOW_TYPE: 0},
        gk.STAINED_GLASS_BEHIND: {ok.BLUR_BEHIND: 12},
        ok.TABLE_PLAN: TABLE_PLAN
    }

    @staticmethod
    def get_default(k):
        """
        Get a non-preset dictionary.

        Is part of a Preset template.

        k: string
            of preset

        Return: dict
            default dict
        """
        if k in NonPreset._default:
            return deepcopy(NonPreset._default[k])
        Preset.get_default(k)

    @staticmethod
    def get_keys(k):
        """
        Get the keys belonging to a non-preset group.

        Is part of a Preset template.

        k: string
            of preset

        Return: list
            of preset keys
            of string
        """
        d = NonPreset._default
        if k in d:
            a = d[k]

            if isinstance(a, dict):
                return a
            return []
        return Preset.get_keys(k)

    @staticmethod
    def load(d, k):
        """
        Load the default settings for a Non-Preset group.

        d: dict
            of widgets

        k: string
            group key
        """
        Draw.load_count += 1
        e = NonPreset.get_default(k)

        [d[i].set_value(e[i]) for i in e if i in d]
        Draw.load_count -= 1

    @staticmethod
    def update_z_item_name(group_key, k, n):
        """
        Set the default name of a newly created ModelList item.

        The default model dict will then load with the latest name.

        group_key: string
            in '_default'

        k: string
            option key
            of group key dict

        n: string
            item name
        """
        NonPreset._default[group_key][k] = n


class PerCell(Preset):
    """
    Inherit the functionality of a Preset.

    Use an option group that have a PerCellGroup.
    """
    def __init__(self, **d):
        Preset.__init__(self, **d)


BEHIND_TYPE = {wk.HAS_PREVIEW: True, wk.WIDGET: NonPreset}
