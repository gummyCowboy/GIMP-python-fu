#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Gradient as fg
from roller_constant_key import Option as ok
from roller_frame import Metal, do_soft_metal_material
from roller_one_fu import Lay, Mage, Sel
from roller_view_hub import set_fill_context
import gimpfu as fu

pdb = fu.pdb


def make_pattern(z, d):
    """
    Make a Line Fashion pattern.

    z: layer
        to receive pattern

    d: dict
        Line Fashion Preset
        {Option key: value}

    Return: layer
        Has material to select.
    """
    w = d[ok.LINE_W]
    w1 = d[ok.GAP_W] + w
    j1 = pdb.gimp_image_new(w1, w1, fu.RGB)
    z1 = Lay.add(j1, "Pattern")
    y = (w1 - w) // 2

    Sel.rect(j1, 0, y, w1, w)
    Sel.fill(z1, (0, 0, 0))

    # Set the Clipboard Image.
    Mage.copy_all(j1)

    pdb.gimp_image_delete(j1)
    set_fill_context(fg.FILL_DICT)
    pdb.gimp_context_set_pattern("Clipboard Image")

    # x, y screen coordinate, '1'
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, 1, 1)
    return z


def do_matter(v, maya):
    """
    Make a frame.

    v: View
    maya: LineFashion
    Return: layer
        with the frame
    """
    return do_soft_metal_material(v, maya, make_pattern, "Line Fashion")


class LineFashion(Metal):
    """Is a metallic frame with striped plating."""

    def __init__(self, *q, **d):
        """
        q: tuple
            Metal spec
        """
        Metal.__init__(self, *q + (do_matter,), **d)
