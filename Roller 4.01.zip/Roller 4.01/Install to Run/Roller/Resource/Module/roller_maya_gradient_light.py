#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Signal as si
from roller_constant_key import Option as ok
from roller_maya import MAIN, Maya
from roller_one_the import The
from roller_option_group import ManyGroup
from roller_view_gradient_light import GradientLight


def make_gradient_light(v, maya):
    """
    Make Gradient Light and / or remove it.

    v: View
    maya: Work
    """
    if maya.is_matter:
        GradientLight.reset()
        GradientLight.create(v, maya)


class Light(ManyGroup):
    """Is used by the Gradient Light step."""

    def __init__(self, **d):
        ManyGroup.__init__(self, **d)

        self.plan = Plan(self)
        self.work = Work(self)


class Plan(Maya):
    issue_q = ()
    vote_type = MAIN

    def __init__(self, any_group):
        Maya.__init__(self, any_group, 0, ())

    def do(self, v):
        """
        Plan doesn't have Gradient Light.

        v: View
        Return: None
            for undo
        """
        return


class Work(Maya):
    put = (make_gradient_light, 'matter'),
    issue_q = 'matter',
    vote_type = MAIN

    def __init__(self, any_group):
        Maya.__init__(
            self,
            any_group,
            1,
            Work.put,
            k_path=[(), (ok.IRR,), (ok.IGR, ok.GRADIENT)]
        )
        self.set_issue()
        self.handle_d[
            any_group.booth.connect(si.VOTE_CHANGE, Work.on_light_change)
        ] = any_group.booth

    def do(self, v):
        """
        Determine if there is change. Send changed signal.

        v: View
        Return: None
            for undo
        """
        self.go = self.value_d[ok.SWITCH]
        self.realize_vote(v)

    def die(self, v):
        GradientLight.reset()

    @staticmethod
    def on_light_change(_, arg):
        """
        _: AnyGroup
            Sent the signal.

        arg: dict
            AnyGroup's vote collection
        """
        The.power.plug(si.LIGHT_CHANGE, None)
