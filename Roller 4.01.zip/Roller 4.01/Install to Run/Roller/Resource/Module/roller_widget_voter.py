#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_key import Widget as wk


class Voter:
    """Subscribe to signal. Receive signal. Cast vote."""

    def __init__(self, **d):
        """
        d: dict
            Init.
        """
        self.handle_d = {}
        self.view_value = [None, None]
        self.issue = d[wk.ISSUE] if wk.ISSUE in d else None

        if self.key and self.change_signal:
            if self.issue and wk.CHANGELESS not in d:
                self.relay += [self.on_voter_change]
            elif wk.CHANGELESS not in d:
                # The option does not vote but effects change.
                self.relay += [self.on_simple_change]

    def on_disappear(self, _, arg):
        """
        The AnyGroup is no longer in service, so disconnect its subscription.
        """
        for i, a in self.handle_d.items():
            a.disconnect(i)
        self.handle_d = {}

    def on_simple_change(self, g):
        """
        Flag the option group as changed.

                g: GTK Widget
            the signal sender
            Is responsible for change.
        """
        self.any_group.changed()

    def on_voter_change(self, g):
        """
        Cast change vote.

        g: GTK Widget
            the signal sender
            Is responsible for change.
        """
        if self.any_group:
            a = self.get_a()

            for x in range(2):
                self.any_group.cast_vote(
                    x, self.key, self.issue, a != self.view_value[x]
                )

            if self.row_key:
                self.any_group.set_sub_widget_a(self.key, self.row_key, a)
            else:
                self.any_group.update_option_a(self.key, a)

    def set_view_value(self, x, a):
        self.view_value[x] = deepcopy(a)
