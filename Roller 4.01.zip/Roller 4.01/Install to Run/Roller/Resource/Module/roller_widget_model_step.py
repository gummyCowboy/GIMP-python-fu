#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Color as co, Signal as si, Widget as fw
from roller_constant_key import Widget as wk
from roller_one_extract import collect_step
from roller_one_the import The
from roller_one_tip import Tip
from roller_port_tree import MODEL_TREE
from roller_widget import set_widget_attr
from roller_widget_button import Button
from roller_widget_label import Label
from roller_widget_tree import get_treeview_item, TreeViewList
import gtk

NO_SHOW = (
    "/Cell/Rectangle", "/Cell/Type", "/Property", "/Preset", "/Canvas/Shift"
)


def convert_to_string(q):
    """
    Convert a list of step key to TreeView compatible string.

    q: list
        of step key
        tuple
        ('item', ...)

    Return: list
        of string
    """
    path_q = []

    for i in q:
        n = ""

        for x, i1 in enumerate(i):
            if x + 1 < len(i):
                n += i1 + "/"
            else:
                n += i1
        path_q += [n]
    return path_q


class ModelStep(gtk.Alignment, object):
    """
    Compose the user interface with a Model step filter. A
    Model step can be hidden or added to the nodal navigation.
    """

    def __init__(self, model_list, branch_q, **d):
        """
        model_list: ModelList
            Has Model.

        branch_q: list
            of Model branch

        d: dict
            Has option.
        """
        super(gtk.Alignment, self).__init__()
        set_widget_attr(self, d)

        self.relay = d[wk.RELAY]
        self._model_list = model_list
        self._branch_q = branch_q
        hbox = gtk.HBox()

        hbox.add(gtk.Label("\n" * 22))

        w = fw.MARGIN
        d[wk.SCROLL] = 1
        d[wk.PADDING] = w, w, w, w
        d[wk.TREE_COLOR] = d[wk.COLOR]
        d[wk.COLOR] = co.LIST_CELL_COLOR
        d[wk.MINIMUM_W] = 100

        self._draw_model_list(hbox, **d)
        self._draw_move_button(hbox, **d)
        self._draw_step_list(hbox, **d)
        self.add(hbox)
        self._init_list()

        # Trigger a change signal.
        self._offline_tree.select_item(0)

        self._verify_buttons()

    def _draw_model_list(self, hbox, **d):
        """
        Draw a list of available Model item.

        d: dict
            Has option.
        """
        vbox = gtk.VBox()
        d[wk.RELAY] = self.relay[:]

        d[wk.RELAY].insert(0, self.on_model_list_change)

        # Has step for the offline dict, '_offline_tree'.
        self._offline_tree = TreeViewList(**d)

        vbox.pack_start(Label(**{wk.TEXT: "Model Shelf:"}), expand=False)
        vbox.pack_start(self._offline_tree, expand=True)
        hbox.pack_start(vbox, expand=True)

    def _draw_move_button(self, hbox, **d):
        """
        Draw a list for selected Model item.

        d: dict
            Has option.
        """
        vbox = gtk.VBox()
        d[wk.TEXT] = gtk.Arrow(gtk.ARROW_LEFT, gtk.SHADOW_NONE)
        d[wk.TOOLTIP] = Tip.MOVE_LEFT
        d[wk.RELAY] = self.relay[:] + [self.on_move_left_action]
        self.move_left = Button(**d)
        d[wk.TEXT] = gtk.Arrow(gtk.ARROW_RIGHT, gtk.SHADOW_NONE)
        d[wk.TOOLTIP] = Tip.MOVE_RIGHT
        d[wk.RELAY] = self.relay[:] + [self.on_move_right_action]
        self.move_right = Button(**d)

        vbox.pack_start(Label(**{wk.TEXT: " "}), expand=False)
        vbox.add(self.move_right)
        vbox.add(self.move_left)
        hbox.add(vbox)

    def _draw_step_list(self, hbox, **d):
        """
        Draw a list for selected Model item.

        d: dict
            Has option.
        """
        vbox = gtk.VBox()
        d[wk.RELAY] = self.relay[:]

        d[wk.RELAY].insert(0, self.on_step_list_change)

        # Has step for the interface navigation tree, '_nav_tree'.
        self._nav_tree = TreeViewList(**d)

        vbox.pack_start(Label(**{wk.TEXT: "Use Step:"}), expand=False)
        vbox.pack_start(self._nav_tree, expand=True)
        hbox.pack_start(vbox, expand=True)

    def _init_list(self):
        """
        A Model has a step key that is part of the navigation tree, or
        is available to add to that tree. Create two list, one for
        the visible and the other for the available. Load each
        TreeViewList per its assignment.
        """
        def _remove_no_show():
            _q = []

            for x, _i in enumerate(q):
                for i1 in NO_SHOW:
                    if i1 in _i:
                        _q += [x]
            for x in reversed(_q):
                q.pop(x)

        total_model_q = []

        for model_name, model_type in self._model_list.get_model_def():
            # Add a list of step key to the Model Tree Widget.
            # Are steps that were not created previously.
            model_step_q = []

            collect_step(MODEL_TREE, (model_type,), model_step_q)

            # Replace the Model type with the Model name.
            model_step_q = [(model_name,) + i[1:] for i in model_step_q]

            # Convert Model specific group key to step key compatible.
            model_step_q = [
                i[:-1] + (i[-1].split(",")[0],) for i in model_step_q
            ]

            # Filter out steps in the interface dict.
            model_step_q = [i for i in model_step_q if i not in self._branch_q]

            # Load the TreeView.
            q = convert_to_string(model_step_q)

            _remove_no_show()
            total_model_q += q

        q = convert_to_string(self._branch_q)

        _remove_no_show()
        self._offline_tree.populate_item_q(total_model_q)
        self._nav_tree.populate_item_q(q)

    def _move_item(self, from_tree, to_tree):
        """
        Move an item from one TreeView to the other.
        """
        n = get_treeview_item(from_tree.treeview)

        if n is not None:
            from_tree.remove_x(from_tree.get_sel_x())
            to_tree.insert_row(len(to_tree.item_q), n)

            x = len(n)

            # Transfer a Node branch.
            for i in from_tree.item_q[:]:
                if n in i[:x] and i[:x + 1][-1] == '/':
                    from_tree.remove_x(from_tree.get_item_x(i))
                    to_tree.insert_row(len(to_tree.item_q), i)

        self._verify_buttons()
        The.power.plug(si.ACCEPT_FOCUS, self)

    def _verify_buttons(self):
        self._verify_left_button()
        self._verify_right_button()

    def _verify_left_button(self):
        """
        The left Button is dependent on a selection in the Tree TreeView.
        """
        self.move_left.set_sensitive(self._nav_tree.get_sel_x() is not None)

    def _verify_right_button(self):
        """
        The right Button is dependent on a selection in the Model TreeView.
        """
        self.move_right.set_sensitive(
            self._offline_tree.get_sel_x() is not None
        )

    def get_a(self):
        """
        Call to retrieve the value of the TreeView.

        Return: tuple
            (list of Model TreeView item, list of Tree TreeView item)
        """
        # Insert hidden step back into the list with Model reference.
        for model_name, model_type in self._model_list.get_model_def():
            model_follower = [model_name + i for i in NO_SHOW]

            if any(
                [
                    i for i in self._nav_tree.item_q
                    if model_name == i.split("/")[0]
                ]
            ):
                self._nav_tree.item_q += model_follower
            else:
                self._offline_tree.item_q += model_follower

        # Convert the item string value into step key tuple.
        return [tuple(i.split("/")) for i in self._nav_tree.item_q]

    def on_model_list_change(self, *_):
        """Respond to a change in the Model list."""
        self._verify_right_button()

    def on_move_left_action(self, *_):
        """
        Move the selected item from the Tree TreeView to the Model TreeView.
        """
        self._move_item(self._nav_tree, self._offline_tree)

    def on_move_right_action(self, *_):
        """
        Move the selected item from the Model TreeView to the Tree TreeView.
        """
        self._move_item(self._offline_tree, self._nav_tree)

    def on_step_list_change(self, *_):
        """Respond to a change in the Tree list."""
        self._verify_left_button()
