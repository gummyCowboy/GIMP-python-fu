#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one import Base
from roller_constant_for import Gradient as fg
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_one_fu import Lay, Mage
from roller_view_real import add_wip_layer, clip_to_wip, finish_style
from roller_view_hub import make_cube_pattern, set_fill_context
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Do the Backdrop Style.

    v: View
        Has scope variable.

    maya: Style
    Return: layer
        with Cube Pattern
    """
    def _fill_it():
        """Fill a layer with the clipboard image pattern."""
        set_fill_context(fg.FILL_DICT)
        pdb.gimp_context_set_pattern("Clipboard Image")
        pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, 0, 0)

    j = v.j
    d = maya.value_d
    key = maya.any_group.item.key
    make_cube_pattern(
        d[ok.HEIGHT_CLIP], d[ok.COLOR_3A], d[ok.IFRW][ok.FLIP_V]
    )

    if d[ok.ANGLE]:
        w = Base.circumradius(j.width, j.height) * 2
        j1 = pdb.gimp_image_new(w, w, fu.RGB)
        z = Lay.add(j1, key)

        _fill_it()
        Mage.rotate(j1, d[ok.ANGLE])
        pdb.gimp_edit_copy_visible(j1)
        pdb.gimp_image_delete(j1)

        z = Lay.paste(maya.group, n=key)

        pdb.gimp_image_reorder_item(j, z, maya.group, 0)
        pdb.gimp_layer_resize_to_image_size(z)
        clip_to_wip(v, z)

    else:
        # pattern layer, 'z'
        z = add_wip_layer(v, maya, key)
        _fill_it()

    if d[ok.IFRW][ok.INVERT]:
        pdb.gimp_drawable_invert(z, 0)
    return finish_style(z, "Cube Pattern")


class CubePattern(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = False

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        k_path = d['k_path']
        d['k_path'] = [k_path, k_path + (ok.IFRW,)]
        Style.__init__(self, *q + (make_style,), **d)
