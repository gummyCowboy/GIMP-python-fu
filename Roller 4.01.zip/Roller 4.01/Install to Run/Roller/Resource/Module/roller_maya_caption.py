#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Caption as pt, Plan as fy, Signal as si
from roller_constant_key import (
    Item as ie, Node as ny, Option as ok, Plan as ak
)
from roller_deco_caption import (
    do_main_cell,
    do_main_face,
    do_canvas,
    do_cell,
    do_face,
    make_main_face_stripe,
    make_main_stripe,
    make_canvas_stripe,
    make_cell_face_stripe,
    make_cell_stripe
)
from roller_maya import (
    MAIN,
    PER,
    CanvasRoute,
    CellRoute,
    ImageRoll,
    check_cake,
    check_matter
)
from roller_maya_shadow import Shadow
from roller_maya_stripe import Stripe
from roller_one_extract import get_planner, make_model_key
from roller_one_the import The
from roller_option_group import DecoGroup
from roller_view_real import make_canvas_group, make_cast_group


def assign_cell_image(v, maya, value):
    """
    Find assigned image for the Image Name Caption Type.

    v: View
    maya: Maya
    value: value
        Is the default value for an image reference when complications arise.
    """
    d = maya.value_d
    per_cell = d[ok.PER_CELL]
    cell_d = maya.cell_d
    image_maya = get_image_maya(v, maya)
    if d[ok.SWITCH] or per_cell:
        for r_c in maya.model.cell_q:
            if r_c in cell_d:
                # Per Cell
                cell_maya = cell_d[r_c]
                e = per_cell[r_c]

            else:
                # main
                cell_maya = maya
                e = d

            if e[ok.TYPE_DECO] == pt.IMAGE_NAME:
                if image_maya:
                    image = image_maya.get_image(r_c)
                    if image != cell_maya.get_image(r_c):
                        cell_maya.is_matter = True
                    cell_maya.set_image(r_c, image)

            else:
                if value != cell_maya.get_image(r_c):
                    cell_maya.is_matter = True
                cell_maya.set_image(r_c, value)


def get_image_maya(v, maya):
    """
    Get the Image Maya for the Caption's Cell.

    v: View
    maya: Maya
    Return: Maya or None
        an Image type relative
    """
    # Canvas, Cell, Face Node position, '2'
    step_key = make_model_key(maya.step_key, (maya.step_key[2], ie.IMAGE))

    any_group = The.helm.get_group(step_key)
    if any_group:
        return (any_group.plan, any_group.work)[v.x]


class Caption(DecoGroup):
    """Assign Caption Maya to an option group."""

    def __init__(self, **d):
        DecoGroup.__init__(self, **d)

        node_k = self.step_key[-2]
        self.plan = {
            ny.CANVAS: PlanCanvas, ny.CELL: PlanCell, ny.FACE: PlanFace
        }[node_k](self)
        self.work = {
            ny.CANVAS: WorkCanvas, ny.CELL: WorkCell, ny.FACE: WorkFace
        }[node_k](self)
        baby = self.item.model.baby
        if node_k == ny.FACE:
            self.handle_d[
                baby.connect(si.CELL_SHIFT_CALC, self.on_cell_calc)
            ] = baby


class Chi(ImageRoll):
    """Is factored from Plan and Work."""

    def __init__(self, any_group, view_x, p, q):
        """
        any_group: AnyGroup
            owner

        view_x: int
            0 or 1; Plan or Work index

        p: function
            Call to make Stripe material.

        q: iterable
            of function for producing View output
        """
        ImageRoll.__init__(
            self,
            any_group,
            view_x,
            q,
            k_path=[
                (),
                (ok.FCR, ok.FONT),
                (ok.LTR,),
                (ok.OCR,),
                (ok.MSS, ok.MARGIN)
            ]
        )
        self.set_issue()
        self.sub_maya[ok.STRIPE] = Stripe(
            any_group, self, view_x, p, (ok.MSS, ok.STRIPE)
        )


class Plan(Chi):
    put = (make_cast_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group, p):
        """
        any_group: AnyGroup
            owner

        p: function
            Call to make Stripe material.
        """
        Chi.__init__(self, any_group, 0, p, self.put)

        planner = get_planner(any_group.step_key)
        self.is_planned = planner.get_option_a(ak.CAPTION)
        self.handle_d[
            planner.connect(
                fy.SIGNAL_D[ak.CAPTION], self.on_plan_option_change
            )
        ] = planner

    def bore(self, v):
        """
        Process change within a View run.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH] and self.is_planned

        if self.go:
            self.is_matter |= self.is_switched

        self.realize(v)
        if self.go:
            self.go = bool(self.matter)
            self.sub_maya[ok.STRIPE].do(v, d)

    def on_plan_option_change(self, _, arg):
        """Respond to change in PlanOption."""
        self.is_planned, self.is_switched = arg


class Work(Chi):
    """Has layer attribute update function. Plan has no need."""
    put = (
        (make_cast_group, 'group'),
        (check_matter, 'matter'),
        (check_cake, None)
    )

    def __init__(self, any_group, p):
        """
        any_group: AnyGroup
            owner

        p: function
            Call to make Stripe material.
        """
        Chi.__init__(self, any_group, 1, p, self.put)
        self.sub_maya[ok.SHADOW] = Shadow(
            any_group, self, (self,), (ok.MSS, ok.SHADOW), is_wrap=False
        )

    def bore(self, v):
        """
        Process change.

        v: View
        """
        d = self.value_d
        self.go = d[ok.SWITCH]

        self.realize(v)
        if self.go:
            self.go = bool(self.matter)
            self.sub_maya[ok.STRIPE].do(v, d)
            self.sub_maya[ok.SHADOW].do(v, d[ok.MSS][ok.SHADOW])


class Main:
    vote_type = MAIN

    def __init__(self):
        return


# Canvas_______________________________________________________________________
class Cloth:

    def __init__(self):
        self.do_matter = do_canvas

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        if self.value_d[ok.TYPE_DECO] == pt.IMAGE_NAME:
            j = get_image_maya(v, self).get_image(None)

            if j != self.get_image(None):
                self.is_matter = True
            self.set_image(None, j)
        else:
            self.set_image(None, None)


class PlanCanvas(Main, Plan, CanvasRoute, Cloth):
    """Is a View guide for Plan's Canvas Plaque."""
    issue_q = 'matter', 'switched'
    put = (make_canvas_group, 'group'), (check_matter, 'matter')

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            owner
        """
        self.do_matter = do_canvas

        Main.__init__(self)
        Plan.__init__(self, any_group, make_canvas_stripe)
        CanvasRoute.__init__(self)
        Cloth.__init__(self)


class WorkCanvas(Main, Work, CanvasRoute, Cloth):
    """Is a View guide for Work's Canvas."""
    issue_q = 'cake', 'matter', 'shade'
    put = (
        (make_canvas_group, 'group'),
        (check_matter, 'matter'),
        (check_cake, None)
    )

    def __init__(self, any_group):
        """
        Check and act on Vote flag change.

        any_group: AnyGroup
            owner
        """
        self.do_matter = do_canvas

        Main.__init__(self)
        Work.__init__(self, any_group, make_canvas_stripe)
        CanvasRoute.__init__(self)
        Cloth.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Cell_________________________________________________________________________
class Cellular:

    def __init__(self):
        self.r_c = None
        self.do_matter = do_main_cell

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_cell_image(v, self, None)


class PlanCell(Main, Plan, CellRoute, Cellular):
    """Manage Plan Cell output."""
    issue_q = 'matter', 'per_cell', 'switched'

    def __init__(self, any_group):
        self.do_matter = do_main_cell

        Main.__init__(self)
        Plan.__init__(self, any_group, make_main_stripe)
        CellRoute.__init__(self, PlanCellPer)
        Cellular.__init__(self)


class WorkCell(Main, Work, CellRoute, Cellular):
    """Manage Work Cell output."""
    issue_q = 'cake', 'matter', 'per_cell', 'shade'

    def __init__(self, any_group):
        self.do_matter = do_main_cell

        Main.__init__(self)
        Work.__init__(self, any_group, make_main_stripe)
        CellRoute.__init__(self, WorkCellPer)
        Cellular.__init__(self)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Per Cell_____________________________________________________________________
class PerCell:
    vote_type = PER

    def __init__(self, do_matter, r_c):
        self.do_matter = do_matter
        self.r_c = r_c


class PlanCellPer(PerCell, Plan):
    """Manage Plan Per Cell output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, r_c):
        """
        any_group: AnyGroup
        r_c: tuple
            (row, column)
        """
        PerCell.__init__(self, do_cell, r_c)
        Plan.__init__(self, any_group, make_cell_stripe)


class WorkCellPer(PerCell, Work):
    """Manage Work Per Cell output."""
    issue_q = 'cake', 'matter', 'shade'

    def __init__(self, any_group, r_c):
        """
        any_group: AnyGroup
        r_c: tuple
            (row, column)
        """
        PerCell.__init__(self, do_cell, r_c)
        Work.__init__(self, any_group, make_cell_stripe)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face_________________________________________________________________________
class Face:

    def __init__(self):
        self.r_c = self.r_c_x = None
        self.do_matter = do_main_face

    def prep(self, v):
        """
        For every View, there is an Image.

        v: View
        """
        assign_cell_image(v, self, [None, None, None])


class PlanFace(Face, Main, Plan, CellRoute):
    """Manage Plan Face output."""
    issue_q = 'matter', 'per_cell', 'switched'

    def __init__(self, any_group):
        Face.__init__(self)
        Main.__init__(self)
        Plan.__init__(self, any_group, make_main_face_stripe)
        CellRoute.__init__(self, PlanFacePer)


class WorkFace(Face, Main, Work, CellRoute):
    """Manage Work Face output."""
    issue_q = 'cake', 'matter', 'per_cell', 'shade'

    def __init__(self, any_group):
        """
        any_group: AnyGroup
            with Face options
        """
        Face.__init__(self)
        Main.__init__(self)
        Work.__init__(self, any_group, make_main_face_stripe)
        CellRoute.__init__(self, WorkFacePer)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯


# Face Per Cell________________________________________________________________
class PlanFacePer(PerCell, Plan):
    """Manage Plan Per Cell Face output."""
    issue_q = 'matter', 'switched'

    def __init__(self, any_group, r_c):
        """
        any_group: AnyGroup
            owner

        r_c: tuple
            (r, c); cell index; of int
        """
        PerCell.__init__(self, do_face, r_c)
        Plan.__init__(self, any_group, make_cell_face_stripe)


class WorkFacePer(PerCell, Work):
    """Manage Work Per Cell Face output."""
    issue_q = 'cake', 'matter', 'shade'

    def __init__(self, any_group, r_c):
        """
        any_group: AnyGroup
            owner

        r_c: tuple
            (r, c); cell index; of int
        """
        PerCell.__init__(self, do_face, r_c)
        Work.__init__(self, any_group, make_cell_face_stripe)
# ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯
