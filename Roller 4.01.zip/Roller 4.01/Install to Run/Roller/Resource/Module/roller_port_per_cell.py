#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_for import Color as co, Widget as fw
from roller_constant_key import Group as gk, Option as ok, Widget as wk
from roller_one import Base
from roller_one_the import The
from roller_one_tip import Tip
from roller_port import Port
from roller_option_squish import make_tooltip
from roller_widget_box import Box, Eventful
from roller_widget_colorful_button import ColorfulButton, SwitchButton
from roller_widget_label import Label
from roller_widget_node import Dust
from roller_port_cell_editor import PortCellEditor
import gtk

# cell padding
PAD = 1
PADDING = [PAD, PAD, PAD, PAD]
H_PAD = [0, 0, PAD, PAD]
V_PAD = [PAD, PAD, 0, 0]

NO_CELL = " Is not a cell. "
HEADER_COLOR = co.HEADER_COLOR
TITLE = "Cell Table: Try escape, enter, space-bar to cancel, save, edit."


def calc_bottom_right(gum):
    """
    Return the row and column for the bottom-right cell of a merge-cell group.

    gum: Gum
        from a topleft cell
    """
    return gum.r + gum.s[0] - 1, gum.c + gum.s[1] - 1


def is_outside(gum, r, c, s):
    """
    Determine if a cell has cells that exist outside the bounds of a rectangle.

    gum: Gum
        Has cell data.

    r, c: int
        row, column

    s: tuple (w, h)
        bounds in cell count

    Return: flag
        Is true if the cell or its group has cells outside of the rectangle.
    """
    if gum.r < r or \
            gum.c < c or \
            gum.r + gum.s[0] > r + s[0] or \
            gum.c + gum.s[1] > c + s[1]:
        return 1


def set_sub_top(a, b):
    """
    Modify a cell's Gum to identify the cell as being sub-topleft.

    a: Gum
        the topleft cell

    b: Gum
        the sub-topleft cell
    """
    b.topleft = a
    b.s = -1, -1


class PortPerCell(Port):
    """Draw a Table of cell(s) reflecting a Model's cell table."""
    window_key = "Cell Table"
    dialog = PortCellEditor

    def __init__(self, d, g):
        """
        d: dict
            Has keyword argument.

        g: PerCellGroup
            Is responsible.
        """
        for i in d.keys():
            setattr(self, i, d[i])

        # Use to return focus to the responsible
        # Button after a dialog close, 'self.widget'.
        self.widget = None

        self.r_c = 0, 0
        self.on_per_cell_cancel = d[wk.ON_CANCEL]
        self.on_per_cell_accept = d[wk.ON_ACCEPT]
        self.model = g.any_group.item.model
        self.group_key = g.any_group.item.key
        self._is_table = True if self.group_key == gk.TYPE_TABLE else False
        self._per_cell_d = deepcopy(g.get_a())
        self._is_merge_cell = g.is_type_table
        self._split_cells = False
        r, c = self.division = self.model.division
        self._table_division = r * 2, c * 2
        self._switch_button_table = Base.make_2d_table(r, c)

        # Use to determine if the Cell Editor has modified a cell.
        # A Per Cell Preset has no Per Cell Preset value.
        self.main_edit_d = deepcopy(g.any_group.value_d)
        self.main_edit_d[ok.PER_CELL] = {}

        self._init_table()

        # Calculate the cell table's view-size.
        w = max(r, c)
        self._more = max(5, w)

        if w < 10:
            size = 500 // w

        elif w < 15:
            size = 50

        else:
            size = 25

        self.cell_height = size
        self.cell_table_group = The.dog.none_group(**{
            wk.ITEM: Dust(key=self.group_key, model=self.model)
        })

        d.update({
            wk.ON_ACCEPT: self.on_accept_cell_table,
            wk.ON_CANCEL: self.on_cancel_cell_table
        })
        Port.__init__(self, d, g)
        self.roller_win.gtk_win.set_title(TITLE)

    def _draw_cell(self, r, c):
        """
        Call for each cell in the Table Widget.

        r, c: int
            row, column
            cell position
            from 0 to n, where n is the Table's span minus one.
        """
        gum = self.gum_table[r][c]
        start, end = self._get_topleft(gum=gum).corners

        self._set_cell_face(gum, start, end)
        if not self._is_table:
            if gum.is_topleft:
                self.set_tooltip(r, c)

    def _draw_column_header(self, c, c1):
        """
        Draw a column header.

        c: int
            cell table column

        c1: int
            actual column
        """
        # column header
        g = Eventful(HEADER_COLOR)
        g1 = gtk.Frame()

        if c % 2:
            g2 = self.col_label = Label(align=(0, 0, 1, 1), text=str(c1))
            g1.add(g2)

        g.add(g1)
        return g

    def _draw_connector(self, r, c):
        """
        Draw a connector SwitchButton.

        r, c: int
            row, column
        """
        # A connector SwitchButton is either on the
        # left-side or on the top of a ColorfulButton.
        if r % 2:
            # left SwitchButton
            p = [self.split_horz, self.connect_left]
            r3, c3 = r, c + 1
            r4, c4 = r // 2, c // 2 - 1
            q = (PAD, PAD, 0, 0)

        else:
            # upper SwitchButton
            p = [self.split_vert, self.connect_up]
            r3, c3 = r + 1, c
            r4, c4 = r // 2 - 1, c // 2
            q = (0, 0, PAD, PAD)

        g = Box(box=gtk.HBox, align=(0, 0, 1, 1), padding=q)
        g1 = self._switch_button_table[r4][c4] = SwitchButton(
            r3, c3,
            cell_table=self.gum_table,
            color=co.CONNECTOR_COLOR,
            container=g,
            any_group=self.cell_table_group,
            relay=p,
            roller_win=self.roller_win,
            text="+"
        )

        g1.set_size(8, 8)
        return g, g1

    def _draw_first_cell(self, g):
        """
        Draw the first cell in the Table Widget. The size of
        the first cell will be the size of every cell in the Table.

        The 'self.roller_win.gtk_win.show_all' function
        causes the 'vbox' allocation to be calculated
        which will fail ScrolledWindow's dependency.
        So it's calculate the scroll region-size manually.

        g: cell widget
            Eventful or ColorfulButton

        Return:
            the width of the cell in pixels
            of int
        """
        row, column = self.division

        self.roller_win.gtk_win.show_all()

        # scale
        w = max(g.allocation.width, g.allocation.height, self.cell_height)
        w1, h = w * column, w * row
        w2 = self.row_label.allocation.width
        h1 = self.col_label.allocation.height
        button_w = 0 if not self._is_table else 15 * (column - 1)
        button_h = 0 if not self._is_table else 15 * (row - 1)
        pad_w = 4 * column
        pad_h = 4 * row
        extra_w, extra_h = self._table_division
        extra = self._more
        extra += 15 if not self._is_table == 3 else 0

        # sum
        w1 += w2 + pad_w + button_w + extra_w + fw.SCROLL_SPAN + extra
        h += h1 + pad_h + button_h + extra_h + fw.SCROLL_SPAN + extra
        w1, h = self.roller_win.get_remaining_dim(w1, h)

        self.set_size_request(w1, h)
        return w

    def _draw_row_header(self, r, r1):
        """
        Draw a row header.

        r: int
            table row

        r1: int
            row number
        """
        # row header
        g = Eventful(HEADER_COLOR)
        g1 = gtk.Frame()

        if r % 2:
            g2 = self.row_label = Label(align=(0, 0, 1, 1), text=str(r1))
            g1.add(g2)

        g.add(g1)
        return g

    def _generate_group(self, slices):
        """
        Slices organize themselves into one or more groups. A slice
        is a cell group with a piece of itself removed by a 'connect_up'
        or 'connect_left' process and a consuming merge group.

        slices: dict
            of dictionaries where each defines a group of cells
        """
        for k in slices:
            # Sort the two possible groups into a
            # larger and a smaller group (short).
            # The larger group will have the greater cell count.
            # The smaller group will be the cells not in the larger group.
            # If there's only one group,
            # the smaller group is not initialized.
            #
            # Starts by finding the longer and shorter row.
            u = slices[k]['size']
            long_row_width = long_row_height = 0
            long_col_width = long_col_height = 0
            short_col_width = short_row_height = 0
            short_row_width = short_col_height = 0
            start_long_row = [0, 0]
            start_short_row = [0, 0]
            start_long_col = [0, 0]
            start_short_col = [0, 0]

            # The key is the topleft coordinate (r, c).
            for r in range(k[0], k[0] + u[0]):
                row_width = 0
                first_col = -1

                for c in range(k[1], k[1] + u[1]):
                    if self._is_vector(k, r, c):
                        row_width += 1
                        if first_col < 0:
                            first_col = c
                    elif row_width:
                        break

                if row_width > long_row_width:
                    if long_row_width > 0:
                        # The second group inherits from the first group.
                        short_row_width = long_row_width
                        short_row_height = long_row_height
                        start_short_row = start_long_row

                    # Initialize the first group.
                    long_row_width = row_width
                    long_row_height = 1
                    start_long_row = r, first_col
                elif row_width:
                    # The vector is long or short.
                    if row_width == long_row_width:
                        long_row_height += 1
                    else:
                        if short_row_height:
                            # Add another row.
                            short_row_height += 1
                        else:
                            # Initialize the second group.
                            short_row_width = row_width
                            start_short_row = r, first_col
                            short_row_height = 1

            # Start finding the long and short column.
            for c in range(k[1], k[1] + u[1]):
                col_height = 0
                first_row = -1

                for r in range(k[0], k[0] + u[0]):
                    if self._is_vector(k, r, c):
                        col_height += 1
                        if first_row < 0:
                            first_row = r
                    elif col_height:
                        break

                if col_height > long_col_height:
                    if long_col_height > 0:
                        # Second group inherits from the first group.
                        short_col_width = long_col_width
                        short_col_height = long_col_height
                        start_short_col = start_long_col

                    # Initialize first group.
                    long_col_height = col_height
                    long_col_width = 1
                    start_long_col = first_row, c
                elif col_height:
                    # The vector is long or short.
                    if col_height == long_col_height:
                        long_col_width += 1
                    else:
                        if short_col_height:
                            short_col_width += 1
                        else:
                            # Initialize the second group.
                            short_col_width = 1
                            short_col_height = col_height
                            start_short_col = first_row, c

            row_cells = long_row_width * long_row_height
            col_cells = long_col_height * long_col_width

            # the second group's dimensions, 'v'
            v = 0

            if row_cells >= col_cells:
                u = long_row_height, long_row_width
                gum = self.gum_table[
                    start_long_row[0]][start_long_row[1]]

                # Process the second group if it was initialized.
                if short_row_width > 0:
                    v = short_row_height, short_row_width
                    gum1 = self.gum_table[
                        start_short_row[0]][start_short_row[1]]

            else:
                u = long_col_height, long_col_width
                gum = self.gum_table[
                    start_long_col[0]][start_long_col[1]]

                # Process the second group if it was initialized.
                if short_col_height > 0:
                    v = short_col_height, short_col_width
                    gum1 = self.gum_table[
                        start_short_col[0]][start_short_col[1]]

            self._set_group(gum, u)

            # Set the second group if there was one.
            if v:
                self._set_group(gum1, v)

    def _get_topleft(self, gum=None, u=None):
        """
        A topleft cell is the cell located at the topleft
        corner of a cell block. Sub-topleft cells refer
        to the topleft cell through a 'topleft' attribute.

        gum: Gum
            Has cell data.

        u: tuple
            row, column

        Return: Gum
            a topleft cell
        """
        if u:
            gum = self.gum_table[u[0]][u[1]]

        if gum.s[0] < 0:
            gum1 = gum.topleft
            v = gum1.r, gum1.c

        else:
            v = gum.r, gum.c
        return self.gum_table[v[0]][v[1]]

    def _init_table(self):
        """Set the initial data needed to draw cells."""
        row, column = self.division

        # Each cell hold a Gum instance.
        self.gum_table = Base.make_2d_table(row, column)

        # Load the cell dimensions.
        for r in range(row):
            for c in range(column):
                if self._is_merge_cell:
                    s = self._per_cell_d[(r, c)]

                else:
                    s = 1, 1
                self.gum_table[r][c] = Gum(
                    s, r, c, (r, c) in self.model.cell_q
                )

        # Initialize the 'topleft' references.
        for r in range(row):
            for c in range(column):
                gum = self.gum_table[r][c]
                if gum.is_topleft:
                    # Initialize the sub-topleft cells.
                    for r1 in range(r, r + gum.s[0]):
                        for c1 in range(c, c + gum.s[1]):
                            if r1 != r or c1 != c:
                                a = self.gum_table[r1][c1]
                                a.topleft = gum

    def _is_vector(self, u, r, c):
        """
        Determine if a cell (r, c) is still referencing a topleft cell at 'u'.

        u: tuple
            (row, column)

        Return: flag
            Is true if the topleft cell is still referenced.
        """
        # Get the cell dict.
        gum = self.gum_table[r][c]

        # Independent cells are not part of a vector.
        if gum.is_group:
            a = self._get_topleft(gum=gum)
            # Gum must refer to its old top.
            if a.r == u[0] and a.c == u[1]:
                return 1

    def _make_cell_button(self, r, c):
        """
        Make a ColorfulButton and add its
        cell coordinates to the ColorfulButton.

        r, c: int
            row, column
            cell position

        Return: ColorfulButton
            newly created
        """
        return ColorfulButton(
            color=co.CELL_COLOR,
            any_group=self.cell_table_group,
            key=(r, c),
            relay=self._open_cell_editor,
            roller_win=self.roller_win,
            text=self.get_cell_symbol(r, c)
        )

    def _merge_groups(self, top, origin):
        """
        Merge two groups into a new group.

        top: Gum
            the topleft cell of a cell block

        origin: Gum
            the topleft cell of another cell block
        """
        # Get the bottom-rights.
        o_b_r = calc_bottom_right(origin)
        t_b_r = calc_bottom_right(top)

        # Merge the group settings.
        m_pos = min(top.r, origin.r), min(top.c, origin.c)
        m_b_r = tuple(max(o, m) for o, m in zip(o_b_r, t_b_r))
        diff = tuple(n - m for n, m in zip(m_b_r, m_pos))
        v = diff[0] + 1, diff[1] + 1

        # Get the topleft cell's dict of the merged group.
        m = self.gum_table[m_pos[0]][m_pos[1]]

        # Create a dictionary of potential slices.
        #
        # Slices are groups that are part of a merged group
        # rectangle, but are exclusive of top and origin groups.
        #
        # Also, slices have cells outside the bounds of the merged group.
        sliced = {}

        for r in range(m_pos[0], m_pos[0] + v[0]):
            for c in range(m_pos[1], m_pos[1] + v[1]):
                gum = self.gum_table[r][c]
                if gum.is_group:
                    t = self._get_topleft(gum=gum)
                    if t.r != top.r or t.c != top.c:
                        if t.r != origin.r or t.c != origin.c:
                            if is_outside(
                                t,
                                m.r, m.c,
                                v
                            ):
                                key = t.r, t.c
                                if key not in sliced:
                                    sliced[key] = {'size': t.s}

        self._set_group(m, v)
        self._generate_group(sliced)

    def _open_cell_editor(self, g):
        """
        Open a cell editor GTK Dialog.

        g: ColorfulButton
            Is responsible.
        """
        self.r_c = g.key
        self.widget = g
        self.roller_win.bring_dialog(self, d={wk.R_C: g.key})

    def _set_block_face(self, start, end):
        """
        Set the appearance of a block of cells.

        start: tuple
            (r, c) for the topleft cell

        end: tuple
            (r, c) for the bottom-right cell
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self._set_cell_face(self.gum_table[r][c], start, end)

    def _set_cell_face(self, gum, start, end):
        """
        Set a cell's appearance.

        gum: Gum
            Has cell data.

        start: tuple
            (r, c) for the topleft cell

        end: tuple
            (r, c) for the bottom-right cell
        """
        if gum.s == (1, 1):
            self._set_single_looks(gum)

        else:
            # The cell is a member of a group.
            #
            # cell neighbor flags
            top = gum.r > start[0]
            bottom = gum.r < end[0]
            left = gum.c > start[1]
            right = gum.c < end[1]

            # top, bottom, left, right
            w = [PAD, PAD, PAD, PAD]

            for x, i in enumerate((top, bottom, left, right)):
                if i:
                    w[x] = 0

            gum.pad_box.set_padding(*w)
            if self._is_table:
                # button updates
                if gum.left_button:
                    g = gum.left_button

                    if left:
                        w = V_PAD[:]
                        for x, i in enumerate((top, bottom)):
                            if i:
                                w[x] = 0

                        g.pad.set_padding(*w)
                        g.set_label(" - ")
                        g.gate = 1
                    else:
                        g.set_label(" + ")
                        g.gate = 0
                        g.pad.set_padding(*V_PAD)
                if gum.top_button:
                    g = gum.top_button

                    if top:
                        w = H_PAD[:]

                        for x, i in enumerate((left, right)):
                            if i:
                                w[x + 2] = 0

                        g.pad.set_padding(*w)
                        g.set_label(" - ")
                        g.gate = 1
                    else:
                        g.set_label(" + ")
                        g.gate = 0
                        g.pad.set_padding(*H_PAD)
        if self._is_table:
            self._update_merge_cell_tooltip(gum)

    def _set_group(self, top, s):
        """
        Set sub-topleft cell attributes and the group's appearance.

        top: Gum
            for a new group

        s: tuple (w, h)
            group's new dimensions
        """
        top.s = s
        start, end = top.corners

        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                if r != top.r or c != top.c:
                    set_sub_top(top, self.gum_table[r][c])
        self._update_block(start, end)

    def _set_single_looks(self, gum):
        """
        Change the appearance of a cell's frame to appear independent.
        If the cell is changing because of a split cells
        operation, then update the cell's SwitchButtons.

        gum: Gum
            Has cell values.
        """
        gum.pad_box.set_padding(*PADDING)
        if self._split_cells:
            for g in (gum.left_button, gum.top_button):
                if g:
                    g.set_label(" + ")

                    g.gate = 0

                    if g == gum.left_button:
                        g.pad.set_padding(*V_PAD)
                    else:
                        g.pad.set_padding(*H_PAD)

    def _update_block(self, start, end):
        """
        Update the cell size and the cell appearance for a block of cells.

        start: Gum
            the topleft cell in the block

        end: Gum
            the bottom-right cell in the block
        """
        self._update_table(start, end)
        self.model.update_cell_block(start, end)
        self._set_block_face(start, end)

    def _update_merge_cell_tooltip(self, gum):
        """
        Call whenever a cell is drawn. Update the
        cell dimension Labels for merge-cell.

        gum: Gum
            Has cell data.
        """
        g, s = gum.box, gum.s
        if gum.is_topleft:
            self.model.get_merge_rect(gum.r, gum.c)
            tip = Tip.MERGE_CELL.format(
                *map(int, self.model.get_merge_rect(gum.r, gum.c))
            )
            g.set_tooltip_text(tip)
            if s != (1, 1):
                start, end = gum.corners
                for r in range(start[0], end[0] + 1):
                    for c in range(start[1], end[1] + 1):
                        if self.gum_table[r][c].box:
                            g1 = self.gum_table[r][c].box
                            if g != g1:
                                g1.set_tooltip_text("")

    def _update_table(self, start, end):
        """
        Update the size attribute for a block of cells.

        start: tuple of int
            the topleft cell in the block
            (r, c)

        end: tuple of int
            the bottom-right cell in the block
            (r, c)
        """
        for r in range(start[0], end[0] + 1):
            for c in range(start[1], end[1] + 1):
                self._per_cell_d[(r, c)] = self.gum_table[r][c].s

    def connect_left(self, gum):
        """
        Connect cells horizontally.

        gum: Gum
            Has cell data.
        """
        origin = self._get_topleft(gum=gum)
        top = self._get_topleft(u=(gum.r, gum.c - 1))
        self._merge_groups(top, origin)

    def connect_up(self, gum):
        """
        Connect cells vertically.

        gum: Gum
            Has cell data.
        """
        origin = self._get_topleft(gum=gum)
        top = self._get_topleft(u=(gum.r - 1, gum.c))
        self._merge_groups(top, origin)

    def draw(self):
        """Draw a cell table."""
        w = 1
        is_table = self._is_table
        is_not_merge = not self._is_table
        row, column = self._table_division
        table = gtk.Table(row, column)
        scroll = gtk.ScrolledWindow()
        is_1st_cell = True
        black_box = Eventful((0, 0, 0))
        black_box.add(table)
        scroll.add_with_viewport(black_box)
        self.add(scroll)
        scroll.set_policy(gtk.POLICY_AUTOMATIC, gtk.POLICY_AUTOMATIC)
        for r in range(row):
            for c in range(column):
                r1, c1 = r // 2 + 1, c // 2 + 1
                r2, c2 = r // 2 - 1, c // 2 - 1

                if r == 0:
                    if is_table or (is_not_merge and c % 2):
                        g = self._draw_column_header(c, c1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif c == 0:
                    if is_table or (is_not_merge and r % 2):
                        g = self._draw_row_header(r, r1)
                        table.attach(g, c, c + 1, r, r + 1)

                elif r % 2 and c % 2:
                    # Create the cell.
                    r3, c3 = r // 2, c // 2
                    gum = self.gum_table[r3][c3]

                    # Add Buttons to the cell attributes.
                    if r > 1:
                        gum.top_button = self._switch_button_table[r2][c3]

                    if c > 1:
                        gum.left_button = self._switch_button_table[r3][c2]

                    g = gum.pad_box = Box(align=(0, 0, 1, 1))

                    # In the Table, there are several widgets. The
                    # cell widgets are either an Eventful, not a valid cell,
                    # or a ColorfulButton, a valid cell. The ColorfulButton
                    # is given a short-cut name, 'box', in the Gum container.
                    if gum.is_topleft and is_not_merge:
                        g1 = self._make_cell_button(r3, c3)

                    elif is_table or not gum.is_cell:
                        g1 = Eventful(co.CELL_COLOR)

                        if is_not_merge and not gum.is_dependent:
                            g1.set_tooltip_text(NO_CELL)
                        elif not gum.is_cell:
                            g1.set_tooltip_text(NO_CELL)

                    else:
                        g1 = self._make_cell_button(r3, c3)

                    g2 = self.gum_table[r3][c3].box = g1

                    g.add(g1)
                    table.attach(g, c, c + 1, r, r + 1)
                    self._draw_cell(r3, c3)

                    if is_1st_cell:
                        w = self._draw_first_cell(g2)
                        is_1st_cell = False
                    g2.set_size_request(w, w)

                elif not (not r % 2 and not c % 2):
                    if is_table:
                        g, g1 = self._draw_connector(r, c)

                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)

                else:
                    if is_table:
                        # This is the square pixel space that lies
                        # at the four corners of a cell group. It
                        # is not active but serves aesthetics.
                        g = Eventful(co.CONNECTOR_COLOR)
                        g1 = gtk.HBox()

                        g.add(g1)
                        table.attach(g, c, c + 1, r, r + 1)

    def get_cell_symbol(self, r, c):
        """
        Get the symbol for a Box.

        r, c: int
            the cell index of the Box
        """
        d = self._per_cell_d[(r, c)] if (r, c) in self._per_cell_d else None
        if self.gum_table[r][c].is_cell and d:
            # Has Preset.
            return "❑"
        else:
            # All Cell, no Preset
            return "…"

    def get_a(self):
        """
        Fetch the value of a cell in the value table.

        Return: dict or None
            Preset
            Is None if the cell is an All cell.
        """
        k = r, c = self.r_c
        box = self.gum_table[r][c].box

        box.label.set_text("☍")
        return self._per_cell_d[k] if k in self._per_cell_d else None

    def get_group_value(self):
        """
        Call before doing a preview.

        Return: list
            cell table
        """
        return deepcopy(self._per_cell_d)

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return self.on_cancel_cell_table, self.on_accept_cell_table

    def on_accept_cell_table(self, *_):
        """
        Accept the changes to the cell table.

        Return: True
            The key-press is handled.
        """
        self.on_per_cell_accept(self._per_cell_d)

    def on_cancel_cell_table(self, *_):
        """
        Cancel the Port.

        Return: True
            The key-press is handled.
        """
        self.on_per_cell_cancel()

    def on_cell_editor_close(self):
        """
        Update the current cell's symbol to
        show that it's back to being inactive.
        """
        for r in range(self.division[0]):
            for c in range(self.division[1]):
                gum = self.gum_table[r][c]
                if gum.is_cell:
                    gum.box.label.set_text(
                        self.get_cell_symbol(r, c)
                    )
                    self.set_tooltip(r, c)

    def set_a(self, d, x=None):
        """
        Set the value of a cell in the value table.

        d: dict
            Preset

        x: int or None
            Plan or Work
            not used
        """
        k = r, c = self.r_c
        box = self.gum_table[r][c].box
        e = self._per_cell_d

        if d != e[k] if k in e else None:
            box.label.modify_fg(gtk.STATE_NORMAL, co.WHITE)

        if d:
            e[k] = deepcopy(d)

        elif k in e:
            e.pop(k)

        box.label.set_label(self.get_cell_symbol(r, c))
        self.set_tooltip(r, c)

    def set_active_cell(self, r, c):
        """
        Set the active cell for get and set operation.

        r, c: int
            cell index for the cell in focus
        """
        # the previous cell
        r1, c1 = self.r_c

        self.gum_table[r1][c1].box.label.set_label(
            self.get_cell_symbol(r1, c1)
        )

        self.r_c = r, c

        # the new cell
        self.gum_table[r][c].box.label.set_text("☍")

    def set_cell_array(self, d, q):
        """
        Set the value of cell from an array of cell index.

        d: dict or None
            Preset for each cell

        q: list
            of (r, c); cell index
        """
        for k in q:
            self.r_c = k
            self.set_a(d)

    def set_tooltip(self, r, c):
        """
        Set the tooltip for a cell.

        g: ColorfulButton
            Has tooltip.

        d: dict
            Preset from the cell table
        """
        d = self._per_cell_d[(r, c)] if (r, c) in self._per_cell_d else None
        g = self.gum_table[r][c].box

        if not d:
            g.set_tooltip_text(" Is main cell. ")
        else:
            g.set_tooltip_text(make_tooltip(self.group_key, d, "", 0, 0))

    def split_horz(self, gum):
        """
        The user has clicked a horizontal connector in a disconnect state.
        Divide the group containing this connector by two columns.

        gum: Gum
            Has cell data.
        """
        self._split_cells = True
        c = gum.c
        top = self._get_topleft(gum=gum)
        w = c - top.c
        w1 = top.s[1] - w
        gum1 = self.gum_table[top.r][top.c + w]

        self._set_group(gum1, (top.s[0], w1))
        self._set_group(top, (top.s[0], w))
        self._split_cells = False

    def split_vert(self, gum):
        """
        The user has clicked a vertical connector in a disconnect state.
        Divide the group containing this connector by two rows.

        gum: Gum
            Has cell data.
        """
        self._split_cells = True
        r = gum.r
        top = self._get_topleft(gum=gum)
        h = r - top.r
        h1 = top.s[0] - h
        gum1 = self.gum_table[top.r + h][top.c]

        # Create new groups from the split.
        self._set_group(gum1, (h1, top.s[1]))
        self._set_group(top, (h, top.s[1]))
        self._split_cells = False


class Gum(object):
    """Use with cell table to hold cell values."""

    def __init__(self, s, r, c, is_cell):
        """
        Create a cell storage object.

        s: tuple
            cell size
            in cells

        r, c: int
            cell index

        is_cell: flag
            Use with hexagonal.
        """
        # size of the cell in cell count
        # (w, h)
        self.s = s

        # row and column cell table indices
        self.r, self.c = r, c

        # Gum
        # If the cell is not a topleft cell,
        # then this is its topleft cell.
        self.topleft = None

        # SwitchButton on the side of the cell in
        # the merge cell Cell Table Window
        self.top_button = self.left_button = None

        # bool
        # Is true if the cell is not
        # a hexagonal cell with an invalid cell index.
        self.is_cell = is_cell

        # bool
        # Is true when the cell has an image assigned.
        self.has_pic = False

        # VBox with padding
        self.pad_box = None

        # Is an Eventful or a ColorfulButton.
        self.box = None

    @property
    def is_dependent(self):
        """
        Dependent cells are not a topleft cell,
        but part of a group of merge-cell.
        """
        return self.s == (-1, -1)

    @property
    def is_group(self):
        """Grouped cells are merge-cell."""
        return self.is_topleft or self.s == (-1, -1)

    @property
    def is_not_pic_cell(self):
        """
        Determine if the cell has an image.

        Return: bool
            Is true if the cell does not have an image.
        """
        return not self.has_pic or not self.is_cell

    @property
    def is_topleft(self):
        """
        Determine if a cell is a topleft cell.

        Return: bool
            Is true if the cell is a topleft cell.
        """
        return (self.s[0] >= 1 or self.s[1] >= 1) and self.is_cell

    @property
    def corners(self):
        """
        Return the row and column indices for a
        cell and its bottom-right cell.
        """
        s = self.r, self.c
        t = s[0] + self.s[0] - 1, s[1] + self.s[1] - 1
        return s, t
