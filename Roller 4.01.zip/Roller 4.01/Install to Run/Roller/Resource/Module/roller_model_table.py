#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import (
    Grid as gr, Shape as sh, Signal as si, Triangle as ft
)
from roller_constant_key import Model as md, Option as ok
from roller_model_grid import Grid
from roller_one import Base
import gimpfu as fu

pdb = fu.pdb


class Table(Grid):
    """
    Has a Canvas and Cell branches. Has one or more row and column.
    """
    model_type = md.TABLE

    def __init__(self, model_name):
        """
        model_name: string
            Identify the model.
        """
        Grid.__init__(self, model_name)

    def _fix_merge_cell(self, d):
        """
        Call if the Table Model is in merge cell state
        and the Cell Type has emitted a changed signal.

        The Table Model's merge cell dimensions may overflow if a
        Model's grid shrinks in size. Correct the overflow references
        by reducing the merge cell block dimensions.

        d: dict
            Cell Type PerCellGroup value
        """
        if self.is_merge_cell:
            row, column = self.division
            for r_c, a in d.items():
                r, c = r_c
                r1, c1 = a[0] + r, a[1] + c
                if r1 > row or c1 > column:
                    # overflowed Table Model's grid size
                    d[r_c] = row - r, column - c

    def calc_division(self, d):
        """
        Determine the row and column count of the cell grid.
        Call with after Canvas pocket has been calculated.

        d: dict
            Cell Type Preset
            {Option key: value}
        """
        n = d[ok.GRID_TYPE]
        w, h = self.canvas_pocket.size

        if n == gr.CELL_COUNT:
            r, c = d[ok.ROW_COUNT], d[ok.COLUMN_COUNT]

        elif n == gr.SHAPE_COUNT:
            r, c = d[ok.VERT_COUNT], d[ok.HORZ_COUNT]

        else:
            # cell size
            width = Base.seal(d[ok.COLUMN_W], 1, w)
            height = Base.seal(d[ok.ROW_H], 1, h)

            # hexagon, ellipse, rhombus, octagon-double, and triangle
            n = self.cell_shape

            if n not in sh.REGULAR:
                if n in sh.REGULAR_HEXAGON:
                    w1, h1 = width * .5, height * .75
                    w2, h2 = w - w1, h - h1
                    r, c = max(1, int(h2 / h1)), max(1, int(w2 / w1))

                elif n in sh.TRUNCATED_HEXAGON:
                    w1, h1 = width * .75, height * .5
                    w2, h2 = w - w1, h - h1
                    r, c = max(1, int(h2 / h1)), max(1, int(w2 / w1))

                elif n in ft.VERTICAL_TRIANGLE:
                    w1 = width * .5
                    w2 = w - w1
                    r, c = max(1, int(h / height)), max(1, int(w2 / w1))

                elif n in ft.HORIZONTAL_TRIANGLE:
                    h1 = height * .5
                    h2 = h - h1
                    r, c = max(1, int(h2 / h1)), max(1, int(w / width))

                elif n == sh.RHOMBUS_SHEAR:
                    w1, h1 = width * .5, height * .5
                    w2, h2 = w - w1, h - h1
                    r, c = max(1, int(h2 / h1)), max(1, int(w2 / w1))
                elif n == sh.OCTAGON_DOUBLE_SHEAR:
                    w1 = width * sh.OCTAGON_RATIO
                    h1 = height * sh.OCTAGON_RATIO
                    w2, h2 = width - w1, height - h1
                    w3, h3 = w - w1, h - h1
                    r, c = max(1, int(h3 / h2)), max(1, int(w3 / w2))
            else:
                r, c = map(int, (max(1, h // height), max(1, w // width)))

        self.division = r, c
        self.baby.emit(si.DIVISION_CHANGE, (r, c))

    def get_cell_block(self, u, v):
        """
        Use when cells are merged, and the merge
        cell's dimension needs to be determined.

        u: tuple
            (r, c) of int
            topleft cell

        v: tuple
            (r, c) of int
            bottom-right cell

        Return the topleft coordinates and the
        scale of an rectangular array of cells.
        """
        x, y = self.goo_d[u].cell.position
        x1, y1, w, h = self.goo_d[v].cell.rect
        w = x1 - x + w
        h = y1 - y + h
        return x, y, w, h

    def init_cell_q(self, d):
        """
        Create a sorted list of valid cell index,
        'cell_q' -> [(row, column), ...].

        d: dict
            Cell Type Preset
        """
        row, column = self.division

        self.update_per_cell_value(d)

        if self.cell_shape not in sh.DOUBLE:
            if self.is_merge_cell:
                # Is a merged cell dependent on a topleft cell, '(-1, -1)'.
                self.cell_q = [
                    r_c for r_c, a in d[ok.PER_CELL].items() if a != (-1, -1)
                ]
            else:
                self.cell_q = [
                    (r, c) for r in range(row) for c in range(column)
                ]

        else:
            # double-spaced cell grid
            self.cell_q = []
            is_indent = d[ok.FCI]
            for r in range(row):
                for c in range(column):
                    if is_indent:
                        if bool(
                            (r % 2 and not c % 2) or (not r % 2 and c % 2)
                        ):
                            self.cell_q += [(r, c)]
                    elif bool(
                        (r % 2 and c % 2) or (not r % 2 and not c % 2)
                    ):
                        self.cell_q += [(r, c)]
        self.cell_q.sort()

    def update_cell_block(self, u, v):
        """
        Update the merge cell size for a cell block.

        u: tuple
            cell index of the topleft cell of the block

        v: tuple
            cell index of the bottom-right cell of the block
        """
        self.goo_d[u].merged.rect = self.get_cell_block(u, v)

    def update_per_cell_value(self, d):
        """
        Check the merge cell value dict.

        d: dict
            Cell Type Preset
            {Option key: value}
        """
        e = d[ok.PER_CELL]
        if self.is_merge_cell:
            # Add missing cell. Remove extraneous cell.
            row, column = self.division
            cell_q = {(r, c) for r in range(row) for c in range(column)}
            keys = set(e.keys())

            # Add.
            for r_c in cell_q:
                if r_c not in keys:
                    e[r_c] = 1, 1

            # Remove.
            for r_c in keys:
                if r_c not in cell_q:
                    e.pop(r_c)

    def update_type(self, arg):
        """
        Update Cell Type dependency.

        arg: tuple
            (Cell Type Preset, is sequence flag)
            {Option key: value}
            If True, then a chained-sequence is processed immediately.
        """
        def _get_cell_shape():
            """
            Get the cell shape according the cell type.

            Return: string
                cell shape descriptor
            """
            if d[ok.GRID_TYPE] == gr.SHAPE_COUNT:
                return d[ok.ECS]
            return d[ok.CELL_SHAPE]

        d, is_sequence = arg
        p = self.baby.feed if is_sequence else self.baby.give
        self.cell_shape = _get_cell_shape()
        self.is_merge_cell = self.what_is_merge_cell(d)
        vote_d = super(Table, self).update_type(arg)

        self._fix_merge_cell(d[ok.PER_CELL])

        if self.is_merge_cell:
            vote_d = {}
            per_cell = d[ok.PER_CELL]
            for r_c in self.cell_q:
                # Goo, 'a'
                a = self.goo_d[r_c]

                s = per_cell[r_c]

                if s == (1, 1):
                    a.merged.rect = a.cell.rect

                elif s != (-1, -1):
                    # Is a topleft merged cell.
                    r, c = r_c
                    x, y, w, h = a.merged.rect = self.get_cell_block(
                        r_c, (r + s[0] - 1, c + s[1] - 1)
                    )
                    a.plaque = x, y, x + w, y, x + w, y + h, x, y + h
                vote_d[r_c] = self.past.did_merged(r_c)

        self.adapt_missing_cell_step(is_sequence)
        p(si.CELL_RECT_CALC, vote_d)

    def what_is_merge_cell(self, d):
        """
        Determine if the Cell Type is in a merge cell state.
        A merge cell state occurs when the Per Cell CheckButton
        is checked in the Cell Type options.

        d: dict
            Cell Type Preset
            {Option key: value}

        Return: bool
            Is true if the Cell Type option group is in merge cell mode.
        """
        if (
            self.cell_shape == sh.RECTANGLE and
            d[ok.GRID_TYPE] == gr.CELL_COUNT and
            (self.division[0] > 1 or self.division[1] > 1)
        ):
            if ok.PER_CELL in d:
                return True if d[ok.PER_CELL] else False
            return False
        return False
