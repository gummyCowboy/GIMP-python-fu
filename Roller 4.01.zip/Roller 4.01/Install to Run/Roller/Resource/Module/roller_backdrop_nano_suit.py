#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one_fu import Lay
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_one_gegl import Gegl
from roller_view_real import add_sub_base_group, finish_style, insert_copy
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make the Backdrop Style.

    v: View
    maya: NanoSuit
    Return: layer
        with style material
    """
    parent = add_sub_base_group(v, maya)
    z = insert_copy(v, parent, parent)
    group = Lay.group(v.j, "WIP", parent=parent, z=z)

    Lay.blur(z, 500)
    Gegl.video_degradation(z, 'dots')

    z = Lay.clone(z, n="Difference")
    z.mode = fu.LAYER_MODE_DIFFERENCE

    Gegl.engrave(z, 3)
    pdb.gimp_drawable_curves_spline(z, fu.HISTOGRAM_VALUE, 4, (.0, .5, 1., 1.))

    z = Lay.merge_group(group)

    if maya.value_d[ok.INVERT]:
        pdb.gimp_drawable_invert(z, 0)
    return finish_style(Lay.merge_group(parent), "Nano Suit")


class NanoSuit(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        Style.__init__(self, *q + (make_style,), **d)
