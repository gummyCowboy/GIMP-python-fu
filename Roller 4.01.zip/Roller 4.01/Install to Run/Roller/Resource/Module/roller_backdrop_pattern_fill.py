#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_view_real import finish_style, insert_copy
from roller_view_hub import (
    get_canvas_points, set_fill_context, set_gimp_pattern
)
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make the Backdrop Style.

    v: View
    maya: PatternFill
    Return: layer
        with the style material
    """
    d = maya.value_d
    parent = maya.group
    z = insert_copy(v, parent, parent)

    # fill point, 'x, y'
    x, y = get_canvas_points(d)[:2]

    set_fill_context(d)
    set_gimp_pattern(d[ok.PBR][ok.PATTERN])
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, x, y)

    if d[ok.INVERT]:
        # no linear, '0'
        pdb.gimp_drawable_invert(z, 0)
    return finish_style(z, "Pattern Fill")


class PatternFill(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.PBR
    is_dependent = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        k_path = d['k_path']
        d['k_path'] = [k_path, k_path + (ok.PBR,)]
        Style.__init__(self, *q + (make_style,), **d)
