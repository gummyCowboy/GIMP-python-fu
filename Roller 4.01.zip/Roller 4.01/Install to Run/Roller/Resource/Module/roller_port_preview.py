#!/usr/bin/env python
# -*- coding: utf-8 -*-
from copy import deepcopy
from roller_constant_key import Widget as wk
from roller_port_process import PortProcess


class PortPreview(PortProcess):
    """
    Make a View possible in a dialog. Respond and handle the dialog's
    Button response for Accept, Cancel, Preview, and Plan.
    """

    def __init__(self, d, g):
        """
        d: dict
            Has init values.

        g: object
            an OptionButton or Glue
            Is referred to as 'safe'.
        """
        self.view_x = None
        self.accept_callback = d[wk.ON_ACCEPT] if wk.ON_ACCEPT in d \
            else self.set_safe_value
        self.cancel_callback = d[wk.ON_CANCEL] if wk.ON_CANCEL in d \
            else None
        self.preview_button = self.plan_button = None
        self._original_value = deepcopy(g.get_a())
        PortProcess.__init__(self, d, g)

    def get_hook(self):
        """
        Fetch the Port's cancel and accept responders.

        Return: tuple
            (function, function) -> (cancel hook, accept hook)
        """
        return self.on_cancel_port_preview, self.on_accept_port_preview

    def on_accept_port_preview(self, *_):
        """
        Respond to an Accept action from the Port.
        Set the option group as changed if that is the case.
        """
        self.accept_callback(self.get_group_value())

    def on_cancel_port_preview(self):
        """Respond to a cancel action from the Window."""
        self.view_x = None
        self.safe.set_a(self._original_value)
        if self.cancel_callback:
            self.cancel_callback()

    def set_safe_value(self, a):
        """
        Get the value from the dialog in order to set the OptionButton's value.

        a: value
            for the OptionButton
        """
        self.view_x = None
        self.safe.set_a(a)
