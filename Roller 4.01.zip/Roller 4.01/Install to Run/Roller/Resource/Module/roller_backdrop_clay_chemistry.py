#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import BackdropStyle as by, Option as ok
from roller_def import get_default_value
from roller_maya_style import Style
from roller_one_fu import Lay, Sel
from roller_one_gegl import Gegl
from roller_view_real import (
    add_sub_base_group,
    add_wip_layer,
    clone_background,
    do_gradient_for_layer,
    finish_style,
    insert_copy
)
from roller_view_hub import get_gradient_factors
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make a style layer.

    v: View
        Has scope variable.

    maya: Style
    Return: layer or None
        style layer
    """
    j = v.j
    d = maya.value_d
    parent = add_sub_base_group(v, maya)
    z = clone_background(v, parent)
    backdrop_z = Lay.clone(z)
    group = Lay.group(j, "WIP", parent=parent, z=z)
    z1 = Lay.clone(z)

    Lay.blur(z, 500)

    z1.name = "HSV Hue"
    z1.mode = fu.LAYER_MODE_HSV_HUE

    pdb.plug_in_gimpressionist(j, z1, "Painted_Rock")

    z = insert_copy(v, group,  z1)
    z.mode = fu.LAYER_MODE_DIFFERENCE

    Gegl.edge(z)

    z = insert_copy(v, group, z)
    z.mode = fu.LAYER_MODE_EXCLUSION

    Sel.rect(j, *v.wip.rect)
    Lay.dilate(z)
    Gegl.waterpixels(z)
    Gegl.unsharp_mask(z, 3., 30., .0)

    z = insert_copy(v, group, z)
    z = Lay.clone(z, n="Linear Light")
    z.mode = fu.LAYER_MODE_LINEAR_LIGHT

    Lay.blur(z, 12)

    z = insert_copy(v, group, z)

    Lay.dilate(z)
    Lay.dilate(z)

    z.mode = fu.LAYER_MODE_GRAIN_EXTRACT
    z1 = Lay.merge_group(group)
    group = Lay.group(j, "WIP", parent=parent, z=z1)
    z2 = Lay.clone(z1, n="Luma Lighten Only")

    Gegl.waterpixels(z2)

    z2.mode = fu.LAYER_MODE_LUMA_LIGHTEN_ONLY
    z2 = Lay.merge(z2)
    z3 = Lay.clone(z2, n="Median Blur")

    Gegl.median_blur(z3, 32, 50.)

    z4 = Lay.clone(z3, n="Pin Light")
    z4.mode = fu.LAYER_MODE_PIN_LIGHT

    Gegl.edge(z4)
    pdb.plug_in_erode(
        j, z4,
        1,                              # propagate black
        7,                              # RGB channels
        1.,                             # full rate
        7,                              # direction mask
        0,                              # low limit
        255                             # upper limit
    )

    z = insert_copy(v, group, z4)
    z2.mode = fu.LAYER_MODE_OVERLAY

    pdb.plug_in_colortoalpha(j, z, (0, 0, 0))
    Gegl.emboss(z2, v.glow_ball.azimuth, 12., 1.)
    Lay.hide(z3)
    Lay.hide(z4)

    e = get_default_value(by.GRADIENT_FILL)

    e[ok.GRADIENT] = d[ok.GBR][ok.GRADIENT]
    e[ok.START_X], e[ok.END_X], e[ok.START_Y], e[ok.END_Y] = \
        get_gradient_factors(d[ok.GRADIENT_ANGLE])

    e.update(d)

    z1 = do_gradient_for_layer(v, e, group, len(group.layers) - 1)
    z1.opacity = 50.

    z = add_wip_layer(
        v, maya, "Back", group=group, offset=len(group.layers) + 1
    )
    z.opacity = z1.opacity

    Lay.color_fill(z, (64, 64, 64))
    Lay.blur(backdrop_z, 500)
    pdb.gimp_image_reorder_item(j, backdrop_z, group, len(group.layers) + 1)
    return finish_style(Lay.merge_group(parent), "Clay Chemistry")


class ClayChemistry(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.GBR
    is_dependent = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        k_path = d['k_path']
        d['k_path'] = [k_path, k_path + (ok.GBR,)]
        Style.__init__(self, *q + (make_style,), **d)
