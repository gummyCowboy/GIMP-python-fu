#!/usr/bin/env python
# -*- coding: utf-8 -*-
from random import choice, randint
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_one_extract import combine_seed
from roller_one_fu import Lay, Sel
from roller_view_real import (
    add_sub_base_group, add_wip_layer, finish_style, insert_copy_above
)
from roller_view_hub import adjust_mean_value
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make the Backdrop Style.

    v: View
    maya: NoiseRift
    Return: layer
        with the style material
    """
    def _add_noise():
        """Create noise."""
        _m = True

        if ok.NOISE_OPACITY in d:
            if not d[ok.NOISE_OPACITY]:
                _m = False
        if _m:
            # Generate the lines.
            # The horizontal and vertical sizes are randomized.
            pdb.plug_in_solid_noise(
                j, z,
                0,                      # no tile-able
                1,                      # yes, turbulent
                d[ok.SEED] + v.glow_ball.seed,
                d[ok.NOISE_AMOUNT],
                float(randint(1, 3)),
                float(randint(1, 3)),
            )

            # Harden the noise.
            # The radius is randomized.
            pdb.plug_in_unsharp_mask(
                j, z,
                choice((1., 3.)),
                54.,                    # amount
                .0                      # threshold
            )

            # Remove the white noise.
            Sel.item(z)
            Sel.invert_clear(z)
            pdb.plug_in_colortoalpha(j, z, (255, 255, 255))

            if d[ok.BLUR]:
                Sel.rect(v.j, *v.wip.rect)
                Lay.blur(z, d[ok.BLUR])

    j = v.j
    d = maya.value_d
    parent = add_sub_base_group(v, maya)
    group = Lay.group(j, "WIP", parent=parent)

    combine_seed(v, d)

    if d[ok.IPR][ok.USE_PLASMA]:
        z = add_wip_layer(v, maya, "Plasma", group=group)

        # lowest turbulence, '1.'
        pdb.plug_in_plasma(j, z, d[ok.SEED], 1.)

        Lay.blur(z, 500)
        z = Lay.clone(z, n="Noise")

    else:
        z = insert_copy_above(v, parent.layers[0], parent.layers[0])

        pdb.gimp_image_reorder_item(j, z, group, 0)
        adjust_mean_value(z)

    _add_noise()

    if d[ok.IPR][ok.INVERT]:
        pdb.gimp_drawable_invert(z, 0)
    return finish_style(Lay.merge_group(parent), "Noise Rift")


class NoiseRift(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_seeded = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        k_path = d['k_path']
        d['k_path'] = [k_path, k_path + (ok.IPR,)]
        Style.__init__(self, *q + (make_style,), **d)

    def do(self, v, d, is_change):
        """
        Manage style output layer.

        v: View
        d: dict
            NoiseRift Preset
            {Option key: value}

        is_change: bool
            If True, then Backdrop Image Maya has material or mask change.
        """
        self.is_dependent = d[ok.IPR][ok.USE_PLASMA]
        super(NoiseRift, self).do(v, d, is_change)
