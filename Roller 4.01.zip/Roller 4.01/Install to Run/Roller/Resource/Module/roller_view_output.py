#!/usr/bin/env python
# -*- coding: utf-8 -*-
import gimpfu as fu

pdb = fu.pdb


class Output:
    """Is factored from Work and Plan."""

    def __init__(self):
        """
        Initialize common variables.
        """
        self.plan_group = self.backdrop_layer = None
