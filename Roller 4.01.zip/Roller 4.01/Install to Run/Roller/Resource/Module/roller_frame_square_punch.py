#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Gradient as fg
from roller_constant_key import Option as ok
from roller_frame import Metal, do_soft_metal_material
from roller_one_fu import Lay, Mage, Sel
from roller_view_hub import set_fill_context
import gimpfu as fu

pdb = fu.pdb


def make_pattern(z, d):
    """
    Draw a rectangle on a rotated layer. Create a pattern
    (a black square). Use the clipboard to hold the
    pattern. Fill the provided layer with the pattern.

    z: layer
        to receive pattern

    d: dict
        Square Punch Preset
        {Option key: value}

    Return: layer
        with the pattern
    """
    side = d[ok.GAP_W]
    w = side + d[ok.LINE_W]
    j1 = pdb.gimp_image_new(w, w, fu.RGB)
    z1 = Lay.add(j1, "Pattern")

    Lay.color_fill(z1, (255, 255, 255))

    # A rectangle at the center of 'z1' will become a hole in the pattern.
    x = (w - side) // 2
    y = (w - side) // 2

    Sel.rect(j1, x, y, w, w)
    Sel.fill(z1, (0, 0, 0))

    # Set the Clipboard Image.
    Mage.copy_all(j1)

    pdb.gimp_image_delete(j1)
    set_fill_context(fg.FILL_DICT)
    pdb.gimp_context_set_pattern("Clipboard Image")

    # x, y screen coordinate, '0'
    pdb.gimp_drawable_edit_bucket_fill(z, fu.FILL_PATTERN, 0, 0)

    pdb.plug_in_colortoalpha(z.image, z, (0, 0, 0))
    return z


def do_matter(v, maya):
    """
    Make a border around material.

    v: View
    maya: SquarePunch
    Return: layer
        with the frame
    """
    return do_soft_metal_material(v, maya, make_pattern, "Square Punch")


class SquarePunch(Metal):
    """Is a metallic frame with rectangular holes."""

    def __init__(self, *q, **d):
        """
        q: tuple
            Metal spec

        d: dict
            Metal spec
        """
        Metal.__init__(self, *q + (do_matter,), **d)
