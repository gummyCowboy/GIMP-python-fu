#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_one import Rect


class Goo(object):
    """Is a container for Cell property."""

    def __init__(self, r_c):
        """
        Is a cell attribute object.

        r, c: int
            cell index
        """
        # row and column cell key
        self.r_c = r_c

        # Rect
        # Is the original cell rectangle, before a merge.
        self.cell = Rect()

        # Rect
        # Use to store cell size which may be a block of cell.
        self.merged = Rect()

        # tuple
        # Is the Cell polygon shape without margin.
        self.plaque = None

        # Rect
        # Is the cell rectangle within margin.
        self.pocket = Rect()

        # tuple
        # Is the cell polygon shape within margin.
        self.shape = None

        # Rect
        # Is the merged rectangle after it has shifted.
        self.shift = Rect()


class Mesh(Goo):
    """Use with the Box Model for Face attribute."""

    def __init__(self, r_c):
        Goo.__init__(self, r_c)

        # Define the face transform output with four points
        # (topleft, top-right, bottom-left, bottom-right).
        self.foam = ()

        # Function
        # Call to transform a mold rectangle into foam.
        self.transform = None
