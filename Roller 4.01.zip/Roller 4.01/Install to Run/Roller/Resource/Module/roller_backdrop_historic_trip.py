#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_maya_style import Style
from roller_one_fu import Lay
from roller_one_gegl import Gegl
from roller_view_real import (
    add_sub_base_group, finish_style, insert_copy, insert_copy_above
)
from roller_view_hub import get_average_color
import gimpfu as fu

pdb = fu.pdb


def make_style(v, maya):
    """
    Make the Backdrop Style.

    v: View
    maya: HistoricTrip
    Return: layer or None
        with backdrop style material
    """
    def _merge(_z, _n):
        """
        Merge a group and set its layer mode.

        _z: layer group
            to merge

        _n: string
            version number

        return: layer
            Is the result of the merge.
        """
        _z = Lay.merge_group(_z)
        _z.mode = fu.LAYER_MODE_GRAIN_MERGE
        _z.name = "Grain Merge " + _n
        pdb.plug_in_colortoalpha(j, _z, (0, 0, 0))
        return _z

    j = v.j
    d = maya.value_d
    parent = add_sub_base_group(v, maya)
    key = maya.any_group.item.key
    z = insert_copy(v, parent, parent)
    bg_1 = Lay.clone(z, n="Original #1")
    bg_2 = Lay.clone(z, n="Original #3")
    group = Lay.group(v.j, "WIP", parent=parent, z=z)
    group1 = Lay.group(j, key + " WIP #2", parent=group, z=bg_1)
    z2 = Lay.clone(bg_1, n="Difference #1")
    z2.mode = fu.LAYER_MODE_DIFFERENCE
    color = get_average_color(z)

    for _ in range(d[ok.ITERATIONS]):
        Gegl.spread(
            z2,
            0,
            amount_x=d[ok.SPREAD],
            amount_y=min(6, d[ok.SPREAD])
        )

    group2 = Lay.group(j, "Sub-Group", parent=group, z=bg_2)
    z2 = Lay.clone(bg_2, n="Difference #2")
    z2.mode = fu.LAYER_MODE_DIFFERENCE

    for _ in range(d[ok.ITERATIONS]):
        Gegl.spread(
            z2,
            0,
            amount_x=min(6, d[ok.SPREAD]),
            amount_y=d[ok.SPREAD]
        )

    Lay.color_fill(z, color)

    z1 = _merge(group1, "#1")
    z2 = _merge(group2, "#2")
    z = insert_copy_above(v, z2, parent.layers[0])

    dissolve_z = Lay.clone(z, n="Dissolve")
    z.mode = fu.LAYER_MODE_HSV_VALUE

    Gegl.emboss(z1, v.glow_ball.azimuth, 12, 1)
    Gegl.emboss(z2, v.glow_ball.azimuth, 12, 1)
    Gegl.waterpixels(z, size=d[ok.SUPERPIXEL_SIZE])
    dissolve_z.mode = fu.LAYER_MODE_DISSOLVE
    dissolve_z.opacity = 50.
    Lay.blur(dissolve_z, 1)

    z = insert_copy_above(v, dissolve_z, parent.layers[0])

    Gegl.saturation(z, d[ok.SATURATION])
    Lay.merge_group(group)

    z = Lay.merge_group(parent, n="Despeckle")

    pdb.plug_in_despeckle(
        j, z,
        1,                  # radius
        0,
        -1,                 # black cut-off
        256                 # white cut-off
    )
    return finish_style(z, "Historic Trip")


class HistoricTrip(Style):
    """Create Backdrop Style output."""
    bump_row_k = ok.BRR
    is_dependent = True

    def __init__(self, *q, **d):
        """
        q: tuple
            Style spec

        d: dict
            Style spec
        """
        Style.__init__(self, *q + (make_style,), **d)
