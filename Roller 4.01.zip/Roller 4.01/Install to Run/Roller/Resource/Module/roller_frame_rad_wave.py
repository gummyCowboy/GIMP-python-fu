#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_key import Option as ok
from roller_frame import Metal, make_canvas_frame_sel, soften_metal_sel
from roller_one_fu import Lay, Sel
from roller_one_rect_table import RectTable
import gimpfu as fu

pdb = fu.pdb


def do_matter(v, maya):
    """
    Make the frame.

    v: View
    maya: RadWave
    Return: layer
        with the Frame
    """
    def _add():
        """Add a layer to the bottom the Maya group."""
        return Lay.add(
            j,
            group.name + " Raised Maze",
            parent=group,
            offset=len(group.layers)
        )

    j = v.j
    d = maya.value_d
    e = d[ok.FNR][ok.FRAME_METAL]
    group = maya.group
    cause = maya.cause.matter

    # layer for the wire, 'z'
    z = _add()

    sel = make_canvas_frame_sel(v, d)

    Sel.border(j, cause, e[ok.FRAME_W], e[ok.FRAME_TYPE])

    sel1 = pdb.gimp_selection_save(j)

    pdb.gimp_selection_none(j)

    x, y, w, h = v.wip.rect
    width, height = v.view_size
    w1 = d[ok.LINE_W]

    if d[ok.LINE_W]:
        grid = RectTable((x, y, w, h), d[ok.ROW], d[ok.COLUMN]).table

        for r in range(1, d[ok.ROW]):
            Sel.rect(j, 0, grid[r][0].y, width, w1, option=fu.CHANNEL_OP_ADD)
        for c in range(1, d[ok.COLUMN]):
            Sel.rect(j, grid[0][c].x, 0, w1, height, option=fu.CHANNEL_OP_ADD)

    Sel.fill(z, (0, 0, 0))
    pdb.gimp_selection_none(j)
    pdb.plug_in_waves(j, z, d[ok.WAVE_AMPLITUDE], 1, d[ok.WAVELENGTH], 0, 1)
    pdb.gimp_selection_none(j)
    pdb.plug_in_whirl_pinch(j, z, d[ok.WHIRL], 0, 2.)
    Sel.item(z)
    pdb.gimp_image_remove_layer(j, z)

    # layer for the combined frame, 'z'
    z = _add()

    for i in (sel, sel1):
        if i:
            Sel.load(j, i, option=fu.CHANNEL_OP_ADD)
            pdb.gimp_image_remove_channel(j, i)

    Sel.opaque(cause, option=fu.CHANNEL_OP_SUBTRACT)
    Sel.rect(v.j, *v.wip.rect, option=fu.CHANNEL_OP_INTERSECT)
    return soften_metal_sel(v, z, e)


class RadWave(Metal):
    """Is a metallic frame with wavy wire filling the canvas."""

    def __init__(self, *q, **d):
        """
        Prepare the sub-maya.

        q: tuple
            Metal spec

        d: dict
            Metal spec
        """
        Metal.__init__(self, *q + (do_matter,), **d)
