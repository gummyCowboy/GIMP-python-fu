#!/usr/bin/env python
# -*- coding: utf-8 -*-
from roller_constant_for import Deco as dc, Plan as fy
from roller_constant_key import Node as ny, Option as ok
from roller_deco import (
    finish_backed,
    make_deco_material,
    paint,
    prep_backed,
    ready_canvas_rect,
    ready_shape,
    test_image,
    transform_foam
)
from roller_one_fu import Lay, Sel
from roller_view_real import add_base_layer, make_group
import gimpfu as fu

PLAN_COLOR_D = {
    ny.CELL: fy.CELL_FRINGE_COLOR,
    ny.CANVAS: fy.CANVAS_FRINGE_COLOR,
    ny.FACE: fy.FACE_FRINGE_COLOR
}
pdb = fu.pdb


def do(v, maya, make):
    """
    Make Fringe material. If Plan is active, it
    makes temporary adjustment to the option settings.

    v: View
    maya: Maya
    make: function
        Call to create Fringe layer.

    Return: layer or None
        matter
    """
    d = maya.value_d

    if not v.x:
        # Preserve.
        type_deco = d[ok.TYPE_DECO]
        mode = d[ok.MODE]
        color = d[ok.COLOR_1]

        # Plan override.
        d[ok.TYPE_DECO] = dc.COLOR
        d[ok.MODE] = "Normal"
        d[ok.COLOR_1] = PLAN_COLOR_D[maya.any_group.render_key[-2]]

    v.deco.type_ = d[ok.TYPE_DECO]
    z = make(v, maya)

    if not v.x:
        # Restore.
        d[ok.TYPE_DECO] = type_deco
        d[ok.MODE] = mode
        d[ok.COLOR_1] = color
        if z:
            z.opacity = 66.
    return z


def do_canvas(v, maya):
    """
    Make Fringe for the Canvas branch.

    v: View
    maya: Maya
    Return: layer or None
        matter
    """
    return do(v, maya, make_canvas_material)


def do_cell(v, maya):
    """
    Make Fringe for Per Cell.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_material)


def do_face(v, maya):
    """
    Draw Per Cell Face Fringe.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_cell_face_material)


def do_main_cell(v, maya):
    """
    Make Cell branch Fringe for main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_material)


def make_canvas_material(v, maya):
    """
    Draw Canvas Fringe material.

    v: View
    maya: Maya
    Return: layer or None
        with Fringe material
    """
    if test_image(v, maya):
        group = maya.group

        prep_backed(v, maya, group)
        ready_canvas_rect(v, maya)

        z = paint_fringe(v, maya, group)

        finish_backed(v)
        return z


def make_cell_face_material(v, maya):
    """
    Make Fringe for Per Cell Face.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    parent = maya.group
    group = make_group(v, "Material", parent, offset=len(parent.layers))

    prep_backed(v, maya, group)
    make_face_material(v, maya, group)
    finish_backed(v)
    return Lay.verify_group(group)


def make_cell_material(v, maya):
    """
    Make Fringe for Per Cell.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    if test_image(v, maya):
        group = maya.group

        prep_backed(v, maya, group)
        ready_shape(v, maya)

        z = paint_fringe(v, maya, maya.group)

        finish_backed(v)
        return z


def make_face_material(v, maya, group):
    """
    Create Face material.

    v: View
    maya: Maya
    group: layer
        Is the destination parent layer of Face output.
    """
    r, c = maya.r_c
    model = maya.model
    if v.deco.type_ == dc.IMAGE:
        face_image_q = maya.get_image((r, c))

    # three faces, '3'
    for face_x in range(3):
        arg = r, c, face_x
        go = True

        if v.deco.type_ == dc.IMAGE:
            go = v.deco.image = face_image_q[face_x]
        if go:
            maya.rect = model.get_face_rect(*arg)
            v.deco.shape = model.get_face_shape(*arg)
            z = paint_fringe(v, maya, group)
            if z:
                transform_foam(v, maya.rect, z, model.get_face_foam(*arg))


def do_main_face(v, maya):
    """
    Draw Fringe Face for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    return do(v, maya, make_main_face_material)


def make_main_face_material(v, maya):
    """
    Create Fringe material for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    parent = maya.group
    group = make_group(v, "Material", parent, offset=len(parent.layers))

    prep_backed(v, maya, group)

    for r, c in maya.main_cell_q:
        maya.r_c = r, c
        make_face_material(v, maya, group)

    finish_backed(v)
    return Lay.verify_group(group)


def make_main_material(v, maya):
    """
    Create Cell branch Fringe for the main option settings.

    v: View
    maya: Maya
    Return: layer or None
        with material
    """
    def _do_average_color():
        _j = v.j
        _d = maya.value_d

        prep_backed(v, maya, group)

        for _r, _c in maya.main_cell_q:
            maya.r_c = _r, _c
            _z = Lay.add_above(v.deco.bg_z, "{}, {}".format(_r, _c))

            ready_shape(v, maya)
            paint(v, _z, _d)
            Sel.item(_z)
            pdb.gimp_image_remove_layer(_j, _z)
            make_deco_material(v, maya, group)

        finish_backed(v)
        return Lay.verify_group(group)

    def _do_many_material():
        """
        The cells have the same Fringe material, but
        the material has to be applied cell-by-cell.
        """
        for _r, _c in maya.main_cell_q:
            maya.r_c = _r, _c
            if test_image(v, maya):
                ready_shape(v, maya)
                paint_fringe(v, maya, group)
        return Lay.verify_group(group)

    def _do_one_material():
        """
        The cells have the same Fringe material,
        so the output is combined on one layer.
        """
        for _r, _c in maya.main_cell_q:
            _z = add_base_layer(v, group)
            maya.r_c = _r, _c

            ready_shape(v, maya)
            paint(v, _z, maya.value_d)

        _z = Lay.verify_group(group)
        prep_backed(v, maya, group, z=_z)

        if _z:
            Sel.item(_z)
            _z = paint_fringe(v, maya, parent, z=_z)

        finish_backed(v)
        return _z

    parent = maya.group
    group = make_group(v, "Material", parent, offset=len(parent.layers))

    if v.deco.type_ == dc.AVERAGE_COLOR:
        return _do_average_color()

    elif v.deco.type_ not in dc.PER_CELL_TYPE:
        # All the Fringe is the same
        # material and is applied one time.
        return _do_one_material()
    else:
        return _do_many_material()


def paint_fringe(v, maya, group, z=None):
    """
    Paint Fringe and apply material.

    v: View
    maya: Maya
    group: layer
        Is the destination parent of Fringe output.

    z: layer
        The layer has Fringe material.

    Return: layer
        with Fringe material
    """
    j = v.j
    d = maya.value_d

    if not z:
        z = add_base_layer(v, group, n="Material")

        Sel.shape(j, v.deco.shape)
        paint(v, z, d)

    n = z.name

    Sel.item(z)

    if v.deco.type_ not in (dc.AS_IS, dc.MULTI_COLOR):
        pdb.gimp_image_remove_layer(v.j, z)

        z = make_deco_material(v, maya, group)
        if z:
            z.name = n
    return z
